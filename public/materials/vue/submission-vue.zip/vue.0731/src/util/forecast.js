import { cityDateKey, formatCityHour, formatCityTime, formatCityWeekday } from './format'

/**
 * @description 시간별 예보 스트립 데이터.
 * 맨 앞에 현재 날씨("지금")를 넣고, 일몰 시각이 구간 안에 있으면 그 자리에 일몰 항목을 끼워 넣는다.
 */
export function buildHourlyItems(forecastList, { timezone = 0, sunset, current, limit = 9 } = {}) {
  const items = []

  if (current) {
    items.push({
      key: 'now',
      label: '지금',
      icon: current.icon,
      temp: current.temp,
    })
  }

  ;(forecastList ?? []).slice(0, limit).forEach((entry) => {
    items.push({
      key: `h-${entry.dt}`,
      label: formatCityHour(entry.dt, timezone),
      icon: entry.weather?.[0]?.icon,
      temp: entry.main?.temp,
    })
  })

  if (!sunset) return items

  const lastDt = forecastList?.[Math.min(limit, forecastList.length) - 1]?.dt
  if (!lastDt || sunset > lastDt) return items

  const sunsetItem = {
    key: 'sunset',
    label: formatCityTime(sunset, timezone),
    icon: 'sunset',
    note: '일몰',
  }
  const insertAt = items.findIndex(
    (item) => item.key.startsWith('h-') && Number(item.key.slice(2)) > sunset,
  )

  if (insertAt === -1) items.push(sunsetItem)
  else items.splice(insertAt, 0, sunsetItem)

  return items
}

/**
 * @description 3시간 단위 예보를 현지 날짜 기준으로 묶어 일별 최저/최고 예보를 만든다.
 */
export function buildDailyItems(forecastList, timezone = 0) {
  const buckets = new Map()

  ;(forecastList ?? []).forEach((entry) => {
    const key = cityDateKey(entry.dt, timezone)
    const bucket = buckets.get(key) ?? {
      key,
      dt: entry.dt,
      min: Number.POSITIVE_INFINITY,
      max: Number.NEGATIVE_INFINITY,
      pop: 0,
      slots: [],
    }

    bucket.min = Math.min(bucket.min, entry.main?.temp_min ?? entry.main?.temp)
    bucket.max = Math.max(bucket.max, entry.main?.temp_max ?? entry.main?.temp)
    bucket.pop = Math.max(bucket.pop, entry.pop ?? 0)
    bucket.slots.push({ dt: entry.dt, icon: entry.weather?.[0]?.icon })

    buckets.set(key, bucket)
  })

  const days = [...buckets.values()]

  return days.map((day, index) => ({
    key: day.key,
    label: index === 0 ? '오늘' : formatCityWeekday(day.dt, timezone),
    icon: pickDayIcon(day.slots, timezone),
    min: day.min,
    max: day.max,
    pop: day.pop,
  }))
}

/**
 * @description 하루를 대표하는 아이콘: 정오에 가장 가까운 낮 아이콘을 우선 사용한다.
 */
function pickDayIcon(slots, timezone) {
  const daySlots = slots.filter((slot) => slot.icon?.endsWith('d'))
  const candidates = daySlots.length > 0 ? daySlots : slots

  const closest = candidates.reduce((best, slot) => {
    const hour = new Date((slot.dt + timezone) * 1000).getUTCHours()
    const distance = Math.abs(hour - 12)
    return !best || distance < best.distance ? { slot, distance } : best
  }, null)

  return closest?.slot.icon
}
