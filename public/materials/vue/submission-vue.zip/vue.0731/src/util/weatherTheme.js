const WEATHER_ICONS = {
  맑음: '☀️',
  비: '🌧️',
  온흐림: '☁️',
  눈: '❄️',
}

const ICON_GLYPHS = {
  '01d': '☀️',
  '01n': '🌙',
  '02d': '🌤️',
  '02n': '☁️',
  '03d': '⛅',
  '03n': '☁️',
  '04d': '☁️',
  '04n': '☁️',
  '09d': '🌧️',
  '09n': '🌧️',
  '10d': '🌦️',
  '10n': '🌧️',
  '11d': '⛈️',
  '11n': '⛈️',
  '13d': '🌨️',
  '13n': '🌨️',
  '50d': '🌫️',
  '50n': '🌫️',
  sunset: '🌇',
}

const WEATHER_GRADIENTS = {
  맑음: 'linear-gradient(165deg, #5ab2f2 0%, #2a75c9 55%, #133e73 100%)',
  비: 'linear-gradient(165deg, #7c8898 0%, #4d5763 55%, #262d36 100%)',
  온흐림: 'linear-gradient(165deg, #97a4b3 0%, #616c79 55%, #333b45 100%)',
  눈: 'linear-gradient(165deg, #aecbe3 0%, #7099ba 55%, #3f5b78 100%)',
}

const CARD_SKIES = {
  clearDay: [
    'radial-gradient(120% 90% at 88% -25%, rgba(255, 255, 255, 0.6), transparent 55%)',
    'radial-gradient(80% 70% at 6% 120%, rgba(255, 255, 255, 0.24), transparent 62%)',
    'linear-gradient(180deg, #54b6f2 0%, #2f96e0 50%, #2179c9 100%)',
  ],
  clearNight: [
    'radial-gradient(110% 85% at 82% -20%, rgba(126, 173, 255, 0.38), transparent 58%)',
    'linear-gradient(180deg, #2a3d68 0%, #1d2a4d 55%, #141c34 100%)',
  ],
  cloudsDay: [
    'radial-gradient(66% 78% at 16% 122%, rgba(255, 255, 255, 0.62), transparent 60%)',
    'radial-gradient(56% 66% at 74% 130%, rgba(255, 255, 255, 0.48), transparent 60%)',
    'radial-gradient(120% 80% at 92% -25%, rgba(255, 255, 255, 0.34), transparent 58%)',
    'linear-gradient(180deg, #83abd2 0%, #7095bd 55%, #6486ad 100%)',
  ],
  cloudsNight: [
    'radial-gradient(66% 78% at 18% 124%, rgba(190, 205, 230, 0.32), transparent 62%)',
    'linear-gradient(180deg, #3c4a68 0%, #2c374f 55%, #222a3c 100%)',
  ],
  rain: [
    'radial-gradient(90% 70% at 20% 118%, rgba(226, 236, 248, 0.3), transparent 62%)',
    'linear-gradient(180deg, #7b8b9c 0%, #5c6b7c 52%, #43505e 100%)',
  ],
  storm: [
    'radial-gradient(100% 70% at 76% -20%, rgba(255, 236, 170, 0.24), transparent 58%)',
    'linear-gradient(180deg, #5a6577 0%, #414a5b 52%, #2c3340 100%)',
  ],
  snow: [
    'radial-gradient(80% 70% at 22% 120%, rgba(255, 255, 255, 0.6), transparent 62%)',
    'linear-gradient(180deg, #b3cbe2 0%, #8dabc8 55%, #6f8dab 100%)',
  ],
  mist: [
    'radial-gradient(120% 80% at 50% 120%, rgba(255, 255, 255, 0.42), transparent 66%)',
    'linear-gradient(180deg, #9fa9b4 0%, #838e9a 55%, #6c7681 100%)',
  ],
}

const SKY_BY_GROUP = {
  '01': { day: 'clearDay', night: 'clearNight' },
  '02': { day: 'cloudsDay', night: 'cloudsNight' },
  '03': { day: 'cloudsDay', night: 'cloudsNight' },
  '04': { day: 'cloudsDay', night: 'cloudsNight' },
  '09': { day: 'rain', night: 'rain' },
  10: { day: 'rain', night: 'rain' },
  11: { day: 'storm', night: 'storm' },
  13: { day: 'snow', night: 'snow' },
  50: { day: 'mist', night: 'mist' },
}

const DEFAULT_GRADIENT = WEATHER_GRADIENTS['맑음']

export function weatherIcon(description) {
  return WEATHER_ICONS[description] ?? '⛅'
}

export function weatherGradient(description) {
  return WEATHER_GRADIENTS[description] ?? DEFAULT_GRADIENT
}

export function iconGlyph(iconCode) {
  return ICON_GLYPHS[iconCode] ?? '⛅'
}

export function isNightIcon(iconCode) {
  return typeof iconCode === 'string' && iconCode.endsWith('n')
}

export function cardSky(iconCode) {
  const group = SKY_BY_GROUP[String(iconCode ?? '').slice(0, 2)]
  const preset = group ? group[isNightIcon(iconCode) ? 'night' : 'day'] : 'clearDay'
  return CARD_SKIES[preset].join(', ')
}
