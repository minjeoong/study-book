const WEEKDAYS = ['일', '월', '화', '수', '목', '금', '토']

/**
 * @description unix(초)와 도시의 timezone offset(초)으로 해당 도시의 현지 시각 Date 를 만든다.
 * @example
 * formatSunTime(1722902400, 32400) -->  "2026-08-05 16:29:20"
 */
const toCityDate = (unix, timezone = 0) => new Date((unix + timezone) * 1000)

/**
 * @description unix(초)와 도시의 timezone offset(초)으로 해당 도시의 현지 시각을 "시:분" 형태로 반환한다.
 * @example
 * formatSunTime(1722902400, 32400) -->  "16:29"
 */
export const formatSunTime = (unix, timezone = 0) => {
  if (!unix) return '-'
  const date = toCityDate(unix, timezone)
  const hours = String(date.getUTCHours()).padStart(2, '0')
  const minutes = String(date.getUTCMinutes()).padStart(2, '0')
  return `${hours}:${minutes}`
}

/**
 * @description unix(초)와 도시의 timezone offset(초)으로 해당 도시의 현지 시각을 "오전/오후 시:분" 형태로 반환한다.
 * @example
 * formatCityTime(1722902400, 32400) -->  "오후 4:29"
 */
export const formatCityTime = (unix, timezone = 0) => {
  if (!unix) return '-'
  const date = toCityDate(unix, timezone)
  const hours = date.getUTCHours()
  const minutes = String(date.getUTCMinutes()).padStart(2, '0')
  const meridiem = hours < 12 ? '오전' : '오후'
  const hour12 = hours % 12 === 0 ? 12 : hours % 12
  return `${meridiem} ${hour12}:${minutes}`
}

/**
 * @description unix(초)와 도시의 timezone offset(초)으로 해당 도시의 현지 시각을 "오전/오후 시시" 형태로 반환한다.
 * @example
 * formatCityHour(1722902400, 32400) -->  "오후 8시"
 */
export const formatCityHour = (unix, timezone = 0) => {
  if (!unix) return '-'
  const date = toCityDate(unix, timezone)
  const hours = date.getUTCHours()
  const meridiem = hours < 12 ? '오전' : '오후'
  const hour12 = hours % 12 === 0 ? 12 : hours % 12
  return `${meridiem} ${hour12}시`
}

/**
 * @description unix(초)와 도시의 timezone offset(초)으로 해당 도시의 현지 요일을 반환한다.
 * @example
 * formatCityWeekday(1722902400, 32400) -->  "목"
 */
export const formatCityWeekday = (unix, timezone = 0) => {
  if (!unix) return '-'
  return WEEKDAYS[toCityDate(unix, timezone).getUTCDay()]
}

/**
 * @description unix(초)와 도시의 timezone offset(초)으로 해당 도시의 현지 날짜를 "2026-08-05" 형태로 반환한다.
 * @example
 * cityDateKey(1722902400, 32400) -->  "2026-08-05"
 */
export const cityDateKey = (unix, timezone = 0) => {
  const date = toCityDate(unix, timezone)
  const month = String(date.getUTCMonth() + 1).padStart(2, '0')
  const day = String(date.getUTCDate()).padStart(2, '0')
  return `${date.getUTCFullYear()}-${month}-${day}`
}
