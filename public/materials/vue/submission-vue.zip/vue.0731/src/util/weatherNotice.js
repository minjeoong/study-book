export const HEAT_WAVE_TEMP = 33
export const COLD_WAVE_TEMP = -12

/**
 * @description 위치·설명·기온으로 토스트에 띄울 제목/본문/타입을 만든다.
 */
export function buildWeatherNotice({ name, description, temp }) {
  const title = `📍 ${name ?? '현재 위치'}의 오늘 날씨`
  const base = `오늘 현재 위치의 날씨는 "${description ?? '알 수 없음'}" 입니다.`

  if (typeof temp === 'number' && temp >= HEAT_WAVE_TEMP) {
    return {
      title,
      message: `${base} 폭염주의가 있으니 오늘은 물을 많이 드시고 더위를 조심하세요.`,
      type: 'warning',
      customClass: 'weather-toast weather-toast--heat',
    }
  }

  if (typeof temp === 'number' && temp <= COLD_WAVE_TEMP) {
    return {
      title,
      message: `${base} 한파주의가 있으니 오늘은 옷을 따뜻하게 입고 추위를 조심하세요.`,
      type: 'warning',
      customClass: 'weather-toast weather-toast--cold',
    }
  }

  return { title, message: base, type: 'info', customClass: 'weather-toast' }
}
