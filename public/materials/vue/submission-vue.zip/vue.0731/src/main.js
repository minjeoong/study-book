import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { ElAlert, ElEmpty, ElLoading } from 'element-plus'
import 'element-plus/es/components/alert/style/css'
import 'element-plus/es/components/empty/style/css'
import 'element-plus/es/components/loading/style/css'
import 'element-plus/es/components/notification/style/css'

import App from './App.vue'
import router from './router'
import './style/theme.css'

const app = createApp(App)

app.use(createPinia())
app.use(router)

app.component('ElAlert', ElAlert)
app.component('ElEmpty', ElEmpty)
app.use(ElLoading)

app.mount('#app')
