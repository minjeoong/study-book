<template>
  <svg
    class="chevron-left-icon"
    viewBox="0 0 8 14"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <path
      d="M7 1L1 7L7 13"
      stroke="currentColor"
      stroke-width="1.6"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>

<style scoped>
.chevron-left-icon {
  width: 8px;
  height: 14px;
  display: block;
}
</style>
