<script setup>
/**
 * macOS 스타일의 날씨 앱 레이아웃
 */
</script>

<template>
  <div class="desktop">
    <div class="mac-window">
      <div class="traffic-lights" aria-hidden="true">
        <span class="light light--close"></span>
        <span class="light light--minimize"></span>
        <span class="light light--zoom"></span>
      </div>

      <div v-if="$slots.toolbar" class="window-toolbar">
        <slot name="toolbar" />
      </div>

      <div class="window-body">
        <slot />
      </div>
    </div>
  </div>
</template>

<style scoped>
.desktop {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 4vh 24px;
}

.mac-window {
  position: relative;
  display: flex;
  width: min(1180px, 100%);
  height: min(760px, 90vh);
  border-radius: 12px;
  overflow: hidden;
  box-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.24),
    0 32px 70px rgba(0, 0, 0, 0.55),
    0 4px 14px rgba(0, 0, 0, 0.4);
}

.traffic-lights {
  position: absolute;
  top: 15px;
  left: 16px;
  z-index: 20;
  display: flex;
  gap: 8px;
}

.light {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  box-shadow: inset 0 0.5px 0 rgba(255, 255, 255, 0.4);
}

.light--close {
  background: #ff5f57;
}

.light--minimize {
  background: #febc2e;
}

.light--zoom {
  background: #28c840;
}

.window-toolbar {
  position: absolute;
  top: 12px;
  right: 16px;
  z-index: 20;
  display: flex;
  align-items: center;
  gap: 8px;
}

.window-body {
  display: flex;
  flex: 1;
  min-width: 0;
  background: var(--sky-day);
}

@media (max-width: 860px) {
  .desktop {
    padding: 0;
  }

  .mac-window {
    width: 100%;
    height: 100vh;
    border-radius: 0;
  }
}
</style>
