<template>
  <div
    class="skeleton-unit"
    :class="`skeleton-unit--${variant}`"
    :style="unitStyle"
    aria-hidden="true"
  ></div>
</template>

<script setup>
import { computed } from 'vue'

defineOptions({ name: 'AppSkeleton' })

const props = defineProps({
  variant: {
    type: String,
    default: 'md',
    validator: (value) => ['sm', 'md', 'lg'].includes(value),
  },
  width: {
    type: String,
    default: null,
  },
  height: {
    type: String,
    default: null,
  },
})

const unitStyle = computed(() => {
  const style = {}
  if (props.width) style.width = props.width
  if (props.height) style.height = props.height
  return style
})
</script>

<style scoped>
.skeleton-unit {
  display: block;
  flex-shrink: 0;
  width: 100%;
  overflow: hidden;
  position: relative;
  background: rgba(255, 255, 255, 0.18);
  border-radius: 999px;
}

.skeleton-unit::after {
  content: '';
  position: absolute;
  inset: 0;
  transform: translateX(-100%);
  background: linear-gradient(
    90deg,
    transparent 0%,
    rgba(255, 255, 255, 0.32) 50%,
    transparent 100%
  );
  animation: skeleton-shimmer 1.4s ease-in-out infinite;
}

.skeleton-unit--sm {
  height: 12px;
}

.skeleton-unit--md {
  height: 16px;
}

.skeleton-unit--lg {
  height: 24px;
  border-radius: 10px;
}

@keyframes skeleton-shimmer {
  100% {
    transform: translateX(100%);
  }
}
</style>
