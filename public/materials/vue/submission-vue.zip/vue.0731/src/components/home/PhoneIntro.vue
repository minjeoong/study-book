<script setup>
/**
 * @description 휴대폰 잠금화면 인트로
 */

import { onMounted, onUnmounted, ref } from 'vue'

const emit = defineEmits(['enter'])

const HELLO = '안녕하세요'

const HELLO_GLYPHS = [
  {
    char: '안',
    strokes: [
      {
        d: 'M30 9 C15 9 10 16 10 29 C10 42 19 49 30 49 C44 49 50 41 50 29 C50 13 42 7 27 10',
        w: 1.6,
      },
      { d: 'M65 3 C63 19 62 36 64 54', w: 1 },
      { d: 'M64 31 C72 27 79 27 87 30', w: 0.55 },
      { d: 'M20 56 C19 68 19 80 21 88 C41 91 63 91 85 87', w: 1.5 },
    ],
  },
  {
    char: '녕',
    strokes: [
      { d: 'M15 5 C14 19 14 33 16 45 C28 48 40 48 52 45', w: 1.2 },
      { d: 'M58 16 C66 13 73 13 81 16', w: 0.55 },
      { d: 'M58 37 C66 34 73 34 81 37', w: 0.55 },
      { d: 'M83 3 C81 19 80 36 82 53', w: 1 },
      {
        d: 'M52 58 C40 58 35 64 35 74 C35 85 43 91 52 91 C64 91 69 84 69 74 C69 61 61 55 48 59',
        w: 1.4,
      },
    ],
  },
  {
    char: '하',
    strokes: [
      { d: 'M27 6 C29 10 30 14 32 18', w: 0.4 },
      { d: 'M11 26 C23 22 37 22 49 26', w: 0.8 },
      {
        d: 'M30 38 C18 38 12 45 12 56 C12 67 20 73 30 73 C43 73 48 65 48 56 C48 42 40 36 26 39',
        w: 1.5,
      },
      { d: 'M69 4 C67 27 66 55 68 87', w: 1.5 },
      { d: 'M68 46 C76 42 84 42 91 45', w: 0.55 },
    ],
  },
  {
    char: '세',
    strokes: [
      { d: 'M32 18 C27 33 19 55 9 75', w: 1.1 },
      { d: 'M24 39 C30 49 37 62 46 75', w: 0.9 },
      { d: 'M51 45 C57 42 63 42 69 45', w: 0.5 },
      { d: 'M70 9 C68 32 68 61 70 85', w: 1.4 },
      { d: 'M90 8 C88 32 88 61 90 85', w: 1.4 },
    ],
  },
  {
    char: '요',
    strokes: [
      {
        d: 'M50 11 C37 11 31 18 31 30 C31 42 39 49 50 49 C63 49 69 41 69 30 C69 16 61 9 47 12',
        w: 1.5,
      },
      { d: 'M32 58 C31 65 31 72 33 79', w: 0.6 },
      { d: 'M63 58 C62 65 62 72 64 79', w: 0.6 },
      { d: 'M11 85 C33 81 66 81 89 86', w: 1.4 },
    ],
  },
]

const GLYPH_ADVANCE = 108
const WRITE_START = 0.45
const STROKE_GAP = 0.02
const GLYPH_GAP = 0.09

const viewBox = `0 0 ${(HELLO_GLYPHS.length - 1) * GLYPH_ADVANCE + 100} 100`

let cursor = WRITE_START
const helloGlyphs = HELLO_GLYPHS.map((glyph, index) => {
  if (index > 0) cursor += GLYPH_GAP

  return {
    x: index * GLYPH_ADVANCE,
    strokes: glyph.strokes.map((stroke) => {
      const duration = 0.06 + 0.06 * stroke.w
      const delay = cursor
      cursor += duration + STROKE_GAP
      const width = 5.6 + 0.8 * stroke.w
      return { d: stroke.d, duration, delay, width }
    }),
  }
})

const signDelay = cursor + 0.25

const BASE_ROTATE_X = 3
const BASE_ROTATE_Y = -18
const MAX_TILT_X = 10
const MAX_TILT_Y = 22

const RAIL_PROFILE = [
  [0, 232, 226, 214],
  [0.08, 200, 194, 182],
  [0.18, 176, 170, 160],
  [0.32, 164, 158, 148],
  [0.5, 158, 152, 142],
  [0.68, 164, 158, 148],
  [0.82, 176, 170, 160],
  [0.92, 198, 192, 180],
  [1, 142, 136, 126],
]

function railTone(depth) {
  let index = 1
  while (index < RAIL_PROFILE.length - 1 && RAIL_PROFILE[index][0] < depth) index += 1

  const [from, r1, g1, b1] = RAIL_PROFILE[index - 1]
  const [to, r2, g2, b2] = RAIL_PROFILE[index]
  const ratio = (depth - from) / (to - from)
  const mix = (a, b) => Math.round(a + (b - a) * ratio)

  return `rgb(${mix(r1, r2)} ${mix(g1, g2)} ${mix(b1, b2)})`
}

const SIDE_LAYERS = 20
const sideLayers = Array.from({ length: SIDE_LAYERS }, (_, index) => {
  const depth = index / (SIDE_LAYERS - 1)
  return { depth, tone: railTone(depth) }
})

const UNLOCK_DISTANCE = 150
const UNLOCK_COMMIT = 0.4

const stageRef = ref(null)
const ready = ref(false)
const isHover = ref(false)
const isLeaving = ref(false)
const isDragging = ref(false)
const unlockProgress = ref(0)
const clock = ref('')

const rotateX = ref(BASE_ROTATE_X)
const rotateY = ref(BASE_ROTATE_Y)
const glareX = ref(50)
const glareY = ref(20)

const target = { x: BASE_ROTATE_X, y: BASE_ROTATE_Y, gx: 50, gy: 20 }
let spin = 0
let rafId = null
let clockTimer = null
let leaveTimer = null
let dragStartY = null
let ignoreNextClick = false

function updateClock() {
  clock.value = new Intl.DateTimeFormat('ko-KR', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: false,
  }).format(new Date())
}

function animate() {
  const ease = 0.09
  rotateX.value += (target.x - rotateX.value) * ease
  rotateY.value += (target.y + spin - rotateY.value) * ease
  glareX.value += (target.gx - glareX.value) * ease
  glareY.value += (target.gy - glareY.value) * ease
  rafId = requestAnimationFrame(animate)
}

function handlePointerDown(event) {
  if (isLeaving.value || event.button !== 0) return
  dragStartY = event.clientY
  stageRef.value?.setPointerCapture(event.pointerId)
}

function handlePointerUp(event) {
  if (dragStartY === null) return

  dragStartY = null
  stageRef.value?.releasePointerCapture(event.pointerId)

  if (unlockProgress.value >= UNLOCK_COMMIT) {
    handleEnter()
    return
  }

  ignoreNextClick = isDragging.value
  isDragging.value = false
  unlockProgress.value = 0
}

function handleClick() {
  if (ignoreNextClick) {
    ignoreNextClick = false
    return
  }
  handleEnter()
}

function handlePointerMove(event) {
  if (!stageRef.value || isLeaving.value) return

  if (dragStartY !== null) {
    const lifted = dragStartY - event.clientY
    if (lifted > 3) isDragging.value = true
    unlockProgress.value = Math.min(1, Math.max(0, lifted / UNLOCK_DISTANCE))
  }

  const rect = stageRef.value.getBoundingClientRect()
  const ratioX = (event.clientX - rect.left) / rect.width - 0.5
  const ratioY = (event.clientY - rect.top) / rect.height - 0.5

  target.y = BASE_ROTATE_Y + ratioX * MAX_TILT_Y * 2
  target.x = BASE_ROTATE_X - ratioY * MAX_TILT_X * 2
  target.gx = 50 + ratioX * 90
  target.gy = 30 + ratioY * 70
}

function resetTilt() {
  isHover.value = false
  target.x = BASE_ROTATE_X
  target.y = BASE_ROTATE_Y
  target.gx = 50
  target.gy = 20
}

function handleWheel(event) {
  if (isLeaving.value) return
  spin = Math.max(-45, Math.min(45, spin + event.deltaY * 0.08))
}

function handleEnter() {
  if (isLeaving.value) return

  isLeaving.value = true
  isDragging.value = false
  unlockProgress.value = 0
  target.x = BASE_ROTATE_X
  target.y = BASE_ROTATE_Y
  spin = 0

  leaveTimer = window.setTimeout(() => emit('enter'), 980)
}

onMounted(() => {
  updateClock()
  clockTimer = window.setInterval(updateClock, 20_000)
  rafId = requestAnimationFrame(animate)
  requestAnimationFrame(() => {
    ready.value = true
  })
})

onUnmounted(() => {
  if (clockTimer) window.clearInterval(clockTimer)
  if (leaveTimer) window.clearTimeout(leaveTimer)
  if (rafId) cancelAnimationFrame(rafId)
})
</script>

<template>
  <div
    ref="stageRef"
    class="phone-stage"
    :class="{ 'is-ready': ready, 'is-leaving': isLeaving, 'is-dragging': isDragging }"
    :style="{ '--unlock': unlockProgress }"
    role="button"
    tabindex="0"
    aria-label="안녕하세요. 위로 쓸어올리거나 클릭하면 맥 화면으로 전환됩니다."
    @click="handleClick"
    @keydown.enter.prevent="handleEnter"
    @keydown.space.prevent="handleEnter"
    @keydown.up.prevent="handleEnter"
    @pointerdown="handlePointerDown"
    @pointerup="handlePointerUp"
    @pointercancel="handlePointerUp"
    @pointermove="handlePointerMove"
    @pointerenter="isHover = true"
    @pointerleave="resetTilt"
    @wheel.passive="handleWheel"
  >
    <div class="stage-light" aria-hidden="true" />

    <div
      class="pair"
      :class="{ 'is-hover': isHover }"
      :style="{
        '--rx': `${rotateX}deg`,
        '--ry': `${rotateY}deg`,
        '--gx': `${glareX}%`,
        '--gy': `${glareY}%`,
      }"
    >
      <div class="device device--rear" aria-hidden="true">
        <div class="back-shell">
          <div class="back-glass">
            <div class="camera-plateau">
              <span class="lens lens-main"><i /></span>
              <span class="lens lens-ultra"><i /></span>
              <span class="lens lens-tele"><i /></span>
              <span class="flash" />
              <span class="lidar" />
            </div>
            <span class="apple-logo" />
          </div>
        </div>
      </div>

      <div class="device device--front">
        <div class="side-wall" aria-hidden="true">
          <span
            v-for="layer in sideLayers"
            :key="layer.depth"
            :style="{
              transform: `translateZ(calc(var(--t) * ${-layer.depth}))`,
              backgroundColor: layer.tone,
            }"
          />
        </div>

        <div class="rail rail-left" aria-hidden="true">
          <span class="antenna" style="top: 3%" />
          <span class="rail-btn btn-action" />
          <span class="rail-btn btn-vol-up" />
          <span class="rail-btn btn-vol-down" />
          <span class="antenna" style="top: 96%" />
        </div>
        <div class="rail rail-right" aria-hidden="true">
          <span class="antenna" style="top: 3%" />
          <span class="rail-btn btn-side" />
          <span class="antenna" style="top: 96%" />
        </div>
        <div class="rail rail-bottom" aria-hidden="true">
          <span class="port-usbc" />
          <span class="speaker-holes" />
        </div>

        <div class="device-shell">
          <div class="device-bezel">
            <div class="device-screen">
              <div class="screen-slide">
                <div class="wallpaper" aria-hidden="true">
                  <span class="wp-canvas" />
                </div>

                <div class="status-bar" aria-hidden="true">
                  <span class="status-time">{{ clock }}</span>
                  <div class="status-right">
                    <svg class="status-icon" viewBox="0 0 18 12" aria-hidden="true">
                      <rect x="0.5" y="7" width="2.5" height="4.5" rx="0.6" fill="currentColor" />
                      <rect x="4.5" y="5" width="2.5" height="6.5" rx="0.6" fill="currentColor" />
                      <rect x="8.5" y="2.5" width="2.5" height="9" rx="0.6" fill="currentColor" />
                      <rect
                        x="12.5"
                        y="0.5"
                        width="2.5"
                        height="11"
                        rx="0.6"
                        fill="currentColor"
                        opacity="0.35"
                      />
                    </svg>
                    <span class="battery">
                      <span class="battery-level" />
                      <span class="battery-cap" />
                    </span>
                  </div>
                </div>

                <div class="hello">
                  <svg class="hello-svg" :viewBox="viewBox" role="img" :aria-label="HELLO">
                    <g transform="skewX(-5)">
                      <g
                        v-for="(glyph, glyphIndex) in helloGlyphs"
                        :key="glyphIndex"
                        :transform="`translate(${glyph.x} 0)`"
                      >
                        <path
                          v-for="(stroke, strokeIndex) in glyph.strokes"
                          :key="strokeIndex"
                          class="hello-stroke"
                          :d="stroke.d"
                          pathLength="1"
                          :style="{
                            animationDelay: `${stroke.delay}s`,
                            animationDuration: `${stroke.duration}s`,
                            strokeWidth: stroke.width,
                          }"
                        />
                      </g>
                    </g>
                  </svg>
                  <p class="hello-sign" :style="{ animationDelay: `${signDelay}s` }">
                    김민정 · 판교 · P282
                  </p>
                </div>

                <div class="lock-footer" aria-hidden="true">
                  <p class="lock-hint">위로 쓸어올려서 열기</p>
                  <span class="info-badge">i</span>
                </div>

                <div class="home-indicator" aria-hidden="true" />
              </div>

              <div class="dynamic-island" aria-hidden="true">
                <span class="island-camera" />
                <span class="island-sensor" />
              </div>
              <div class="screen-glare" aria-hidden="true" />
            </div>
          </div>
        </div>
      </div>

      <div class="pair-glow" aria-hidden="true" />
    </div>
  </div>
</template>

<style scoped>
@import url(https://fonts.googleapis.com/css?family=Alex+Brush);

.phone-stage {
  position: fixed;
  inset: 0;
  z-index: 40;
  display: grid;
  place-items: center;
  background: #000;
  cursor: pointer;
  overflow: hidden;
  perspective: 1500px;
  perspective-origin: 50% 45%;
}

.phone-stage.is-leaving {
  pointer-events: none;
}

.stage-fade {
  position: absolute;
  inset: 0;
  z-index: 10;
  pointer-events: none;
  background: #000;
  opacity: 1;
}

.phone-stage.is-ready .stage-fade {
  opacity: 0;
  transition: opacity 0.45s ease;
}

.phone-stage.is-leaving .stage-fade {
  opacity: 1;
  transition: opacity 0.55s ease 0.95s;
}

.stage-light {
  position: absolute;
  inset: 0;
  pointer-events: none;
  background:
    radial-gradient(
      42% 34% at 50% 22%,
      rgba(255, 255, 255, 0.16) 0%,
      rgba(255, 255, 255, 0.05) 46%,
      transparent 74%
    ),
    radial-gradient(72% 58% at 50% 58%, rgba(140, 148, 168, 0.09) 0%, transparent 72%);
}

.pair {
  --w: min(232px, 34vw);
  --t: calc(var(--w) * 0.13);
  position: relative;
  width: calc(var(--w) * 1.6);
  height: calc(var(--w) * 852 / 393);
  transform-style: preserve-3d;
  transform: rotateX(var(--rx)) rotateY(var(--ry)) translateY(26px) scale(0.94);
}

.phone-stage.is-ready .pair {
  transform: rotateX(var(--rx)) rotateY(var(--ry)) translateY(0) scale(1);
}

.phone-stage.is-ready:not(.is-leaving) .pair.is-hover {
  transform: rotateX(var(--rx)) rotateY(var(--ry)) translateY(-6px) scale(1.03);
}

.device {
  position: absolute;
  top: 0;
  width: var(--w);
  aspect-ratio: 393 / 852;
  transform-style: preserve-3d;
}

.device--rear {
  left: 0;
  transform: translate3d(0, 2.5%, -62px) scale(0.96);
}

.device--front {
  right: 0;
  transform: translateZ(0);
}

.side-wall {
  position: absolute;
  inset: 0;
  transform-style: preserve-3d;
  pointer-events: none;
}

.side-wall span {
  position: absolute;
  inset: 0;
  border-radius: 18.4% / 8.6%;
  padding: 10px;
  mask-image: linear-gradient(#000 0 0), linear-gradient(#000 0 0);
  mask-clip: border-box, content-box;
  mask-composite: exclude;
  -webkit-mask-image: linear-gradient(#000 0 0), linear-gradient(#000 0 0);
  -webkit-mask-clip: border-box, content-box;
  -webkit-mask-composite: xor;
  background-image:
    linear-gradient(
      180deg,
      rgba(255, 255, 255, 0.22) 0%,
      rgba(255, 255, 255, 0) 12%,
      rgba(255, 255, 255, 0.06) 38%,
      rgba(255, 255, 255, 0) 62%,
      rgba(255, 255, 255, 0.08) 86%,
      rgba(255, 255, 255, 0.2) 100%
    ),
    repeating-linear-gradient(180deg, rgba(255, 255, 255, 0.025) 0 1px, rgba(0, 0, 0, 0.02) 1px 2px);
}

.rail {
  position: absolute;
  transform-style: preserve-3d;
  backface-visibility: hidden;
}

.rail-left,
.rail-right {
  top: 8.6%;
  height: 82.8%;
  width: var(--t);
  border-radius: 1.5px;

  mask-image: linear-gradient(180deg, transparent 0, #000 3.2%, #000 96.8%, transparent 100%);
  -webkit-mask-image: linear-gradient(
    180deg,
    transparent 0,
    #000 3.2%,
    #000 96.8%,
    transparent 100%
  );
  background:
    linear-gradient(
      180deg,
      rgba(255, 255, 255, 0.22) 0%,
      rgba(255, 255, 255, 0) 14%,
      rgba(255, 255, 255, 0.05) 42%,
      rgba(255, 255, 255, 0) 70%,
      rgba(255, 255, 255, 0.16) 100%
    ),
    linear-gradient(
      var(--rail-face, 90deg),
      #efe8dc 0%,
      #d2cbc0 6%,
      #b7b0a4 14%,
      #a39c90 28%,
      #968f83 50%,
      #a39c90 72%,
      #b7b0a4 86%,
      #ccc5b9 94%,
      #8f887c 100%
    );
  box-shadow: inset 0 0 0 0.5px rgba(255, 255, 255, 0.1);
}

.rail-left {
  left: 0;
  --rail-angle: 270deg;
  --rail-face: 270deg;
  transform-origin: left center;
  transform: translateZ(calc(var(--t) * -1)) rotateY(-90deg);
}

.rail-right {
  right: 0;
  --rail-angle: 90deg;
  --rail-face: 90deg;
  transform-origin: right center;
  transform: translateZ(calc(var(--t) * -1)) rotateY(90deg);
}

.rail-bottom {
  left: 18.4%;
  bottom: 0;
  width: 63.2%;
  height: var(--t);
  transform-origin: center bottom;
  transform: translateZ(calc(var(--t) * -1)) rotateX(-90deg);
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(
    0deg,
    #8a8377 0%,
    #ada69a 14%,
    #948d81 40%,
    #948d81 60%,
    #ada69a 86%,
    #e4ddd1 100%
  );
}

.antenna {
  position: absolute;
  left: 8%;
  width: 84%;
  height: 1px;
  background: rgba(55, 50, 44, 0.45);
  box-shadow: 0 0.5px 0 rgba(255, 255, 255, 0.22);
  z-index: 1;
}

.rail-btn {
  position: absolute;
  left: 50%;
  width: 58%;
  /* 레일 기준 +z 가 기기 바깥이라, 버튼이 실제로 툭 솟아오른다. */
  --btn-pop: calc(var(--w) * 0.005);
  transform: translateX(-50%) translateZ(var(--btn-pop));
  border-radius: calc(var(--w) * 0.018);
  background: linear-gradient(
    var(--rail-angle, 90deg),
    #e8e1d5 0%,
    #c2bbae 20%,
    #a59e92 48%,
    #8f887c 76%,
    #6a655c 100%
  );
  box-shadow:
    0 0 0 0.8px rgba(35, 30, 24, 0.65),
    0.5px 0 1px rgba(0, 0, 0, 0.35),
    inset 0 0.6px 0 rgba(255, 255, 255, 0.42),
    inset 0 -0.6px 0 rgba(0, 0, 0, 0.38);
  z-index: 2;
}

.btn-action {
  top: 9%;
  height: 3.5%;
}

.btn-vol-up {
  top: 16%;
  height: 7.5%;
}

.btn-vol-down {
  top: 25.5%;
  height: 7.5%;
}

.btn-side {
  top: 18%;
  height: 11.2%;
  --btn-pop: calc(var(--w) * 0.02);
  box-shadow:
    0 0 0 0.8px rgba(35, 30, 24, 0.7),
    1px 0 2.5px rgba(0, 0, 0, 0.45),
    0 0 4px 0.5px rgba(0, 0, 0, 0.3),
    inset 0 0.6px 0 rgba(255, 255, 255, 0.5),
    inset 0 -0.6px 0 rgba(0, 0, 0, 0.42);
}

.port-usbc {
  width: 9%;
  height: 34%;
  border-radius: 999px;
  background: #0d0c0b;
  box-shadow: inset 0 0 0 0.5px rgba(0, 0, 0, 0.9);
}

.speaker-holes {
  position: absolute;
  right: 14%;
  width: 12%;
  height: 22%;
  border-radius: 999px;
  background: repeating-linear-gradient(90deg, rgba(20, 18, 16, 0.85) 0 1px, transparent 1px 3px);
}

.device-shell {
  position: relative;
  height: 100%;
  border-radius: 18.4% / 8.6%;
  padding: 1.5%;
  transform: translateZ(2px);
  background: linear-gradient(
    90deg,
    #ece5d9 0%,
    #c2bcb0 1.6%,
    #9a958c 6%,
    #89867f 22%,
    #7a7772 50%,
    #89867f 78%,
    #a5a29b 93%,
    #cdc8be 98.4%,
    #ece5d9 100%
  );
  box-shadow: 0 46px 100px rgba(0, 0, 0, 0.8);
}

.back-shell {
  position: relative;
  height: 100%;
  border-radius: 18.4% / 8.6%;
  padding: 1.5%;
  transform: translateZ(0.5px);
  background: linear-gradient(
    90deg,
    #ece5d9 0%,
    #cfc8bc 1.8%,
    #a8a19a 6%,
    #8f887c 22%,
    #827b70 50%,
    #8f887c 78%,
    #a8a19a 94%,
    #cfc8bc 98.2%,
    #ece5d9 100%
  );
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.55),
    0 46px 100px rgba(0, 0, 0, 0.8);
}

.back-glass {
  position: relative;
  height: 100%;
  border-radius: 17% / 7.9%;
  overflow: hidden;
  background:
    radial-gradient(100% 55% at 74% 10%, rgba(255, 255, 255, 0.16), transparent 62%),
    linear-gradient(160deg, #bfbcb5 0%, #b4b1aa 42%, #aaa7a0 70%, #b8b5ae 100%);
  box-shadow: inset 0 0 0 0.5px rgba(0, 0, 0, 0.28);
}

.camera-plateau {
  position: absolute;
  left: 5.5%;
  top: 2.4%;
  width: 43%;
  aspect-ratio: 1;
  border-radius: 34%;
  background: linear-gradient(148deg, #ded7ca 0%, #b1a99c 32%, #918a7e 62%, #c4bcae 100%);
  box-shadow:
    inset 0 1px 0 rgba(255, 255, 255, 0.6),
    inset 0 -1px 1px rgba(0, 0, 0, 0.3),
    0 5px 12px rgba(0, 0, 0, 0.42);
}

.lens {
  position: absolute;
  width: 38%;
  aspect-ratio: 1;
  transform: translate(-50%, -50%);
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: linear-gradient(155deg, #efe8db 0%, #a49c90 38%, #6b655c 68%, #cdc5b7 100%);
  box-shadow:
    0 2px 5px rgba(0, 0, 0, 0.55),
    inset 0 0 0 1px rgba(255, 255, 255, 0.3);
}

.lens i {
  width: 66%;
  height: 66%;
  border-radius: 50%;
  background: radial-gradient(
    circle at 33% 28%,
    #33456a 0%,
    #101a2e 38%,
    #050810 70%,
    #0b0e16 100%
  );
  box-shadow:
    inset 0 0 0 1px rgba(255, 255, 255, 0.14),
    inset 0 2px 4px rgba(0, 0, 0, 0.95);
}

.lens-main {
  left: 27%;
  top: 27%;
}

.lens-ultra {
  left: 27%;
  top: 73%;
}

.lens-tele {
  left: 73%;
  top: 56%;
}

.flash {
  position: absolute;
  left: 73%;
  top: 22%;
  width: 21%;
  aspect-ratio: 1;
  transform: translate(-50%, -50%);
  border-radius: 50%;
  background: radial-gradient(
    circle at 38% 32%,
    #fffdf5 0%,
    #f2e6cc 42%,
    #b6aa90 76%,
    #6d6458 100%
  );
  box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.28);
}

.lidar {
  position: absolute;
  left: 60%;
  top: 84%;
  width: 13%;
  aspect-ratio: 1;
  transform: translate(-50%, -50%);
  border-radius: 50%;
  background: radial-gradient(circle at 36% 30%, #4c463c 0%, #17150f 58%, #090805 100%);
}

.apple-logo {
  --apple-mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'%3E%3Cpath fill='black' d='M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z'/%3E%3C/svg%3E");
  position: absolute;
  left: 50%;
  top: 45%;
  width: 15%;
  aspect-ratio: 1;
  transform: translate(-50%, -50%);
  display: grid;
  place-items: center;
  font-size: 0;
}

.apple-logo::before {
  content: '';
  width: 100%;
  height: 100%;
  background: rgba(255, 255, 255, 0.55);
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.18);
  /* 사과 실루엣 */
  mask: var(--apple-mask) center / contain no-repeat;
  -webkit-mask: var(--apple-mask) center / contain no-repeat;
}

.device-shell::after {
  content: '';
  position: absolute;
  inset: 1.1%;
  border-radius: 17.6% / 8.2%;
  pointer-events: none;
  box-shadow:
    inset 0 0 0 1px rgba(255, 255, 255, 0.34),
    inset 0 0 3px rgba(0, 0, 0, 0.6);
}

.device-bezel {
  position: relative;
  height: 100%;
  border-radius: 16.6% / 7.8%;
  padding: 1.15%;
  background: #010101;
  box-shadow:
    inset 0 0 0 0.5px rgba(255, 255, 255, 0.07),
    inset 0 0 14px rgba(0, 0, 0, 0.9);
}

.device-screen {
  position: relative;
  height: 100%;
  border-radius: 15.8% / 7.3%;
  background: #000;
  overflow: hidden;
  color: #f5f5f7;
  container-type: inline-size;
}

/* 벽지 + UI + 홈 인디케이터. 클릭 시 통째로 위로 밀린다. */
.screen-slide {
  position: absolute;
  inset: 0;
  will-change: transform;
}

.phone-stage.is-leaving .screen-slide {
  transform: translateY(-110%);
  transition: transform 1.25s cubic-bezier(0.32, 0.72, 0, 1);
}

/* iOS 기본 벽지 느낌의 흐르는 리본 */
.wallpaper {
  position: absolute;
  inset: 0;
  overflow: hidden;
  background: #1c6a8e;
}

/* iOS hello 화면 벽지 — 파랑·청록·초록·노랑이 번지는 구성.
   blur 필터는 크롬에서 이음새를 남기므로 radial-gradient 만으로 만든다. */
.wp-canvas {
  position: absolute;
  inset: 0;
  background:
    radial-gradient(46% 26% at 16% 6%, #3f5fc4 0%, transparent 70%),
    radial-gradient(52% 28% at 78% 4%, #2f8fae 0%, transparent 72%),
    radial-gradient(40% 26% at 98% 26%, #2b6fc0 0%, transparent 68%),
    radial-gradient(44% 26% at 2% 34%, #2f9b86 0%, transparent 70%),
    radial-gradient(56% 30% at 66% 40%, #2ba59c 0%, transparent 72%),
    radial-gradient(40% 24% at 26% 54%, #4bb08a 0%, transparent 68%),
    radial-gradient(48% 26% at 8% 74%, #e0a63c 0%, transparent 70%),
    radial-gradient(52% 26% at 52% 86%, #ecc84f 0%, transparent 70%),
    radial-gradient(46% 30% at 96% 82%, #3f5fc4 0%, transparent 70%),
    radial-gradient(38% 22% at 84% 60%, #2f8fae 0%, transparent 68%),
    linear-gradient(158deg, #2f62bd 0%, #2b9aa2 38%, #6fb277 62%, #dcb544 82%, #3f5fc4 100%);
}

.screen-glare {
  position: absolute;
  inset: 0;
  z-index: 6;
  pointer-events: none;
  background:
    radial-gradient(70% 45% at var(--gx) var(--gy), rgba(255, 255, 255, 0.05) 0%, transparent 68%),
    linear-gradient(122deg, rgba(255, 255, 255, 0.045) 0%, transparent 38%);
  mix-blend-mode: screen;
}

.dynamic-island {
  position: absolute;
  top: 2.1%;
  left: 50%;
  z-index: 5;
  width: 27.5%;
  aspect-ratio: 126 / 37;
  transform: translateX(-50%);
  border-radius: 999px;
  background: #000;
  box-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.05),
    0 8px 18px rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 7%;
  padding-right: 7%;
}

.island-camera {
  width: 18%;
  aspect-ratio: 1;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 32%, #46536b 0%, #16203a 45%, #04060c 100%);
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.1);
}

.island-sensor {
  width: 7%;
  aspect-ratio: 1;
  border-radius: 50%;
  background: #111;
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.05);
}

.status-bar {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  z-index: 4;
  height: 7.2%;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  padding: 0 7% 1.2%;
  font-size: clamp(8px, 3.4cqw, 13px);
  font-weight: 600;
  letter-spacing: -0.02em;
  pointer-events: none;
}

.status-time {
  min-width: 3.2em;
  text-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
}

.status-right {
  display: flex;
  align-items: center;
  gap: 3.5%;
}

.status-icon {
  width: clamp(10px, 7.4cqw, 16px);
  height: auto;
  color: #f5f5f7;
}

.status-icon.wifi {
  width: clamp(9px, 6.9cqw, 15px);
}

.battery {
  position: relative;
  width: clamp(15px, 11cqw, 24px);
  height: clamp(7px, 5.1cqw, 11px);
  border: 1px solid rgba(245, 245, 247, 0.55);
  border-radius: 2.5px;
  display: flex;
  align-items: center;
  padding: 1px;
}

.battery-level {
  width: 72%;
  height: 100%;
  border-radius: 1.5px;
  background: #f5f5f7;
}

.battery-cap {
  position: absolute;
  right: -3px;
  width: 1.5px;
  height: 4px;
  border-radius: 0 1px 1px 0;
  background: rgba(245, 245, 247, 0.55);
}

.hello {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 0 8%;
  text-align: center;
}

.hello-svg {
  width: 94%;
  height: auto;
  overflow: visible;
  filter: drop-shadow(0 2px 10px rgba(0, 0, 0, 0.35));
}

/* pathLength=1 로 길이를 정규화해 두면 획 길이와 상관없이 같은 식으로 그을 수 있다. */
.hello-stroke {
  fill: none;
  stroke: #fff;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  animation-name: stroke-write;
  animation-timing-function: cubic-bezier(0.5, 0, 0.55, 1);
  animation-fill-mode: forwards;
}

.hello-sign {
  margin: 0;
  font-size: clamp(8px, 3.6cqw, 14px);
  font-weight: 500;
  letter-spacing: 0.01em;
  color: rgba(255, 255, 255, 0.88);
  text-shadow: 0 1px 6px rgba(0, 0, 0, 0.35);
  opacity: 0;
  transform: translateY(6px);
  animation: hello-in 0.7s cubic-bezier(0.22, 1, 0.36, 1) forwards;
}

.lock-footer {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 4.4%;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  animation: hello-in 0.9s ease 2.1s forwards;
}

.lock-hint {
  margin: 0;
  font-size: clamp(8px, 3.4cqw, 13px);
  font-weight: 500;
  letter-spacing: -0.01em;
  color: rgba(255, 255, 255, 0.92);
  text-shadow: 0 1px 6px rgba(0, 0, 0, 0.3);
}

.info-badge {
  position: absolute;
  right: 7%;
  display: grid;
  place-items: center;
  width: clamp(14px, 6.4cqw, 22px);
  aspect-ratio: 1;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.75);
  font-size: clamp(8px, 3.6cqw, 13px);
  font-weight: 500;
  font-style: italic;
  line-height: 1;
  color: rgba(255, 255, 255, 0.92);
}

.home-indicator {
  position: absolute;
  left: 50%;
  bottom: 1.6%;
  width: 36%;
  height: 0.55%;
  min-height: 4px;
  transform: translateX(-50%);
  border-radius: 999px;
  background: rgba(245, 245, 247, 0.92);
}

.pair-glow {
  position: absolute;
  left: 2%;
  right: 2%;
  bottom: -48px;
  height: 62px;
  border-radius: 50%;
  background: radial-gradient(ellipse at center, rgba(255, 255, 255, 0.16), transparent 72%);
  filter: blur(14px);
  opacity: 0.5;
  transform: translateZ(-60px);
  transition: opacity 0.35s ease;
}

.pair.is-hover .pair-glow {
  opacity: 0.85;
}

@keyframes hello-in {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes stroke-write {
  to {
    stroke-dashoffset: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .phone-stage,
  .pair,
  .hello-sign,
  .lock-footer,
  .screen-slide {
    animation: none;
    transition: none;
    opacity: 1;
    transform: none;
  }

  .hello-stroke {
    animation: none;
    stroke-dashoffset: 0;
  }
}
</style>
