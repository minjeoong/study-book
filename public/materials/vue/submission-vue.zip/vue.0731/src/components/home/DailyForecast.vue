<script setup>
import { computed } from 'vue'
import { useConfigStore } from '@/stores/configStore'
import { iconGlyph } from '@/util/weatherTheme'

/**
 * @description 일별 예보 컴포넌트
 */

const props = defineProps({
  days: {
    type: Array,
    default: () => [],
  },
  currentTemp: {
    type: Number,
    default: null,
  },
})

const configStore = useConfigStore()

const scale = computed(() => {
  if (props.days.length === 0) return { min: 0, span: 1 }
  const min = Math.min(...props.days.map((day) => day.min))
  const max = Math.max(...props.days.map((day) => day.max))
  return { min, span: Math.max(max - min, 1) }
})

function ratio(temp) {
  return ((temp - scale.value.min) / scale.value.span) * 100
}

function barStyle(day) {
  const left = ratio(day.min)
  return {
    left: `${left}%`,
    width: `${Math.max(ratio(day.max) - left, 4)}%`,
    background: `linear-gradient(90deg, ${tempColor(day.min)}, ${tempColor(day.max)})`,
  }
}

function tempColor(celsius) {
  if (celsius <= 0) return '#6fb7ff'
  if (celsius <= 10) return '#54c9e8'
  if (celsius <= 18) return '#7ed957'
  if (celsius <= 24) return '#f2c14b'
  if (celsius <= 30) return '#f59349'
  return '#ef5d3c'
}
</script>

<template>
  <ul class="daily">
    <li v-for="(day, index) in days" :key="day.key" class="daily-row">
      <span class="daily-label">{{ day.label }}</span>

      <span class="daily-icon">
        <span aria-hidden="true">{{ iconGlyph(day.icon) }}</span>
        <span v-if="day.pop >= 0.2" class="daily-pop">{{ Math.round(day.pop * 100) }}%</span>
      </span>

      <span class="daily-temp">{{ configStore.convert(day.min) }}°</span>

      <span class="daily-bar">
        <span class="daily-bar-fill" :style="barStyle(day)"></span>
        <span
          v-if="index === 0 && currentTemp !== null"
          class="daily-bar-dot"
          :style="{ left: `${ratio(currentTemp)}%` }"
        ></span>
      </span>

      <span class="daily-temp daily-temp--max">{{ configStore.convert(day.max) }}°</span>
    </li>
  </ul>
</template>

<style scoped>
.daily {
  margin: 0;
  padding: 0;
  list-style: none;
}

.daily-row {
  display: grid;
  grid-template-columns: 34px 34px 34px 1fr 34px;
  align-items: center;
  gap: 8px;
  height: 40px;
  border-top: 1px solid rgba(255, 255, 255, 0.14);
  color: var(--text-on-sky);
  font-size: 14px;
}

.daily-row:first-child {
  border-top: none;
}

.daily-label {
  font-weight: 600;
}

.daily-icon {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 17px;
  line-height: 1.05;
}

.daily-pop {
  font-size: 10px;
  font-weight: 600;
  color: #6fd3ff;
}

.daily-temp {
  text-align: right;
  color: rgba(255, 255, 255, 0.7);
  font-variant-numeric: tabular-nums;
}

.daily-temp--max {
  color: #fff;
  font-weight: 500;
}

.daily-bar {
  position: relative;
  height: 5px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.22);
}

.daily-bar-fill {
  position: absolute;
  top: 0;
  bottom: 0;
  border-radius: 999px;
}

.daily-bar-dot {
  position: absolute;
  top: 50%;
  width: 7px;
  height: 7px;
  margin-left: -3.5px;
  border-radius: 50%;
  background: #fff;
  transform: translateY(-50%);
  box-shadow: 0 0 0 1.5px rgba(0, 0, 0, 0.18);
}
</style>
