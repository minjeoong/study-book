<script setup>
import { computed } from 'vue'
import { useConfigStore } from '@/stores/configStore'
import { formatCityHour, formatCityWeekday, cityDateKey } from '@/util/format'
import { iconGlyph } from '@/util/weatherTheme'

const props = defineProps({
  forecast: {
    type: Object,
    default: null,
  },
})

const configStore = useConfigStore()

const timezone = computed(() => props.forecast?.city?.timezone ?? 0)

const hourly = computed(() => (props.forecast?.list ?? []).slice(0, 8))

const daily = computed(() => {
  const list = props.forecast?.list ?? []
  const grouped = new Map()

  for (const entry of list) {
    const key = cityDateKey(entry.dt, timezone.value)
    if (!grouped.has(key)) grouped.set(key, [])
    grouped.get(key).push(entry)
  }

  return Array.from(grouped.values())
    .slice(0, 5)
    .map((entries) => {
      const noonEntry =
        entries.find((entry) => new Date(entry.dt_txt.replace(' ', 'T')).getUTCHours() === 12) ??
        entries[Math.floor(entries.length / 2)]
      const temps = entries.map((entry) => entry.main.temp)

      return {
        key: noonEntry.dt,
        weekday: formatCityWeekday(noonEntry.dt, timezone.value),
        icon: noonEntry.weather[0].icon,
        max: configStore.convert(Math.max(...temps)),
        min: configStore.convert(Math.min(...temps)),
      }
    })
})

const precipChance = computed(() => {
  const pops = hourly.value.map((entry) => entry.pop ?? 0)
  if (pops.length === 0) return 0
  return Math.round(Math.max(...pops) * 100)
})
</script>

<template>
  <div v-if="forecast" class="forecast">
    <div class="forecast-row sky-panel">
      <div v-for="entry in hourly" :key="entry.dt" class="hour-slot">
        <p class="hour-label">{{ formatCityHour(entry.dt, timezone) }}</p>
        <span class="hour-icon">{{ iconGlyph(entry.weather[0].icon) }}</span>
        <p class="hour-temp">{{ configStore.convert(entry.main.temp) }}°</p>
      </div>
    </div>

    <div class="forecast-columns">
      <div class="daily-card sky-panel">
        <p class="card-title">5일간의 예보</p>
        <div v-for="day in daily" :key="day.key" class="day-row">
          <span class="day-weekday">{{ day.weekday }}</span>
          <span class="day-icon">{{ iconGlyph(day.icon) }}</span>
          <span class="day-low">{{ day.min }}°</span>
          <span class="day-bar" aria-hidden="true" />
          <span class="day-high">{{ day.max }}°</span>
        </div>
      </div>

      <div class="precip-card sky-panel">
        <p class="card-title">강수 확률</p>
        <p class="precip-value">{{ precipChance }}%</p>
        <p class="precip-caption">앞으로 24시간 중 최고 강수 확률입니다.</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.forecast {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 14px;
}

.forecast-row {
  display: flex;
  gap: 18px;
  padding: 14px 16px;
  overflow-x: auto;
}

.hour-slot {
  flex: 0 0 auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  color: var(--text-on-sky);
}

.hour-label {
  margin: 0;
  font-size: 12px;
  font-weight: 500;
  color: var(--text-on-sky-dim);
}

.hour-icon {
  font-size: 18px;
}

.hour-temp {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
}

.forecast-columns {
  display: grid;
  grid-template-columns: 1.4fr 1fr;
  gap: 10px;
}

.card-title {
  margin: 0 0 10px;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: -0.01em;
  color: var(--text-on-sky-dim);
}

.daily-card {
  padding: 14px 16px;
}

.day-row {
  display: grid;
  grid-template-columns: 32px 24px 26px 1fr 26px;
  align-items: center;
  gap: 8px;
  padding: 6px 0;
  font-size: 13px;
  color: var(--text-on-sky);
}

.day-weekday {
  font-weight: 600;
}

.day-icon {
  font-size: 14px;
  text-align: center;
}

.day-low {
  color: var(--text-on-sky-dim);
  text-align: right;
}

.day-high {
  font-weight: 600;
}

.day-bar {
  height: 3px;
  border-radius: 999px;
  background: linear-gradient(90deg, #4fa8ea, #ff9f43, #ff5f57);
  opacity: 0.85;
}

.precip-card {
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
}

.precip-value {
  margin: 0;
  font-size: 30px;
  font-weight: 300;
  color: var(--text-on-sky);
}

.precip-caption {
  margin: 6px 0 0;
  font-size: 12px;
  line-height: 1.4;
  color: var(--text-on-sky-dim);
}
</style>
