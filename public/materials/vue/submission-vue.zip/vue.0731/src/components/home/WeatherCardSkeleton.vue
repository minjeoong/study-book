<script setup>
import Skeleton from '../shared/Skeleton.vue'
</script>

<template>
  <div class="city-card-skeleton">
    <div class="skeleton-head">
      <Skeleton variant="md" width="44%" height="15px" />
      <Skeleton variant="lg" width="46px" height="26px" />
    </div>
    <Skeleton variant="sm" width="34%" height="11px" />
    <div class="skeleton-foot">
      <Skeleton variant="sm" width="42%" height="11px" />
      <Skeleton variant="sm" width="34%" height="11px" />
    </div>
  </div>
</template>

<style scoped>
.city-card-skeleton {
  display: flex;
  flex-direction: column;
  gap: 9px;
  min-height: 96px;
  padding: 12px 14px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.1);
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.08);
}

.skeleton-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.skeleton-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-top: auto;
}
</style>
