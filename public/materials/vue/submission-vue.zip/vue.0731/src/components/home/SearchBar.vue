<script setup>
import SearchIcon from '../Icon/SearchIcon.vue'

defineProps({
  searchQuery: {
    type: String,
    required: true,
  },
  isFiltering: {
    type: Boolean,
    default: false,
  },
})

const emit = defineEmits(['update-query'])

function handleInput(event) {
  emit('update-query', event.target.value)
}

function clearQuery() {
  emit('update-query', '')
}
</script>

<template>
  <div class="search-bar">
    <div class="search-field">
      <SearchIcon class="search-icon" />
      <input class="search-input" placeholder="검색" :value="searchQuery" @input="handleInput" />
      <button
        v-if="searchQuery"
        type="button"
        class="clear-button"
        aria-label="검색어 지우기"
        @click="clearQuery"
      >
        ×
      </button>
    </div>

    <p v-if="searchQuery" class="search-status">
      <span>{{ searchQuery }}</span>
      {{ isFiltering ? ' 입력 중...' : ' 검색 결과' }}
    </p>
  </div>
</template>

<style scoped>
.search-field {
  position: relative;
}

.search-icon {
  position: absolute;
  top: 50%;
  left: 9px;
  transform: translateY(-50%);
  width: 14px;
  height: 14px;
  color: rgba(255, 255, 255, 0.55);
  pointer-events: none;
}

.search-input {
  width: 100%;
  height: 30px;
  padding: 0 30px 0 28px;
  font-family: inherit;
  font-size: 13px;
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.14);
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.12);
  outline: none;
  backdrop-filter: blur(12px) saturate(160%);
  -webkit-backdrop-filter: blur(12px) saturate(160%);
  transition:
    background 0.18s ease,
    border-color 0.18s ease;
}

.search-input::placeholder {
  color: rgba(255, 255, 255, 0.5);
}

.search-input:focus {
  background: rgba(255, 255, 255, 0.18);
  border-color: rgba(255, 255, 255, 0.32);
}

.clear-button {
  position: absolute;
  top: 50%;
  right: 7px;
  transform: translateY(-50%);
  width: 18px;
  height: 18px;
  padding: 0;
  display: grid;
  place-items: center;
  border: none;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.24);
  color: rgba(255, 255, 255, 0.9);
  font-size: 13px;
  line-height: 1;
  cursor: pointer;
}

.clear-button:hover {
  background: rgba(255, 255, 255, 0.38);
}

.search-status {
  margin: 8px 2px 0;
  font-size: 11px;
  color: rgba(255, 255, 255, 0.5);
}

.search-status span {
  font-weight: 600;
  color: rgba(255, 255, 255, 0.82);
}
</style>
