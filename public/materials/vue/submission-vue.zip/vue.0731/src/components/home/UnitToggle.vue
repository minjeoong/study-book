<script setup>
import { useConfigStore } from '@/stores/configStore'

const configStore = useConfigStore()
</script>

<template>
  <div class="unit-toggle" role="group" aria-label="온도 단위">
    <button
      type="button"
      class="unit-option"
      :class="{ 'is-active': configStore.unit === 'celsius' }"
      :aria-pressed="configStore.unit === 'celsius'"
      @click="configStore.setUnit('celsius')"
    >
      °C
    </button>
    <button
      type="button"
      class="unit-option"
      :class="{ 'is-active': configStore.unit === 'fahrenheit' }"
      :aria-pressed="configStore.unit === 'fahrenheit'"
      @click="configStore.setUnit('fahrenheit')"
    >
      °F
    </button>
  </div>
</template>

<style scoped>
.unit-toggle {
  display: flex;
  gap: 2px;
  padding: 2px;
  border-radius: 9px;
  background: rgba(255, 255, 255, 0.16);
  border: 1px solid rgba(255, 255, 255, 0.18);
  backdrop-filter: blur(18px) saturate(140%);
  -webkit-backdrop-filter: blur(18px) saturate(140%);
}

.unit-option {
  min-width: 36px;
  padding: 5px 8px;
  border: none;
  border-radius: 7px;
  background: transparent;
  color: rgba(255, 255, 255, 0.78);
  font-family: inherit;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition:
    background-color 0.18s ease,
    color 0.18s ease;
}

.unit-option:hover {
  color: #fff;
}

.unit-option.is-active {
  color: #1c2230;
  background: rgba(255, 255, 255, 0.92);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.18);
}
</style>
