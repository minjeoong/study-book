<script setup>
import { useConfigStore } from '@/stores/configStore'
import { iconGlyph } from '@/util/weatherTheme'

/**
 * @description 시간별 예보 컴포넌트
 */

defineProps({
  summary: {
    type: String,
    default: '',
  },
  hours: {
    type: Array,
    default: () => [],
  },
})

const configStore = useConfigStore()
</script>

<template>
  <section class="hourly sky-panel">
    <p v-if="summary" class="hourly-summary">{{ summary }}</p>

    <div class="hourly-track" role="list">
      <div v-for="hour in hours" :key="hour.key" class="hourly-item" role="listitem">
        <p class="hourly-label" :class="{ 'is-now': hour.key === 'now' }">{{ hour.label }}</p>
        <p class="hourly-glyph" aria-hidden="true">{{ iconGlyph(hour.icon) }}</p>
        <p class="hourly-temp">
          <template v-if="hour.note">{{ hour.note }}</template>
          <template v-else>{{ configStore.convert(hour.temp) }}°</template>
        </p>
      </div>
    </div>
  </section>
</template>

<style scoped>
.hourly {
  padding: 14px 4px 16px;
}

.hourly-summary {
  margin: 0 16px 12px;
  padding-bottom: 12px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 13px;
  line-height: 1.5;
  color: var(--text-on-sky);
}

.hourly-track {
  display: flex;
  gap: 2px;
  padding: 0 10px;
  overflow-x: auto;
  scrollbar-width: none;
}

.hourly-track::-webkit-scrollbar {
  display: none;
}

.hourly-item {
  flex: 1 0 68px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 2px 6px;
  color: var(--text-on-sky);
}

.hourly-label {
  margin: 0;
  font-size: 12px;
  font-weight: 500;
  white-space: nowrap;
  color: rgba(255, 255, 255, 0.85);
}

.hourly-label.is-now {
  font-weight: 700;
  color: #fff;
}

.hourly-glyph {
  margin: 0;
  font-size: 20px;
  line-height: 1;
}

.hourly-temp {
  margin: 0;
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.01em;
  white-space: nowrap;
}
</style>
