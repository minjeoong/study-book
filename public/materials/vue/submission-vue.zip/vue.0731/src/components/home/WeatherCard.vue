<script setup>
import { computed } from 'vue'
import { useConfigStore } from '@/stores/configStore'
import { cardSky, iconGlyph } from '@/util/weatherTheme'
import { formatCityTime } from '@/util/format'

const props = defineProps({
  city: {
    type: Object,
    required: true,
  },
  isSelected: {
    type: Boolean,
    default: false,
  },
})

const emit = defineEmits(['select-card', 'click-detail'])

const configStore = useConfigStore()

const temp = computed(() => configStore.convert(props.city.temp))
const tempMax = computed(() => configStore.convert(props.city.tempMax))
const tempMin = computed(() => configStore.convert(props.city.tempMin))
const localTime = computed(() => formatCityTime(props.city.dt, props.city.timezone))
const sky = computed(() => cardSky(props.city.icon))
const glyph = computed(() => iconGlyph(props.city.icon))

function handleSelect() {
  emit('select-card', props.city)
}

function handleDetail(event) {
  event.stopPropagation()
  emit('click-detail', props.city)
}
</script>

<template>
  <div
    class="city-card"
    :class="{ 'is-selected': isSelected }"
    :style="{ backgroundImage: sky }"
    role="button"
    tabindex="0"
    :aria-pressed="isSelected"
    @click="handleSelect"
    @keydown.enter.prevent="handleSelect"
    @keydown.space.prevent="handleSelect"
  >
    <div class="card-head">
      <p class="card-name">{{ city.name }}</p>
      <p class="card-temp">{{ temp }}°</p>
    </div>

    <p class="card-time">{{ localTime }}</p>

    <div class="card-foot">
      <p class="card-condition">
        <span class="card-glyph" aria-hidden="true">{{ glyph }}</span>
        {{ city.description }}
      </p>
      <p class="card-range">최고:{{ tempMax }}° 최저:{{ tempMin }}°</p>
      <button type="button" class="card-detail" @click="handleDetail">
        상세보기
        <svg viewBox="0 0 8 14" aria-hidden="true">
          <path
            d="M1 1L7 7L1 13"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </button>
    </div>
  </div>
</template>

<style scoped>
.city-card {
  position: relative;
  display: flex;
  flex-direction: column;
  min-height: 96px;
  padding: 11px 14px 10px;
  border-radius: 12px;
  color: #fff;
  cursor: pointer;
  overflow: hidden;
  background-size: cover;
  box-shadow:
    inset 0 0 0 1px rgba(255, 255, 255, 0.1),
    0 4px 12px rgba(0, 0, 0, 0.22);
  transition:
    box-shadow 0.2s ease,
    filter 0.2s ease;
}

.city-card:hover {
  filter: brightness(1.06);
}

.city-card:focus-visible {
  outline: 2px solid rgba(255, 255, 255, 0.85);
  outline-offset: -2px;
}

.city-card.is-selected {
  box-shadow:
    inset 0 0 0 3px #ffffffa8,
    0 6px 30px rgba(0, 0, 0, 0.05);
}

.card-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px;
}

.card-name {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  letter-spacing: -0.01em;
  text-shadow: 0 1px 3px rgba(0, 0, 0, 0.25);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.card-temp {
  margin: -4px 0 0;
  font-size: 32px;
  font-weight: 300;
  line-height: 1;
  letter-spacing: -0.02em;
  text-shadow: 0 1px 4px rgba(0, 0, 0, 0.22);
}

.card-time {
  margin: 1px 0 0;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.85);
  text-shadow: 0 1px 3px rgba(0, 0, 0, 0.22);
}

.card-foot {
  position: relative;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 8px;
  margin-top: auto;
  padding-top: 12px;
}

.card-condition {
  margin: 0;
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.92);
  text-shadow: 0 1px 3px rgba(0, 0, 0, 0.22);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.card-glyph {
  font-size: 11px;
  line-height: 1;
}

.card-range {
  margin: 0;
  flex-shrink: 0;
  font-size: 11px;
  color: rgba(255, 255, 255, 0.88);
  text-shadow: 0 1px 3px rgba(0, 0, 0, 0.22);
  transition: opacity 0.16s ease;
}

.card-detail {
  position: absolute;
  right: 0;
  bottom: 0;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 3px 8px;
  border: none;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.26);
  color: #fff;
  font-family: inherit;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  opacity: 0;
  pointer-events: none;
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
  transition: opacity 0.16s ease;
}

.card-detail svg {
  width: 5px;
  height: 9px;
}

.city-card:hover .card-range,
.city-card:focus-within .card-range {
  opacity: 0;
}

.city-card:hover .card-detail,
.city-card:focus-within .card-detail {
  opacity: 1;
  pointer-events: auto;
}

.card-detail:hover {
  background: rgba(255, 255, 255, 0.4);
}
</style>
