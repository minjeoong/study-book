<script setup>
import { computed } from 'vue'
import { useConfigStore } from '@/stores/configStore'
import { formatSunTime } from '@/util/format'
import { iconGlyph } from '@/util/weatherTheme'

const props = defineProps({
  weatherData: {
    type: Object,
    default: null,
  },
  isLoading: {
    type: Boolean,
    default: false,
  },
  error: {
    type: [Object, Boolean],
    default: null,
  },
  emptyText: {
    type: String,
    default: '해당 도시 정보를 찾을 수 없습니다.',
  },
})

const configStore = useConfigStore()

const heroIcon = computed(() => iconGlyph(props.weatherData?.weather?.[0]?.icon))

const sunrise = computed(() => {
  const data = props.weatherData
  if (!data) return '-'
  return formatSunTime(data.sys.sunrise, data.timezone)
})

const sunset = computed(() => {
  const data = props.weatherData
  if (!data) return '-'
  return formatSunTime(data.sys.sunset, data.timezone)
})
</script>

<template>
  <div class="weather-hero">
    <template v-if="weatherData">
      <p class="hero-city">{{ weatherData.name }}</p>
      <p class="hero-temp">
        {{ weatherData.main.temp }}<span class="hero-unit">{{ configStore.unitSymbol }}</span>
      </p>
      <p class="hero-condition">
        <span class="hero-icon">{{ heroIcon }}</span>{{ weatherData.weather[0].description }}
      </p>
      <p class="hero-range">
        최고 {{ weatherData.main.temp_max }}° 최저 {{ weatherData.main.temp_min }}°
      </p>

      <div class="stat-grid">
        <div class="stat-tile sky-panel">
          <p class="stat-label">체감</p>
          <p class="stat-value">{{ weatherData.main.feels_like }}{{ configStore.unitSymbol }}</p>
        </div>
        <div class="stat-tile sky-panel">
          <p class="stat-label">습도</p>
          <p class="stat-value">{{ weatherData.main.humidity }}%</p>
        </div>
        <div class="stat-tile sky-panel">
          <p class="stat-label">풍속</p>
          <p class="stat-value">{{ weatherData.wind.speed }} m/s</p>
        </div>
        <div class="stat-tile sky-panel">
          <p class="stat-label">일출</p>
          <p class="stat-value">{{ sunrise }}</p>
        </div>
        <div class="stat-tile sky-panel">
          <p class="stat-label">일몰</p>
          <p class="stat-value">{{ sunset }}</p>
        </div>
      </div>

      <p class="hero-footnote">도시 ID {{ weatherData.id }}</p>
    </template>
    <div v-else-if="error" class="state-panel">
      <el-alert title="날씨 정보를 불러오지 못했습니다." type="error" show-icon :closable="false" />
    </div>
    <div v-else-if="!isLoading" class="state-panel">
      <el-empty :description="emptyText" :image-size="80" />
    </div>
  </div>
</template>

<style scoped>
.weather-hero {
  position: relative;
  min-height: 220px;
  text-align: center;
  color: var(--text-on-sky);
}

.hero-city {
  margin: 0;
  font-size: 22px;
  font-weight: 600;
  letter-spacing: -0.01em;
}

.hero-temp {
  margin: 4px 0 0;
  font-size: 64px;
  font-weight: 200;
  line-height: 1;
}

.hero-unit {
  font-size: 30px;
  font-weight: 300;
}

.hero-condition {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  margin: 2px 0 0;
  font-size: 15px;
  font-weight: 500;
  color: var(--text-on-sky-dim);
}

.hero-icon {
  font-size: 15px;
}

.hero-range {
  margin: 4px 0 22px;
  font-size: 13px;
  font-weight: 600;
  color: var(--text-on-sky-dim);
}

.stat-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
  gap: 10px;
  text-align: left;
}

.stat-tile {
  padding: 12px 14px;
}

.stat-label {
  margin: 0 0 6px;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.02em;
  color: var(--text-on-sky-dim);
  text-transform: uppercase;
}

.stat-value {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: var(--text-on-sky);
}

.hero-footnote {
  margin: 14px 0 0;
  font-size: 11px;
  font-weight: 500;
  color: var(--text-on-sky-dim);
  text-align: center;
}

.state-panel {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 220px;
}
</style>
