<script setup>
import { computed } from 'vue'

/**
 * @description 강수량 지도 컴포넌트
 */

const props = defineProps({
  lat: {
    type: Number,
    default: null,
  },
  lon: {
    type: Number,
    default: null,
  },
  label: {
    type: String,
    default: '',
  },
  zoom: {
    type: Number,
    default: 5,
  },
})

const TILE_SIZE = 256
const OWM_KEY = import.meta.env.VITE_API_KEY

const focus = computed(() => {
  if (props.lat === null || props.lon === null) return null

  const scale = 2 ** props.zoom
  const rad = (props.lat * Math.PI) / 180
  const x = ((props.lon + 180) / 360) * scale
  const y = ((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2) * scale

  return { x, y, scale }
})

const tiles = computed(() => {
  if (!focus.value) return []

  const { x, y, scale } = focus.value
  const originX = Math.floor(x) - 1
  const originY = Math.floor(y) - 1
  const result = []

  for (let row = 0; row < 3; row += 1) {
    for (let col = 0; col < 3; col += 1) {
      const tileX = (((originX + col) % scale) + scale) % scale
      const tileY = originY + row
      if (tileY < 0 || tileY >= scale) continue

      result.push({
        key: `${tileX}-${tileY}`,
        base: `https://basemaps.cartocdn.com/rastertiles/voyager/${props.zoom}/${tileX}/${tileY}.png`,
        rain: `https://tile.openweathermap.org/map/precipitation_new/${props.zoom}/${tileX}/${tileY}.png?appid=${OWM_KEY}`,
        left: col * TILE_SIZE,
        top: row * TILE_SIZE,
      })
    }
  }

  return result
})

const layerStyle = computed(() => {
  if (!focus.value) return {}
  const { x, y } = focus.value
  const offsetX = (x - (Math.floor(x) - 1)) * TILE_SIZE
  const offsetY = (y - (Math.floor(y) - 1)) * TILE_SIZE
  return { transform: `translate(${-offsetX}px, ${-offsetY}px)` }
})
</script>

<template>
  <div class="rain-map">
    <div v-if="tiles.length > 0" class="tile-layer" :style="layerStyle">
      <img
        v-for="tile in tiles"
        :key="`base-${tile.key}`"
        class="tile tile--base"
        :style="{ left: `${tile.left}px`, top: `${tile.top}px` }"
        :src="tile.base"
        alt=""
        loading="lazy"
      />
      <img
        v-for="tile in tiles"
        :key="`rain-${tile.key}`"
        class="tile tile--rain"
        :style="{ left: `${tile.left}px`, top: `${tile.top}px` }"
        :src="tile.rain"
        alt=""
        loading="lazy"
      />
    </div>

    <span v-if="label" class="map-marker">{{ label }}</span>
  </div>
</template>

<style scoped>
.rain-map {
  position: relative;
  height: 100%;
  min-height: 148px;
  border-radius: 12px;
  overflow: hidden;
  background: linear-gradient(180deg, #29394f 0%, #1e2a3c 100%);
}

.tile-layer {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 768px;
  height: 768px;
}

.tile {
  position: absolute;
  width: 256px;
  height: 256px;
}

.tile--base {
  filter: saturate(0.85) brightness(0.96);
}

.tile--rain {
  opacity: 0.85;
}

.map-marker {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  padding: 3px 10px;
  border-radius: 999px;
  background: #2f6fd0;
  color: #fff;
  font-size: 12px;
  font-weight: 700;
  box-shadow:
    0 0 0 2px rgba(255, 255, 255, 0.85),
    0 4px 10px rgba(0, 0, 0, 0.3);
}
</style>
