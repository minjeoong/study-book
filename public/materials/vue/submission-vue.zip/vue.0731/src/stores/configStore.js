import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

/**
 * @description 날씨 단위를 세팅하는 스토어
 */
export const useConfigStore = defineStore('config', () => {
  const unit = ref('celsius')

  const unitSymbol = computed(() => {
    return unit.value === 'celsius' ? '°C' : '°F'
  })

  function toggleUnit() {
    unit.value = unit.value === 'celsius' ? 'fahrenheit' : 'celsius'
  }

  function setUnit(next) {
    unit.value = next
  }

  /** 섭씨 원본값을 현재 단위에 맞춰 정수로 변환한다. */
  function convert(celsius) {
    if (celsius === null || celsius === undefined || Number.isNaN(Number(celsius))) return null
    const value = Number(celsius)
    return Math.round(unit.value === 'fahrenheit' ? (value * 9) / 5 + 32 : value)
  }

  return {
    unit,
    unitSymbol,
    toggleUnit,
    setUnit,
    convert,
  }
})
