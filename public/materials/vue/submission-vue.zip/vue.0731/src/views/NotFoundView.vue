<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

function goHome() {
  router.push('/')
}
</script>

<template>
  <div class="route-page">
    <div class="not-found sky-panel">
      <h1>404</h1>
      <p>페이지를 찾을 수 없습니다.</p>
      <button type="button" class="glass-button" @click="goHome">홈으로 돌아가기</button>
    </div>
  </div>
</template>

<style scoped>
.not-found {
  padding: 48px 24px;
  text-align: center;
}

h1 {
  margin: 0 0 8px;
  font-size: 48px;
  letter-spacing: -0.03em;
  color: var(--text-on-sky);
}

p {
  margin: 0 0 20px;
  color: var(--text-on-sky-dim);
}
</style>
