<script setup>
import { useRoute, useRouter } from 'vue-router'
import { ref, watch } from 'vue'
import { getWeatherById } from '@/api/weather-hooks'
import WeatherHero from '@/components/home/WeatherHero.vue'
import ChevronLeftIcon from '@/components/Icon/ChevronLeftIcon.vue'

const route = useRoute()
const router = useRouter()

const weatherData = ref(null)
const isLoading = ref(false)
const error = ref(null)

function goHome() {
  router.push('/')
}

const fetchWeather = async () => {
  const id = route.params.id
  if (!id) {
    weatherData.value = null
    error.value = null
    return
  }
  isLoading.value = true
  error.value = null

  try {
    weatherData.value = await getWeatherById(id)
  } catch (err) {
    weatherData.value = null
    error.value = err
    console.error(err)
  } finally {
    isLoading.value = false
  }
}

watch(
  () => route.params.id,
  () => fetchWeather(),
  { immediate: true },
)
</script>

<template>
  <div class="route-page" v-loading="isLoading" element-loading-text="날씨 정보를 불러오는 중...">
    <button type="button" class="back-link" @click="goHome">
      <ChevronLeftIcon />
      날씨
    </button>

    <WeatherHero :weather-data="weatherData" :is-loading="isLoading" :error="error" />
  </div>
</template>

<style scoped>
.back-link {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin: 0 0 16px;
  padding: 4px 2px;
  border: none;
  background: transparent;
  color: var(--text-on-sky);
  font-size: 15px;
  font-weight: 500;
  cursor: pointer;
}
</style>
