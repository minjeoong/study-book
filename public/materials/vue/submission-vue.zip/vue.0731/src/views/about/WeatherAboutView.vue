<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

const FEATURES = [
  { icon: '🔍', title: '도시 검색', desc: '입력 debounce로 타이핑이 멈추면 결과를 갱신' },
  { icon: '🏙️', title: '도시 카드', desc: '선택 / 상세보기, 날씨별 하늘 그라디언트 배경' },
  { icon: '📈', title: '시간별 · 5일 예보', desc: '현재 온도부터 강수 확률까지 한눈에' },
  { icon: '🌡️', title: '단위 전환', desc: '섭씨 ↔ 화씨, 전체 화면에 즉시 반영' },
  { icon: '📍', title: '위치 알림', desc: '현재 위치 날씨를 토스트로 안내' },
  { icon: '🚦', title: '라우팅', desc: '라우트 지연 로딩 + Catch-all(404) 처리' },
]

const STACK = ['Vue 3', 'Vite', 'Vue Router', 'Pinia', 'Axios', 'Element Plus']

function goHome() {
  router.push('/')
}
</script>

<template>
  <div class="route-page">
    <div class="weather-about sky-panel">
      <div class="about-header">
        <span class="about-emoji" aria-hidden="true">🌤️</span>
        <div>
          <h2 class="about-title">날씨 대시보드</h2>
          <p class="about-subtitle">Vue 3 실습 과제 · 판교 9반 P282 김민정</p>
        </div>
      </div>

      <p class="about-lead">
        OpenWeatherMap API로 도시별 날씨와 예보를 조회하는 학습용 대시보드입니다. iPhone
        잠금화면 인트로를 지나면 macOS Weather 앱을 재현한 화면에서 도시를 검색하고 선택해
        상세 날씨를 확인할 수 있어요.
      </p>

      <div class="about-grid">
        <div v-for="feature in FEATURES" :key="feature.title" class="about-feature">
          <span class="feature-icon" aria-hidden="true">{{ feature.icon }}</span>
          <p class="feature-title">{{ feature.title }}</p>
          <p class="feature-desc">{{ feature.desc }}</p>
        </div>
      </div>

      <div class="about-stack">
        <span v-for="tech in STACK" :key="tech" class="stack-badge">{{ tech }}</span>
      </div>

      <button type="button" class="glass-button about-back" @click="goHome">
        🏠 메인 대시보드로 돌아가기
      </button>
    </div>
  </div>
</template>

<style scoped>
.weather-about {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 22px 24px;
}

.about-header {
  display: flex;
  align-items: center;
  gap: 12px;
}

.about-emoji {
  font-size: 30px;
  line-height: 1;
}

.about-title {
  margin: 0;
  font-size: 19px;
  font-weight: 700;
  letter-spacing: -0.02em;
  color: var(--text-on-sky);
}

.about-subtitle {
  margin: 3px 0 0;
  font-size: 12px;
  font-weight: 500;
  color: var(--text-on-sky-dim);
}

.about-lead {
  margin: 0;
  font-size: 13px;
  line-height: 1.6;
  color: var(--text-on-sky-dim);
}

.about-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}

.about-feature {
  padding: 12px 12px 13px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.07);
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.feature-icon {
  font-size: 16px;
}

.feature-title {
  margin: 6px 0 3px;
  font-size: 12.5px;
  font-weight: 700;
  color: var(--text-on-sky);
}

.feature-desc {
  margin: 0;
  font-size: 11px;
  line-height: 1.45;
  color: var(--text-on-sky-dim);
}

.about-stack {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.stack-badge {
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  color: var(--text-on-sky);
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.14);
}

.about-back {
  align-self: flex-start;
  margin-top: 2px;
}
</style>
