<script setup>
import { onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import PhoneIntro from '@/components/home/PhoneIntro.vue'
import { INTRO_DONE_KEY } from '@/router/intro'

const router = useRouter()

onMounted(() => {
  document.body.classList.add('is-intro')
  document.body.classList.remove('is-desktop')
})

onUnmounted(() => {
  document.body.classList.remove('is-intro')
  document.body.classList.add('is-desktop')
})

function handleEnter() {
  sessionStorage.setItem(INTRO_DONE_KEY, '1')
  router.push({ name: 'home' })
}
</script>

<template>
  <PhoneIntro @enter="handleEnter" />
</template>
