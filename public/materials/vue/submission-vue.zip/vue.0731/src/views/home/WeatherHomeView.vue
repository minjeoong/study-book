<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch, watchEffect } from 'vue'
import SearchBar from '../../components/home/SearchBar.vue'
import WeatherCard from '../../components/home/WeatherCard.vue'
import WeatherCardSkeleton from '../../components/home/WeatherCardSkeleton.vue'
import WeatherHero from '../../components/home/WeatherHero.vue'
import WeatherForecast from '../../components/home/WeatherForecast.vue'
import { useRouter } from 'vue-router'
import { getForecastById, getWeatherById, getWeatherGroup } from '../../api/weather-hooks'
import { notifyCurrentLocationWeather } from '../../hooks/notifyCurrentLocationWeather'

const DEBOUNCE_MS = 300

const CITY_LABELS = {
  1835848: '서울',
  1835553: '수원',
  1838519: '부산',
}

const SEED_IDS = Object.keys(CITY_LABELS).map(Number)

let debounceTimer = null
const searchQuery = ref('')
const debouncedQuery = ref('')
const weatherList = ref([])
const isLoading = ref(false)
const error = ref(null)
const selectedCityInfo = reactive({})
const router = useRouter()

const selectedDetail = ref(null)
const selectedForecast = ref(null)
const isDetailLoading = ref(false)
const detailError = ref(null)

const filteredWeatherList = computed(() => {
  const keyword = debouncedQuery.value.trim().toLowerCase()
  if (!keyword) return weatherList.value

  return weatherList.value.filter((weather) =>
    [weather.name, weather.enName].some((label) => label?.toLowerCase().includes(keyword)),
  )
})

const isFiltering = computed(() => searchQuery.value !== debouncedQuery.value)

function updateQuery(query) {
  searchQuery.value = query
}

async function loadDetail(id) {
  isDetailLoading.value = true
  detailError.value = null
  try {
    const [weather, forecast] = await Promise.all([getWeatherById(id), getForecastById(id)])
    selectedDetail.value = weather
    selectedForecast.value = forecast
  } catch (err) {
    detailError.value = err
    selectedDetail.value = null
    selectedForecast.value = null
  } finally {
    isDetailLoading.value = false
  }
}

function selectCard(weather) {
  Object.assign(selectedCityInfo, weather)
  loadDetail(weather.id)
}

function clickDetail(city) {
  router.push(`/weather/${city.id}`)
}

function mapGroupItemToCity(item) {
  return {
    id: String(item.id),
    name: CITY_LABELS[item.id] ?? item.name,
    enName: item.name,
    description: item.weather?.[0]?.description,
    icon: item.weather?.[0]?.icon,
    temp: item.main?.temp,
    tempMax: item.main?.temp_max,
    tempMin: item.main?.temp_min,
    dt: item.dt,
    timezone: item.timezone,
  }
}

async function fetchSeedGroupWeather() {
  isLoading.value = true
  error.value = null
  try {
    const response = await getWeatherGroup(SEED_IDS)
    const list = response?.list ?? []
    weatherList.value = list.map(mapGroupItemToCity)

    if (weatherList.value.length > 0) {
      selectCard(weatherList.value[0])
    }
  } catch (err) {
    error.value = err
  } finally {
    isLoading.value = false
  }
}

onMounted(() => {
  fetchSeedGroupWeather()
  notifyCurrentLocationWeather()
})

/** watch 로 검색어 debounce 처리 */
watch(searchQuery, (value) => {
  clearTimeout(debounceTimer)

  if (value === '') {
    debouncedQuery.value = ''
    return
  }

  debounceTimer = setTimeout(() => {
    debouncedQuery.value = value
  }, DEBOUNCE_MS)
})

/** watchEffect 과제 요구사항 */
watchEffect(() => {
  console.log(`[검색어] ${searchQuery.value || '(전체)'}`)
})

/** watch 과제 요구사항 */
watch(
  () => selectedCityInfo.name,
  (name) => {
    if (!name) return
    console.log(`[상태바] ${name}이 선택되었습니다.`)
  },
)

onUnmounted(() => {
  clearTimeout(debounceTimer)
})
</script>

<template>
  <div class="weather-app">
    <aside class="weather-sidebar">
      <SearchBar
        :search-query="searchQuery"
        :is-filtering="isFiltering"
        @update-query="updateQuery"
      />

      <p class="status-bar" v-if="selectedCityInfo.name">
        {{ selectedCityInfo.name }}이 선택되었습니다.
      </p>

      <div v-if="isLoading" class="weather-list" aria-busy="true" aria-live="polite">
        <WeatherCardSkeleton />
        <WeatherCardSkeleton />
        <WeatherCardSkeleton />
      </div>
      <div v-else-if="error" class="state-panel">
        <el-alert
          title="날씨 정보를 불러오지 못했습니다."
          type="error"
          show-icon
          :closable="false"
        />
      </div>
      <div v-else-if="filteredWeatherList.length === 0" class="state-panel">
        <el-empty description="검색 결과가 없습니다." :image-size="64" />
      </div>
      <div v-else class="weather-list">
        <WeatherCard
          v-for="weather in filteredWeatherList"
          :key="weather.id"
          :city="weather"
          :is-selected="selectedCityInfo.id === weather.id"
          @select-card="selectCard"
          @click-detail="clickDetail"
        />
      </div>
    </aside>

    <section
      class="weather-detail-pane"
      v-loading="isDetailLoading"
      element-loading-text="날씨 정보를 불러오는 중..."
    >
      <WeatherHero
        :weather-data="selectedDetail"
        :is-loading="isDetailLoading"
        :error="detailError"
        empty-text="왼쪽에서 도시를 선택해보세요"
      />
      <WeatherForecast v-if="selectedDetail" :forecast="selectedForecast" />
    </section>
  </div>
</template>

<style scoped>
.weather-app {
  flex: 1;
  display: flex;
  min-width: 0;
  min-height: 0;
}

.weather-sidebar {
  flex: 0 0 280px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 54px 14px 20px;
  overflow-y: auto;
  background: var(--sidebar-bg);
  border-right: 1px solid var(--sidebar-border);
  backdrop-filter: blur(24px) saturate(160%);
  -webkit-backdrop-filter: blur(24px) saturate(160%);
}

.weather-detail-pane {
  position: relative;
  flex: 1;
  min-width: 0;
  min-height: 0;
  padding: 54px 28px 28px;
  overflow-y: auto;
}

.state-panel {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 140px;
  padding: 24px;
  border-radius: var(--radius-card);
  background: var(--glass-bg-soft);
  border: 1px solid var(--glass-border-soft);
  font-size: 14px;
  font-weight: 600;
  color: var(--text-secondary);
}

.status-bar {
  min-height: 16px;
  margin: 0;
  font-size: 12px;
  font-weight: 600;
  color: var(--accent-green);
}

.weather-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
</style>
