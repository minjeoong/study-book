import { ElNotification } from 'element-plus'
import { getWeather } from '../api/weather-hooks'
import { buildWeatherNotice } from '../util/weatherNotice'

/**
 * @description 현재 위치 기반 날씨 알림을 보여준다.
 */
export function notifyCurrentLocationWeather() {
  if (!navigator.geolocation) return

  navigator.geolocation.getCurrentPosition(
    async ({ coords }) => {
      try {
        const data = await getWeather(coords.latitude, coords.longitude)
        const notice = buildWeatherNotice({
          name: data.name,
          description: data.weather?.[0]?.description,
          temp: data.main?.temp,
        })

        ElNotification({
          ...notice,
          duration: 6000,
          position: 'top-right',
        })
      } catch {
        // 위치 기반 날씨 조회 실패 시
      }
    },
    () => {},
  )
}
