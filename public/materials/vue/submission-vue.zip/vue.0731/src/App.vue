<script setup>
import { computed, onUnmounted, watch } from 'vue'
import { RouterLink, RouterView, useRoute } from 'vue-router'
import MacWindowLayout from './components/shared/MacWindowLayout.vue'
import UnitToggle from './components/home/UnitToggle.vue'

const route = useRoute()
const showLayout = computed(() => route.meta.layout !== false)

watch(
  showLayout,
  (value) => {
    document.body.classList.toggle('is-intro', !value)
    document.body.classList.toggle('is-desktop', value)
  },
  { immediate: true },
)

onUnmounted(() => {
  document.body.classList.remove('is-intro', 'is-desktop')
})
</script>

<template>
  <RouterView v-if="!showLayout" />

  <Transition name="desktop-reveal">
    <MacWindowLayout v-if="showLayout">
      <template #toolbar>
        <nav class="window-nav" aria-label="주요 메뉴">
          <RouterLink to="/" exact-active-class="is-active">날씨</RouterLink>
          <RouterLink to="/about" active-class="is-active">소개</RouterLink>
        </nav>
        <UnitToggle />
      </template>

      <RouterView />
    </MacWindowLayout>
  </Transition>
</template>

<style>
body.is-intro {
  background: #050505 !important;
  animation: none !important;
}

.window-nav {
  display: flex;
  gap: 2px;
  padding: 2px;
  border-radius: 9px;
  background: rgba(255, 255, 255, 0.16);
  border: 1px solid rgba(255, 255, 255, 0.18);
  backdrop-filter: blur(18px) saturate(140%);
  -webkit-backdrop-filter: blur(18px) saturate(140%);
}

.window-nav a {
  padding: 5px 14px;
  border-radius: 7px;
  font-size: 12px;
  font-weight: 600;
  letter-spacing: -0.01em;
  text-decoration: none;
  color: rgba(255, 255, 255, 0.78);
  transition:
    background-color 0.18s ease,
    color 0.18s ease;
}

.window-nav a:hover {
  color: #fff;
}

.window-nav a.is-active {
  color: #1c2230;
  background: rgba(255, 255, 255, 0.92);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.18);
}

.window-nav a:focus-visible {
  outline: 2px solid rgba(255, 255, 255, 0.8);
  outline-offset: 1px;
}

.desktop-reveal-enter-active {
  transition:
    opacity 1s ease,
    transform 1.15s cubic-bezier(0.22, 1, 0.36, 1);
}

.desktop-reveal-enter-from {
  opacity: 0;
  transform: translateY(24px) scale(0.96);
}

.desktop-reveal-enter-to {
  opacity: 1;
  transform: translateY(0) scale(1);
}

@media (prefers-reduced-motion: reduce) {
  .desktop-reveal-enter-active {
    transition-duration: 0.5s !important;
  }
}
</style>
