import { api } from './index'

export const getWeather = async (lat, lon) => {
  const response = await api.get('/weather', {
    params: { lat, lon },
  })
  return response.data
}

export const getWeatherById = async (id) => {
  const response = await api.get('/weather', {
    params: { id },
  })
  return response.data
}

export const getWeatherGroup = async (ids) => {
  const list = await Promise.all(ids.map((id) => getWeatherById(id)))
  return { list }
}

export const getForecastById = async (id) => {
  const response = await api.get('/forecast', {
    params: { id },
  })
  return response.data
}

export const getWeatherList = async (query) => {
  const response = await api.get('/weather', {
    params: { q: query },
  })
  return response.data
}
