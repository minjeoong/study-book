import axios from 'axios'

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  params: {
    appid: import.meta.env.VITE_API_KEY,
    units: 'metric',
    lang: 'kr',
  },
})
