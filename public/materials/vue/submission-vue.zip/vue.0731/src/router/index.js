import { createRouter, createWebHistory } from 'vue-router'
import { hasFinishedIntro } from './intro'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/intro',
      name: 'intro',
      component: () => import('../views/intro/IntroView.vue'),
      meta: { layout: false },
    },
    {
      path: '/',
      name: 'home',
      component: () => import('../views/home/WeatherHomeView.vue'),
    },
    {
      path: '/weather/:id',
      name: 'weather-detail',
      component: () => import('../views/detail/WeatherDetailView.vue'),
    },
    {
      path: '/about',
      name: 'about',
      component: () => import('../views/about/WeatherAboutView.vue'),
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'not-found',
      component: () => import('../views/NotFoundView.vue'),
    },
  ],
})

/** 첫 진입(홈)만 인트로 */
router.beforeEach((to) => {
  if (to.name === 'intro') return true
  if (to.name === 'home' && !hasFinishedIntro()) {
    return { name: 'intro', replace: true }
  }
  return true
})

export default router
