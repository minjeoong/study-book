/** 인트로 페이지는 첫 진입만 띄우고, 404 페이지 등 에서는 보여지지 않도록 세팅하기 위한 헬퍼 함수 */

export const INTRO_DONE_KEY = 'weather-intro-done'

export function hasFinishedIntro() {
  return sessionStorage.getItem(INTRO_DONE_KEY) === '1'
}
