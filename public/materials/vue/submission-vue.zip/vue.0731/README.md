# 🌈 과제: 날씨 대시보드 (Weather Dashboard)
### 판교 9반 P282 김민정


Vue 3(Composition API) 실습 과제로 만든 날씨 대시보드입니다. [OpenWeatherMap](https://openweathermap.org/api) API로 도시별 날씨·예보를 조회하며, iPhone 잠금화면 인트로 → 실제 macOS **Weather 앱을 재현한 사이드바 + 상세 패널 UI**로 이어지는 화면 위에 검색 · 도시 선택 · 시간별/일별 예보 · 단위 전환 기능을 구현했습니다.

> 1. 실습 요구사항을 얼마나/어떻게 충족했는지 체크리스트로 정리하고 
> 2. 요구사항 외 추가로 구현한 부분의 의도와 구현 방식을 설명하는 데 중점을 두었습니다.

## 목차

- [기술 스택](#기술-스택)
- [실행 방법](#실행-방법)
- [프로젝트 구조](#프로젝트-구조)
- [실습 요구사항 충족 체크리스트](#실습-요구사항-충족-체크리스트)
  - [1일차 — 반응형 상태 · 컴포넌트 분리](#1일차--반응형-상태--컴포넌트-분리)
  - [2일차 — Vue Router](#2일차--vue-router)
  - [3일차 — Axios · 단위 토글 · Element Plus](#3일차--axios--단위-토글--element-plus)
  - [4일차 — 빌드 · 배포](#4일차--빌드--배포)
- [추가 구현 사항](#추가-구현-사항)
  - [1. macOS Weather 앱 UI 재현](#1-macos-weather-앱-ui-재현)
  - [2. 검색 Debounce](#2-검색-debounce)
  - [3. App.vue → MacWindowLayout 슬롯 분리](#3-appvue--macwindowlayout-슬롯-분리)
  - [4. 인트로 페이지 라우팅 분리](#4-인트로-페이지-라우팅-분리)
  - [5. iPhone 인트로 애니메이션](#5-iphone-인트로-애니메이션)
  - [6. 현재 위치 날씨 토스트 알림](#6-현재-위치-날씨-토스트-알림)

## 기술 스택

| 구분            | 사용 기술                                          |
| --------------- | -------------------------------------------------- |
| 프레임워크      | Vue 3 (`<script setup>`, Composition API)          |
| 빌드 도구       | Vite                                               |
| 라우팅          | Vue Router 4 (동적 임포트를 통한 라우트 지연 로딩) |
| 상태 관리       | Pinia                                              |
| HTTP 클라이언트 | Axios                                              |
| UI 컴포넌트     | Element Plus (Alert / Empty / Loading directive, Notification) |
| 코드 품질       | ESLint (flat config) + Prettier                    |

## 실행 방법

```sh
npm install
```

`.env.example`을 복사해 `.env` 파일을 만들고 OpenWeatherMap API 키를 넣습니다.

```sh
cp .env.example .env
```

```env
VITE_API_URL=https://api.openweathermap.org/data/2.5
VITE_API_KEY=발급받은_API_키
```

```sh
npm run dev       # 개발 서버
npm run build      # 프로덕션 빌드
npm run preview    # 빌드 결과 미리보기
npm run lint        # ESLint 검사 (자동 수정)
npm run format      # Prettier 포맷팅
```

> `.env`는 `.gitignore`에 등록되어 있어 커밋되지 않도록 세팅했습니다. 
> 실제 키 값은 `.env.example`을 참고해 로컬에서만 채워주세요!

## 프로젝트 구조

```
src/
├─ api/
│  ├─ index.js             # axios 인스턴스 (OpenWeatherMap 공통 파라미터)
│  └─ weather-hooks.js      # 날씨/예보 조회 함수 (getWeather, getWeatherById, getForecastById 등)
├─ components/
│  ├─ Icon/                 
│  ├─ home/                 # 홈 화면 전용 컴포넌트
│  │  ├─ SearchBar.vue
│  │  ├─ WeatherCard.vue         
│  │  ├─ WeatherCardSkeleton.vue
│  │  ├─ WeatherHero.vue         
│  │  ├─ WeatherForecast.vue     
│  │  ├─ UnitToggle.vue
│  │  └─ PhoneIntro.vue         
│  └─ shared/                 # 전역에서 쓰이는 컴포넌트
│     ├─ MacWindowLayout.vue     
│     └─ Skeleton.vue            
├─ hooks/
│  └─ notifyCurrentLocationWeather.js  
├─ router/
│  ├─ index.js              
│  └─ intro.js              
├─ stores/
│  └─ configStore.js         # 온도 단위(섭씨/화씨) 상태 스토어
├─ style/
│  └─ theme.css               # 디자인 토큰
├─ util/
│  ├─ format.js                # 날짜/시각 포맷 유틸 (도시 현지 시각 기준)
│  ├─ weatherTheme.js           # 날씨 아이콘 코드 → 이모지 / 카드 하늘 그라디언트 매핑
│  └─ weatherNotice.js           # 기온별 토스트 문구 생성
└─ views/
   ├─ intro/IntroView.vue        
   ├─ home/WeatherHomeView.vue    
   ├─ detail/WeatherDetailView.vue 
   ├─ about/WeatherAboutView.vue
   └─ NotFoundView.vue           
```

> 실습 가이드에서 제시한 `components/exercise/` 폴더 구조 대신, 컴포넌트를 실제 쓰임(화면 공통 `shared/` vs 홈 화면 전용 `home/`)에 따라 재배치했습니다. 파일 역할과 props/emits 계약은 요구사항과 동일합니다.
>
> `src/components/home/`에는 시간별/일별 예보와 강수 지도를 더 정교하게 그려보려고 실험한 `HourlyForecast.vue` / `DailyForecast.vue` / `PrecipitationMap.vue`, `src/util/forecast.js`도 함께 들어 있습니다. 현재 화면에는 더 단순한 `WeatherForecast.vue`가 연결되어 있고, 이 실험 컴포넌트들은 아직 어디에도 연결되지 않은 상태(다음 작업 후보)입니다.

## 실습 요구사항 충족 체크리스트

### 1일차 — 반응형 상태 · 컴포넌트 분리

| 요구사항 | 충족 여부 | 구현 위치 |
| --- | --- | --- |
| `searchQuery`, `selectedCityInfo`, `weatherList`를 반응형 상태로 정의 | ✅ | `WeatherHomeView.vue` — `ref`(searchQuery, weatherList), `reactive`(selectedCityInfo) |
| `computed`로 `filteredWeatherList` 구성 (검색어 포함 필터링) | ✅ | `WeatherHomeView.vue` — `filteredWeatherList = computed(...)` |
| `watch`로 `selectedCityInfo` 감시, 상태바 문구 변경 시 콘솔로그 | ✅ | `WeatherHomeView.vue` — `watch(() => selectedCityInfo.name, ...)` |
| `watchEffect`로 `searchQuery` 감시 (타이핑마다 로그) | ✅ | `WeatherHomeView.vue` — `watchEffect(() => console.log(...))` |
| 공통 레이아웃 컴포넌트 + `<slot>` 활용 | ✅ | `MacWindowLayout.vue` — `toolbar` / 기본(본문) 슬롯, `theme.css`의 `.sky-panel` / `.route-page` 공통 클래스 |
| `SearchBar.vue` props(`searchQuery`) / emits(`update-query`) | ✅ | `components/home/SearchBar.vue` |
| `WeatherCard.vue` props(`city`) / emits(`select-card`, `click-detail`) | ✅ | `components/home/WeatherCard.vue` |
| 컴포넌트별 `<style scoped>` 분리 | ✅ | 각 `.vue` 파일마다 `<style scoped>` 사용 |

> **참고**: 최초 구현에서는 `BaseDashboardCard.vue`라는 공통 래퍼 컴포넌트가 `<slot>` 요구사항을 담당했습니다. 이후 화면을 macOS Weather 앱처럼 **사이드바 + 상세 패널** 구조로 다시 짜면서 카드형 래퍼가 더 이상 레이아웃에 맞지 않아 제거했고, 같은 역할(공통 UI를 고정하고 콘텐츠만 갈아끼우기)은 `MacWindowLayout.vue`의 슬롯과 `theme.css`의 공통 클래스가 대신하고 있습니다.

### 2일차 — Vue Router

| 요구사항 | 충족 여부 | 구현 위치 |
| --- | --- | --- |
| 라우터 지연 로딩(Lazy Loading) | ✅ | `router/index.js` — 전 라우트 `() => import(...)` |
| Catch-all Route (404) | ✅ | `router/index.js` — `path: '/:pathMatch(.*)*'` → `NotFoundView` |
| `App.vue`에 Navigation Bar(`RouterLink`) + `RouterView` 배치 | ✅ | `App.vue` — `MacWindowLayout`의 `toolbar` 슬롯에 `RouterLink` 2개(날씨/소개), 본문에 `RouterView` |
| `WeatherHomeView.vue`로 메인 대시보드 구성 | ✅ | `views/home/WeatherHomeView.vue` |
| `WeatherAboutView.vue` 소개 내용 + "메인 대시보드로 돌아가기" | ✅ | `views/about/WeatherAboutView.vue` |

### 3일차 — Axios · 단위 토글 · Element Plus

| 요구사항 | 충족 여부 | 구현 위치 |
| --- | --- | --- |
| Axios 설치 및 API 인스턴스 구성 | ✅ | `package.json`, `api/index.js` |
| OpenWeatherMap API 키 연동 | ✅ | `.env` (`VITE_API_URL`, `VITE_API_KEY`) → `api/index.js` |
| 단위 토글 UI (`UnitToggle.vue`) | ✅ | `components/home/UnitToggle.vue` — 섭씨/화씨 버튼 2개로 직접 전환(`configStore.setUnit`) |
| Navigation Bar 옆에 배치 | ✅ | `App.vue` — `toolbar` 슬롯 안에서 내비게이션 링크 바로 옆에 배치 |
| 메인 · 상세 화면 모두에 단위 설정 반영 | ✅ | `WeatherCard.vue`, `WeatherHero.vue` — `configStore.convert()` / `unitSymbol` 참조 |
| Element Plus 적용 | ✅ | `ElAlert`(에러), `ElEmpty`(빈 결과), `v-loading` 디렉티브(로딩), `ElNotification`(토스트) |

### 4일차 — 빌드 · 배포

| 요구사항 | 충족 여부 | 구현 위치 |
| --- | --- | --- |
| 로딩 / 에러 / 빈 결과 상태 처리 | ✅ | `WeatherHomeView.vue`, `WeatherHero.vue` — 스켈레톤 · `el-alert` · `el-empty` · `v-loading` (아래 설명 참고) |
| ESLint 점검, 제출 과제에 Error 없음 | ✅ | `eslint.config.js` + `npm run lint` (Error 0건) |
| API 키를 환경 변수로 분리, Git에 업로드되지 않도록 함 | ✅ | `.env`는 `.gitignore` 등록(비커밋), `.env.example`로 필요한 키 안내 |
| Vite 빌드 후 `dist/`를 GitHub Pages로 정적 호스팅 | ✅  | `npm run build`로 `dist/` 생성까지는 확인, 배포 워크플로는 아직 구성하지 않음 |

**로딩 / 에러 / 빈 상태 처리**: 왼쪽 사이드바 목록은 스켈레톤(`WeatherCardSkeleton`) / 에러(`el-alert`) / 빈 결과(`el-empty`) 3가지 상태를 명시적으로 분기 처리합니다. 오른쪽 상세 패널은 도시를 클릭하면 `getWeatherById` + `getForecastById`를 동시에 호출하는데, 이 요청이 끝날 때까지 `WeatherHomeView.vue`의 `.weather-detail-pane` 전체에 `v-loading`을 걸어 온도 영역과 예보 카드가 한 번에 로딩 상태로 전환되도록 했습니다. 단독 상세 페이지(`/weather/:id`)도 같은 패턴(`.route-page`에 `v-loading`)을 재사용합니다.

> 처음에는 `v-loading`을 상세 정보 컴포넌트(`WeatherHero`) 안쪽에만 걸었더니, 도시를 바꿀 때 온도 영역만 스피너로 가려지고 그 아래 예보 카드는 이전 도시 데이터를 그대로 보여줘서 어색했습니다. 로딩 마스크를 상세 패널 전체로 옮기고 나서야 하나의 로딩 상태로 자연스럽게 묶였습니다.

> 실제 배포를 켜려면 `vite.config.js`에 저장소 이름에 맞는 `base` 경로를 지정하고, GitHub Actions(또는 다른 정적 호스팅)에서 `npm run build` 결과(`dist/`)를 올리는 워크플로를 추가하면 됩니다. Vue Router가 `createWebHistory()`(경로 기반 라우팅)를 쓰기 때문에, 정적 호스팅에 배포할 경우 `/weather/1835848`처럼 하위 경로를 새로고침했을 때 404가 나지 않도록 리다이렉트 처리([spa-github-pages](https://github.com/rafgraph/spa-github-pages) 기법 등)를 함께 준비해야 합니다.

## 추가 구현 사항

여기서부터는 실습 요구사항에는 없지만, 완성도를 높이기 위해 추가한 부분입니다.

### 1. macOS Weather 앱 UI 재현

**어떻게**: 인트로가 실제 iPhone 잠금화면을 재현하는 만큼, 잠금 해제 뒤에 이어지는 화면도 평범한 카드 그리드 대시보드보다는 macOS 네이티브 **Weather 앱**에 가까운 경험을 주고 싶어서 레이아웃을 다시 짰습니다.

- `MacWindowLayout.vue` — 빨강/노랑/초록 트래픽 라이트, 오른쪽 위에 떠 있는 툴바(`toolbar` 슬롯), 그리고 본문을 `--sky-day` 하늘 그라디언트로 채우는 3단 구조입니다.
- `WeatherHomeView.vue` — 왼쪽에 `280px` 고정 폭 사이드바(검색창 + 도시 카드 목록, 어두운 유리 배경 `--sidebar-bg`), 오른쪽에 선택한 도시의 상세 패널을 두는 2단 레이아웃입니다. 목록에서 도시를 클릭하면 `getWeatherById` + `getForecastById`를 동시에 호출해 상세 패널을 채웁니다.
- `WeatherCard.vue` — 사이드바의 각 도시 카드 배경은 `weatherTheme.js`의 `cardSky(icon)`으로 그립니다. OpenWeatherMap이 내려주는 아이콘 코드(`01d`, `10n` 등)를 낮/밤 여부(`isNightIcon`)와 날씨 그룹(맑음/구름/비/눈/안개…)에 맞춰 여러 겹의 그라디언트로 조합해 하늘을 흉내냅니다. 도시의 현지 시각도 `dt` + `timezone`으로 계산(`formatCityTime`)해 카드에 함께 보여줍니다.
- `WeatherHero.vue` + `WeatherForecast.vue` — 선택된 도시의 큰 온도/컨디션/최고·최저는 하늘 배경 위에 그대로 얹고, 체감·습도·풍속·일출·일몰은 반투명 유리 타일(`.sky-panel`)로 감쌌습니다. 그 아래로 `getForecastById`(3시간 간격 5일 예보)를 가공해 시간별 예보 스트립과 5일 예보, 강수 확률을 보여줍니다.

**왜 아이콘 코드를 기준으로 삼았는지**: 처음에는 `weather[0].description`(한글 설명, 예: "맑음")을 키로 아이콘/그라디언트를 매핑했습니다. 하지만 설명 텍스트는 API 언어 설정이나 문구가 바뀌면 매핑이 깨지기 쉬운 값입니다. 반면 아이콘 코드(`01d`~`50n`)는 OpenWeatherMap이 보장하는 고정된 값이라, 도시나 시간대에 상관없이 항상 같은 하늘/이모지로 안정적으로 매핑할 수 있습니다. `weatherTheme.js`에는 두 방식이 함께 남아 있는데(`weatherIcon`/`weatherGradient`는 구버전, `iconGlyph`/`cardSky`가 현재 쓰는 함수), 실제 컴포넌트는 전부 아이콘 코드 기반 함수만 사용합니다.

### 2. 검색 Debounce

**어떻게**: `WeatherHomeView.vue`에서 입력값(`searchQuery`)과 실제 필터링에 쓰이는 값(`debouncedQuery`)을 분리했습니다. `searchQuery`를 `watch`로 감시하다가 입력이 멈추면 300ms 뒤에 `debouncedQuery`를 갱신하고, 리스트는 `debouncedQuery` 기준으로만 필터링합니다.

```js
const DEBOUNCE_MS = 300
let debounceTimer = null

watch(searchQuery, (value) => {
  clearTimeout(debounceTimer)
  if (value === '') {
    debouncedQuery.value = ''
    return
  }
  debounceTimer = setTimeout(() => {
    debouncedQuery.value = value
  }, DEBOUNCE_MS)
})
```

타이핑 중인지 여부는 `isFiltering = computed(() => searchQuery.value !== debouncedQuery.value)`로 판단해서, `SearchBar.vue`에 `is-filtering` prop으로 내려줍니다. 검색어가 있을 때는 이 값에 따라 검색창 아래에 "입력 중..." / "검색 결과" 문구가 바뀝니다.

**왜 적용했는지**: 검색어를 입력하는 도중에도 매 타이핑마다 리스트를 즉시 필터링하면, 글자가 하나씩 늘어날 때마다 "일치 -> 불일치 -> 재일치"가 반복되면서 결과 화면(카드 목록 / 빈 결과 안내)이 계속 바뀌는 깜빡임이 발생합니다. 사용자가 입력을 마칠 때까지 필터링을 미루면 이 화면 전환 횟수를 줄일 수 있어, 검색어 입력 처리에서 흔히 쓰이는 debounce 패턴을 그대로 적용했습니다.

**기대 효과**: 타이핑 도중에는 "입력 중" 문구만 보여주고, 입력이 멈춘 뒤 한 번만 결과를 렌더링하므로 결과 화면이 여러 번 깜빡이는 대신 한 번에 완성된 화면으로 전환됩니다.

### 3. App.vue → MacWindowLayout 슬롯 분리

**어떻게**: 초기에는 `App.vue`가 타이틀바, 트래픽 라이트, 네비게이션 등 macOS 창 UI 마크업/스타일을 전부 직접 그리고 있었습니다. 이를 `components/shared/MacWindowLayout.vue`라는 별도 컴포넌트로 옮기고, `App.vue`는 "무엇을 넣을지"만 결정하도록 리팩터링했습니다.

```vue
<!-- App.vue -->
<MacWindowLayout>
  <template #toolbar>
    <nav class="window-nav">
      <RouterLink to="/">날씨</RouterLink>
      <RouterLink to="/about">소개</RouterLink>
    </nav>
    <UnitToggle />
  </template>

  <RouterView />
</MacWindowLayout>
```

`MacWindowLayout`은 트래픽 라이트와 하늘 배경(`--sky-day`)을 자체적으로 그리고, `v-if="$slots.toolbar"`로 툴바 슬롯이 채워졌을 때만 그 영역을 렌더링합니다.

**왜 이렇게 했는지**: `App.vue`가 라우팅 진입점(`RouterView`)과 macOS 창 스타일(트래픽 라이트, 툴바, 하늘 배경 등)을 동시에 책임지면, 창 디자인을 바꿀 때마다 `App.vue`를 건드려야 하고 반대로 라우팅/전역 상태 로직을 볼 때도 스타일 마크업이 시야를 가립니다. 슬롯 기반 레이아웃 컴포넌트로 분리하면 "창이 어떻게 생겼는지"와 "창 안에 무엇이 들어가는지"의 관심사를 나눌 수 있습니다.

> 처음에는 `title` / `nav` 슬롯을 따로 두고 `title` 슬롯에 별도의 `Header.vue`(제목 텍스트)를 꽂았습니다. 이후 실제 macOS Weather 앱처럼 창 제목 없이 툴바 하나(내비게이션 + 단위 토글)만 오른쪽 위에 떠 있는 편이 더 자연스러워서, 슬롯을 `toolbar` 하나로 합치고 더 이상 쓰지 않게 된 `Header.vue`는 제거했습니다.

### 4. 인트로 페이지 라우팅 분리 -> 404 페이지에서도 인트로가 뜨는 문제 트러블 슈팅

#### 문제 상황

초기 구현에서는 iPhone 인트로(`PhoneIntro.vue`)를 `App.vue` 최상단에 `v-if="showIntro"`로 두고, 앱이 마운트될 때마다 **항상** 인트로를 먼저 보여주는 방식이었습니다. 이 구조에서는 라우터가 어떤 페이지를 렌더링하려 해도 사용자는 macOS 창 UI가 아니라 iPhone 화면만 보게 되어, 다음과 같은 문제가 있었습니다.

1. **존재하지 않는 URL로 직접 진입해도 404가 아니라 인트로가 뜸** :  `App.vue`의 `PhoneIntro`가 먼저 화면을 덮어써서 실제로는 404를 볼 수 없음
2. **404 페이지에서 홈으로 돌아가도 인트로가 다시 뜸**  : `showIntro` 상태가 초기화되어 재생됨
3. **인트로와 본문 UI의 책임이 `App.vue`에 섞임** : "어떤 페이지를 보여줄지"는 Vue Router가 결정해야 하는데, 인트로 on/off가 라우트와 무관한 로컬 state로 관리됨

#### 해결 방향

인트로를 **독립된 라우트(`/intro`)** 로 분리하고, "이미 인트로를 통과했는지"만 `sessionStorage`로 기억한 뒤, **홈(`/`)으로 처음 들어올 때만** 인트로로 보내도록 라우터 가드를 추가했습니다.

```js
// router/intro.js
export const INTRO_DONE_KEY = 'weather-intro-done'
export function hasFinishedIntro() {
  return sessionStorage.getItem(INTRO_DONE_KEY) === '1'
}
```

```js
// router/index.js
router.beforeEach((to) => {
  if (to.name === 'intro') return true
  if (to.name === 'home' && !hasFinishedIntro()) {
    return { name: 'intro', replace: true }
  }
  return true
})
```

가드 조건이 `to.name === 'home'`**일 때만** 인트로로 보내기 때문에, catch-all 404 라우트(`not-found`)나 `/about`, `/weather/:id` 등 다른 경로는 인트로와 무관하게 바로 렌더링됩니다.

**왜 `sessionStorage`인가**: `localStorage`는 브라우저를 완전히 닫았다 열어도 값이 남아 "다음 날 다시 접속해도 인트로를 안 보는" 문제가 생깁니다. `sessionStorage`는 탭(세션) 단위로만 유지되어, 같은 탭에서는 인트로가 반복되지 않으면서도 새 탭/새 방문에서는 다시 볼 수 있기 때문에 Session Storage 가 적합하다고 생각했습니다.

### 5. iPhone 인트로 애니메이션

`components/home/PhoneIntro.vue`는 `/intro` 라우트(`IntroView.vue`)에서만 사용됩니다. iPhone 잠금화면을 CSS 3D 변환(`transform-style: preserve-3d`)과 SVG 스트로크 애니메이션으로 재현하고, 위로 드래그하거나 클릭/키보드로 잠금을 해제하면 `router.push({ name: 'home' })`으로 홈으로 이동합니다. 실사용 기능은 아니지만 `pointerdown/pointermove/pointerup` 기반 드래그 처리, `requestAnimationFrame` 보간, `prefers-reduced-motion` 대응 등 인터랙션/애니메이션 구현 연습을 위해 추가했습니다.

### 6. 현재 위치 날씨 토스트 알림

**어떻게**: 홈 화면 진입(`onMounted`) 시 브라우저 위치 권한(`navigator.geolocation`)을 요청해 좌표를 받고, `getWeather(lat, lon)`으로 현재 위치의 날씨를 조회한 뒤 Element Plus `ElNotification`으로 우측 상단에 토스트를 띄웁니다. 로직은 세 파일로 나눴습니다.

- `util/weatherNotice.js` — 순수 함수 `buildWeatherNotice({ name, description, temp })`. 기온만 보고 제목/본문 문구/타입(`info`/`warning`)/커스텀 클래스만 계산해서 반환하는, DOM이나 API를 모르는 로직입니다.
- `hooks/notifyCurrentLocationWeather.js`의 `notifyCurrentLocationWeather()` — geolocation 요청 → `api/weather-hooks.js`의 `getWeather` 호출 → `buildWeatherNotice` 결과로 `ElNotification` 호출까지 담당하는 조립 함수입니다. 처음에는 `api/weather-hooks.js` 안에 함께 두었지만, "서버에서 날씨 데이터를 가져오는 순수 API 함수"와 "위치 권한을 묻고 화면에 토스트까지 띄우는 부수효과 로직"의 성격이 달라 `hooks/` 폴더로 분리했습니다.
- `WeatherHomeView.vue`는 `onMounted(() => { fetchSeedGroupWeather(); notifyCurrentLocationWeather() })` 한 줄만 호출합니다.

```js
export const HEAT_WAVE_TEMP = 33
export const COLD_WAVE_TEMP = -12

export function buildWeatherNotice({ name, description, temp }) {
  // temp >= 33 → "폭염주의가 있으니 물을 많이 드시고 더위를 조심하세요" (warning)
  // temp <= -12 → "한파주의가 있으니 옷을 따뜻하게 입고 추위를 조심하세요" (warning)
  // 그 외 → 평범한 날씨 안내 (info)
}
```

**왜 함수를 이렇게 나눴는지**: 온도 구간별 문구를 만드는 로직(`buildWeatherNotice`)과 "위치를 구하고 API를 부르고 화면에 띄운다"는 부수효과 로직(`notifyCurrentLocationWeather`)을 분리하면, 문구/기준 온도만 바꿀 때는 `weatherNotice.js` 한 파일만 보면 되고, 위치 조회 실패나 권한 거부 같은 예외 처리는 조립 함수 쪽에만 몰아둘 수 있습니다. 위치 권한을 거부하거나 API 호출이 실패해도 토스트는 부가 기능이므로 화면을 막지 않고 조용히 넘어가도록 했습니다.
