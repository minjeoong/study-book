import os
import uuid
import streamlit as st

from earthfm.agent import run_earth_radio
from earthfm.audio import render_radio_audio, transcribe_audio_bytes
from earthfm.mock_demo import get_mock_output

st.set_page_config(
    page_title="Earth.FM MVP v4",
    page_icon="🌍",
    layout="wide",
)

st.title("🌍 Earth.FM MVP v4")
st.caption(
    "Terra Main → Luna Retrievers → Middleware/Guardrail → QA → TTS/Audio Mixer"
)

if "thread_id" not in st.session_state:
    st.session_state["thread_id"] = str(uuid.uuid4())

with st.sidebar:
    st.header("Session")
    st.code(st.session_state["thread_id"][:12] + "...")

    if st.button("새 대화"):
        for key in list(st.session_state.keys()):
            if key != "thread_id":
                st.session_state.pop(key, None)
        st.session_state["thread_id"] = str(uuid.uuid4())
        st.rerun()

    st.divider()
    generate_audio = st.checkbox("최종 Audio 생성", value=True)
    mix_ambient = st.checkbox("Freesound 환경음 믹스", value=True)

    voice = st.selectbox(
        "TTS Voice",
        ["coral", "alloy", "nova", "shimmer", "echo", "onyx"],
        index=0,
    )

    mock_mode = st.checkbox(
        "Mock 데모",
        value=not bool(os.getenv("OPENAI_API_KEY")),
    )

st.subheader("Earth Radio 요청")
input_mode = st.radio(
    "입력 방식",
    ["텍스트", "음성"],
    horizontal=True,
)

prompt_text = ""

if input_mode == "텍스트":
    prompt_text = st.text_area(
        "요청",
        value="오늘 아이슬란드의 지구 소리를 들려줘.",
        height=90,
    )
else:
    if hasattr(st, "audio_input"):
        audio_value = st.audio_input("🎙️ 음성으로 요청")
    else:
        audio_value = st.file_uploader(
            "음성 파일 업로드",
            type=["wav", "mp3", "m4a", "webm"],
        )

    if audio_value is not None:
        st.audio(audio_value)

        if mock_mode:
            prompt_text = "오늘 아이슬란드의 지구 소리를 들려줘."
            st.info("Mock 모드에서는 STT를 호출하지 않습니다.")
        else:
            if st.button("📝 STT 변환"):
                try:
                    filename = getattr(
                        audio_value,
                        "name",
                        "request.wav",
                    )
                    st.session_state["transcript"] = (
                        transcribe_audio_bytes(
                            audio_value.getvalue(),
                            filename=filename,
                        )
                    )
                except Exception as e:
                    st.error(f"STT 실패: {e}")

            prompt_text = st.session_state.get("transcript", "")
            if prompt_text:
                st.success(f"인식 결과: {prompt_text}")

if st.button(
    "📻 Earth Radio 생성",
    type="primary",
    disabled=not bool(prompt_text.strip()),
):
    if mock_mode:
        output, trace = get_mock_output()
        st.warning("Mock 데이터입니다. 실제 자연현상/음원이 아닙니다.")
    else:
        try:
            with st.spinner("Earth.FM Agent 실행 중..."):
                output, trace = run_earth_radio(
                    prompt_text,
                    thread_id=st.session_state["thread_id"],
                )
        except Exception as e:
            st.error(str(e))
            st.stop()

    st.session_state["output"] = output
    st.session_state["trace"] = trace
    st.session_state.pop("final_audio", None)
    st.session_state.pop("audio_meta", None)

output = st.session_state.get("output")

if output:
    st.divider()

    st.write(
        f"**Output Status:** `{output['status']}` · "
        f"**Schema:** `{output['schema_version']}` · "
        f"**Request ID:** `{output['request_id']}`"
    )

    if output["status"] == "blocked":
        st.error(output.get("error_message") or "Guardrail에 의해 차단되었습니다.")
        st.json(output["guardrails"])
        st.stop()

    broadcast = output.get("broadcast")
    if not broadcast:
        st.error(output.get("error_message") or "방송 결과가 없습니다.")
        st.stop()

    st.subheader(broadcast["title"])

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("🌍 Earth Mood", broadcast["earth_mood"])
    c2.metric("🔁 Terra 재질의", broadcast["requery_count"])
    c3.metric("📡 Data", broadcast["data_status"])
    c4.metric("🛡️ Guard", "PASS" if output["guardrails"]["passed"] else "DEGRADED")

    tabs = st.tabs(
        [
            "🌍 Earth Data",
            "✨ AI Interpretation",
            "🎧 Sound Selection",
            "📻 Final Audio",
            "🛡️ Guardrails",
            "✅ QA",
            "⚙️ Runtime",
            "🧠 Trace",
            "🧩 Output JSON",
        ]
    )

    with tabs[0]:
        st.write(broadcast["earth_data_brief"])
        if broadcast.get("weather_context"):
            st.caption("Weather Context")
            st.json(broadcast["weather_context"])
        for event in broadcast.get("earth_data") or []:
            with st.expander(
                f"{event['source']} · {event['title']}"
            ):
                st.json(event)

    with tabs[1]:
        st.write(broadcast["ai_interpretation"])
        st.divider()
        st.write(broadcast["closing_message"])

    with tabs[2]:
        st.write(broadcast["sound_selection_reason"])
        sounds = broadcast.get("selected_sounds") or []
        if not sounds:
            st.info("선정된 Freesound 음원이 없습니다.")
        for sound in sounds:
            st.markdown(f"### {sound['title']}")
            st.audio(sound["preview_url"])
            st.caption(
                f"{sound['creator']} · {sound['license']} · "
                f"{sound['duration_sec']:.1f}s"
            )

    with tabs[3]:
        if not generate_audio:
            st.info("사이드바에서 최종 Audio 생성을 켜주세요.")
        elif mock_mode and not os.getenv("OPENAI_API_KEY"):
            st.info("Mock + API Key 없음 상태에서는 TTS를 호출하지 않습니다.")
        else:
            if "final_audio" not in st.session_state:
                try:
                    with st.spinner("TTS + Freesound Audio Mixer 처리 중..."):
                        audio_bytes, audio_meta = render_radio_audio(
                            broadcast,
                            voice=voice,
                            mix_ambient=mix_ambient,
                        )
                        st.session_state["final_audio"] = audio_bytes
                        st.session_state["audio_meta"] = audio_meta.model_dump()

                        output["audio"] = audio_meta.model_dump()
                        st.session_state["output"] = output
                except Exception as e:
                    st.error(f"Audio 생성 실패: {e}")

            if st.session_state.get("final_audio"):
                st.audio(
                    st.session_state["final_audio"],
                    format="audio/mp3",
                )
                st.json(st.session_state.get("audio_meta"))

    with tabs[4]:
        for check in output["guardrails"].get("checks", []):
            icon = "✅" if check["passed"] else "⚠️"
            st.write(
                f"{icon} **{check['name']}** · "
                f"{check['severity']} · {check['action']}"
            )
            if check.get("issues"):
                st.caption(" / ".join(check["issues"]))

    with tabs[5]:
        st.json(output.get("qa"))

    with tabs[6]:
        st.json(output.get("runtime"))

    with tabs[7]:
        for i, step in enumerate(
            st.session_state.get("trace", []),
            1,
        ):
            with st.expander(
                f"{i}. {step.get('step', 'step')}"
            ):
                st.json(step)

    with tabs[8]:
        st.json(st.session_state["output"])

    st.divider()
    st.caption(broadcast["disclaimer"])
