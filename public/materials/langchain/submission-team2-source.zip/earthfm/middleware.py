"""
설명 : 도구 호출 전후에 끼워 넣는 공통 처리를 담당한다. 호출 횟수 제한, 인자 검증, 캐시, 재시도와 입력·출력 가드레일 실행 순서를 여기서 정한다.
작성자 : 김태동
작성일 : 2026-09-11
참조 : config.py, guardrail_tools.py
return : 없음
"""


from __future__ import annotations
import hashlib
import json
import time
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any
import requests
from .config import settings
from .guardrail_tools import (
    input_guard_tool,
    normalize_input_tool,
    output_guard_tool,
    sanitize_tool_output_tool,
    validate_tool_args_tool,
)


"""
설명 : 한 번 실행 동안 도구·모델 호출 수와 캐시 적중, 재시도 횟수를 세는 카운터.
"""
@dataclass
class RuntimeCounter:
    tool_calls: int = 0
    model_calls: int = 0
    cache_hits: int = 0
    retry_count: int = 0
    middleware_trace: list[str] | None = None

    """
    설명 : 실행 추적 목록이 없으면 빈 목록으로 초기화한다.
    작성자 : 김태동
    """
    def __post_init__(self):
        if self.middleware_trace is None:
            self.middleware_trace = []


_runtime: ContextVar[RuntimeCounter | None] = ContextVar(
    "earthfm_runtime",
    default=None,
)
_TOOL_CACHE: dict[str, tuple[float, Any]] = {}


"""
설명 : 새 실행 카운터를 세팅한다.
작성자 : 김태동
"""
def begin_runtime() -> None:
    _runtime.set(RuntimeCounter())


"""
설명 : 현재 실행 카운터를 가져오고 없으면 만든다.
작성자 : 김태동
"""
def get_runtime() -> RuntimeCounter:
    runtime = _runtime.get()
    if runtime is None:
        runtime = RuntimeCounter()
        _runtime.set(runtime)
    return runtime


"""
설명 : 실행 통계를 딕셔너리로 돌려준다.
작성자 : 김태동
"""
def runtime_dict() -> dict:
    r = get_runtime()
    return {
        "tool_calls": r.tool_calls,
        "model_calls": r.model_calls,
        "cache_hits": r.cache_hits,
        "retry_count": r.retry_count,
        "middleware_trace": list(r.middleware_trace or []),
    }


"""
설명 : 입력 정제와 입력 가드레일을 차례로 실행한다.
작성자 : 김태동
"""
def before_agent_input(text: str) -> dict:
    runtime = get_runtime()
    normalized = normalize_input_tool.invoke({"text": text})
    runtime.middleware_trace.append("InputNormalizationMiddleware")
    guarded = input_guard_tool.invoke({"text": normalized["text"]})
    runtime.middleware_trace.append("InputGuardMiddleware")
    runtime.middleware_trace.append("PIIMiddleware(Input)")
    return guarded


"""
설명 : 모델 호출 수를 세고 한도를 넘으면 멈춘다.
작성자 : 김태동
"""
def count_model_call(label: str) -> None:
    runtime = get_runtime()
    runtime.model_calls += 1
    runtime.middleware_trace.append(f"ModelCall:{label}")
    if runtime.model_calls > settings.model_call_limit:
        raise RuntimeError(
            f"ModelCallLimitMiddleware: limit={settings.model_call_limit}"
        )


"""
설명 : 도구 이름과 인자로 캐시 키를 만든다.
작성자 : 김태동
"""
def _cache_key(tool_name: str, args: dict) -> str:
    raw = json.dumps(
        {"tool": tool_name, "args": args},
        ensure_ascii=False,
        sort_keys=True,
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


"""
설명 : 다시 시도해도 되는 오류인지 판단한다.
작성자 : 김태동
"""
def _retryable(exc: Exception) -> bool:
    if isinstance(
        exc,
        (
            requests.Timeout,
            requests.ConnectionError,
        ),
    ):
        return True
    if isinstance(exc, requests.HTTPError):
        status = exc.response.status_code if exc.response is not None else None
        return status == 429 or (status is not None and 500 <= status < 600)
    return False


"""
설명 : 한도 확인·검증·캐시·재시도를 거쳐 도구를 실행한다.
작성자 : 김태동
"""
def invoke_tool_with_middleware(
    tool,
    args: dict[str, Any],
    *,
    use_cache: bool = True,
) -> Any:
    runtime = get_runtime()
    runtime.tool_calls += 1
    runtime.middleware_trace.append(f"ToolCall:{tool.name}")
    if runtime.tool_calls > settings.tool_call_limit:
        raise RuntimeError(
            f"ToolCallLimitMiddleware: limit={settings.tool_call_limit}"
        )
    validation = validate_tool_args_tool.invoke(
        {
            "tool_name": tool.name,
            "args": args,
        }
    )
    runtime.middleware_trace.append("GR-12 ToolArgumentValidation")
    if not validation.get("passed"):
        raise ValueError(
            f"Tool argument blocked: {validation.get('issues')}"
        )
    key = _cache_key(tool.name, args)
    now = time.time()
    if use_cache and key in _TOOL_CACHE:
        stored_at, value = _TOOL_CACHE[key]
        if now - stored_at <= settings.cache_ttl_sec:
            runtime.cache_hits += 1
            runtime.middleware_trace.append("EarthDataCacheMiddleware:HIT")
            return value
    runtime.middleware_trace.append("EarthDataCacheMiddleware:MISS")
    last_error: Exception | None = None
    attempts = settings.tool_retry_count + 1
    for attempt in range(attempts):
        try:
            value = tool.invoke(args)
            safe = sanitize_tool_output_tool.invoke(
                {
                    "tool_name": tool.name,
                    "payload": value,
                }
            )["payload"]
            runtime.middleware_trace.append("ExternalDataInjectionGuard")
            if use_cache:
                _TOOL_CACHE[key] = (time.time(), safe)
            return safe
        except Exception as exc:
            last_error = exc
            if attempt < attempts - 1 and _retryable(exc):
                runtime.retry_count += 1
                runtime.middleware_trace.append(
                    f"ToolRetryMiddleware:{attempt + 1}"
                )
                time.sleep(
                    settings.tool_retry_backoff_sec * (2 ** attempt)
                )
                continue
            runtime.middleware_trace.append("ToolErrorMiddleware")
            raise
    raise last_error or RuntimeError("unknown tool failure")


"""
설명 : 방송 결과에 출력 가드레일을 적용한다.
작성자 : 김태동
"""
def after_broadcast_output(broadcast: dict) -> dict:
    runtime = get_runtime()
    report = output_guard_tool.invoke({"broadcast": broadcast})
    runtime.middleware_trace.append("EvidenceValidationMiddleware")
    runtime.middleware_trace.append("PIIMiddleware(Output)")
    return report
