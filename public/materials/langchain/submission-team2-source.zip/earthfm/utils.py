"""
설명 : 거리 계산, 검색용 bbox 만들기, GeoJSON 좌표 읽기, 사건 중요도 점수 매기기, Freesound 라이선스 허용 판정 같은 계산용 보조 함수들이 있다.
작성자 : 임동건
작성일 : 2026-09-11
참조 : 없음
return : 없음
"""


from __future__ import annotations
from datetime import datetime, timezone
from math import asin, cos, exp, radians, sin, sqrt


"""
설명 : 지금 시각을 UTC ISO 문자열로 돌려준다.
작성자 : 임동건
"""
def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


"""
설명 : 두 좌표 사이의 거리를 km로 계산한다.
작성자 : 임동건
"""
def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0088
    p1 = radians(lat1)
    p2 = radians(lat2)
    dp = radians(lat2 - lat1)
    dl = radians(lon2 - lon1)
    a = sin(dp / 2) ** 2 + cos(p1) * cos(p2) * sin(dl / 2) ** 2
    return 2 * r * asin(sqrt(a))


"""
설명 : 반경을 EONET bbox 사각형으로 바꿔준다.
작성자 : 임동건
"""
def radius_to_bbox(lat: float, lon: float, radius_km: float) -> tuple[float, float, float, float]:
    lat_delta = radius_km / 111.0
    cos_lat = max(abs(cos(radians(lat))), 0.15)
    lon_delta = radius_km / (111.0 * cos_lat)
    min_lat = max(-90.0, lat - lat_delta)
    max_lat = min(90.0, lat + lat_delta)
    min_lon = max(-180.0, lon - lon_delta)
    max_lon = min(180.0, lon + lon_delta)
    return min_lon, max_lat, max_lon, min_lat


"""
설명 : GeoJSON 도형에서 대표 좌표 하나를 뽑는다.
작성자 : 임동건
"""
def representative_point(geometry_type: str, coordinates) -> tuple[float, float] | None:
    if not coordinates:
        return None
    if geometry_type == "Point":
        lon, lat = coordinates[:2]
        return float(lat), float(lon)
    if geometry_type == "Polygon":
        ring = coordinates[0] if coordinates else []
        if not ring:
            return None
        lons = [float(p[0]) for p in ring if len(p) >= 2]
        lats = [float(p[1]) for p in ring if len(p) >= 2]
        if not lats:
            return None
        return sum(lats) / len(lats), sum(lons) / len(lons)
    if geometry_type == "MultiPolygon":
        poly = coordinates[0] if coordinates else []
        if not poly:
            return None
        return representative_point("Polygon", poly)
    return None


"""
설명 : 사건이 얼마나 최근인지 0~1 점수로 계산한다.
작성자 : 임동건
"""
def recency_score(occurred_at: str | None, horizon_hours: float = 168.0) -> float:
    if not occurred_at:
        return 0.4
    try:
        dt = datetime.fromisoformat(occurred_at.replace("Z", "+00:00"))
        hours = max(0.0, (datetime.now(timezone.utc) - dt).total_seconds() / 3600)
        return max(0.0, min(1.0, exp(-hours / horizon_hours)))
    except ValueError:
        return 0.4


"""
설명 : 거리를 0~1 점수로 바꿔준다.
작성자 : 임동건
"""
def distance_score(distance_km: float | None, scale_km: float = 500.0) -> float:
    if distance_km is None:
        return 0.0
    return max(0.0, min(1.0, exp(-distance_km / scale_km)))


"""
설명 : 지진 규모를 중요도 점수로 바꿔준다.
작성자 : 임동건
"""
def quake_severity_score(magnitude: float | None) -> float:
    if magnitude is None:
        return 0.3
    if magnitude >= 7:
        return 1.0
    if magnitude >= 6:
        return 0.9
    if magnitude >= 5:
        return 0.75
    if magnitude >= 4:
        return 0.55
    if magnitude >= 3:
        return 0.35
    return 0.2


EONET_CATEGORY_WEIGHT = {
    "severeStorms": 0.75,
    "volcanoes": 0.8,
    "wildfires": 0.7,
    "floods": 0.65,
    "landslides": 0.65,
    "seaLakeIce": 0.45,
    "snow": 0.4,
    "drought": 0.5,
    "dustHaze": 0.4,
    "tempExtremes": 0.6,
}


"""
설명 : EONET 사건 종류를 중요도 점수로 바꿔준다.
작성자 : 임동건
"""
def eonet_severity_score(event_type: str) -> float:
    return EONET_CATEGORY_WEIGHT.get(event_type, 0.5)


"""
설명 : 최근성·거리·규모를 합쳐 사건 중요도를 매긴다.
작성자 : 임동건
"""
def importance_score(
    *,
    source: str,
    occurred_at: str | None,
    distance_km: float | None,
    magnitude: float | None = None,
    event_type: str = "",
    ongoing: bool | None = None,
    completeness: float = 1.0,
) -> float:
    r = recency_score(occurred_at)
    d = distance_score(distance_km)
    if source == "USGS":
        s = quake_severity_score(magnitude)
    else:
        s = eonet_severity_score(event_type)
    active = 1.0 if ongoing else 0.5
    score = 0.30 * r + 0.25 * d + 0.25 * s + 0.10 * active + 0.10 * completeness
    return round(max(0.0, min(1.0, score)), 4)


"""
설명 : 쓸 수 있는 Freesound 라이선스인지 판별한다.
작성자 : 임동건
"""
def is_allowed_freesound_license(license_value: str | None) -> bool:
    if not license_value:
        return False
    x = license_value.lower()
    if "publicdomain/zero" in x or "cc0" in x:
        return True
    is_by = (
        "creativecommons.org/licenses/by/" in x
        or x.strip().startswith("attribution")
        or "cc by" in x
    )
    blocked = ("by-nc" in x) or ("by-sa" in x) or ("noncommercial" in x) or ("sharealike" in x)
    return bool(is_by and not blocked)
