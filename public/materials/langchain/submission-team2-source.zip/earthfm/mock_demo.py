"""
설명 : 실제 API 호출 없이 기능 확인용으로 쓸 가짜 방송 결과 하나를 만들어 돌려주는 파일이다. UI나 연동 테스트에서 mock 모드로 사용한다.
작성자 : 임동건
작성일 : 2026-09-11
참조 : schemas.py
return : 없음
"""


import uuid
from datetime import datetime, timezone
from .schemas import (
    AudioOutput,
    EarthFMOutput,
    EarthRadioBroadcast,
    GuardrailCheck,
    GuardrailReport,
    QAVerdict,
    RuntimeStats,
)


"""
설명 : 가짜 방송 결과와 실행 추적을 만들어 돌려준다.
작성자 : 임동건
"""
def get_mock_output() -> tuple[dict, list[dict]]:
    qa = QAVerdict(
        verdict="pass",
        factual_consistency=True,
        weather_consistency=True,
        sound_consistency=True,
        safety_valid=True,
        schema_valid=True,
        critical=False,
        issues=[],
        regenerate_required=False,
    )
    broadcast = EarthRadioBroadcast.model_validate(
        {
            "title": "[MOCK] 불과 얼음의 섬, 오늘의 Earth Radio",
            "location": "Iceland",
            "observed_at": datetime.now(timezone.utc).isoformat(),
            "requested_scope": {"days": 7, "radius_km": 500},
            "effective_scope": {"days": 7, "radius_km": 500},
            "requery_count": 0,
            "scope_expanded": False,
            "data_status": "complete",
            "earth_mood": "powerful",
            "mood_reason": "Mock Earth Data 기반 예시입니다.",
            "requested_sound_mood": "auto",
            "earth_data": [
                {
                    "source": "NASA_EONET",
                    "event_id": "MOCK-EONET-001",
                    "event_type": "volcanoes",
                    "title": "[MOCK] Volcanic Event",
                    "occurred_at": "2026-09-10T06:00:00+00:00",
                    "distance_km": 120.0,
                    "ongoing": True,
                    "importance_score": 0.77,
                },
                {
                    "source": "USGS",
                    "event_id": "MOCK-USGS-001",
                    "event_type": "earthquake",
                    "title": "[MOCK] M 4.8 earthquake",
                    "occurred_at": "2026-09-10T07:00:00+00:00",
                    "magnitude": 4.8,
                    "magnitude_unit": "Mw",
                    "depth_km": 8.0,
                    "distance_km": 95.0,
                    "ongoing": False,
                    "tsunami": False,
                    "importance_score": 0.73,
                },
            ],
            "weather_context": {
                "observed_at": "2026-09-10T10:00",
                "temperature_c": 9.0,
                "precipitation_mm": 0.0,
                "rain_mm": 0.0,
                "weather_code": 3,
                "wind_speed_kmh": 24.0,
                "timezone": "Atlantic/Reykjavik",
            },
            "selected_sounds": [],
            "broadcast_mode": "normal",
            "earth_data_brief": (
                "[MOCK DATA] 화산·지진·현재 기상 Context를 가진 테스트 Fixture입니다."
            ),
            "ai_interpretation": (
                "낮은 대지의 울림과 차가운 바람이 공존하는 웅장한 분위기의 예시입니다."
            ),
            "sound_selection_reason": (
                "Mock 모드에서는 Freesound API를 호출하지 않습니다."
            ),
            "closing_message": "이 결과는 기능 확인용 Mock입니다.",
            "disclaimer": (
                "MOCK 데이터입니다. 실제 재난 정보가 아닙니다. "
                "공식 재난 경보, 예측 또는 안전 판단으로 사용할 수 없습니다."
            ),
            "qa_verdict": qa.model_dump(),
            "degraded_flags": ["mock_mode"],
        }
    )
    guard = GuardrailReport(
        passed=True,
        blocked=False,
        checks=[
            GuardrailCheck(
                name="GR-01 Prompt Injection",
                passed=True,
                severity="high",
            ),
            GuardrailCheck(
                name="GR-11 Structured Output",
                passed=True,
                severity="high",
            ),
        ],
    )
    output = EarthFMOutput(
        request_id=str(uuid.uuid4()),
        status="degraded",
        broadcast=broadcast,
        audio=AudioOutput(status="not_requested"),
        guardrails=guard,
        qa=qa,
        runtime=RuntimeStats(
            tool_calls=0,
            model_calls=0,
            middleware_trace=["MockMode"],
        ),
        degraded_flags=["mock_mode"],
    )
    trace = [
        {"step": "input_middleware", "data": {"passed": True}},
        {"step": "terra_request_resolver", "data": {"model": "Terra"}},
        {"step": "luna_location_subagent", "data": {"status": "mock"}},
        {"step": "terra_supervisor", "data": {"route": "earth_retrieval"}},
        {"step": "luna_eonet_subagent", "data": {"events": 1}},
        {"step": "luna_usgs_subagent", "data": {"events": 1}},
        {"step": "terra_evidence_judge", "data": {"decision": "need_weather"}},
        {"step": "luna_weather_subagent", "data": {"status": "ok"}},
        {"step": "terra_mood_sound_planner", "data": {"earth_mood": "powerful"}},
        {"step": "luna_freesound_subagent", "data": {"status": "mock"}},
        {"step": "terra_radio_writer", "data": {"status": "ok"}},
        {"step": "luna_qa_reviewer", "data": qa.model_dump()},
        {"step": "output_guardrail", "data": {"passed": True}},
    ]
    return output.model_dump(), trace
