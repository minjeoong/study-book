"""
설명 : 완성된 방송 원고를 받아 TTS로 낭독 MP3를 만들고, Freesound 환경음을 입혀 최종 라디오 음원을 완성하는 부분이다. 실패하면 낭독만 있는 상태로 낮춰 반환한다.
작성자 : 박규리
작성일 : 2026-09-11
참조 : config.py, schemas.py
return : 없음
"""


from __future__ import annotations
import io
import math
import os
import re
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Iterable
import requests
from openai import OpenAI
from .config import settings
from .schemas import AudioOutput


"""
설명 : OpenAI 클라이언트를 만들어 돌려준다.
작성자 : 박규리
"""
def _client() -> OpenAI:
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY가 설정되지 않았습니다.")
    return OpenAI(api_key=settings.openai_api_key)


"""
설명 : pydub이 사용할 ffmpeg 경로를 지정해 준다.
작성자 : 박규리
"""
def _configure_ffmpeg():
    if not settings.ffmpeg_binary:
        return
    try:
        from pydub import AudioSegment
        AudioSegment.converter = settings.ffmpeg_binary
    except Exception:
        pass


"""
설명 : 음성 바이트를 받아 텍스트로 변환한다.
작성자 : 박규리
"""
def transcribe_audio_bytes(
    audio_bytes: bytes,
    *,
    filename: str = "request.wav",
    language: str = "ko",
) -> str:
    suffix = Path(filename).suffix or ".wav"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp_path = tmp.name
    try:
        with open(tmp_path, "rb") as audio_file:
            response = _client().audio.transcriptions.create(
                model=settings.stt_model,
                file=audio_file,
                language=language,
            )
        text = getattr(response, "text", None)
        if not text and isinstance(response, str):
            text = response
        if not text:
            raise RuntimeError("STT 응답에 transcription text가 없습니다.")
        return str(text).strip()
    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass


TTS_INSTRUCTIONS = {
    "normal": "한국어 라디오 진행자처럼 차분하고 자연스럽게 말하세요.",
    "documentary": "한국어 자연 다큐멘터리의 나레이션처럼 객관적이고 차분한 목소리로 말하세요.",
    "children": "어린이가 듣기 편하도록 부드럽고 친근한 목소리로 천천히 또박또박 말하세요.",
    "emotional": "과장하지 않되 시를 낭송하듯이 감정을 담아서 이야기하세요.",
    "data": "수치와 출처가 잘 들리도록 또렷한 목소리로 중립적으로 말하세요.",
}


"""
설명 : 방송 내용을 순서대로 이어붙여 TTS용 원고를 만든다.
작성자 : 박규리
"""
def build_tts_text(broadcast: dict) -> str:
    return "\n\n".join(
        [
            broadcast.get("title", ""),
            "Earth Data.",
            broadcast.get("earth_data_brief", ""),
            "AI Interpretation.",
            broadcast.get("ai_interpretation", ""),
            "Sound Selection.",
            broadcast.get("sound_selection_reason", ""),
            broadcast.get("closing_message", ""),
            broadcast.get("disclaimer", ""),
        ]
    ).strip()


"""
설명 : 긴 원고를 문장 단위로 잘라 TTS에 넣기 좋게 나눈다.
작성자 : 박규리
"""
def split_tts_text(text: str, max_chars: int | None = None) -> list[str]:
    max_chars = max_chars or settings.tts_segment_chars
    text = text.strip()
    if not text:
        return []
    sentences = [
        s.strip()
        for s in re.split(r"(?<=[.!?。！？])\s+|\n+", text)
        if s.strip()
    ]
    chunks: list[str] = []
    current = ""
    for sentence in sentences:
        if len(sentence) > max_chars:
            if current:
                chunks.append(current.strip())
                current = ""
            for i in range(0, len(sentence), max_chars):
                chunks.append(sentence[i:i + max_chars].strip())
            continue
        candidate = f"{current} {sentence}".strip()
        if current and len(candidate) > max_chars:
            chunks.append(current.strip())
            current = sentence
        else:
            current = candidate
    if current:
        chunks.append(current.strip())
    return chunks


"""
설명 : 한 덩어리 텍스트를 MP3 음성으로 바꿔 돌려준다.
작성자 : 박규리
"""
def _tts_segment_to_mp3(
    text: str,
    *,
    voice: str,
    instructions: str,
) -> bytes:
    with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp:
        out_path = tmp.name
    try:
        with _client().audio.speech.with_streaming_response.create(
            model=settings.tts_model,
            voice=voice,
            input=text,
            instructions=instructions,
            response_format="mp3",
        ) as response:
            response.stream_to_file(out_path)
        return Path(out_path).read_bytes()
    finally:
        try:
            os.remove(out_path)
        except OSError:
            pass


"""
설명 : 원고 전체를 TTS로 읽어 하나의 낭독 MP3로 완성한다.
작성자 : 박규리
"""
def synthesize_broadcast(
    broadcast: dict,
    *,
    voice: str | None = None,
) -> tuple[bytes, AudioOutput]:
    _configure_ffmpeg()
    from pydub import AudioSegment
    text = build_tts_text(broadcast)
    chunks = split_tts_text(text)
    if not chunks:
        raise RuntimeError("TTS로 변환할 방송 원고가 없습니다.")
    voice = voice or settings.tts_voice
    mode = broadcast.get("broadcast_mode", "normal")
    instructions = TTS_INSTRUCTIONS.get(
        mode,
        TTS_INSTRUCTIONS["normal"],
    )
    narration = AudioSegment.silent(duration=0)
    for idx, chunk in enumerate(chunks):
        segment_bytes = _tts_segment_to_mp3(
            chunk,
            voice=voice,
            instructions=instructions,
        )
        segment = AudioSegment.from_file(
            io.BytesIO(segment_bytes),
            format="mp3",
        )
        if idx > 0:
            narration += AudioSegment.silent(duration=220)
        narration += segment
    output = io.BytesIO()
    narration.export(
        output,
        format="mp3",
        bitrate=settings.audio_bitrate,
    )
    meta = AudioOutput(
        status="narration_only",
        duration_sec=round(len(narration) / 1000, 2),
        narration_segments=len(chunks),
        background_track_count=0,
        note="TTS narration generated",
    )
    return output.getvalue(), meta


"""
설명 : Freesound 미리듣기 파일을 받아온다.
작성자 : 박규리
"""
def _download_preview(url: str) -> bytes:
    last_error = None
    for attempt in range(2):
        try:
            response = requests.get(
                url,
                timeout=settings.request_timeout_sec,
            )
            response.raise_for_status()
            return response.content
        except Exception as exc:
            last_error = exc
    raise last_error or RuntimeError("preview download failed")


"""
설명 : 받아온 음성 바이트를 pydub 오디오로 바꾼다.
작성자 : 박규리
"""
def _decode_preview(raw: bytes):
    from pydub import AudioSegment
    return AudioSegment.from_file(io.BytesIO(raw))


"""
설명 : 짧은 음원은 반복하고 긴 음원은 잘라 목표 길이에 맞춘다.
작성자 : 박규리
"""
def _fit_clip(clip, duration_ms: int):
    if len(clip) <= 0:
        raise ValueError("empty audio clip")
    if len(clip) >= duration_ms:
        return clip[:duration_ms]
    repeat = math.ceil(duration_ms / len(clip))
    return (clip * repeat)[:duration_ms]


"""
설명 : 음원들의 볼륨 차이를 줄이도록 크기를 맞춘다.
작성자 : 박규리
"""
def _normalize_to_dbfs(clip, target_dbfs: float):
    if clip.dBFS == float("-inf"):
        return clip
    gain = target_dbfs - clip.dBFS
    gain = max(-18.0, min(18.0, gain))
    return clip.apply_gain(gain)


"""
설명 : 최대 3개 환경음으로 배경 사운드 레이어를 만든다.
작성자 : 박규리
"""
def _build_background_bed(
    selected_sounds: list[dict],
    duration_ms: int,
) -> tuple[object | None, list[str], list[str]]:
    from pydub import AudioSegment
    usable = []
    used_ids: list[str] = []
    skipped_ids: list[str] = []
    download_targets: list[tuple[str, str]] = []

    for sound in selected_sounds[:3]:
        sid = str(sound.get("sound_id", ""))
        url = sound.get("preview_url")
        if not url:
            skipped_ids.append(sid)
            continue

        download_targets.append((sid, url))

    if download_targets:
        with ThreadPoolExecutor(
            max_workers=len(download_targets),
        ) as executor:
            downloads = [
                (sid, executor.submit(_download_preview, url))
                for sid, url in download_targets
            ]

            for sid, future in downloads:
                try:
                    raw = future.result()
                    clip = _decode_preview(raw)
                    if len(clip) <= 300:
                        raise ValueError("audio clip too short")
                    usable.append((sid, clip))
                except Exception:
                    skipped_ids.append(sid)

    if not usable:
        return None, used_ids, skipped_ids
    if len(usable) == 1:
        sid, clip = usable[0]
        used_ids.append(sid)
        bed = _fit_clip(clip, duration_ms)
        bed = _normalize_to_dbfs(
            bed,
            settings.audio_background_dbfs,
        )
        return bed, used_ids, skipped_ids
    per_track = max(
        3000,
        math.ceil(
            (
                duration_ms
                + settings.audio_crossfade_ms * (len(usable) - 1)
            )
            / len(usable)
        ),
    )
    bed = AudioSegment.silent(duration=0)
    for idx, (sid, clip) in enumerate(usable):
        used_ids.append(sid)
        part = _fit_clip(clip, per_track)
        part = _normalize_to_dbfs(
            part,
            settings.audio_background_dbfs,
        )
        if idx == 0:
            bed = part
        else:
            cf = min(
                settings.audio_crossfade_ms,
                len(bed) // 3,
                len(part) // 3,
            )
            bed = bed.append(part, crossfade=max(0, cf))
    return _fit_clip(bed, duration_ms), used_ids, skipped_ids


"""
설명 : 낭독 MP3에 환경음을 깔아 최종 방송 음원을 완성한다.
작성자 : 박규리
"""
def mix_with_freesound(
    broadcast: dict,
    narration_mp3: bytes,
    *,
    narration_meta: AudioOutput | None = None,
) -> tuple[bytes, AudioOutput]:
    _configure_ffmpeg()
    from pydub import AudioSegment
    narration_meta = narration_meta or AudioOutput(
        status="narration_only"
    )
    sounds = broadcast.get("selected_sounds") or []
    if not sounds:
        narration_meta.status = "narration_only"
        narration_meta.note = "No Freesound candidate; narration only"
        return narration_mp3, narration_meta
    try:
        narration = AudioSegment.from_file(
            io.BytesIO(narration_mp3),
            format="mp3",
        )
        intro_ms = settings.audio_intro_ms
        outro_ms = settings.audio_outro_ms
        total_ms = intro_ms + len(narration) + outro_ms
        bed, used_ids, skipped_ids = _build_background_bed(
            sounds,
            total_ms,
        )
        if bed is None:
            meta = narration_meta.model_copy(deep=True)
            meta.status = "narration_only"
            meta.used_sound_ids = []
            meta.skipped_sound_ids = skipped_ids
            meta.note = "All Freesound previews failed; narration only"
            return narration_mp3, meta
        intro = bed[:intro_ms]
        under_narration = bed[
            intro_ms:intro_ms + len(narration)
        ]
        outro = bed[
            intro_ms + len(narration):
            total_ms
        ]
        intro = _normalize_to_dbfs(
            intro,
            settings.audio_intro_dbfs,
        ).fade_in(min(1200, len(intro)))
        under_narration = _normalize_to_dbfs(
            under_narration,
            settings.audio_background_dbfs,
        )
        outro = _normalize_to_dbfs(
            outro,
            settings.audio_outro_dbfs,
        ).fade_out(min(1800, len(outro)))
        narration = narration.fade_in(100).fade_out(120)
        mixed_body = under_narration.overlay(narration)
        final = intro + mixed_body + outro
        final = final.fade_in(500).fade_out(1000)
        if final.max_dBFS > -1.0:
            final = final.apply_gain(-1.0 - final.max_dBFS)
        output = io.BytesIO()
        final.export(
            output,
            format="mp3",
            bitrate=settings.audio_bitrate,
        )
        meta = AudioOutput(
            status="mixed",
            duration_sec=round(len(final) / 1000, 2),
            narration_segments=narration_meta.narration_segments,
            background_track_count=len(used_ids),
            used_sound_ids=used_ids,
            skipped_sound_ids=skipped_ids,
            note="TTS narration mixed with Freesound ambience",
        )
        return output.getvalue(), meta
    except Exception as exc:
        meta = narration_meta.model_copy(deep=True)
        meta.status = "narration_only"
        meta.note = (
            f"Audio mixer degraded to narration_only: "
            f"{type(exc).__name__}"
        )
        return narration_mp3, meta


"""
설명 : 원고를 음성으로 만들고 환경음 믹스까지 한번에 처리한다.
작성자 : 박규리
"""
def render_radio_audio(
    broadcast: dict,
    *,
    voice: str | None = None,
    mix_ambient: bool = True,
) -> tuple[bytes, AudioOutput]:
    narration, narration_meta = synthesize_broadcast(
        broadcast,
        voice=voice,
    )
    if not mix_ambient:
        return narration, narration_meta
    return mix_with_freesound(
        broadcast,
        narration,
        narration_meta=narration_meta,
    )
