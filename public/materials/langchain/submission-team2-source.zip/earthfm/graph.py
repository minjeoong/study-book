"""
설명 : Earth.FM의 핵심 랭그래프를 조립하는 파일이다. 입력 가드, 지역 확정, 지구 데이터 수집, 증거 판정, 분위기·음원 계획, 방송 원고 작성, QA까지 노드를 이어 붙인다.
작성자 : 임동건
작성일 : 2026-09-11
참조 : config.py, middleware.py, schemas.py, state.py, subagents.py, utils.py
return : 없음
"""

from __future__ import annotations

import json
from copy import deepcopy
from datetime import datetime, timezone
import uuid
from typing import Any

from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph

from .config import settings
from .middleware import (
    after_broadcast_output,
    before_agent_input,
    count_model_call,
    runtime_dict,
)
from .schemas import EarthFMOutput, GuardrailReport, RuntimeStats
from .schemas import (
    ActiveRequest,
    EarthDataItem,
    EarthRadioBroadcast,
    EvidenceJudgement,
    MainRoute,
    MoodPlan,
    NarrationParts,
    QAVerdict,
    RequestResolution,
    SearchScope,
)
from .state import EarthFMState
from .subagents import (
    run_eonet_subagent,
    run_freesound_subagent,
    run_location_subagent,
    run_usgs_subagent,
    run_weather_subagent,
)
from .utils import utc_now_iso

"""
설명 : Terra 메인 모델을 만든다.
작성자 : 임동건
"""
def _terra():
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY가 설정되지 않았습니다.")
    return ChatOpenAI(
        model=settings.main_model,
        api_key=settings.openai_api_key,
        temperature=0.5,
        timeout=30,
    )

REQUEST_RESOLVER_PROMPT = """
당신은 Earth.FM의 Main LLM Terra이며 이번 노드에서는 Request/Context Resolver 역할만 한다.

현재 사용자 메시지와 previous_active_request를 비교하여 이번 Turn의 active_request를 만든다.

우선순위:
현재 사용자가 명시한 값 > 이전 Thread State > 서비스 기본값

기본값:
- 기간 7일
- 반경 500km
- requested_sound_mood = auto
- broadcast_mode = normal
- sound_count = 3

규칙:
- 사용자가 변경하지 않은 이전 조건은 유지한다.
- 내부 재질의로 변경된 effective_scope는 다음 Turn의 requested_scope로 승계하지 않는다.
- earth_mood는 여기서 추측하지 않는다.
- region/location이 바뀌면 location_changed=true, earth_query_changed=true.
- 기간/반경만 바뀌면 earth_query_changed=true.
- requested_sound_mood가 바뀌면 sound_query_changed=true.
- broadcast_mode만 바뀌면 narration_changed=true.
"""

SUPERVISOR_PROMPT = """
당신은 Earth.FM의 Main LLM Terra Supervisor다.

현재 Thread State와 Request 변경사항을 보고 다음 route를 하나 선택한다.

earth_retrieval:
- 새 지역
- 기간/반경 변경
- 아직 Earth Evidence가 없음

sound_only:
- Earth Data는 재사용 가능하고 requested_sound_mood만 변경됨

narration_only:
- Earth Data와 Sound를 재사용할 수 있고 방송 해설 모드만 변경됨

외부 API Retriever들은 Luna SubAgent가 담당한다.
당신은 API raw data를 직접 생성하지 않는다.
"""

JUDGE_PROMPT = """
당신은 Earth.FM Main LLM Terra의 Evidence Judge 노드다.

Luna Retriever SubAgent가 가져온 NASA EONET / USGS / Weather 결과를 바탕으로
현재 방송을 위한 Evidence가 충분한지 판단한다.

decision:
- enough: 현재 Evidence로 주요 사건과 Earth Mood를 설명할 수 있음
- requery_earth: 기간/반경을 조정해 EONET/USGS를 다시 조회할 가치가 있음
- need_weather: 자연현상 데이터만으로 분위기가 부족해 현재 기상 Context가 필요함
- no_event: 정상 조회가 완료되었고 주요 자연현상이 없다고 종료 가능
- unavailable: 필수 Earth API가 모두 실패하여 판단 불가

규칙:
- 검색 확대는 고정 순서가 아니다. 현재 Evidence를 보고 합리적으로 next_days / next_radius_km를 정한다.
- 이미 의미 있는 사건이 있으면 불필요한 확대를 하지 않는다.
- Weather는 자연재해 데이터가 아니라 현재 환경 분위기를 보조하는 Context다.
- 사건을 생성하거나 수치를 수정하지 않는다.
- 범위를 축소하지 않는다.
"""

MOOD_SOUND_PLANNER_PROMPT = """
당신은 Earth.FM Main LLM Terra의 Mood & Sound Planner 노드다.

이 노드는 SubAgent가 아니다.
NASA EONET, USGS, 필요 시 Weather Context를 종합하여
실제 Earth Mood와 Freesound 검색 query를 계획한다.

Earth Mood enum:
calm, mysterious, tense, dynamic, powerful, recovery, neutral

규칙:
- earth_mood는 실제 Earth Data 기반.
- requested_sound_mood는 사용자의 청취 취향.
- 둘을 절대 동일시하지 않는다.
- 사용자가 calm을 원해도 Earth Data가 intense하면 실제 mood를 왜곡하지 않는다.
- sound_query만 사용자 취향에 맞춰 부드럽게 조정할 수 있다.
- Freesound 검색어는 2~6개 영어 환경음 키워드로 만든다.
- 비명/붕괴/사람의 피해를 연상시키는 자극적인 키워드를 피한다.
"""

RADIO_WRITER_PROMPT = """
당신은 Earth.FM Main LLM Terra의 Radio Writer 노드다.

당신은 새로운 Earth Data를 생성할 권한이 없다.
earth_data_brief와 weather_context는 이미 Evidence로 확정된 사실이다.

생성 가능:
- title
- ai_interpretation
- sound_selection_reason
- closing_message

금지:
- Evidence에 없는 규모·위치·사건·날짜 추가
- 미래 재난 예측
- 공식 재난 경보처럼 표현
- 대피/안전 판단
- 실제 사건의 소리라고 Freesound를 설명

broadcast_mode에 따라 말투만 바꾼다.
"""

QA_PROMPT = """
당신은 Earth.FM의 QA Reviewer SubAgent(Luna)다.

Main Terra가 작성한 broadcast draft를 제공된 Evidence와만 비교해 검증한다.
새로운 API를 호출하거나 새로운 사실을 검색/추가하지 않는다.

검사:
1. Earth Data 수치/사건 일치
2. Weather 수치 일치
3. Freesound 제목/제작자/License/URL 일치
4. Earth Data와 AI Interpretation 분리
5. 미래 재난 예측/공식 경보 표현 여부
6. 필수 Structured Output 필드 존재 여부

Critical 오류가 있으면 reject.
경미한 표현 문제는 pass_with_warning.
문제가 없으면 pass.

MVP에서는 Prompt Injection/Guardrail 판단을 수행하지 않는다.
그 기능은 향후 별도 확장 대상이다.

"""

"""
설명 : 사용자 입력을 정제하고 입력 가드레일을 실행한다.
작성자 : 임동건
"""
def input_middleware_node(state: EarthFMState) -> dict:
    result = before_agent_input(state["user_message"])
    report = result["report"]

    return {
        "request_id": state.get("request_id") or str(uuid.uuid4()),
        "sanitized_user_message": result["sanitized_text"],
        "input_guard_report": report,
        "trace": [
            {
                "step": "input_middleware",
                "data": report,
            }
        ],
    }

"""
설명 : 입력 가드 결과에 따라 분기를 정한다.
작성자 : 임동건
"""
def route_after_input_guard(state: EarthFMState) -> str:
    report = state.get("input_guard_report") or {}
    if report.get("blocked"):
        return "blocked_output"
    return "request_resolver"

"""
설명 : 차단된 요청에 대한 결과를 만든다.
작성자 : 임동건
"""
def blocked_output_node(state: EarthFMState) -> dict:
    guard = GuardrailReport.model_validate(
        state.get("input_guard_report")
    )
    output = EarthFMOutput(
        request_id=state.get("request_id") or str(uuid.uuid4()),
        status="blocked",
        broadcast=None,
        guardrails=guard,
        qa=None,
        runtime=RuntimeStats.model_validate(runtime_dict()),
        degraded_flags=[],
        error_message="요청이 입력 Guardrail에 의해 차단되었습니다.",
    )
    return {
        "final_output": output.model_dump(),
        "trace": [
            {
                "step": "blocked_output",
                "data": {"reason": "input_guard"},
            }
        ],
    }

"""
설명 : 이전 턴의 요청 상태를 가져온다.
작성자 : 임동건
"""
def _previous_request(state: EarthFMState) -> dict | None:
    return state.get("active_request")

"""
설명 : 이번 턴의 요청 조건을 확정한다.
작성자 : 임동건
"""
def request_resolver_node(state: EarthFMState) -> dict:
    defaults = {
        "location": "",
        "search_scope": {
            "days": settings.default_search_days,
            "radius_km": settings.default_radius_km,
        },
        "requested_sound_mood": settings.default_sound_mood,
        "broadcast_mode": settings.default_broadcast_mode,
        "sound_count": settings.default_sound_count,
    }

    previous = _previous_request(state)
    count_model_call("Terra:RequestResolver")
    resolver = _terra().with_structured_output(RequestResolution)
    result = resolver.invoke(
        [
            ("system", REQUEST_RESOLVER_PROMPT),
            (
                "user",
                json.dumps(
                    {
                        "user_message": state.get("sanitized_user_message") or state["user_message"],
                        "previous_active_request": previous,
                        "service_defaults": defaults,
                    },
                    ensure_ascii=False,
                ),
            ),
        ]
    )

    payload = result.model_dump()
    active = payload["active_request"]

    return {
        "active_request": active,
        "requested_scope": active["search_scope"],
        "location_changed": payload["location_changed"],
        "earth_query_changed": payload["earth_query_changed"],
        "sound_query_changed": payload["sound_query_changed"],
        "narration_changed": payload["narration_changed"],
        "trace": [{"step": "terra_request_resolver", "data": payload}],
    }

"""
설명 : 지역이 바뀌었는지 보고 다음 노드를 고른다.
작성자 : 임동건
"""
def route_after_request(state: EarthFMState) -> str:
    if state.get("resolved_location") is None or state.get("location_changed"):
        return "location_subagent"
    return "terra_supervisor"

"""
설명 : 지역명을 좌표로 확정한다.
작성자 : 임동건
"""
def location_subagent_node(state: EarthFMState) -> dict:
    request = ActiveRequest.model_validate(state["active_request"])
    result = run_location_subagent(request.location)

    if result.status != "ok" or result.location is None:
        raise RuntimeError(f"지역을 확정하지 못했습니다: {result.note}")

    return {
        "resolved_location": result.location.model_dump(),
        "trace": [{"step": "luna_location_subagent", "data": result.model_dump()}],
    }

"""
설명 : 이전에 모은 증거가 오래됐는지 검사한다.
작성자 : 임동건
"""
def _is_previous_evidence_stale(state: EarthFMState) -> bool:
    draft = state.get("broadcast_draft")
    if not draft or not draft.get("observed_at"):
        return False

    try:
        observed = datetime.fromisoformat(
            str(draft["observed_at"]).replace("Z", "+00:00")
        )
        if observed.tzinfo is None:
            observed = observed.replace(tzinfo=timezone.utc)

        age_minutes = (
            datetime.now(timezone.utc)
            - observed.astimezone(timezone.utc)
        ).total_seconds() / 60

        return age_minutes > settings.state_freshness_minutes
    except Exception:
        return True

"""
설명 : 다음 단계로 갈 경로를 정한다.
작성자 : 임동건
"""
def terra_supervisor_node(state: EarthFMState) -> dict:
    has_earth = bool(
        state.get("eonet_events")
        or state.get("earthquakes")
        or state.get("weather_context")
        or state.get("broadcast_draft")
    )
    has_sounds = bool(state.get("selected_sounds"))
    evidence_stale = _is_previous_evidence_stale(state)

    count_model_call("Terra:Supervisor")
    router = _terra().with_structured_output(MainRoute)
    result = router.invoke(
        [
            ("system", SUPERVISOR_PROMPT),
            (
                "user",
                json.dumps(
                    {
                        "location_changed": state.get("location_changed", False),
                        "earth_query_changed": state.get("earth_query_changed", False),
                        "sound_query_changed": state.get("sound_query_changed", False),
                        "narration_changed": state.get("narration_changed", False),
                        "has_earth_evidence": has_earth,
                        "has_selected_sounds": has_sounds,
                        "evidence_stale": evidence_stale,
                    },
                    ensure_ascii=False,
                ),
            ),
        ]
    )

    if not has_earth:
        result.route = "earth_retrieval"
        result.reason = "현재 Thread에 Earth Evidence가 없어 신규 조회가 필요합니다."
    elif evidence_stale:
        result.route = "earth_retrieval"
        result.reason = (
            "GR-06 Data Freshness: 이전 Evidence snapshot이 freshness 기준을 넘어 "
            "Earth Data를 다시 조회합니다."
        )

    return {
        "main_route": result.route,
        "main_route_reason": result.reason,
        "trace": [{"step": "terra_supervisor", "data": result.model_dump()}],
    }

"""
설명 : 슈퍼바이저가 고른 경로를 반환한다.
작성자 : 임동건
"""
def route_from_supervisor(state: EarthFMState) -> str:
    return state["main_route"]

"""
설명 : 지구 데이터 조회 범위를 정리하고 팬아웃을 준비한다.
작성자 : 임동건
"""
def earth_dispatch_node(state: EarthFMState) -> dict:
    if not state.get("effective_scope") or state.get("earth_query_changed") or state.get("location_changed"):
        effective = state["requested_scope"]
    else:
        effective = state["effective_scope"]

    return {
        "effective_scope": effective,
        "requery_count": 0 if state.get("earth_query_changed") or state.get("location_changed") else int(state.get("requery_count") or 0),
        "weather_context": None if state.get("earth_query_changed") or state.get("location_changed") else state.get("weather_context"),
        "eonet_status": "pending",
        "usgs_status": "pending",
        "weather_status": "not_requested",
        "trace": [{"step": "terra_earth_dispatch", "data": {"effective_scope": effective}}],
    }

"""
설명 : EONET에서 주변 자연현상을 조회한다.
작성자 : 임동건
"""
def eonet_subagent_node(state: EarthFMState) -> dict:
    loc = state["resolved_location"]
    scope = SearchScope.model_validate(
        state.get("effective_scope") or state["requested_scope"]
    )
    result = run_eonet_subagent(
        latitude=loc["latitude"],
        longitude=loc["longitude"],
        days=scope.days,
        radius_km=scope.radius_km,
    )

    return {
        "eonet_events": [x.model_dump() for x in result.events],
        "eonet_status": result.status,
        "trace": [{"step": "luna_eonet_subagent", "data": result.model_dump()}],
    }

"""
설명 : USGS에서 주변 지진 정보를 조회한다.
작성자 : 임동건
"""
def usgs_subagent_node(state: EarthFMState) -> dict:
    loc = state["resolved_location"]
    scope = SearchScope.model_validate(
        state.get("effective_scope") or state["requested_scope"]
    )
    result = run_usgs_subagent(
        latitude=loc["latitude"],
        longitude=loc["longitude"],
        days=scope.days,
        radius_km=scope.radius_km,
    )

    return {
        "earthquakes": [x.model_dump() for x in result.events],
        "usgs_status": result.status,
        "trace": [{"step": "luna_usgs_subagent", "data": result.model_dump()}],
    }

"""
설명 : EONET과 USGS 결과를 합치고 중복을 빼고 중요도순으로 정렬한다.
작성자 : 임동건
"""
def _combined_events(state: EarthFMState) -> list[EarthDataItem]:
    raw = list(state.get("eonet_events") or []) + list(state.get("earthquakes") or [])
    events = [EarthDataItem.model_validate(x) for x in raw]

    seen = set()
    unique = []
    for e in events:
        key = (
            e.source,
            e.event_id or f"{e.event_type}|{e.title}|{e.occurred_at}",
        )
        if key in seen:
            continue
        seen.add(key)
        unique.append(e)

    unique.sort(
        key=lambda x: x.importance_score if x.importance_score is not None else 0.0,
        reverse=True,
    )
    return unique[:3]

"""
설명 : 모은 증거로 방송에 쓸 데이터가 충분한지 판단한다.
작성자 : 임동건
"""
def terra_judge_node(state: EarthFMState) -> dict:
    events = _combined_events(state)
    eonet_ok = state.get("eonet_status") != "error"
    usgs_ok = state.get("usgs_status") != "error"
    weather = state.get("weather_context")

    current_scope = SearchScope.model_validate(
        state.get("effective_scope") or state["requested_scope"]
    )
    requested_scope = SearchScope.model_validate(state["requested_scope"])
    requery_count = int(state.get("requery_count") or 0)

    if not eonet_ok and not usgs_ok:
        result = EvidenceJudgement(
            decision="unavailable",
            reason="EONET과 USGS Retriever가 모두 실패했습니다.",
        )
    elif weather is not None and not events:
        result = EvidenceJudgement(
            decision="no_event",
            reason="EONET/USGS에서 주요 사건이 없고 Weather Context까지 확보되어 추가 조회 없이 종료합니다.",
        )
    elif state.get("weather_status") == "error" and not events:
        result = EvidenceJudgement(
            decision="no_event",
            reason="EONET/USGS에서는 주요 사건이 없으며 Weather Retriever는 실패했습니다. Earth Data 기준으로 no_event 처리합니다.",
        )
    else:
        count_model_call("Terra:EvidenceJudge")
        judge = _terra().with_structured_output(EvidenceJudgement)
        result = judge.invoke(
            [
                ("system", JUDGE_PROMPT),
                (
                    "user",
                    json.dumps(
                        {
                            "requested_scope": requested_scope.model_dump(),
                            "effective_scope": current_scope.model_dump(),
                            "requery_count": requery_count,
                            "max_requery_count": settings.max_requery_count,
                            "hard_limits": {
                                "days": settings.max_search_days,
                                "radius_km": settings.max_radius_km,
                            },
                            "source_status": {
                                "eonet_ok": eonet_ok,
                                "usgs_ok": usgs_ok,
                            },
                            "earth_events": [x.model_dump() for x in events],
                            "weather_context": weather,
                        },
                        ensure_ascii=False,
                    ),
                ),
            ]
        )
    if (
        result.decision == "no_event"
        and not events
        and weather is None
        and state.get("weather_status") == "not_requested"
    ):
        result = EvidenceJudgement(
            decision="need_weather",
            reason=(
                "주요 자연현상이 없어 현재 Weather Context를 "
                "보조 정보로 조회합니다."
            ),
        )

    if result.decision == "need_weather" and (
        weather is not None
        or state.get("weather_status") == "error"
    ):
        ...
    
    if result.decision == "need_weather" and (weather is not None or state.get("weather_status") == "error"):
        result = EvidenceJudgement(
            decision="enough" if events else "no_event",
            reason="Weather 조회가 이미 완료되었거나 실패 상태이므로 현재 Evidence 기준으로 진행합니다.",
        )

    if result.decision == "requery_earth":
        if requery_count >= settings.max_requery_count:
            result = EvidenceJudgement(
                decision="enough" if events else ("no_event" if weather else "need_weather"),
                reason="재조회 상한에 도달하여 현재 Evidence 기준으로 다음 단계로 진행합니다.",
            )
        else:
            next_days = min(
                settings.max_search_days,
                max(current_scope.days, int(result.next_days or current_scope.days)),
            )
            next_radius = min(
                settings.max_radius_km,
                max(current_scope.radius_km, float(result.next_radius_km or current_scope.radius_km)),
            )
            if next_days == current_scope.days and next_radius == current_scope.radius_km:
                result = EvidenceJudgement(
                    decision="enough" if events else ("no_event" if weather else "need_weather"),
                    reason="유효한 범위 확대가 제안되지 않아 현재 Evidence 기준으로 진행합니다.",
                )
            else:
                result.next_days = next_days
                result.next_radius_km = next_radius

    return {
        "evidence_judgement": result.model_dump(),
        "trace": [{"step": "terra_evidence_judge", "data": result.model_dump()}],
    }

"""
설명 : 판단 결과에 따라 다음 노드를 고른다.
작성자 : 임동건
"""
def route_from_judge(state: EarthFMState) -> str:
    decision = state["evidence_judgement"]["decision"]
    if decision == "requery_earth":
        return "prepare_requery"
    if decision == "need_weather":
        return "weather_subagent"
    return "mood_planner"

"""
설명 : 재조회용 범위를 세팅한다.
작성자 : 임동건
"""
def prepare_requery_node(state: EarthFMState) -> dict:
    judgement = EvidenceJudgement.model_validate(state["evidence_judgement"])
    current = SearchScope.model_validate(
        state.get("effective_scope") or state["requested_scope"]
    )
    next_scope = SearchScope(
        days=judgement.next_days or current.days,
        radius_km=judgement.next_radius_km or current.radius_km,
    )
    return {
        "effective_scope": next_scope.model_dump(),
        "requery_count": int(state.get("requery_count") or 0) + 1,
        "weather_context": None,
        "eonet_status": "pending",
        "usgs_status": "pending",
        "weather_status": "not_requested",
        "trace": [{"step": "terra_requery_plan", "data": next_scope.model_dump()}],
    }

"""
설명 : 현재 날씨 정보를 조회한다.
작성자 : 임동건
"""
def weather_subagent_node(state: EarthFMState) -> dict:
    loc = state["resolved_location"]
    result = run_weather_subagent(
        latitude=loc["latitude"],
        longitude=loc["longitude"],
    )

    return {
        "weather_context": result.weather.model_dump() if result.weather else None,
        "weather_status": result.status,
        "trace": [{"step": "luna_weather_subagent", "data": result.model_dump()}],
    }

"""
설명 : 지구 데이터 분위기와 Freesound 검색어를 정한다.
작성자 : 임동건
"""
def mood_planner_node(state: EarthFMState) -> dict:
    request = ActiveRequest.model_validate(state["active_request"])
    events = _combined_events(state)
    weather = state.get("weather_context")

    count_model_call("Terra:MoodSoundPlanner")
    planner = _terra().with_structured_output(MoodPlan)
    result = planner.invoke(
        [
            ("system", MOOD_SOUND_PLANNER_PROMPT),
            (
                "user",
                json.dumps(
                    {
                        "earth_data": [x.model_dump() for x in events],
                        "weather_context": weather,
                        "requested_sound_mood": request.requested_sound_mood,
                    },
                    ensure_ascii=False,
                ),
            ),
        ]
    )

    if not events and not weather:
        result.earth_mood = "neutral"
        result.mood_reason = "확인 가능한 Earth Data와 Weather Context가 충분하지 않습니다."

    return {
        "earth_mood": result.earth_mood,
        "mood_reason": result.mood_reason,
        "sound_query": result.sound_query,
        "trace": [{"step": "terra_mood_sound_planner", "data": result.model_dump()}],
    }

"""
설명 : Freesound에서 환경음 후보를 고른다.
작성자 : 임동건
"""
def freesound_subagent_node(state: EarthFMState) -> dict:
    request = ActiveRequest.model_validate(state["active_request"])
    result = run_freesound_subagent(
        query=state["sound_query"],
        limit=request.sound_count,
    )

    return {
        "selected_sounds": [x.model_dump() for x in result.sounds],
        "freesound_status": result.status,
        "trace": [{"step": "luna_freesound_subagent", "data": result.model_dump()}],
    }

"""
설명 : 조회된 데이터를 방송용 요약 문장으로 만든다.
작성자 : 임동건
"""
def make_earth_data_brief(state: EarthFMState) -> str:
    events = _combined_events(state)
    lines = []

    for e in events:
        if e.source == "USGS":
            parts = [f"USGS — {e.title}"]
            if e.magnitude is not None:
                parts.append(f"규모 {e.magnitude}")
            if e.depth_km is not None:
                parts.append(f"깊이 {e.depth_km}km")
            if e.distance_km is not None:
                parts.append(f"기준 위치에서 약 {e.distance_km}km")
            if e.occurred_at:
                parts.append(f"발생 {e.occurred_at}")
            if e.tsunami is not None:
                parts.append(f"쓰나미 상태 {'표시됨' if e.tsunami else '표시 없음'}")
            lines.append(", ".join(parts) + ".")
        else:
            parts = [f"NASA EONET — {e.title} ({e.event_type})"]
            if e.distance_km is not None:
                parts.append(f"기준 위치에서 약 {e.distance_km}km")
            if e.occurred_at:
                parts.append(f"최근 관측 {e.occurred_at}")
            if e.ongoing is not None:
                parts.append("진행 중" if e.ongoing else "종료")
            lines.append(", ".join(parts) + ".")

    weather = state.get("weather_context")
    if weather:
        w = []
        if weather.get("temperature_c") is not None:
            w.append(f"기온 {weather['temperature_c']}°C")
        if weather.get("precipitation_mm") is not None:
            w.append(f"강수 {weather['precipitation_mm']}mm")
        if weather.get("wind_speed_kmh") is not None:
            w.append(f"풍속 {weather['wind_speed_kmh']}km/h")
        if weather.get("observed_at"):
            w.append(f"관측 {weather['observed_at']}")
        if w:
            lines.append("Open-Meteo Weather — " + ", ".join(w) + ".")

    if not lines:
        return "현재 최종 검색 범위에서 방송에 소개할 주요 자연현상이 확인되지 않았습니다."

    return "\n".join(lines)

"""
설명 : 방송 원고 초안을 작성한다.
작성자 : 임동건
"""
def radio_writer_node(state: EarthFMState) -> dict:
    request = ActiveRequest.model_validate(state["active_request"])
    brief = make_earth_data_brief(state)
    sounds = state.get("selected_sounds") or []

    count_model_call("Terra:RadioWriter")
    writer = _terra().with_structured_output(NarrationParts)
    result = writer.invoke(
        [
            ("system", RADIO_WRITER_PROMPT),
            (
                "user",
                json.dumps(
                    {
                        "location": state["resolved_location"],
                        "broadcast_mode": request.broadcast_mode,
                        "earth_data_brief": brief,
                        "earth_mood": state.get("earth_mood"),
                        "mood_reason": state.get("mood_reason"),
                        "requested_sound_mood": request.requested_sound_mood,
                        "selected_sounds": sounds,
                        "qa_feedback": state.get("qa_result") if int(state.get("qa_retry_count") or 0) > 0 else None,
                    },
                    ensure_ascii=False,
                ),
            ),
        ]
    )

    events = _combined_events(state)
    eonet_ok = state.get("eonet_status") != "error"
    usgs_ok = state.get("usgs_status") != "error"

    flags = []
    if state.get("eonet_status") == "error":
        flags.append("eonet_unavailable")
    if state.get("usgs_status") == "error":
        flags.append("usgs_unavailable")
    if state.get("weather_status") == "error":
        flags.append("weather_unavailable")
    if state.get("freesound_status") == "error":
        flags.append("freesound_unavailable")

    if not eonet_ok and not usgs_ok:
        data_status = "unavailable"
    elif not eonet_ok or not usgs_ok:
        data_status = "partial"
    elif not events:
        data_status = "no_event"
    else:
        data_status = "complete"

    requested_scope = SearchScope.model_validate(state["requested_scope"])
    effective_scope = SearchScope.model_validate(
        state.get("effective_scope") or state["requested_scope"]
    )

    loc = state["resolved_location"]
    location_name = ", ".join(
        [
            x
            for x in [loc.get("name"), loc.get("admin1"), loc.get("country")]
            if x
        ]
    )

    draft = EarthRadioBroadcast(
        title=result.title,
        location=location_name,
        observed_at=utc_now_iso(),
        requested_scope=requested_scope,
        effective_scope=effective_scope,
        requery_count=int(state.get("requery_count") or 0),
        scope_expanded=requested_scope != effective_scope,
        data_status=data_status,
        earth_mood=state.get("earth_mood") or "neutral",
        mood_reason=state.get("mood_reason") or "",
        requested_sound_mood=request.requested_sound_mood,
        earth_data=events,
        weather_context=state.get("weather_context"),
        selected_sounds=sounds,
        broadcast_mode=request.broadcast_mode,
        earth_data_brief=brief,
        ai_interpretation=result.ai_interpretation,
        sound_selection_reason=result.sound_selection_reason,
        closing_message=result.closing_message,
        disclaimer=(
            "이 서비스는 공개 데이터 기반의 교육·문화·엔터테인먼트 서비스이며 "
            "공식 재난 경보, 재난 예측 또는 안전 판단이 아닙니다. "
            "추천 환경음은 실제 사건의 음향을 재현한 것이 아니라 데이터 분위기에 맞춘 선택입니다."
        ),
        degraded_flags=list(dict.fromkeys(flags)),
    )

    return {
        "earth_data_brief": brief,
        "broadcast_draft": draft.model_dump(),
        "trace": [{"step": "terra_radio_writer", "data": {"title": result.title}}],
    }

"""
설명 : 원고가 증거와 맞는지 검토한다.
작성자 : 임동건
"""
def qa_reviewer_node(state: EarthFMState) -> dict:
    count_model_call("Luna:QAReviewer")
    reviewer = ChatOpenAI(
        model=settings.sub_model,
        api_key=settings.openai_api_key,
        temperature=0.5,
        timeout=30,
    ).with_structured_output(QAVerdict)

    evidence = {
        "earth_data": [x.model_dump() for x in _combined_events(state)],
        "weather_context": state.get("weather_context"),
        "selected_sounds": state.get("selected_sounds") or [],
    }

    result = reviewer.invoke(
        [
            ("system", QA_PROMPT),
            (
                "user",
                json.dumps(
                    {
                        "evidence": evidence,
                        "broadcast_draft": state["broadcast_draft"],
                    },
                    ensure_ascii=False,
                ),
            ),
        ]
    )

    return {
        "qa_result": result.model_dump(),
        "trace": [{"step": "luna_qa_reviewer", "data": result.model_dump()}],
    }

"""
설명 : 검토 결과에 따라 원고 재작성 여부를 정한다.
작성자 : 임동건
"""
def route_from_qa(state: EarthFMState) -> str:
    qa = QAVerdict.model_validate(state["qa_result"])
    retry_count = int(state.get("qa_retry_count") or 0)

    if qa.verdict == "reject" and qa.regenerate_required and retry_count < 1:
        return "retry_writer"

    return "output_guardrail"

"""
설명 : QA 재시도 횟수를 하나 올린다.
작성자 : 임동건
"""
def retry_writer_marker_node(state: EarthFMState) -> dict:
    return {
        "qa_retry_count": int(state.get("qa_retry_count") or 0) + 1,
        "trace": [{"step": "qa_retry_writer", "data": {"retry": 1}}],
    }

"""
설명 : 완성된 방송에 출력 가드레일을 적용한다.
작성자 : 임동건
"""
def output_guardrail_node(state: EarthFMState) -> dict:
    report = after_broadcast_output(state["broadcast_draft"])

    return {
        "output_guard_report": report,
        "trace": [
            {
                "step": "output_guardrail",
                "data": report,
            }
        ],
    }

"""
설명 : 출력 가드 결과에 따라 최종 처리 방식을 고른다.
작성자 : 임동건
"""
def route_after_output_guard(state: EarthFMState) -> str:
    report = state.get("output_guard_report") or {}
    qa = QAVerdict.model_validate(state["qa_result"]) if state.get("qa_result") else None

    if qa is not None and qa.verdict == "reject":
        return "degraded_finalize"

    if report.get("passed"):
        return "finalize"

    return "degraded_finalize"

"""
설명 : 검증을 통과 못한 부분을 안전한 문구로 대체해 결과를 만든다.
작성자 : 임동건
"""
def degraded_finalize_node(state: EarthFMState) -> dict:
    draft = dict(state["broadcast_draft"])
    flags = list(draft.get("degraded_flags") or [])
    flags.append("output_guardrail_degraded")

    draft["ai_interpretation"] = (
        "AI 해석 영역이 최종 검증을 통과하지 못해 이번 방송에서는 감성 해석을 생략합니다."
    )
    draft["sound_selection_reason"] = (
        "표시된 환경음은 Freesound의 허용 라이선스 후보 중 선택된 음원입니다."
    )
    draft["closing_message"] = (
        "확인된 Earth Data와 출처를 기준으로 내용을 확인해 주세요."
    )
    draft["degraded_flags"] = list(dict.fromkeys(flags))
    draft["qa_verdict"] = state.get("qa_result")

    safe_broadcast = EarthRadioBroadcast.model_validate(draft)

    input_report = GuardrailReport.model_validate(
        state.get("input_guard_report")
    )
    output_report = GuardrailReport.model_validate(
        state.get("output_guard_report")
    )

    merged_checks = input_report.checks + output_report.checks
    merged_guard = GuardrailReport(
        passed=False,
        blocked=False,
        checks=merged_checks,
        sanitized_fields=input_report.sanitized_fields,
    )

    output = EarthFMOutput(
        request_id=state.get("request_id") or str(uuid.uuid4()),
        status="degraded",
        broadcast=safe_broadcast,
        guardrails=merged_guard,
        qa=QAVerdict.model_validate(state["qa_result"]) if state.get("qa_result") else None,
        runtime=RuntimeStats.model_validate(runtime_dict()),
        degraded_flags=safe_broadcast.degraded_flags,
        error_message=None,
    )

    return {
        "final_output": output.model_dump(),
        "trace": [
            {
                "step": "degraded_finalize",
                "data": {"flags": safe_broadcast.degraded_flags},
            }
        ],
    }

"""
설명 : 최종 방송 결과를 완성한다.
작성자 : 임동건
"""
def finalize_node(state: EarthFMState) -> dict:
    draft = dict(state["broadcast_draft"])
    draft["qa_verdict"] = state.get("qa_result")
    final_broadcast = EarthRadioBroadcast.model_validate(draft)

    input_report = GuardrailReport.model_validate(
        state.get("input_guard_report")
    )
    output_report = GuardrailReport.model_validate(
        state.get("output_guard_report")
    )

    merged_guard = GuardrailReport(
        passed=input_report.passed and output_report.passed,
        blocked=input_report.blocked or output_report.blocked,
        checks=input_report.checks + output_report.checks,
        sanitized_fields=input_report.sanitized_fields + output_report.sanitized_fields,
    )

    status = "ok"
    if final_broadcast.degraded_flags:
        status = "degraded"

    output = EarthFMOutput(
        request_id=state.get("request_id") or str(uuid.uuid4()),
        status=status,
        broadcast=final_broadcast,
        guardrails=merged_guard,
        qa=QAVerdict.model_validate(state["qa_result"]) if state.get("qa_result") else None,
        runtime=RuntimeStats.model_validate(runtime_dict()),
        degraded_flags=final_broadcast.degraded_flags,
    )

    return {
        "final_output": output.model_dump(),
        "trace": [
            {
                "step": "finalize",
                "data": {
                    "status": status,
                    "qa": state.get("qa_result"),
                },
            }
        ],
    }

checkpointer = InMemorySaver()

"""
설명 : 전체 그래프를 조립한다.
작성자 : 임동건
"""
def build_graph():
    graph = StateGraph(EarthFMState)

    graph.add_node("input_middleware", input_middleware_node)
    graph.add_node("blocked_output", blocked_output_node)
    graph.add_node("request_resolver", request_resolver_node)
    graph.add_node("location_subagent", location_subagent_node)
    graph.add_node("terra_supervisor", terra_supervisor_node)

    graph.add_node("earth_dispatch", earth_dispatch_node)
    graph.add_node("eonet_subagent", eonet_subagent_node)
    graph.add_node("usgs_subagent", usgs_subagent_node)
    graph.add_node("terra_judge", terra_judge_node)
    graph.add_node("prepare_requery", prepare_requery_node)
    graph.add_node("weather_subagent", weather_subagent_node)

    graph.add_node("mood_planner", mood_planner_node)
    graph.add_node("freesound_subagent", freesound_subagent_node)
    graph.add_node("radio_writer", radio_writer_node)

    graph.add_node("qa_reviewer", qa_reviewer_node)
    graph.add_node("retry_writer_marker", retry_writer_marker_node)
    graph.add_node("output_guardrail", output_guardrail_node)
    graph.add_node("degraded_finalize", degraded_finalize_node)
    graph.add_node("finalize", finalize_node)

    graph.add_edge(START, "input_middleware")

    graph.add_conditional_edges(
        "input_middleware",
        route_after_input_guard,
        {
            "blocked_output": "blocked_output",
            "request_resolver": "request_resolver",
        },
    )
    graph.add_edge("blocked_output", END)

    graph.add_conditional_edges(
        "request_resolver",
        route_after_request,
        {
            "location_subagent": "location_subagent",
            "terra_supervisor": "terra_supervisor",
        },
    )

    graph.add_edge("location_subagent", "terra_supervisor")

    graph.add_conditional_edges(
        "terra_supervisor",
        route_from_supervisor,
        {
            "earth_retrieval": "earth_dispatch",
            "sound_only": "mood_planner",
            "narration_only": "radio_writer",
        },
    )

    graph.add_edge("earth_dispatch", "eonet_subagent")
    graph.add_edge("earth_dispatch", "usgs_subagent")

    graph.add_edge(["eonet_subagent", "usgs_subagent"], "terra_judge")

    graph.add_conditional_edges(
        "terra_judge",
        route_from_judge,
        {
            "prepare_requery": "prepare_requery",
            "weather_subagent": "weather_subagent",
            "mood_planner": "mood_planner",
        },
    )

    graph.add_edge("prepare_requery", "eonet_subagent")
    graph.add_edge("prepare_requery", "usgs_subagent")
    graph.add_edge("weather_subagent", "terra_judge")

    graph.add_edge("mood_planner", "freesound_subagent")
    graph.add_edge("freesound_subagent", "radio_writer")
    graph.add_edge("radio_writer", "qa_reviewer")

    graph.add_conditional_edges(
        "qa_reviewer",
        route_from_qa,
        {
            "retry_writer": "retry_writer_marker",
            "output_guardrail": "output_guardrail",
        },
    )

    graph.add_edge("retry_writer_marker", "radio_writer")

    graph.add_conditional_edges(
        "output_guardrail",
        route_after_output_guard,
        {
            "finalize": "finalize",
            "degraded_finalize": "degraded_finalize",
        },
    )

    graph.add_edge("finalize", END)
    graph.add_edge("degraded_finalize", END)

    return graph.compile(checkpointer=checkpointer)

earthfm_graph = build_graph()
