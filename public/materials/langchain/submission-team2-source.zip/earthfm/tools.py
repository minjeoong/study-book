"""
설명 : Open-Meteo 지오코딩·기상, NASA EONET, USGS 지진, Freesound API를 직접 호출하는 외부 연동 도구들이 있다. 받아온 결과를 서비스 형식으로 다듬어 반환한다.
작성자 : 김동욱
작성일 : 2026-09-11
참조 : config.py, utils.py
return : 없음
"""


from __future__ import annotations
from datetime import datetime, timedelta, timezone
from typing import Any
import requests
from langchain.tools import tool
from .config import settings
from .utils import (
    haversine_km,
    importance_score,
    is_allowed_freesound_license,
    radius_to_bbox,
    representative_point,
)


"""
설명 : GET 요청을 보내고 JSON 응답을 돌려준다.
작성자 : 김동욱
"""
def _get_json(url: str, *, params: dict[str, Any], headers: dict[str, str] | None = None) -> dict:
    response = requests.get(
        url,
        params=params,
        headers=headers,
        timeout=settings.request_timeout_sec,
    )
    response.raise_for_status()
    return response.json()


"""
설명 : 지역명을 Open-Meteo에서 위치 후보로 바꿔준다.
작성자 : 김동욱
"""
@tool
def resolve_location_api(query: str, language: str = "ko") -> dict:
    data = _get_json(
        settings.geocoding_url,
        params={
            "name": query,
            "count": 5,
            "language": language,
            "format": "json",
        },
    )
    results = data.get("results") or []
    candidates = []
    for row in results[:5]:
        candidates.append(
            {
                "name": row.get("name"),
                "country": row.get("country"),
                "admin1": row.get("admin1"),
                "latitude": row.get("latitude"),
                "longitude": row.get("longitude"),
                "timezone": row.get("timezone"),
            }
        )
    return {
        "found": bool(candidates),
        "query": query,
        "candidates": candidates,
    }


"""
설명 : 주변의 진행 중인 자연현상을 EONET에서 찾는다.
작성자 : 김동욱
"""
@tool
def search_eonet_api(
    latitude: float,
    longitude: float,
    days: int = 7,
    radius_km: float = 500,
) -> dict:
    min_lon, max_lat, max_lon, min_lat = radius_to_bbox(latitude, longitude, radius_km)
    bbox = f"{min_lon},{max_lat},{max_lon},{min_lat}"
    data = _get_json(
        settings.eonet_url,
        params={
            "days": days,
            "status": "open",
            "bbox": bbox,
            "limit": 100,
        },
    )
    normalized = []
    for event in data.get("events", []):
        geometries = event.get("geometry") or []
        if not geometries:
            continue
        latest = sorted(geometries, key=lambda g: g.get("date") or "")[-1]
        point = representative_point(latest.get("type", ""), latest.get("coordinates"))
        if point is None:
            continue
        event_lat, event_lon = point
        dist = haversine_km(latitude, longitude, event_lat, event_lon)
        if dist > radius_km:
            continue
        categories = event.get("categories") or []
        category = categories[0] if categories else {}
        event_type = category.get("id") or category.get("title") or "other"
        sources = event.get("sources") or []
        source_url = sources[0].get("url") if sources else event.get("link")
        occurred_at = latest.get("date")
        ongoing = event.get("closed") is None
        magnitude = event.get("magnitudeValue")
        item = {
            "source": "NASA_EONET",
            "event_id": event.get("id"),
            "event_type": event_type,
            "title": event.get("title") or "Untitled EONET event",
            "occurred_at": occurred_at,
            "magnitude": magnitude,
            "magnitude_unit": event.get("magnitudeUnit"),
            "depth_km": None,
            "distance_km": round(dist, 1),
            "ongoing": ongoing,
            "tsunami": None,
            "source_url": source_url,
        }
        item["importance_score"] = importance_score(
            source="NASA_EONET",
            occurred_at=occurred_at,
            distance_km=dist,
            magnitude=magnitude,
            event_type=event_type,
            ongoing=ongoing,
            completeness=1.0,
        )
        normalized.append(item)
    normalized.sort(key=lambda x: x["importance_score"], reverse=True)
    return {"events": normalized[:30]}


"""
설명 : 주변에서 일어난 지진을 USGS에서 찾는다.
작성자 : 김동욱
"""
@tool
def search_usgs_api(
    latitude: float,
    longitude: float,
    days: int = 7,
    radius_km: float = 500,
) -> dict:
    start = datetime.now(timezone.utc) - timedelta(days=days)
    data = _get_json(
        settings.usgs_url,
        params={
            "format": "geojson",
            "latitude": latitude,
            "longitude": longitude,
            "maxradiuskm": radius_km,
            "starttime": start.isoformat(),
            "orderby": "time",
            "limit": 100,
        },
    )
    normalized = []
    for feature in data.get("features", []):
        props = feature.get("properties") or {}
        coords = (feature.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        event_lon = float(coords[0])
        event_lat = float(coords[1])
        depth_km = float(coords[2]) if len(coords) >= 3 and coords[2] is not None else None
        dist = haversine_km(latitude, longitude, event_lat, event_lon)
        occurred_at = None
        if props.get("time") is not None:
            occurred_at = datetime.fromtimestamp(
                props["time"] / 1000,
                tz=timezone.utc,
            ).isoformat()
        magnitude = props.get("mag")
        item = {
            "source": "USGS",
            "event_id": feature.get("id"),
            "event_type": "earthquake",
            "title": props.get("title") or props.get("place") or "Earthquake",
            "occurred_at": occurred_at,
            "magnitude": magnitude,
            "magnitude_unit": "Mw" if magnitude is not None else None,
            "depth_km": depth_km,
            "distance_km": round(dist, 1),
            "ongoing": False,
            "tsunami": bool(props.get("tsunami")) if props.get("tsunami") is not None else None,
            "source_url": props.get("url"),
        }
        completeness = 1.0 if all(
            [
                occurred_at is not None,
                magnitude is not None,
                depth_km is not None,
                props.get("url"),
            ]
        ) else 0.7
        item["importance_score"] = importance_score(
            source="USGS",
            occurred_at=occurred_at,
            distance_km=dist,
            magnitude=magnitude,
            event_type="earthquake",
            ongoing=False,
            completeness=completeness,
        )
        normalized.append(item)
    normalized.sort(key=lambda x: x["importance_score"], reverse=True)
    return {"events": normalized[:30]}


"""
설명 : 해당 좌표의 현재 날씨를 조회한다.
작성자 : 김동욱
"""
@tool
def get_weather_api(
    latitude: float,
    longitude: float,
) -> dict:
    current_fields = ",".join(
        [
            "temperature_2m",
            "precipitation",
            "rain",
            "weather_code",
            "wind_speed_10m",
        ]
    )
    data = _get_json(
        settings.weather_url,
        params={
            "latitude": latitude,
            "longitude": longitude,
            "current": current_fields,
            "timezone": "auto",
        },
    )
    current = data.get("current") or {}
    return {
        "weather": {
            "observed_at": current.get("time"),
            "temperature_c": current.get("temperature_2m"),
            "precipitation_mm": current.get("precipitation"),
            "rain_mm": current.get("rain"),
            "weather_code": current.get("weather_code"),
            "wind_speed_kmh": current.get("wind_speed_10m"),
            "timezone": data.get("timezone"),
        }
    }


"""
설명 : 조건에 맞는 Freesound 환경음 후보를 찾는다.
작성자 : 김동욱
"""
@tool
def search_freesound_api(query: str, limit: int = 3) -> dict:
    if not settings.freesound_api_key:
        return {
            "available": False,
            "error": "FREESOUND_API_KEY is not configured",
            "sounds": [],
        }
    fields = "id,url,name,tags,username,license,duration,previews"
    data = _get_json(
        settings.freesound_url,
        params={
            "query": query,
            "page_size": max(15, limit * 5),
            "fields": fields,
        },
        headers={"Authorization": f"Token {settings.freesound_api_key}"},
    )
    sounds = []
    for row in data.get("results", []):
        if not is_allowed_freesound_license(row.get("license")):
            continue
        previews = row.get("previews") or {}
        preview = previews.get("preview-lq-mp3")
        duration = row.get("duration")
        if not preview or not duration:
            continue
        sounds.append(
            {
                "sound_id": str(row.get("id")),
                "title": row.get("name") or "Untitled sound",
                "preview_url": preview,
                "duration_sec": float(duration),
                "tags": (row.get("tags") or [])[:20],
                "creator": row.get("username") or "unknown",
                "license": row.get("license") or "",
                "page_url": row.get("url") or "",
            }
        )
        if len(sounds) >= limit:
            break
    return {
        "available": True,
        "sounds": sounds,
    }
