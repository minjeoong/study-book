"""
설명 : 랭그래프가 한 턴 동안 들고 다니는 상태 항목들의 모양을 정한다. 요청 정보, 조회 결과, 방송 초안, 실행 추적이 여기에 담긴다.
작성자 : 임동건
작성일 : 2026-09-11
참조 : 없음
return : 없음
"""


from __future__ import annotations
import operator
from typing import Annotated, Any, TypedDict


"""
설명 : 그래프가 한 턴 동안 공유하는 상태 항목들의 형식.
"""
class EarthFMState(TypedDict, total=False):
    user_message: str
    sanitized_user_message: str
    thread_id: str
    request_id: str
    input_guard_report: dict[str, Any]
    output_guard_report: dict[str, Any]
    active_request: dict[str, Any]
    resolved_location: dict[str, Any] | None
    location_changed: bool
    earth_query_changed: bool
    sound_query_changed: bool
    narration_changed: bool
    main_route: str
    main_route_reason: str
    requested_scope: dict[str, Any]
    effective_scope: dict[str, Any]
    requery_count: int
    eonet_events: list[dict[str, Any]]
    earthquakes: list[dict[str, Any]]
    weather_context: dict[str, Any] | None
    selected_sounds: list[dict[str, Any]]
    eonet_status: str
    usgs_status: str
    weather_status: str
    freesound_status: str
    evidence_judgement: dict[str, Any]
    earth_mood: str
    mood_reason: str
    sound_query: str
    earth_data_brief: str
    broadcast_draft: dict[str, Any]
    qa_result: dict[str, Any]
    qa_retry_count: int
    final_output: dict[str, Any]
    trace: Annotated[list[dict[str, Any]], operator.add]
