"""
설명 : 서비스 전체에서 주고받는 데이터 모양을 pydantic 모델로 정의해 둔 파일이다. 요청, 지역, 지구 데이터, 방송 내용, 출력 봉투 스키마가 여기 모여 있다.
작성자 : 김태동
작성일 : 2026-09-11
참조 : 없음
return : 없음
"""


from typing import Any, Literal
from pydantic import BaseModel, Field
EarthMood = Literal[
    "calm",
    "mysterious",
    "tense",
    "dynamic",
    "powerful",
    "recovery",
    "neutral",
]
BroadcastMode = Literal[
    "normal",
    "documentary",
    "children",
    "emotional",
    "data",
]


"""
설명 : 기간과 반경으로 만든 검색 범위.
"""
class SearchScope(BaseModel):
    days: int = Field(default=7, ge=1, le=30)
    radius_km: float = Field(default=500, gt=0, le=5000)


"""
설명 : 이번 턴에 확정된 지역, 검색 범위, 청취 분위기, 방송 모드.
"""
class ActiveRequest(BaseModel):
    location: str
    search_scope: SearchScope
    requested_sound_mood: str | None = "auto"
    broadcast_mode: BroadcastMode = "normal"
    sound_count: int = Field(default=3, ge=1, le=5)


"""
설명 : 이번 턴에 확정된 요청과 함께 바뀐 항목들.
"""
class RequestResolution(BaseModel):
    active_request: ActiveRequest
    location_changed: bool = False
    earth_query_changed: bool = False
    sound_query_changed: bool = False
    narration_changed: bool = False


"""
설명 : 슈퍼바이저가 고른 다음 단계 경로.
"""
class MainRoute(BaseModel):
    route: Literal["earth_retrieval", "sound_only", "narration_only"]
    reason: str


"""
설명 : EONET·USGS 조회에 쓸 좌표와 검색 범위 계획.
"""
class EarthQueryPlan(BaseModel):
    latitude: float
    longitude: float
    days: int = Field(ge=1, le=30)
    radius_km: float = Field(gt=0, le=5000)


"""
설명 : 날씨 조회에 쓸 좌표 계획.
"""
class WeatherQueryPlan(BaseModel):
    latitude: float
    longitude: float


"""
설명 : Freesound 검색에 쓸 검색어와 개수 계획.
"""
class SoundQueryPlan(BaseModel):
    query: str
    limit: int = Field(ge=1, le=5)


"""
설명 : 확정된 지역의 이름, 좌표, 시간대.
"""
class LocationInfo(BaseModel):
    name: str
    country: str | None = None
    admin1: str | None = None
    latitude: float
    longitude: float
    timezone: str | None = None


"""
설명 : 지역 확정 서브에이전트의 실행 결과.
"""
class LocationSubAgentResult(BaseModel):
    status: Literal["ok", "empty", "error"]
    location: LocationInfo | None = None
    candidates: list[LocationInfo] = []
    note: str = ""


"""
설명 : EONET이나 USGS에서 받아온 사건 하나.
"""
class EarthDataItem(BaseModel):
    source: Literal["NASA_EONET", "USGS"]
    event_id: str | None = None
    event_type: str
    title: str
    occurred_at: str | None = None
    magnitude: float | None = None
    magnitude_unit: str | None = None
    depth_km: float | None = None
    distance_km: float | None = None
    ongoing: bool | None = None
    tsunami: bool | None = None
    source_url: str | None = None
    importance_score: float | None = Field(default=None, ge=0, le=1)


"""
설명 : 지구 데이터 조회 서브에이전트의 실행 결과.
"""
class EarthRetrieverResult(BaseModel):
    status: Literal["ok", "empty", "error"]
    source: Literal["NASA_EONET", "USGS"]
    events: list[EarthDataItem] = []
    note: str = ""


"""
설명 : 현재 날씨 데이터(기온, 강수, 풍속 등).
"""
class WeatherContext(BaseModel):
    observed_at: str | None = None
    temperature_c: float | None = None
    precipitation_mm: float | None = None
    rain_mm: float | None = None
    weather_code: int | None = None
    wind_speed_kmh: float | None = None
    timezone: str | None = None


"""
설명 : 날씨 조회 서브에이전트의 실행 결과.
"""
class WeatherSubAgentResult(BaseModel):
    status: Literal["ok", "empty", "error"]
    weather: WeatherContext | None = None
    note: str = ""


"""
설명 : 모은 증거로 방송을 만들기에 충분한지에 대한 판단.
"""
class EvidenceJudgement(BaseModel):
    decision: Literal[
        "enough",
        "requery_earth",
        "need_weather",
        "no_event",
        "unavailable",
    ]
    reason: str
    next_days: int | None = None
    next_radius_km: float | None = None


"""
설명 : 지구 데이터 분위기 판정과 Freesound 검색어 계획.
"""
class MoodPlan(BaseModel):
    earth_mood: EarthMood
    mood_reason: str
    sound_query: str


"""
설명 : 선정된 Freesound 음원의 정보.
"""
class SoundSelection(BaseModel):
    sound_id: str
    title: str
    preview_url: str
    duration_sec: float = Field(gt=0)
    tags: list[str] = []
    creator: str
    license: str
    page_url: str


"""
설명 : 음원 검색 서브에이전트의 실행 결과.
"""
class SoundRetrieverResult(BaseModel):
    status: Literal["ok", "empty", "error"]
    sounds: list[SoundSelection] = []
    note: str = ""


"""
설명 : 방송 원고 중 AI가 생성하는 문구들.
"""
class NarrationParts(BaseModel):
    title: str
    ai_interpretation: str
    sound_selection_reason: str
    closing_message: str


"""
설명 : QA 검토 결과와 발견된 문제 목록.
"""
class QAVerdict(BaseModel):
    verdict: Literal["pass", "pass_with_warning", "reject"]
    factual_consistency: bool
    weather_consistency: bool
    sound_consistency: bool
    safety_valid: bool
    schema_valid: bool
    critical: bool
    issues: list[str] = []
    regenerate_required: bool = False


"""
설명 : 가드레일 개별 검사 항목의 결과 하나.
"""
class GuardrailCheck(BaseModel):
    name: str
    passed: bool
    severity: Literal["low", "medium", "high", "critical"] = "low"
    action: Literal["allow", "mask", "sanitize", "block", "degrade"] = "allow"
    issues: list[str] = []


"""
설명 : 입력·출력 가드레일 검사 결과 모음.
"""
class GuardrailReport(BaseModel):
    passed: bool
    blocked: bool = False
    checks: list[GuardrailCheck] = []
    sanitized_fields: list[str] = []


"""
설명 : 한 번 실행의 호출 수와 처리 추적 기록.
"""
class RuntimeStats(BaseModel):
    tool_calls: int = 0
    model_calls: int = 0
    cache_hits: int = 0
    retry_count: int = 0
    middleware_trace: list[str] = []


"""
설명 : 최종 방송의 전체 내용(데이터, 해석, 음원, 안내 문구).
"""
class EarthRadioBroadcast(BaseModel):
    title: str
    location: str
    observed_at: str
    requested_scope: SearchScope
    effective_scope: SearchScope
    requery_count: int = Field(default=0, ge=0)
    scope_expanded: bool = False
    data_status: Literal["complete", "partial", "no_event", "unavailable"]
    earth_mood: EarthMood
    mood_reason: str
    requested_sound_mood: str | None = None
    earth_data: list[EarthDataItem]
    weather_context: WeatherContext | None = None
    selected_sounds: list[SoundSelection]
    broadcast_mode: BroadcastMode
    earth_data_brief: str
    ai_interpretation: str
    sound_selection_reason: str
    closing_message: str
    disclaimer: str
    qa_verdict: QAVerdict | None = None
    degraded_flags: list[str] = []


"""
설명 : 만들어진 음성의 상태와 사용된 음원 정보.
"""
class AudioOutput(BaseModel):
    status: Literal[
        "not_requested",
        "mixed",
        "narration_only",
        "failed",
    ] = "not_requested"
    mime_type: str = "audio/mpeg"
    duration_sec: float | None = None
    narration_segments: int = 0
    background_track_count: int = 0
    used_sound_ids: list[str] = []
    skipped_sound_ids: list[str] = []
    note: str | None = None


"""
설명 : 서비스가 밖으로 낼 본내는 최종 결과 봉투.
"""
class EarthFMOutput(BaseModel):
    schema_version: str = "1.0"
    request_id: str
    status: Literal["ok", "degraded", "blocked", "error"]
    broadcast: EarthRadioBroadcast | None = None
    audio: AudioOutput = AudioOutput()
    guardrails: GuardrailReport
    qa: QAVerdict | None = None
    runtime: RuntimeStats = RuntimeStats()
    degraded_flags: list[str] = []
    error_message: str | None = None
