"""
설명 : 프롬프트 인젝션 탐지, 비밀키 가리기, 좌표와 상세 주소 일반화, 출력 문구의 숫자와 재난 표현 검사 같은 가드레일 규칙 도구들이 모여 있다.
작성자 : 김태동
작성일 : 2026-09-11
참조 : schemas.py, utils.py, config.py
return : 없음
"""


from __future__ import annotations
import copy
import math
import re
from datetime import datetime, timezone
from typing import Any
from langchain.tools import tool
from pydantic import BaseModel
from .schemas import (
    EarthRadioBroadcast,
    GuardrailCheck,
    GuardrailReport,
    SearchScope,
)
from .utils import is_allowed_freesound_license
from .config import settings
SECRET_PATTERNS = [
    re.compile(r"\bsk-[A-Za-z0-9_\-]{12,}\b"),
    re.compile(r"\b(?:api[_ -]?key|secret[_ -]?key)\s*[:=]\s*[A-Za-z0-9_\-]{8,}\b", re.I),
]
INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(all\s+)?previous", re.I),
    re.compile(r"previous\s+instructions?", re.I),
    re.compile(r"system\s+prompt", re.I),
    re.compile(r"developer\s+(message|instructions?)", re.I),
    re.compile(r"이전\s*(모든\s*)?(지시|명령).{0,12}무시", re.I),
    re.compile(r"시스템\s*프롬프트", re.I),
    re.compile(r"내부\s*(지시|프롬프트)", re.I),
]
DISASTER_SAFETY_PATTERNS = [
    re.compile(r"(곧|조만간|앞으로).{0,15}(지진|화산|폭풍|홍수).{0,10}(발생|폭발|온다|일어날)", re.I),
    re.compile(r"(반드시|즉시).{0,10}(대피|피난|이동)", re.I),
    re.compile(r"(공식\s*경보|재난\s*경보가\s*발령)", re.I),
    re.compile(r"(안전합니다|위험하지\s*않습니다|위험합니다)", re.I),
]
COORD_PATTERN = re.compile(
    r"(?P<lat>-?\d{1,2}\.\d{3,})\s*[, ]\s*(?P<lon>-?\d{1,3}\.\d{3,})"
)
KOREAN_DETAIL_NUMBER = re.compile(
    r"(?P<prefix>(?:로|길|동|가|읍|면|리)\s*)\d{1,4}(?:-\d{1,4})?"
)


"""
설명 : API 키 같은 비밀 토큰을 가려 돌려준다.
작성자 : 김태동
"""
def _mask_secrets(text: str) -> tuple[str, bool]:
    changed = False
    out = text
    for pattern in SECRET_PATTERNS:
        new = pattern.sub("[REDACTED_SECRET]", out)
        if new != out:
            changed = True
        out = new
    return out, changed


"""
설명 : 정확한 좌표를 대략적인 값으로 뭉둥게 만든다.
작성자 : 김태동
"""
def _generalize_coordinates(text: str) -> tuple[str, bool]:
    changed = False
    """
    설명 : 바꿔치기하면서 바뀜 플래그를 세운다.
    작성자 : 김태동
    """
    def repl(match: re.Match) -> str:
        nonlocal changed
        changed = True
        lat = round(float(match.group("lat")), 2)
        lon = round(float(match.group("lon")), 2)
        return f"{lat:.2f}, {lon:.2f}"
    return COORD_PATTERN.sub(repl, text), changed


"""
설명 : 상세 주소 번호를 지우고 동·로 이름만 남긴다.
작성자 : 김태동
"""
def _generalize_address(text: str) -> tuple[str, bool]:
    new = KOREAN_DETAIL_NUMBER.sub(r"\g<prefix>[상세번호]", text)
    return new, new != text


"""
설명 : 입력의 불필요한 공백과 제어문자를 정리한다.
작성자 : 김태동
"""
@tool
def normalize_input_tool(text: str) -> dict:
    normalized = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", " ", text)
    normalized = re.sub(r"[ \t]+", " ", normalized)
    normalized = re.sub(r"\n{3,}", "\n\n", normalized).strip()
    return {"text": normalized}


"""
설명 : 입력에서 인젝션·비밀키·개인 위치정보를 검사한다.
작성자 : 김태동
"""
@tool
def input_guard_tool(text: str) -> dict:
    checks: list[dict] = []
    sanitized_fields: list[str] = []
    injection_hits = [p.pattern for p in INJECTION_PATTERNS if p.search(text)]
    checks.append(
        GuardrailCheck(
            name="GR-01 Prompt Injection",
            passed=not injection_hits,
            severity="high",
            action="block" if injection_hits else "allow",
            issues=["prompt injection pattern detected"] if injection_hits else [],
        ).model_dump()
    )
    sanitized, secret_changed = _mask_secrets(text)
    checks.append(
        GuardrailCheck(
            name="GR-02 API Secret",
            passed=True,
            severity="critical",
            action="mask" if secret_changed else "allow",
            issues=["secret-like token masked"] if secret_changed else [],
        ).model_dump()
    )
    if secret_changed:
        sanitized_fields.append("input.secret")
    sanitized, coord_changed = _generalize_coordinates(sanitized)
    sanitized, address_changed = _generalize_address(sanitized)
    pii_changed = coord_changed or address_changed
    checks.append(
        GuardrailCheck(
            name="GR-03 Location PII",
            passed=True,
            severity="high",
            action="sanitize" if pii_changed else "allow",
            issues=["precise location generalized"] if pii_changed else [],
        ).model_dump()
    )
    if pii_changed:
        sanitized_fields.append("input.location")
    blocked = bool(injection_hits)
    report = GuardrailReport(
        passed=not blocked,
        blocked=blocked,
        checks=[GuardrailCheck.model_validate(c) for c in checks],
        sanitized_fields=sanitized_fields,
    )
    return {
        "sanitized_text": sanitized,
        "report": report.model_dump(),
    }


"""
설명 : 도구 인자 검증 시 입력 형식을 맞추기 위한 모델.
"""
class ToolArgsValidationInput(BaseModel):
    tool_name: str
    args: dict[str, Any]


"""
설명 : 도구 인자가 허용 범위 안인지 검사한다.
작성자 : 김태동
"""
@tool(args_schema=ToolArgsValidationInput)
def validate_tool_args_tool(tool_name: str, args: dict) -> dict:
    issues = []
    if "latitude" in args:
        try:
            lat = float(args["latitude"])
            if not math.isfinite(lat) or not (-90 <= lat <= 90):
                issues.append("invalid latitude")
        except Exception:
            issues.append("invalid latitude")
    if "longitude" in args:
        try:
            lon = float(args["longitude"])
            if not math.isfinite(lon) or not (-180 <= lon <= 180):
                issues.append("invalid longitude")
        except Exception:
            issues.append("invalid longitude")
    if "days" in args:
        try:
            days = int(args["days"])
            if not (1 <= days <= 30):
                issues.append("days out of range")
        except Exception:
            issues.append("invalid days")
    if "radius_km" in args:
        try:
            radius = float(args["radius_km"])
            if not (0 < radius <= 5000):
                issues.append("radius_km out of range")
        except Exception:
            issues.append("invalid radius_km")
    if tool_name == "search_freesound_api":
        if not str(args.get("query", "")).strip():
            issues.append("empty freesound query")
        try:
            limit = int(args.get("limit", 0))
            if not (1 <= limit <= 5):
                issues.append("freesound limit out of range")
        except Exception:
            issues.append("invalid freesound limit")
    check = GuardrailCheck(
        name="GR-12 Tool Argument Validation",
        passed=not issues,
        severity="high",
        action="block" if issues else "allow",
        issues=issues,
    )
    return check.model_dump()


"""
설명 : 외부 결과에서 허용된 필드만 남기고 비밀을 긁어낸다.
작성자 : 김태동
"""
@tool
def sanitize_tool_output_tool(tool_name: str, payload: dict) -> dict:
    data = copy.deepcopy(payload)
    if tool_name == "search_freesound_api":
        safe_sounds = []
        for s in data.get("sounds") or []:
            if not is_allowed_freesound_license(s.get("license")):
                continue
            safe_sounds.append(
                {
                    "sound_id": str(s.get("sound_id", "")),
                    "title": str(s.get("title", ""))[:200],
                    "preview_url": str(s.get("preview_url", ""))[:1000],
                    "duration_sec": s.get("duration_sec"),
                    "tags": [str(t)[:80] for t in (s.get("tags") or [])[:20]],
                    "creator": str(s.get("creator", ""))[:120],
                    "license": str(s.get("license", ""))[:500],
                    "page_url": str(s.get("page_url", ""))[:1000],
                }
            )
        data["sounds"] = safe_sounds
    """
    설명 : 문자열을 순회하며 비밀 토큰을 긁어낸다.
    작성자 : 김태동
    """
    def scrub(obj):
        if isinstance(obj, str):
            return _mask_secrets(obj)[0]
        if isinstance(obj, list):
            return [scrub(x) for x in obj]
        if isinstance(obj, dict):
            return {k: scrub(v) for k, v in obj.items()}
        return obj
    return {"payload": scrub(data)}


"""
설명 : 방송에 근거로 쓰인 숫자들을 모아 돌려준다.
작성자 : 김태동
"""
def _all_evidence_numbers(broadcast: EarthRadioBroadcast) -> set[str]:
    numbers: set[str] = set()
    for e in broadcast.earth_data:
        for value in [
            e.magnitude,
            e.depth_km,
            e.distance_km,
            e.importance_score,
        ]:
            if value is not None:
                numbers.add(str(value))
                try:
                    numbers.add(str(float(value)).rstrip("0").rstrip("."))
                except Exception:
                    pass
        if e.distance_km is not None:
            numbers.add(str(round(float(e.distance_km))))
    if broadcast.weather_context:
        for value in [
            broadcast.weather_context.temperature_c,
            broadcast.weather_context.precipitation_mm,
            broadcast.weather_context.rain_mm,
            broadcast.weather_context.wind_speed_kmh,
        ]:
            if value is not None:
                numbers.add(str(value))
                try:
                    numbers.add(str(float(value)).rstrip("0").rstrip("."))
                except Exception:
                    pass
    return {n for n in numbers if n}


"""
설명 : 완성된 방송이 규칙을 지키는지 여러 항목으로 검사한다.
작성자 : 김태동
"""
@tool
def output_guard_tool(broadcast: dict) -> dict:
    checks: list[GuardrailCheck] = []
    try:
        parsed = EarthRadioBroadcast.model_validate(broadcast)
        checks.append(
            GuardrailCheck(
                name="GR-11 Structured Output",
                passed=True,
                severity="high",
            )
        )
    except Exception as exc:
        checks.append(
            GuardrailCheck(
                name="GR-11 Structured Output",
                passed=False,
                severity="high",
                action="degrade",
                issues=[str(exc)[:500]],
            )
        )
        return GuardrailReport(
            passed=False,
            blocked=False,
            checks=checks,
        ).model_dump()
    freshness_issue = False
    freshness_message = []
    try:
        observed = datetime.fromisoformat(
            parsed.observed_at.replace("Z", "+00:00")
        )
        if observed.tzinfo is None:
            observed = observed.replace(tzinfo=timezone.utc)
        age_min = (
            datetime.now(timezone.utc) - observed.astimezone(timezone.utc)
        ).total_seconds() / 60
        freshness_issue = age_min > settings.state_freshness_minutes
        if freshness_issue:
            freshness_message.append(
                f"evidence snapshot age={age_min:.1f}min"
            )
    except Exception:
        freshness_issue = True
        freshness_message.append("invalid observed_at")
    checks.append(
        GuardrailCheck(
            name="GR-06 Data Freshness",
            passed=not freshness_issue,
            severity="high",
            action="degrade" if freshness_issue else "allow",
            issues=freshness_message,
        )
    )
    expected_expanded = parsed.requested_scope != parsed.effective_scope
    scope_ok = expected_expanded == parsed.scope_expanded
    checks.append(
        GuardrailCheck(
            name="GR-07 Search Scope Disclosure",
            passed=scope_ok,
            severity="medium",
            action="degrade" if not scope_ok else "allow",
            issues=[] if scope_ok else ["scope_expanded mismatch"],
        )
    )
    invalid_sound_ids = [
        s.sound_id
        for s in parsed.selected_sounds
        if not is_allowed_freesound_license(s.license)
    ]
    checks.append(
        GuardrailCheck(
            name="GR-08 Freesound License",
            passed=not invalid_sound_ids,
            severity="high",
            action="degrade" if invalid_sound_ids else "allow",
            issues=[f"invalid license sound_id={x}" for x in invalid_sound_ids],
        )
    )
    generative_text = "\n".join(
        [
            parsed.ai_interpretation,
            parsed.sound_selection_reason,
            parsed.closing_message,
        ]
    )
    safety_hits = [
        p.pattern for p in DISASTER_SAFETY_PATTERNS if p.search(generative_text)
    ]
    checks.append(
        GuardrailCheck(
            name="GR-09 Disaster Safety",
            passed=not safety_hits,
            severity="critical",
            action="degrade" if safety_hits else "allow",
            issues=["unsafe disaster expression"] if safety_hits else [],
        )
    )
    allowed_numbers = _all_evidence_numbers(parsed)
    generated_numbers = set(
        re.findall(r"(?<![\w])\d+(?:\.\d+)?", generative_text)
    )
    unexpected_numbers = sorted(
        n for n in generated_numbers
        if n not in allowed_numbers
        and n not in {"0", "1"}
    )
    checks.append(
        GuardrailCheck(
            name="GR-05 Earth Data Grounding",
            passed=not unexpected_numbers,
            severity="critical",
            action="degrade" if unexpected_numbers else "allow",
            issues=[f"unexpected numeric claim: {n}" for n in unexpected_numbers],
        )
    )
    mood_issue = False
    if not parsed.earth_data and parsed.weather_context is None:
        mood_issue = parsed.earth_mood not in {"neutral", "calm"}
    checks.append(
        GuardrailCheck(
            name="GR-10 Mood/Facts Separation",
            passed=not mood_issue,
            severity="high",
            action="degrade" if mood_issue else "allow",
            issues=["earth_mood unsupported by evidence"] if mood_issue else [],
        )
    )
    passed = all(c.passed for c in checks)
    return GuardrailReport(
        passed=passed,
        blocked=False,
        checks=checks,
    ).model_dump()
