"""
설명 : 그래프를 직접 부르지 않고 바깥에서 호출하는 실행 진입점 함수들이 있다. 텍스트 결과만 받는 실행과 TTS 오디오까지 붙여 주는 실행 두 가지를 제공한다.
작성자 : 임동건
작성일 : 2026-09-11
참조 : graph.py, middleware.py, audio.py
return : 없음
"""


from __future__ import annotations
import uuid
from .graph import earthfm_graph
from .middleware import begin_runtime


"""
설명 : 그래프를 실행해 최종 방송 결과와 실행 추적을 돌려준다.
작성자 : 임동건
"""
def run_earth_radio(
    user_message: str,
    *,
    thread_id: str = "default",
) -> tuple[dict, list[dict]]:
    begin_runtime()
    result = earthfm_graph.invoke(
        {
            "user_message": user_message,
            "thread_id": thread_id,
            "request_id": str(uuid.uuid4()),
            "trace": [],
        },
        config={
            "configurable": {
                "thread_id": thread_id,
            }
        },
    )
    final = result.get("final_output")
    if not final:
        raise RuntimeError(
            "Earth.FM graph가 final_output을 생성하지 못했습니다."
        )
    return final, result.get("trace") or []


"""
설명 : 방송 결과에 TTS 음성을 붙여 오디오까지 함께 반환하는 진입점이다.
작성자 : 임동건
"""
def run_earth_radio_with_audio(
    user_message: str,
    *,
    thread_id: str = "default",
    voice: str | None = None,
    mix_ambient: bool = True,
) -> tuple[dict, list[dict], bytes | None]:
    from .audio import render_radio_audio
    output, trace = run_earth_radio(
        user_message,
        thread_id=thread_id,
    )
    if output.get("status") in {"blocked", "error"}:
        return output, trace, None
    broadcast = output.get("broadcast")
    if not broadcast:
        return output, trace, None
    try:
        audio_bytes, audio_meta = render_radio_audio(
            broadcast,
            voice=voice,
            mix_ambient=mix_ambient,
        )
        output["audio"] = audio_meta.model_dump()
        if (
            mix_ambient
            and broadcast.get("selected_sounds")
            and audio_meta.status == "narration_only"
        ):
            flags = list(output.get("degraded_flags") or [])
            flags.append("audio_mixer_degraded")
            output["degraded_flags"] = list(dict.fromkeys(flags))
            if output.get("status") == "ok":
                output["status"] = "degraded"
        return output, trace, audio_bytes
    except Exception as exc:
        output["audio"] = {
            "status": "failed",
            "mime_type": "audio/mpeg",
            "duration_sec": None,
            "narration_segments": 0,
            "background_track_count": 0,
            "used_sound_ids": [],
            "skipped_sound_ids": [],
            "note": f"{type(exc).__name__}: {exc}",
        }
        flags = list(output.get("degraded_flags") or [])
        flags.append("audio_failed")
        output["degraded_flags"] = list(dict.fromkeys(flags))
        if output.get("status") == "ok":
            output["status"] = "degraded"
        return output, trace, None
