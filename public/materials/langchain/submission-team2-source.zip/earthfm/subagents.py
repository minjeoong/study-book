"""
설명 : Luna 서브에이전트들이 모인 파일이다. 지역명 확정, EONET과 USGS·기상 조회 계획 세우기, Freesound 환경음 검색을 맡는다.
작성자 : 김동욱
작성일 : 2026-09-11
참조 : tools.py, middleware.py, schemas.py, config.py
return : 없음
"""

from __future__ import annotations

import json
from typing import Any

from langchain_openai import ChatOpenAI

from .config import settings
from .schemas import (
    EarthDataItem,
    EarthQueryPlan,
    EarthRetrieverResult,
    LocationInfo,
    LocationSubAgentResult,
    SoundQueryPlan,
    SoundRetrieverResult,
    WeatherContext,
    WeatherQueryPlan,
    WeatherSubAgentResult,
)
from .middleware import count_model_call, invoke_tool_with_middleware
from .tools import (
    get_weather_api,
    resolve_location_api,
    search_eonet_api,
    search_freesound_api,
    search_usgs_api,
)

"""
설명 : Luna 서브 모델을 만든다.
작성자 : 김동욱
"""
def _luna():
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY가 설정되지 않았습니다.")
    return ChatOpenAI(
        model=settings.sub_model,
        api_key=settings.openai_api_key,
        temperature=0.5,
        timeout=30,
    )

LOCATION_PROMPT = """
당신은 Earth.FM의 Location Retriever SubAgent이며 모델은 Luna다.

Main Terra가 요청한 지역을 Open-Meteo Geocoding 결과에서 확정한다.

규칙:
- 제공된 API candidate 밖의 위치·좌표를 만들지 않는다.
- name, country, admin1을 보고 가장 적합한 후보를 선택한다.
- 위치 검색 외의 역할을 수행하지 않는다.
- 자연현상·지진·Mood·방송 문장을 생성하지 않는다.
"""

EONET_PROMPT = """
당신은 Earth.FM의 NASA EONET Retriever SubAgent이며 모델은 Luna다.

Main Terra가 전달한 retrieval task를 NASA EONET API 파라미터로 변환한다.

규칙:
- latitude/longitude는 Terra가 제공한 값 그대로 사용한다.
- 검색 범위를 임의로 확대하거나 축소하지 않는다.
- Mood, 중요도 해석, 방송 문장을 만들지 않는다.
- 당신의 역할은 EONET 조회 계획을 확정하는 것뿐이다.
"""

USGS_PROMPT = """
당신은 Earth.FM의 USGS Earthquake Retriever SubAgent이며 모델은 Luna다.

Main Terra가 전달한 retrieval task를 USGS API 파라미터로 변환한다.

규칙:
- latitude/longitude/days/radius_km는 Terra가 지정한 범위를 보존한다.
- 검색 범위를 스스로 확대하지 않는다.
- 지진 규모나 깊이를 예측하지 않는다.
- Mood나 방송 원고를 작성하지 않는다.
"""

WEATHER_PROMPT = """
당신은 Earth.FM의 Open-Meteo Weather Retriever SubAgent이며 모델은 Luna다.

Terra Evidence Judge가 Weather Context가 필요하다고 판단했을 때만 실행된다.

규칙:
- Terra가 제공한 좌표를 그대로 사용한다.
- 현재 기상 Context 조회 외의 판단을 하지 않는다.
- 재난 위험도나 미래 날씨를 추론하지 않는다.
"""

FREESOUND_PROMPT = """
당신은 Earth.FM의 Freesound Retriever SubAgent이며 모델은 Luna다.

Terra Mood & Sound Planner가 만든 sound_query를 받아 Freesound 검색 계획을 확정한다.

규칙:
- sound_query의 의도를 다른 분위기로 바꾸지 않는다.
- 요청된 limit를 초과하지 않는다.
- 음원 분위기 기획은 하지 않는다. Planner는 Terra의 역할이다.
- 실제 음원 metadata는 Freesound API 결과만 사용한다.
"""

"""
설명 : 도구를 안전하게 실행하고 오류를 글자로 바꿔 돌려준다.
작성자 : 김동욱
"""
def _safe_invoke(tool, args: dict[str, Any]) -> tuple[dict | None, str | None]:
    try:
        result = invoke_tool_with_middleware(tool, args, use_cache=True)
        return result, None
    except Exception as exc:
        return None, f"{type(exc).__name__}: {exc}"

"""
설명 : Luna의 조회 계획을 Terra가 정한 범위에 맞게 고정한다.
작성자 : 김동욱
"""
def _locked_earth_plan(
    *,
    prompt: str,
    latitude: float,
    longitude: float,
    days: int,
    radius_km: float,
) -> EarthQueryPlan:
    count_model_call("Luna:EarthQueryPlan")
    planner = _luna().with_structured_output(EarthQueryPlan)
    proposed = planner.invoke(
        [
            ("system", prompt),
            (
                "user",
                json.dumps(
                    {
                        "terra_task": {
                            "latitude": latitude,
                            "longitude": longitude,
                            "days": days,
                            "radius_km": radius_km,
                        }
                    },
                    ensure_ascii=False,
                ),
            ),
        ]
    )

    return EarthQueryPlan(
        latitude=latitude,
        longitude=longitude,
        days=days,
        radius_km=radius_km,
    )

"""
설명 : 지역명 후보를 받아 최종 위치를 확정한다.
작성자 : 김동욱
"""
def run_location_subagent(query: str) -> LocationSubAgentResult:
    api_result, error = _safe_invoke(
        resolve_location_api,
        {"query": query, "language": "ko"},
    )
    if error:
        return LocationSubAgentResult(status="error", note=error)

    candidates_raw = (api_result or {}).get("candidates") or []
    if not candidates_raw:
        return LocationSubAgentResult(status="empty", note="Geocoding 결과 없음")

    candidates = [LocationInfo.model_validate(x) for x in candidates_raw]

    count_model_call("Luna:LocationRetriever")
    selector = _luna().with_structured_output(LocationSubAgentResult)
    result = selector.invoke(
        [
            ("system", LOCATION_PROMPT),
            (
                "user",
                json.dumps(
                    {
                        "requested_location": query,
                        "api_candidates": [c.model_dump() for c in candidates],
                    },
                    ensure_ascii=False,
                ),
            ),
        ]
    )

    if result.location is None:
        result.location = candidates[0]

    valid = any(
        abs(result.location.latitude - c.latitude) < 1e-9
        and abs(result.location.longitude - c.longitude) < 1e-9
        for c in candidates
    )
    if not valid:
        result.location = candidates[0]
        result.note = (
            result.note + " | Luna가 API 후보 밖 위치를 선택해 첫 후보로 교정"
        ).strip(" |")

    result.candidates = candidates
    result.status = "ok"
    return result

"""
설명 : EONET 조회 계획을 세우고 API 결과를 받아온다.
작성자 : 김동욱
"""
def run_eonet_subagent(
    *,
    latitude: float,
    longitude: float,
    days: int,
    radius_km: float,
) -> EarthRetrieverResult:
    try:
        plan = _locked_earth_plan(
            prompt=EONET_PROMPT,
            latitude=latitude,
            longitude=longitude,
            days=days,
            radius_km=radius_km,
        )
    except Exception as exc:
        return EarthRetrieverResult(
            status="error",
            source="NASA_EONET",
            note=f"Luna planning failed: {type(exc).__name__}: {exc}",
        )

    api_result, error = _safe_invoke(
        search_eonet_api,
        plan.model_dump(),
    )
    if error:
        return EarthRetrieverResult(
            status="error",
            source="NASA_EONET",
            note=error,
        )

    events = [
        EarthDataItem.model_validate(x)
        for x in ((api_result or {}).get("events") or [])
    ]
    return EarthRetrieverResult(
        status="ok" if events else "empty",
        source="NASA_EONET",
        events=events,
        note="Luna planned → NASA EONET API retrieved",
    )

"""
설명 : USGS 조회 계획을 세우고 지진 데이터를 받아온다.
작성자 : 김동욱
"""
def run_usgs_subagent(
    *,
    latitude: float,
    longitude: float,
    days: int,
    radius_km: float,
) -> EarthRetrieverResult:
    try:
        plan = _locked_earth_plan(
            prompt=USGS_PROMPT,
            latitude=latitude,
            longitude=longitude,
            days=days,
            radius_km=radius_km,
        )
    except Exception as exc:
        return EarthRetrieverResult(
            status="error",
            source="USGS",
            note=f"Luna planning failed: {type(exc).__name__}: {exc}",
        )

    api_result, error = _safe_invoke(
        search_usgs_api,
        plan.model_dump(),
    )
    if error:
        return EarthRetrieverResult(
            status="error",
            source="USGS",
            note=error,
        )

    events = [
        EarthDataItem.model_validate(x)
        for x in ((api_result or {}).get("events") or [])
    ]
    return EarthRetrieverResult(
        status="ok" if events else "empty",
        source="USGS",
        events=events,
        note="Luna planned → USGS API retrieved",
    )

"""
설명 : 날씨 조회 계획을 세우고 현재 기상 정보를 받아온다.
작성자 : 김동욱
"""
def run_weather_subagent(
    *,
    latitude: float,
    longitude: float,
) -> WeatherSubAgentResult:
    try:
        count_model_call("Luna:WeatherRetriever")
        planner = _luna().with_structured_output(WeatherQueryPlan)
        _ = planner.invoke(
            [
                ("system", WEATHER_PROMPT),
                (
                    "user",
                    json.dumps(
                        {
                            "terra_task": {
                                "latitude": latitude,
                                "longitude": longitude,
                            }
                        },
                        ensure_ascii=False,
                    ),
                ),
            ]
        )
        plan = WeatherQueryPlan(latitude=latitude, longitude=longitude)
    except Exception as exc:
        return WeatherSubAgentResult(
            status="error",
            note=f"Luna planning failed: {type(exc).__name__}: {exc}",
        )

    api_result, error = _safe_invoke(
        get_weather_api,
        plan.model_dump(),
    )
    if error:
        return WeatherSubAgentResult(status="error", note=error)

    raw = (api_result or {}).get("weather")
    if not raw:
        return WeatherSubAgentResult(status="empty", note="Weather 결과 없음")

    return WeatherSubAgentResult(
        status="ok",
        weather=WeatherContext.model_validate(raw),
        note="Luna planned → Open-Meteo Weather API retrieved",
    )

"""
설명 : Freesound 검색 계획을 세우고 허용된 환경음을 고른다.
작성자 : 김동욱
"""
def run_freesound_subagent(
    *,
    query: str,
    limit: int,
) -> SoundRetrieverResult:
    try:
        count_model_call("Luna:FreesoundRetriever")
        planner = _luna().with_structured_output(SoundQueryPlan)
        proposed = planner.invoke(
            [
                ("system", FREESOUND_PROMPT),
                (
                    "user",
                    json.dumps(
                        {
                            "terra_task": {
                                "sound_query": query,
                                "limit": limit,
                            }
                        },
                        ensure_ascii=False,
                    ),
                ),
            ]
        )

        plan = SoundQueryPlan(query=query, limit=limit)
    except Exception as exc:
        return SoundRetrieverResult(
            status="error",
            note=f"Luna planning failed: {type(exc).__name__}: {exc}",
        )

    api_result, error = _safe_invoke(
        search_freesound_api,
        plan.model_dump(),
    )
    if error:
        return SoundRetrieverResult(status="error", note=error)

    if not api_result or not api_result.get("available"):
        return SoundRetrieverResult(
            status="error",
            note=(api_result or {}).get("error", "Freesound unavailable"),
        )

    sounds = (api_result or {}).get("sounds") or []
    if not sounds:
        keywords = query.split()
        if len(keywords) > 2:
            fallback_query = " ".join(keywords[:2])
            fallback_result, fallback_error = _safe_invoke(
                search_freesound_api,
                {"query": fallback_query, "limit": limit},
            )
            if fallback_error:
                return SoundRetrieverResult(
                    status="error",
                    note=fallback_error,
                )
            sounds = (fallback_result or {}).get("sounds") or []
            if sounds:
                return SoundRetrieverResult(
                    status="ok",
                    sounds=sounds,
                    note=(
                        "Luna planned → Freesound API retrieved "
                        f"with simplified query: {fallback_query}"
                    ),
                )

    if not sounds:
        return SoundRetrieverResult(status="empty", note="Freesound 결과 없음")

    return SoundRetrieverResult(
        status="ok",
        sounds=sounds,
        note="Luna planned → Freesound API retrieved",
    )
