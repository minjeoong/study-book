"""
설명 : 환경변수에서 서비스 설정값을 읽어 한곳에 모아 두는 파일이다. 검색 범위 기본값부터 모델, 음성, 오디오 믹서, 호출 한도까지 여기서 관리한다.
작성자 : 임동건
작성일 : 2026-09-11
참조 : 없음
return : 없음
"""


from dataclasses import dataclass
import os
from dotenv import load_dotenv
load_dotenv()


"""
설명 : 서비스 전체 설정값을 환경변수에서 고정하는 클래스.
"""
@dataclass(frozen=True)
class Settings:
    default_search_days: int = int(os.getenv("DEFAULT_SEARCH_DAYS", "7"))
    default_radius_km: float = float(os.getenv("DEFAULT_RADIUS_KM", "500"))
    default_sound_mood: str = os.getenv("DEFAULT_SOUND_MOOD", "auto")
    default_broadcast_mode: str = os.getenv("DEFAULT_BROADCAST_MODE", "normal")
    default_sound_count: int = int(os.getenv("DEFAULT_SOUND_COUNT", "3"))
    openai_api_key: str | None = os.getenv("OPENAI_API_KEY")
    main_model: str = os.getenv("OPENAI_MODEL", "gpt-5.6-terra")
    sub_model: str = os.getenv("SUBAGENT_MODEL", "gpt-5.6-luna")
    stt_model: str = os.getenv("STT_MODEL", "gpt-4o-mini-transcribe")
    tts_model: str = os.getenv("TTS_MODEL", "gpt-4o-mini-tts")
    tts_voice: str = os.getenv("TTS_VOICE", "coral")
    tts_segment_chars: int = int(os.getenv("TTS_SEGMENT_CHARS", "2200"))
    freesound_api_key: str | None = os.getenv("FREESOUND_API_KEY")
    geocoding_url: str = "https://geocoding-api.open-meteo.com/v1/search"
    weather_url: str = "https://api.open-meteo.com/v1/forecast"
    eonet_url: str = "https://eonet.gsfc.nasa.gov/api/v3/events"
    usgs_url: str = "https://earthquake.usgs.gov/fdsnws/event/1/query"
    freesound_url: str = "https://freesound.org/apiv2/search/"
    max_requery_count: int = int(os.getenv("MAX_REQUERY_COUNT", "2"))
    max_search_days: int = int(os.getenv("MAX_SEARCH_DAYS", "30"))
    max_radius_km: float = float(os.getenv("MAX_RADIUS_KM", "1500"))
    request_timeout_sec: int = int(os.getenv("REQUEST_TIMEOUT_SEC", "8"))
    tool_retry_count: int = int(os.getenv("TOOL_RETRY_COUNT", "2"))
    tool_retry_backoff_sec: float = float(os.getenv("TOOL_RETRY_BACKOFF_SEC", "0.6"))
    tool_call_limit: int = int(os.getenv("TOOL_CALL_LIMIT", "12"))
    model_call_limit: int = int(os.getenv("MODEL_CALL_LIMIT", "12"))
    cache_ttl_sec: int = int(os.getenv("CACHE_TTL_SEC", "600"))
    state_freshness_minutes: int = int(os.getenv("STATE_FRESHNESS_MINUTES", "10"))
    ffmpeg_binary: str | None = os.getenv("FFMPEG_BINARY")
    audio_bitrate: str = os.getenv("AUDIO_BITRATE", "192k")
    audio_intro_ms: int = int(os.getenv("AUDIO_INTRO_MS", "3500"))
    audio_outro_ms: int = int(os.getenv("AUDIO_OUTRO_MS", "4500"))
    audio_crossfade_ms: int = int(os.getenv("AUDIO_CROSSFADE_MS", "1200"))
    audio_background_dbfs: float = float(os.getenv("AUDIO_BACKGROUND_DBFS", "-24"))
    audio_intro_dbfs: float = float(os.getenv("AUDIO_INTRO_DBFS", "-16"))
    audio_outro_dbfs: float = float(os.getenv("AUDIO_OUTRO_DBFS", "-18"))
    app_env: str = os.getenv("APP_ENV", "development")
    log_level: str = os.getenv("LOG_LEVEL", "INFO")


settings = Settings()
