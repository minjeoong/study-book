package com.lecture.enrollment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnrollmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
