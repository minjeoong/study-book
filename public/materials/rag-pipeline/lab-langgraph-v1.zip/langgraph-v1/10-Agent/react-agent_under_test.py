"""
react-agent_under_test.py
=========================
평가 대상(System Under Test)인 ReAct 에이전트를 **import 가능한 형태**로 정리한 모듈.
`10-React-Agent.ipynb` 의 구성을 그대로 옮겼고, 평가 안전을 위해 파일 도구를
**샌드박스 디렉터리(root_dir)** 로 제한한다.

사용:
    # [수정] 파일명(react-agent_under_test.py)에 하이픈(-)이 포함되어 있어
    #        일반 `import` 문으로는 로드할 수 없습니다. importlib으로 경로 기반 로드가 필요합니다.
    import importlib.util
    _spec = importlib.util.spec_from_file_location(
        "react_agent_under_test", "react-agent_under_test.py"
    )
    sut = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(sut)
    agent = sut.build_agent(sandbox_dir="eval_sandbox")
    res = agent.invoke({"messages": [("human", "...")]},
                       {"configurable": {"thread_id": "t1"}})
"""
import os
from typing import List, Dict

from langchain.agents import create_agent
from langchain.tools import tool
from langchain_core.documents import Document
from langchain.chat_models import init_chat_model
from langchain_teddynote.tools.tavily import TavilySearch
from langchain_teddynote.tools import GoogleNews
from langchain_community.agent_toolkits import FileManagementToolkit
from langchain_community.document_loaders import PDFPlumberLoader
from langgraph.checkpoint.memory import MemorySaver

DEFAULT_SANDBOX = "eval_sandbox"


def build_tools(sandbox_dir: str = DEFAULT_SANDBOX) -> list:
    """10-React-Agent 와 동일한 도구 구성. 파일 도구만 sandbox_dir 로 제한."""
    os.makedirs(sandbox_dir, exist_ok=True)

    # 1) 웹 검색 (Tavily)
    web_search = TavilySearch(
        topic="general",
        include_domains=["google.com"],
        max_results=5,
        include_answer=False,
        include_raw_content=False,
        include_images=False,
        format_output=False,
    )
    web_search.name = "web_search"
    web_search.description = "Use this tool to search on the web for any topic other than news."

    # 2) 키워드 뉴스 검색 (GoogleNews)
    @tool
    def search_news_by_keyword(query: str) -> List[Dict[str, str]]:
        """Look up news by keyword"""
        return GoogleNews().search_by_keyword(query, k=10)

    # 3) 파일 관리 (write_file / read_file / list_directory ...) — root_dir 로 샌드박싱
    file_management_tools = FileManagementToolkit(root_dir=str(sandbox_dir)).get_tools()

    # 4) PDF 로드
    @tool
    def load_pdf(file_path: str) -> List[Document]:
        """Use this tool to load a PDF file and return the content"""
        return PDFPlumberLoader(file_path).load()

    return [web_search, search_news_by_keyword, *file_management_tools, load_pdf]


def build_agent(sandbox_dir: str = DEFAULT_SANDBOX, model_name: str = "gpt-4o-mini"):
    """평가 대상 ReAct 에이전트를 생성해 반환."""
    # [업데이트] ChatOpenAI -> init_chat_model 로 교체
    model = init_chat_model(model_name, model_provider="openai", temperature=0)
    tools = build_tools(sandbox_dir)
    return create_agent(model, tools, checkpointer=MemorySaver())


def tool_names(sandbox_dir: str = DEFAULT_SANDBOX) -> list:
    """구성된 도구 이름 목록(평가 제약 작성 시 참고용)."""
    return [t.name for t in build_tools(sandbox_dir)]
