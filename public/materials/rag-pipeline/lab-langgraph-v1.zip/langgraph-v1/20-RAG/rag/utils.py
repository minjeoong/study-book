"""RAG 파이프라인에서 사용하는 문서 포매팅 유틸리티 함수들."""

from __future__ import annotations


def format_docs(docs: list) -> str:
    """Document 리스트를 XML 형식의 문자열로 포매팅합니다."""
    return "\n".join(
        f"<document>"
        f"<content>{doc.page_content}</content>"
        f"<source>{doc.metadata['source']}</source>"
        f"<page>{int(doc.metadata['page']) + 1}</page>"
        f"</document>"
        for doc in docs
    )


def format_searched_docs(docs: list[dict]) -> str:
    """웹 검색 결과 딕셔너리 리스트를 XML 형식의 문자열로 포매팅합니다."""
    return "\n".join(
        f"<document>"
        f"<content>{doc['content']}</content>"
        f"<source>{doc['url']}</source>"
        f"</document>"
        for doc in docs
    )


def format_task(tasks: list[str]) -> list[tuple[str, int]]:
    """'태스크명:N시간' 형식의 문자열 리스트를 (태스크명, 시간) 튜플 리스트로 변환합니다."""
    return [
        (task, int(time_str.replace("시간", "").strip()))
        for item in tasks
        for task, time_str in [item.rsplit(":", 1)]
    ]
