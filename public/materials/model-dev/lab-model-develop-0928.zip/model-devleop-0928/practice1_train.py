"""Practice #1 - Random Forest churn model: performance by split + variable importance/relationships."""
import itertools
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

from churn_features import CAT_COLS, NUM_COLS, TARGET, build_pipeline, split_60_20_20

DATA = Path("/Users/minjeong/Downloads/bank_churn_train.csv")
OUT = Path(__file__).parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "Apple SD Gothic Neo", "axes.unicode_minus": False})
BLUE, ORANGE, INK, MUTED, GRID = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e", "#e4e3df"

df = pd.read_csv(DATA)
X_tr, X_va, X_te, y_tr, y_va, y_te = split_60_20_20(df)
print(f"rows: train={len(X_tr)} valid={len(X_va)} test={len(X_te)} | churn rate "
      f"{y_tr.mean():.3f}/{y_va.mean():.3f}/{y_te.mean():.3f}")


def scores(model, X, y):
    p = model.predict_proba(X)[:, 1]
    return {"Accuracy": accuracy_score(y, p >= 0.5), "F1": f1_score(y, p >= 0.5), "AUC": roc_auc_score(y, p)}


def table(model):
    return pd.DataFrame({"Train": scores(model, X_tr, y_tr), "Validation": scores(model, X_va, y_va),
                         "Test": scores(model, X_te, y_te)}).T.round(4)


# 1) Baseline: default RandomForest (reference for overfitting)
base = build_pipeline().fit(X_tr, y_tr)
base_tbl = table(base)
print("\n[Baseline RF - default params]\n", base_tbl)

# 2) Hyper-parameters chosen on the Validation set only (Test untouched).
#    Rule: among configs within 0.005 of the best Validation AUC, take the one with the
#    smallest Train-Validation AUC gap (least overfit) - validation AUCs are nearly tied.
grid = {"max_depth": [None, 6, 8, 10], "min_samples_leaf": [1, 5, 10, 20],
        "max_features": ["sqrt", 0.5], "class_weight": [None, "balanced_subsample"]}
results = []
for vals in itertools.product(*grid.values()):
    params = dict(zip(grid, vals))
    m = build_pipeline(n_estimators=300, **params).fit(X_tr, y_tr)
    results.append({**params, "train_auc": roc_auc_score(y_tr, m.predict_proba(X_tr)[:, 1]),
                    "val_auc": roc_auc_score(y_va, m.predict_proba(X_va)[:, 1])})
res = pd.DataFrame(results)
res["gap"] = res.train_auc - res.val_auc
cand = res[res.val_auc >= res.val_auc.max() - 0.005].sort_values(["gap", "val_auc"], ascending=[True, False])
res.sort_values("val_auc", ascending=False).round(4).to_csv(OUT / "p1_grid_search.csv", index=False)
print("\nCandidates (Val AUC within 0.005 of best), least overfit first\n", cand.head(8).round(4).to_string(index=False))
row = cand.iloc[0]
best = {k: row[k] for k in grid}
best = {k: (None if v is None or (isinstance(v, float) and np.isnan(v)) else
            int(v) if k in ("max_depth", "min_samples_leaf") else v) for k, v in best.items()}
print("best params:", best)

final = build_pipeline(**best).fit(X_tr, y_tr)
final_tbl = table(final)
print("\n[Final RF - tuned on Validation, threshold 0.5]\n", final_tbl)

# Supplementary: decision threshold that maximises F1 on Validation (churners are only ~21%)
p_va = final.predict_proba(X_va)[:, 1]
ths = np.arange(0.10, 0.71, 0.01)
thr = float(ths[np.argmax([f1_score(y_va, p_va >= t) for t in ths])].round(2))
thr_tbl = pd.DataFrame({name: {"Accuracy": accuracy_score(y, final.predict_proba(X)[:, 1] >= thr),
                               "F1": f1_score(y, final.predict_proba(X)[:, 1] >= thr)}
                        for name, X, y in [("Train", X_tr, y_tr), ("Validation", X_va, y_va), ("Test", X_te, y_te)]}).T.round(4)
print(f"\n[Final RF - threshold {thr} (F1-optimal on Validation)]\n", thr_tbl)
pd.concat({"Baseline(default)": base_tbl, "Final(tuned)": final_tbl,
           f"Final(threshold={thr})": thr_tbl}).to_csv(OUT / "p1_performance.csv")
(OUT / "best_params.json").write_text(json.dumps({**best, "n_estimators": 500, "random_state": 42,
                                                   "threshold_f1_opt": thr}, indent=2))

# 3) Variable importance: impurity (MDI) aggregated to original variables + permutation on Test
rf = final.named_steps["model"]
feat_names = final.named_steps["preprocess"].get_feature_names_out()
mdi = pd.Series(rf.feature_importances_, index=feat_names)
orig = {f: next((c for c in CAT_COLS if f.startswith(c + "_")), f) for f in feat_names}
mdi = mdi.groupby(orig).sum()
perm = permutation_importance(final, X_te, y_te, scoring="roc_auc", n_repeats=20, random_state=42, n_jobs=-1)
perm = pd.Series(perm.importances_mean, index=X_te.columns).rename({"accountOpeningDate": "TenureMonths"})
imp = pd.DataFrame({"MDI_importance": mdi, "Permutation_AUC_drop(Test)": perm.reindex(mdi.index)})
imp = imp.sort_values("MDI_importance", ascending=False)
imp.insert(0, "Rank", range(1, len(imp) + 1))
print("\n[Variable importance]\n", imp.round(4))
imp.round(4).to_csv(OUT / "p1_feature_importance.csv")

# 4) Relationship of each variable with Exited (full training file, observed churn rate)
d = df.copy()
d["TenureMonths"] = (pd.to_datetime(d.baseDate, format="%m/%d/%Y")
                     - pd.to_datetime(d.accountOpeningDate, format="%m/%d/%Y")).dt.days / 30.44
overall = d[TARGET].mean()
rel_rows = []
bins = {"Age": [17, 30, 40, 50, 60, 100], "NumOfProducts": None, "Balance": [-1, 0, 50000, 100000, 150000, 1e7],
        "CreditScore": [0, 580, 650, 720, 800, 900], "EstimatedSalary": [0, 50000, 100000, 150000, 1e7],
        "TenureMonths": [-1, 24, 48, 72, 96, 200], "IsActiveMember": None, "Geography": None, "Gender": None,
        "HasCrCard": None}
labels = {"Balance": ["0", "0-5만", "5-10만", "10-15만", "15만+"],
          "EstimatedSalary": ["0-5만", "5-10만", "10-15만", "15만+"]}
for var in imp.index:
    s = d[var]
    if bins.get(var) is not None:
        s = pd.cut(d[var], bins[var], labels=labels.get(var))
        s = s.cat.add_categories("결측").fillna("결측") if s.isna().any() else s
    elif var in CAT_COLS:
        s = d[var].fillna("결측")
    g = d.groupby(s, observed=True)[TARGET].agg(churn_rate="mean", n="size")
    for lvl, r in g.iterrows():
        rel_rows.append({"Variable": var, "Level": str(lvl), "N": int(r.n), "ChurnRate": round(r.churn_rate, 4),
                         "Lift_vs_avg": round(r.churn_rate / overall, 2)})
rel = pd.DataFrame(rel_rows)
rel.to_csv(OUT / "p1_variable_target_relationship.csv", index=False)
means = d.groupby(TARGET)[NUM_COLS].mean().T.rename(columns={0: "Mean_Stay(0)", 1: "Mean_Exit(1)"})
means.round(2).to_csv(OUT / "p1_numeric_means_by_target.csv")
print("\n[Numeric means by Exited]\n", means.round(2))
print("\n[Churn rate by level] overall =", round(overall, 4))
print(rel.to_string(index=False))

# ---- Charts ----
def style(ax):
    for sp in ("top", "right", "left"):
        ax.spines[sp].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.tick_params(colors=MUTED, length=0)
    ax.grid(axis="x", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)

fig, ax = plt.subplots(figsize=(8, 5))
imp_plot = imp.sort_values("MDI_importance")
ax.barh(imp_plot.index, imp_plot["MDI_importance"], color=BLUE, height=0.6)
for i, v in enumerate(imp_plot["MDI_importance"]):
    ax.text(v + 0.003, i, f"{v:.3f}", va="center", color=INK, fontsize=9)
style(ax)
ax.set_title("변수 중요도 (Random Forest, MDI)", loc="left", color=INK, fontsize=13)
fig.tight_layout(); fig.savefig(OUT / "p1_feature_importance.png", dpi=150); plt.close(fig)

top = list(imp.index[:6])
fig, axes = plt.subplots(2, 3, figsize=(13, 7))
for ax, var in zip(axes.flat, top):
    r = rel[rel.Variable == var]
    ax.bar(r.Level, r.ChurnRate, color=BLUE, width=0.6)
    ax.axhline(overall, color=ORANGE, linewidth=1.5, linestyle="--")
    for x, v in zip(r.Level, r.ChurnRate):
        ax.text(x, v + 0.01, f"{v:.0%}", ha="center", color=INK, fontsize=9)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    ax.spines["left"].set_color(GRID); ax.spines["bottom"].set_color(GRID)
    ax.tick_params(colors=MUTED, length=0)
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
    ax.set_ylim(0, min(1.1, r.ChurnRate.max() + 0.12))
    ax.set_title(var, loc="left", color=INK)
fig.suptitle(f"상위 6개 변수의 구간별 이탈률 (주황 점선 = 전체 평균 {overall:.1%})", x=0.01, ha="left", color=INK, fontsize=13)
fig.tight_layout(); fig.savefig(OUT / "p1_churn_rate_by_variable.png", dpi=150); plt.close(fig)
print("\nsaved outputs to", OUT)
