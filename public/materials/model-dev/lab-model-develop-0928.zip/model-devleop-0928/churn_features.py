"""Feature engineering shared by training (Practice 1/2) and scoring (Practice 3).

bank_churn_model.pkl references this module, so keep it next to the .pkl
(or on PYTHONPATH) when loading the model.
"""
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

TARGET = "Exited"
DROP_COLS = ["CustomerId", "Surname"]
NUM_COLS = ["CreditScore", "Age", "Balance", "NumOfProducts", "HasCrCard",
            "IsActiveMember", "EstimatedSalary", "TenureMonths"]
CAT_COLS = ["Geography", "Gender"]
DATE_FMT = "%m/%d/%Y"


class DateFeatures(BaseEstimator, TransformerMixin):
    """Drop ID columns and derive TenureMonths = baseDate - accountOpeningDate."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = X.copy()
        base = pd.to_datetime(X["baseDate"], format=DATE_FMT)
        opened = pd.to_datetime(X["accountOpeningDate"], format=DATE_FMT)
        X["TenureMonths"] = (base - opened).dt.days / 30.44
        drop = DROP_COLS + ["baseDate", "accountOpeningDate", TARGET]
        return X.drop(columns=[c for c in drop if c in X.columns])


def build_pipeline(**rf_params):
    preprocess = ColumnTransformer([
        ("num", SimpleImputer(strategy="median"), NUM_COLS),
        ("cat", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]), CAT_COLS),
    ], verbose_feature_names_out=False)
    rf = RandomForestClassifier(n_estimators=500, random_state=42, n_jobs=-1)
    rf.set_params(**rf_params)
    return Pipeline([("features", DateFeatures()), ("preprocess", preprocess), ("model", rf)])


def split_60_20_20(df, seed=42):
    """Stratified Train 60% / Validation 20% / Test 20%."""
    from sklearn.model_selection import train_test_split
    X, y = df.drop(columns=[TARGET]), df[TARGET]
    X_tr, X_tmp, y_tr, y_tmp = train_test_split(X, y, test_size=0.4, stratify=y, random_state=seed)
    X_va, X_te, y_va, y_te = train_test_split(X_tmp, y_tmp, test_size=0.5, stratify=y_tmp, random_state=seed)
    return X_tr, X_va, X_te, y_tr, y_va, y_te
