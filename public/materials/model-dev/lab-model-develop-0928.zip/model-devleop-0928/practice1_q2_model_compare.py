"""Practice #1 Self-Practice Q2 - RandomForest vs XGBoost vs LightGBM on the same split & preprocessing.

Run with the project venv; on macOS XGBoost/LightGBM need libomp, borrowed from scikit-learn's wheel:
  DYLD_LIBRARY_PATH=.venv/lib/python3.11/site-packages/sklearn/.dylibs .venv/bin/python practice1_q2_model_compare.py
"""
import itertools
import warnings
from pathlib import Path

import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from xgboost import XGBClassifier

from churn_features import build_pipeline, split_60_20_20

warnings.filterwarnings("ignore")
OUT = Path(__file__).parent / "outputs"
df = pd.read_csv("/Users/minjeong/Downloads/bank_churn_train.csv")
X_tr, X_va, X_te, y_tr, y_va, y_te = split_60_20_20(df)

MODELS = {
    "RandomForest": (lambda **p: RandomForestClassifier(n_estimators=500, random_state=42, n_jobs=-1, **p),
                     {"max_depth": [None, 6, 8, 10], "min_samples_leaf": [1, 5, 10, 20], "max_features": ["sqrt", 0.5]}),
    "XGBoost": (lambda **p: XGBClassifier(n_estimators=300, random_state=42, n_jobs=-1, eval_metric="logloss", **p),
                {"max_depth": [2, 3, 4, 6], "learning_rate": [0.03, 0.1], "subsample": [0.8, 1.0], "min_child_weight": [1, 5]}),
    "LightGBM": (lambda **p: LGBMClassifier(n_estimators=300, random_state=42, n_jobs=-1, verbose=-1, **p),
                 {"num_leaves": [4, 8, 15, 31], "learning_rate": [0.03, 0.1], "min_child_samples": [10, 20, 40],
                  "subsample": [0.8], "subsample_freq": [1]}),
}


def metrics(pipe, X, y):
    p = pipe.predict_proba(X)[:, 1]
    return {"Accuracy": accuracy_score(y, p >= 0.5), "F1": f1_score(y, p >= 0.5), "AUC": roc_auc_score(y, p)}


rows, chosen = [], {}
for name, (make, grid) in MODELS.items():
    res = []
    for vals in itertools.product(*grid.values()):
        params = dict(zip(grid, vals))
        pipe = build_pipeline().set_params(model=make(**params)).fit(X_tr, y_tr)
        res.append({**params, "train_auc": roc_auc_score(y_tr, pipe.predict_proba(X_tr)[:, 1]),
                    "val_auc": roc_auc_score(y_va, pipe.predict_proba(X_va)[:, 1])})
    res = pd.DataFrame(res)
    res["gap"] = res.train_auc - res.val_auc
    # same rule as Practice #1: within 0.005 of best Validation AUC -> least overfit
    best = res[res.val_auc >= res.val_auc.max() - 0.005].sort_values(["gap", "val_auc"], ascending=[True, False]).iloc[0]
    params = {k: (None if pd.isna(best[k]) else best[k].item() if hasattr(best[k], "item") else best[k]) for k in grid}
    params = {k: (int(v) if isinstance(v, float) and v.is_integer() and k not in ("learning_rate", "subsample", "max_features") else v)
              for k, v in params.items()}
    chosen[name] = params
    pipe = build_pipeline().set_params(model=make(**params)).fit(X_tr, y_tr)
    for split, X, y in [("Train", X_tr, y_tr), ("Validation", X_va, y_va), ("Test", X_te, y_te)]:
        rows.append({"Model": name, "Set": split, **metrics(pipe, X, y)})

tbl = pd.DataFrame(rows).set_index(["Model", "Set"]).round(4)
tbl.to_csv(OUT / "p1_q2_model_comparison.csv")
print(tbl)
print("\nchosen params:", *[f"{k}: {v}" for k, v in chosen.items()], sep="\n  ")
test_auc = tbl.xs("Test", level="Set").AUC.sort_values(ascending=False)
print("\nTest AUC ranking:", ", ".join(f"{m} {v:.4f}" for m, v in test_auc.items()))
