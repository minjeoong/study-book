"""Gaussian Naive Bayes vs naive baselines vs tuned RF - bank churn (Part A) and KOSPI200 (Part B)."""
import json
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")
HERE = Path(__file__).parent


def row(name, split, y, p, thr=0.5):
    return {"Model": name, "Set": split, "Accuracy": accuracy_score(y, p >= thr),
            "F1": f1_score(y, p >= thr, zero_division=0), "AUC": roc_auc_score(y, p) if np.ptp(p) > 0 else 0.5}


# ---------- Part A: bank churn ----------
from churn_features import build_pipeline, split_60_20_20

df = pd.read_csv("/Users/minjeong/Downloads/bank_churn_train.csv")
X_tr, X_va, X_te, y_tr, y_va, y_te = split_60_20_20(df)
sets = [("Train", X_tr, y_tr), ("Validation", X_va, y_va), ("Test", X_te, y_te)]
nb = build_pipeline().set_params(model=GaussianNB())
nb.steps.insert(2, ("scale", StandardScaler()))
nb.fit(X_tr, y_tr)
rf = build_pipeline(max_depth=6, min_samples_leaf=5, max_features="sqrt").fit(X_tr, y_tr)
rows = []
for s, X, y in sets:
    rows.append(row("Naive: 전부 0(유지)", s, y, np.zeros(len(y))))
    rows.append(row("Naive: 나이만 사용", s, y, X.Age.values / 100))
    rows.append(row("Naive Bayes", s, y, nb.predict_proba(X)[:, 1]))
    rows.append(row("Random Forest(최종)", s, y, rf.predict_proba(X)[:, 1]))
a = pd.DataFrame(rows).set_index(["Model", "Set"]).round(4)
print("=== Part A · 은행 이탈 ===\n", a.xs("Test", level="Set").to_string(), "\n")
print(a.to_string(), "\n")
a.to_csv(HERE / "outputs" / "naive_bayes_comparison.csv")

# ---------- Part B: KOSPI200 ----------
sys.path.insert(0, str(HERE / "stock"))
from stock_model import PRICE_COLS, TARGET, build_pipeline as sbuild, load, time_split

sd = load(HERE / "stock" / "kospi200_train.csv")
tr, va, te = time_split(sd)
y = lambda d: d[TARGET].astype(int)
nbs = sbuild(PRICE_COLS).set_params(model=GaussianNB())
nbs.steps.insert(1, ("scale", StandardScaler()))
nbs.fit(tr, y(tr))
best = json.loads((HERE / "stock" / "outputs" / "best_params.json").read_text())
rfs = sbuild(best["num_cols"], max_depth=best["max_depth"], min_samples_leaf=best["min_samples_leaf"],
             max_features=best["max_features"]).fit(tr, y(tr))
rows, spread = [], {}
for s, d in [("Train", tr), ("Validation", va), ("Test", te)]:
    preds = {"Naive: 전부 0(언더퍼폼)": np.zeros(len(d)),
             "Naive: 모멘텀(최근 60일 수익률)": d.ret_60.fillna(0).values,
             "Naive: 단기반전(-최근 5일 수익률)": -d.ret_5.fillna(0).values,
             "Naive Bayes": nbs.predict_proba(d)[:, 1],
             "Random Forest(최종)": rfs.predict_proba(d)[:, 1]}
    for name, p in preds.items():
        rows.append(row(name, s, y(d), p, thr=0.5 if "Naive:" not in name or "전부" in name else np.inf))
        if s == "Test" and "전부" not in name:
            q = d.assign(s=p).groupby("baseDate").apply(
                lambda g: g.nlargest(40, "s").excess_ret_20.mean() - g.nsmallest(40, "s").excess_ret_20.mean(),
                include_groups=False)
            spread[name] = (q.mean(), (q > 0).mean())
b = pd.DataFrame(rows).set_index(["Model", "Set"]).round(4)
bt = b.xs("Test", level="Set")[["AUC"]].copy()
bt["상위20%-하위20% 월평균"] = [spread.get(m, (np.nan,))[0] for m in bt.index]
bt["상위>하위 개월 비율"] = [spread.get(m, (np.nan, np.nan))[1] for m in bt.index]
print("=== Part B · KOSPI200 (Test) ===\n", bt.round(4).to_string(), "\n")
print(b.to_string())
b.to_csv(HERE / "stock" / "outputs" / "naive_bayes_comparison.csv")
