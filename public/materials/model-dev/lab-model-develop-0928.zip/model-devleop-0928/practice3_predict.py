"""Practice #3 - Score new customers (bank_churn_new.csv) with bank_churn_model.pkl."""
from pathlib import Path

import joblib
import pandas as pd

import churn_features  # noqa: F401  (needed so the pickle can resolve DateFeatures)

HERE = Path(__file__).parent
model = joblib.load(HERE / "bank_churn_model.pkl")
new = pd.read_csv("/Users/minjeong/Downloads/bank_churn_new.csv")

out = new.copy()
out["Churn_Score"] = model.predict_proba(new)[:, 1].round(4)
out["Churn_Pred_0.5"] = (out.Churn_Score >= 0.5).astype(int)
out[f"Churn_Pred_{model.churn_threshold_}"] = (out.Churn_Score >= model.churn_threshold_).astype(int)
out["Risk_Grade"] = pd.cut(out.Churn_Score, [-0.01, 0.2, 0.4, 0.6, 1.0], labels=["Low", "Medium", "High", "Very High"])
out = out.sort_values("Churn_Score", ascending=False)
out.insert(0, "Rank", range(1, len(out) + 1))
out.to_csv(HERE / "outputs" / "bank_churn_new_scored.csv", index=False, encoding="utf-8-sig")

print(f"scored {len(out)} customers | mean score {out.Churn_Score.mean():.3f}")
print(out.Risk_Grade.value_counts().reindex(["Very High", "High", "Medium", "Low"]).to_string())
print(f"predicted churners: @0.5 = {out['Churn_Pred_0.5'].sum()}, "
      f"@{model.churn_threshold_} = {out[f'Churn_Pred_{model.churn_threshold_}'].sum()}")
print(out.head(10)[["Rank", "CustomerId", "Surname", "Age", "Geography", "NumOfProducts",
                    "IsActiveMember", "Balance", "Churn_Score", "Risk_Grade"]].to_string(index=False))
