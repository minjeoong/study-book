"""Shared definitions for the KOSPI200 outperformance model (Practice 1~3).

The pickle references this module - keep it next to kospi200_model.pkl when loading.
"""
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

TARGET = "Outperform"
ID_COLS = ["Code", "Name"]                                  # excluded (like CustomerId / Surname)
LEAK_COLS = ["fwd_ret_20", "kospi_fwd_ret_20", "excess_ret_20", "targetEndDate"]  # future info
PRICE_COLS = ["ret_5", "ret_20", "ret_60", "ret_120", "ret_250", "mom_12_1", "exret_20", "exret_60",
              "vol_20", "vol_60", "beta_120", "high52_gap", "low52_gap", "ma_gap_20", "ma_gap_60",
              "ma_gap_120", "rsi_14", "max_ret_20", "volume_ratio_5_60", "log_trading_value_20"]
FLOW_COLS = ["frgn_flow_20", "frgn_flow_60", "organ_flow_20", "organ_flow_60", "indiv_flow_20", "indiv_flow_60",
             "frgn_hold_pct", "frgn_hold_chg_20", "frgn_hold_chg_60"]
MKT_COLS = ["mkt_ret_20", "mkt_vol_20", "mkt_ma_gap_60"]
FEATURE_SETS = {"A. 시세": PRICE_COLS, "B. 시세+수급": PRICE_COLS + FLOW_COLS,
                "C. 시세+수급+시장": PRICE_COLS + FLOW_COLS + MKT_COLS, "D. 수급": FLOW_COLS}
NUM_COLS = PRICE_COLS + FLOW_COLS + MKT_COLS   # every numeric column in the table
CAT_COLS = ["IndustryCode"]

# Time-based partition (~60 / 20 / 20 of base months)
TRAIN_END, VALID_END = "2023-06-30", "2024-12-31"


def load(path):
    return pd.read_csv(path, dtype={"Code": str, "IndustryCode": str}, parse_dates=["baseDate"]
                       + (["targetEndDate"] if "train" in str(path) else []))


def build_pipeline(num_cols=PRICE_COLS, **rf_params):
    preprocess = ColumnTransformer([
        ("num", SimpleImputer(strategy="median"), list(num_cols)),
        ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                          ("onehot", OneHotEncoder(handle_unknown="ignore", min_frequency=100,
                                                   sparse_output=False))]), CAT_COLS),
    ], remainder="drop", verbose_feature_names_out=False)   # drops Code/Name/baseDate
    rf = RandomForestClassifier(n_estimators=500, random_state=42, n_jobs=-1)
    rf.set_params(**rf_params)
    return Pipeline([("preprocess", preprocess), ("model", rf)])


def time_split(df):
    """Train <= 2023-06 < Validation <= 2024-12 < Test.  Embargo: drop rows whose 20-day
    target window runs into the next partition, so no future return leaks backwards."""
    tr = df[df.baseDate <= TRAIN_END]
    va = df[(df.baseDate > TRAIN_END) & (df.baseDate <= VALID_END)]
    te = df[df.baseDate > VALID_END]
    tr = tr[tr.targetEndDate < va.baseDate.min()]
    va = va[va.targetEndDate < te.baseDate.min()]
    return tr, va, te
