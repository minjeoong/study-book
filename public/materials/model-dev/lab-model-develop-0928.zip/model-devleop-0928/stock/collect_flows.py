"""Step 0b - Daily investor flows per stock from Naver (foreign / institution / individual net buy, foreign hold %)."""
import time
from pathlib import Path

import pandas as pd
import requests

DATA = Path(__file__).parent / "data"
OUT = DATA / "flows"
OUT.mkdir(exist_ok=True)
H = {"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)", "Referer": "https://m.stock.naver.com/"}
FIRST, START_CURSOR = "20180601", "20260924"   # cursor is exclusive -> first page starts at 2026-09-23


def num(s):
    return float(str(s).replace(",", "").replace("%", "").replace("+", "")) if s not in (None, "", "-") else None


members = pd.read_csv(DATA / "kospi200_members.csv", dtype=str)
for i, code in enumerate(members.Code, 1):
    f = OUT / f"{code}.csv"
    if f.exists():
        continue
    rows, cursor = [], START_CURSOR
    while cursor > FIRST:
        for attempt in range(4):
            try:
                page = requests.get(f"https://m.stock.naver.com/api/stock/{code}/trend?pageSize=60&bizdate={cursor}",
                                    headers=H, timeout=15).json()
                break
            except Exception:
                time.sleep(2 * (attempt + 1))
        else:
            page = []
        if not page:
            break
        rows += [{"Date": r["bizdate"], "foreign_net": num(r["foreignerPureBuyQuant"]),
                  "organ_net": num(r["organPureBuyQuant"]), "indiv_net": num(r["individualPureBuyQuant"]),
                  "foreign_hold_pct": num(r["foreignerHoldRatio"]),
                  "volume": num(r["accumulatedTradingVolume"])} for r in page]
        if page[-1]["bizdate"] >= cursor:
            break
        cursor = page[-1]["bizdate"]
        time.sleep(0.05)
    pd.DataFrame(rows).drop_duplicates("Date").sort_values("Date").to_csv(f, index=False)
    if i % 20 == 0:
        print(f"flows {i}/{len(members)}", flush=True)
print("done")
