"""Step 0 - Collect KOSPI200 constituents (Naver) + daily OHLCV (FinanceDataReader) into stock/data/."""
import time
from pathlib import Path

import FinanceDataReader as fdr
import pandas as pd
import requests

DATA = Path(__file__).parent / "data"
PRICES = DATA / "prices"
PRICES.mkdir(parents=True, exist_ok=True)
START = "2017-06-01"
H = {"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)", "Referer": "https://m.stock.naver.com/"}

# 1) Current KOSPI200 constituents + industry code
members = []
for page in range(1, 20):
    rows = requests.get(f"https://m.stock.naver.com/api/index/KPI200/enrollStocks?pageSize=20&page={page}",
                        headers=H, timeout=10).json()
    if not rows:
        break
    members += [{"Code": r["itemCode"], "Name": r["stockName"]} for r in rows]
members = pd.DataFrame(members).drop_duplicates("Code")
industry = []
for code in members.Code:
    try:
        j = requests.get(f"https://m.stock.naver.com/api/stock/{code}/integration", headers=H, timeout=10).json()
        industry.append(str(j.get("industryCode") or "NA"))
    except Exception:
        industry.append("NA")
    time.sleep(0.1)
members["IndustryCode"] = industry
members.to_csv(DATA / "kospi200_members.csv", index=False, encoding="utf-8-sig")
print("members:", len(members), "| industries:", members.IndustryCode.nunique())

# 2) Daily OHLCV per stock (cached)
for i, code in enumerate(members.Code, 1):
    f = PRICES / f"{code}.csv"
    if f.exists():
        continue
    for attempt in range(3):
        try:
            fdr.DataReader(code, START)[["Open", "High", "Low", "Close", "Volume"]].to_csv(f)
            break
        except Exception as e:
            print("retry", code, e)
            time.sleep(2)
    if i % 50 == 0:
        print(f"prices {i}/{len(members)}")
    time.sleep(0.1)

# 3) Benchmark index (KOSPI)
kospi = fdr.DataReader("KS11", START)[["Close"]]
kospi.to_csv(DATA / "kospi_index.csv")
print("KOSPI:", kospi.index.min().date(), "~", kospi.index.max().date())
last = pd.read_csv(PRICES / "005930.csv", index_col=0, parse_dates=True).index.max()
print("stock prices last date (005930):", last.date())
