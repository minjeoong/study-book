"""Self-Practice Q2 for the stock project - RandomForest vs XGBoost vs LightGBM (same features, time split).

  DYLD_LIBRARY_PATH=../.venv/lib/python3.11/site-packages/sklearn/.dylibs ../.venv/bin/python model_compare.py
"""
import itertools
import json
import warnings
from pathlib import Path

import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from xgboost import XGBClassifier

from stock_model import TARGET, build_pipeline, load, time_split

warnings.filterwarnings("ignore")
HERE = Path(__file__).parent
OUT = HERE / "outputs"
num_cols = json.loads((OUT / "best_params.json").read_text())["num_cols"]
tr, va, te = time_split(load(HERE / "kospi200_train.csv"))
y = lambda d: d[TARGET].astype(int)

MODELS = {
    "RandomForest": (lambda **p: RandomForestClassifier(n_estimators=300, random_state=42, n_jobs=-1, **p),
                     {"max_depth": [4, 6, 8, None], "min_samples_leaf": [20, 50, 100, 200], "max_features": ["sqrt", 0.3]}),
    "XGBoost": (lambda **p: XGBClassifier(n_estimators=300, random_state=42, n_jobs=-1, eval_metric="logloss", **p),
                {"max_depth": [2, 3, 4], "learning_rate": [0.01, 0.05], "subsample": [0.7], "colsample_bytree": [0.7],
                 "min_child_weight": [10, 50]}),
    "LightGBM": (lambda **p: LGBMClassifier(n_estimators=300, random_state=42, n_jobs=-1, verbose=-1, **p),
                 {"num_leaves": [4, 8, 16], "learning_rate": [0.01, 0.05], "min_child_samples": [50, 200],
                  "subsample": [0.7], "subsample_freq": [1], "colsample_bytree": [0.7]}),
}

rows, chosen = [], {}
for name, (make, grid) in MODELS.items():
    res = []
    for vals in itertools.product(*grid.values()):
        params = dict(zip(grid, vals))
        pipe = build_pipeline(num_cols).set_params(model=make(**params)).fit(tr, y(tr))
        res.append({**params, "train_auc": roc_auc_score(y(tr), pipe.predict_proba(tr)[:, 1]),
                    "val_auc": roc_auc_score(y(va), pipe.predict_proba(va)[:, 1])})
    res = pd.DataFrame(res)
    res["gap"] = res.train_auc - res.val_auc
    best = res[res.val_auc >= res.val_auc.max() - 0.005].sort_values(["gap", "val_auc"], ascending=[True, False]).iloc[0]
    params = {k: (None if pd.isna(best[k]) else best[k]) for k in grid}
    params = {k: (int(v) if isinstance(v, float) and v.is_integer() and k in
                  ("max_depth", "min_samples_leaf", "num_leaves", "min_child_samples", "subsample_freq", "min_child_weight") else v)
              for k, v in params.items()}
    chosen[name] = params
    pipe = build_pipeline(num_cols).set_params(model=make(**params)).fit(tr, y(tr))
    for split, d in [("Train", tr), ("Validation", va), ("Test", te)]:
        p = pipe.predict_proba(d)[:, 1]
        row = {"Model": name, "Set": split, "Accuracy": accuracy_score(y(d), p >= 0.5),
               "F1": f1_score(y(d), p >= 0.5), "AUC": roc_auc_score(y(d), p)}
        if split == "Test":
            q = d.assign(s=p).groupby("baseDate").apply(
                lambda g: g.nlargest(40, "s").excess_ret_20.mean() - g.nsmallest(40, "s").excess_ret_20.mean(),
                include_groups=False)
            row["Top-Bottom 20% spread/month"] = q.mean()
        rows.append(row)

tbl = pd.DataFrame(rows).set_index(["Model", "Set"]).round(4)
tbl.to_csv(OUT / "q2_model_comparison.csv")
print(tbl.to_string())
print("\nchosen params:", *[f"{k}: {v}" for k, v in chosen.items()], sep="\n  ")
