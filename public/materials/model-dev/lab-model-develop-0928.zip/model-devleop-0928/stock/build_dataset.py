"""Step 1 - Build the model tables (same shape as the bank-churn practice CSVs).

  kospi200_train.csv : one row per (stock, month-end base date), with Target `Outperform`
  kospi200_new.csv   : one row per stock at the latest complete trading day, no Target

Target  Outperform = 1 if the stock's next-20-trading-day return > KOSPI's over the same window.
Feature window      = data up to and including baseDate only (60~250 trading days back):
                      price/volume (FinanceDataReader) + investor flows (Naver).
"""
from pathlib import Path

import numpy as np
import pandas as pd
import requests

HERE = Path(__file__).parent
DATA = HERE / "data"
LAST_COMPLETE_DAY = "2026-09-23"   # 9/28 bar may be intraday; 9/24-26 = Chuseok
FIRST_BASE = "2019-01-01"
H = 20                             # prediction horizon (trading days)

# ---- KOSPI benchmark: FinanceDataReader history + Naver for the most recent days ----
kospi = pd.read_csv(DATA / "kospi_index.csv", index_col=0, parse_dates=True)["Close"]
rows = requests.get("https://m.stock.naver.com/api/index/KOSPI/price?pageSize=60&page=1",
                    headers={"User-Agent": "Mozilla/5.0", "Referer": "https://m.stock.naver.com/"}, timeout=10).json()
naver = pd.Series({pd.Timestamp(r["localTradedAt"]): float(r["closePrice"].replace(",", "")) for r in rows}).sort_index()
overlap = naver.index.intersection(kospi.index)[:-1]   # FDR's last row can be an intraday snapshot
assert (naver[overlap] - kospi[overlap]).abs().max() < 0.5, "Naver/FDR KOSPI mismatch"
kospi = naver.combine_first(kospi).sort_index()          # Naver official closes win on overlap
kospi = kospi[kospi.index <= LAST_COMPLETE_DAY]
cal = kospi.index
k_ret = kospi.pct_change()

members = pd.read_csv(DATA / "kospi200_members.csv", dtype=str)

# month-end trading days (+ the latest complete day for the scoring set)
month_ends = pd.Series(cal, index=cal).groupby(cal.to_period("M")).max()
month_ends = month_ends[month_ends >= FIRST_BASE]
new_base = cal.max()
fwd_idx = pd.Series(np.arange(len(cal)), index=cal)


def stock_features(code):
    p = pd.read_csv(DATA / "prices" / f"{code}.csv", index_col=0, parse_dates=True)
    p = p[p.index <= LAST_COMPLETE_DAY]
    first = p.index.min()
    p = p.reindex(cal[cal >= first])
    c = p.Close.ffill()
    v = p.Volume.fillna(0)
    r = c.pct_change()
    f = pd.DataFrame(index=c.index)
    for n in (5, 20, 60, 120, 250):
        f[f"ret_{n}"] = c / c.shift(n) - 1
    f["mom_12_1"] = c.shift(20) / c.shift(250) - 1
    f["exret_20"] = f.ret_20 - (kospi / kospi.shift(20) - 1)
    f["exret_60"] = f.ret_60 - (kospi / kospi.shift(60) - 1)
    f["vol_20"] = r.rolling(20).std() * np.sqrt(252)
    f["vol_60"] = r.rolling(60).std() * np.sqrt(252)
    kr = k_ret.reindex(c.index)
    f["beta_120"] = r.rolling(120, min_periods=60).cov(kr) / kr.rolling(120, min_periods=60).var()
    f["high52_gap"] = c / c.rolling(250, min_periods=60).max() - 1
    f["low52_gap"] = c / c.rolling(250, min_periods=60).min() - 1
    for n in (20, 60, 120):
        f[f"ma_gap_{n}"] = c / c.rolling(n).mean() - 1
    gain, loss = r.clip(lower=0).rolling(14).mean(), (-r.clip(upper=0)).rolling(14).mean()
    f["rsi_14"] = 100 - 100 / (1 + gain / loss.replace(0, np.nan))
    f["max_ret_20"] = r.rolling(20).max()
    f["volume_ratio_5_60"] = v.rolling(5).mean() / v.rolling(60).mean().replace(0, np.nan)
    f["log_trading_value_20"] = np.log1p((c * v).rolling(20).mean())
    # investor flows (Naver, unadjusted shares -> normalised by Naver's own unadjusted volume)
    fl = pd.read_csv(DATA / "flows" / f"{code}.csv", dtype={"Date": str})
    fl.index = pd.to_datetime(fl.pop("Date"), format="%Y%m%d")
    fl = fl.reindex(c.index)
    for who, col in (("frgn", "foreign_net"), ("organ", "organ_net"), ("indiv", "indiv_net")):
        for n in (20, 60):
            f[f"{who}_flow_{n}"] = (fl[col].rolling(n, min_periods=n // 2).sum()
                                    / fl.volume.rolling(n, min_periods=n // 2).sum().replace(0, np.nan))
    hold = fl.foreign_hold_pct.ffill(limit=5)
    f["frgn_hold_pct"] = hold
    f["frgn_hold_chg_20"] = hold - hold.shift(20)
    f["frgn_hold_chg_60"] = hold - hold.shift(60)
    f["days_listed"] = np.arange(1, len(c) + 1)
    # target
    f["fwd_ret_20"] = c.shift(-H) / c - 1
    return f


kospi_feat = pd.DataFrame({
    "mkt_ret_20": kospi / kospi.shift(20) - 1,
    "mkt_vol_20": k_ret.rolling(20).std() * np.sqrt(252),
    "mkt_ma_gap_60": kospi / kospi.rolling(60).mean() - 1,
})
k_fwd = kospi.shift(-H) / kospi - 1
target_end = pd.Series(cal, index=cal).shift(-H)

frames = []
for code, name, ind in members[["Code", "Name", "IndustryCode"]].itertuples(index=False):
    f = stock_features(code)
    f = f[f.index.isin(month_ends.values) | (f.index == new_base)]
    f = f[f.days_listed >= 60]                       # need >= 60 trading days of history
    f.insert(0, "IndustryCode", ind)
    f.insert(0, "Name", name)
    f.insert(0, "Code", code)
    frames.append(f)
df = pd.concat(frames).rename_axis("baseDate").reset_index()
df = df.join(kospi_feat, on="baseDate")
df["kospi_fwd_ret_20"] = df.baseDate.map(k_fwd)
df["targetEndDate"] = df.baseDate.map(target_end)
df["excess_ret_20"] = df.fwd_ret_20 - df.kospi_fwd_ret_20
df["Outperform"] = (df.excess_ret_20 > 0).astype("Int64")
df = df.drop(columns=["days_listed"])

labeled = df[df.targetEndDate.notna() & df.fwd_ret_20.notna() & (df.baseDate < new_base)].copy()
new = df[df.baseDate == new_base].drop(columns=["fwd_ret_20", "kospi_fwd_ret_20", "targetEndDate",
                                                "excess_ret_20", "Outperform"])
labeled.to_csv(HERE / "kospi200_train.csv", index=False, encoding="utf-8-sig", date_format="%Y-%m-%d")
new.to_csv(HERE / "kospi200_new.csv", index=False, encoding="utf-8-sig", date_format="%Y-%m-%d")

print(f"train: {len(labeled):,} rows | {labeled.Code.nunique()} stocks | base dates "
      f"{labeled.baseDate.min().date()} ~ {labeled.baseDate.max().date()} ({labeled.baseDate.nunique()} months)")
print(f"Outperform rate: {labeled.Outperform.mean():.3f}")
print(labeled.groupby(labeled.baseDate.dt.year).Outperform.agg(["mean", "size"]).round(3).T)
print(f"new: {len(new)} rows | baseDate {new_base.date()}")
print(labeled.isna().mean().round(3)[lambda s: s > 0])
