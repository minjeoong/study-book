"""Practice #3 - Score KOSPI200 stocks at the latest base date (kospi200_new.csv) with kospi200_model.pkl."""
from pathlib import Path

import joblib
import pandas as pd

import stock_model  # noqa: F401  (keeps the pickle's module importable)
from stock_model import load

HERE = Path(__file__).parent
model = joblib.load(HERE / "kospi200_model.pkl")
new = load(HERE / "kospi200_new.csv")

out = new[["Code", "Name", "IndustryCode", "baseDate"]].copy()
out["Outperform_Score"] = model.predict_proba(new)[:, 1].round(4)
out["Outperform_Pred"] = (out.Outperform_Score >= model.outperform_threshold_).astype(int)
out["Score_Quintile"] = pd.qcut(out.Outperform_Score.rank(method="first"), 5,
                                labels=["Q1(하위20%)", "Q2", "Q3", "Q4", "Q5(상위20%)"])
key = ["ret_20", "ret_60", "high52_gap", "vol_20", "frgn_flow_20", "organ_flow_20", "frgn_hold_chg_20"]
out = out.join(new[key].round(4)).sort_values("Outperform_Score", ascending=False)
out.insert(0, "Rank", range(1, len(out) + 1))
out.to_csv(HERE / "outputs" / "kospi200_new_scored.csv", index=False, encoding="utf-8-sig", date_format="%Y-%m-%d")

print(f"scored {len(out)} stocks | baseDate {out.baseDate.iloc[0].date()} | "
      f"target window: next 20 trading days vs KOSPI")
print(f"score range {out.Outperform_Score.min():.3f} ~ {out.Outperform_Score.max():.3f}, "
      f"predicted outperform (>= {model.outperform_threshold_}): {out.Outperform_Pred.sum()}")
print("\nTop 10\n", out.head(10)[["Rank", "Code", "Name", "Outperform_Score"] + key[:4]].to_string(index=False))
print("\nBottom 5\n", out.tail(5)[["Rank", "Code", "Name", "Outperform_Score"] + key[:4]].to_string(index=False))
