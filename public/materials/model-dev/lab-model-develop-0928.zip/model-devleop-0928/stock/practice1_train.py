"""Practice #1 - KOSPI200 20-day outperformance model: performance by split + variable importance/relationships."""
import itertools
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

from stock_model import CAT_COLS, FEATURE_SETS, MKT_COLS, NUM_COLS, TARGET, build_pipeline, load, time_split

HERE = Path(__file__).parent
OUT = HERE / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "Apple SD Gothic Neo", "axes.unicode_minus": False})
BLUE, ORANGE, INK, MUTED, GRID = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e", "#e4e3df"

df = load(HERE / "kospi200_train.csv")
tr, va, te = time_split(df)
for name, d in [("Train", tr), ("Validation", va), ("Test", te)]:
    print(f"{name:<10} {d.baseDate.min().date()} ~ {d.baseDate.max().date()} | {len(d):>6,} rows "
          f"({len(d) / (len(tr) + len(va) + len(te)):.0%}) | outperform rate {d[TARGET].mean():.3f}")
sets = {"Train": tr, "Validation": va, "Test": te}


def scores(model, d, thr=0.5):
    p = model.predict_proba(d)[:, 1]
    y = d[TARGET].astype(int)
    return {"Accuracy": accuracy_score(y, p >= thr), "F1": f1_score(y, p >= thr), "AUC": roc_auc_score(y, p)}


def table(model, thr=0.5):
    return pd.DataFrame({k: scores(model, d, thr) for k, d in sets.items()}).T.round(4)


y = lambda d: d[TARGET].astype(int)
grid = {"max_depth": [4, 6, 8, None], "min_samples_leaf": [20, 50, 100, 200], "max_features": ["sqrt", 0.3]}

# 1) Feature-set x hyper-parameter search on Validation only (Test untouched)
results = []
for fs_name, cols in FEATURE_SETS.items():
    for vals in itertools.product(*grid.values()):
        params = dict(zip(grid, vals))
        m = build_pipeline(cols, n_estimators=300, **params).fit(tr, y(tr))
        results.append({"feature_set": fs_name, **params,
                        "train_auc": roc_auc_score(y(tr), m.predict_proba(tr)[:, 1]),
                        "val_auc": roc_auc_score(y(va), m.predict_proba(va)[:, 1])})
res = pd.DataFrame(results)
res["gap"] = res.train_auc - res.val_auc
res.sort_values("val_auc", ascending=False).round(4).to_csv(OUT / "p1_grid_search.csv", index=False)
fs_tbl = res.groupby("feature_set").agg(best_val_auc=("val_auc", "max"), mean_val_auc=("val_auc", "mean"),
                                        n_features=("feature_set", lambda s: len(FEATURE_SETS[s.iloc[0]])))
fs_tbl.round(4).to_csv(OUT / "p1_feature_set_comparison.csv")
print("\n[Feature-set comparison on Validation]\n", fs_tbl.round(4))
fs_best = fs_tbl.best_val_auc.idxmax()
num_cols = FEATURE_SETS[fs_best]

# Within the chosen set: among configs within 0.005 of the best Val AUC, pick the least overfit
sub = res[res.feature_set == fs_best]
cand = sub[sub.val_auc >= sub.val_auc.max() - 0.005].sort_values(["gap", "val_auc"], ascending=[True, False])
print(f"\nCandidates for '{fs_best}' (Val AUC within 0.005 of best), least overfit first\n",
      cand.head(6).round(4).to_string(index=False))
row = cand.iloc[0]
best = {k: (None if row[k] is None or (isinstance(row[k], float) and np.isnan(row[k])) else
            int(row[k]) if k in ("max_depth", "min_samples_leaf") else row[k]) for k in grid}
print("chosen feature set:", fs_best, "| best params:", best)

# Baseline for reference: default RandomForest on the same features
base = build_pipeline(num_cols).fit(tr, y(tr))
base_tbl = table(base)
print("\n[Baseline RF - default params]\n", base_tbl)

final = build_pipeline(num_cols, **best).fit(tr, y(tr))
final_tbl = table(final)
print("\n[Final RF - tuned on Validation, threshold 0.5]\n", final_tbl)

# Threshold stays at 0.5: an F1-optimal cut-off on Validation (~0.30) labels *every* stock as
# outperform (F1 = 2p/(1+p)), which is meaningless here - the score is used as a ranking instead.
thr = 0.5
pd.concat({"Baseline(default)": base_tbl, "Final(tuned)": final_tbl}).to_csv(OUT / "p1_performance.csv")
(OUT / "best_params.json").write_text(json.dumps({"feature_set": fs_best, "num_cols": num_cols, **best,
                                                   "n_estimators": 500, "random_state": 42,
                                                   "threshold": thr}, indent=2, ensure_ascii=False))

# 3) Investment-view check on Test: realised excess return by predicted-score quintile (per month)
te = te.assign(score=final.predict_proba(te)[:, 1])
te["score_q"] = te.groupby("baseDate").score.transform(lambda s: pd.qcut(s.rank(method="first"), 5, labels=False) + 1)
q_tbl = te.groupby("score_q").agg(avg_excess_ret_20=("excess_ret_20", "mean"), outperform_rate=(TARGET, "mean"),
                                  n=("Code", "size"))
monthly = te.groupby(["baseDate", "score_q"]).excess_ret_20.mean().unstack()
monthly_auc = te.groupby("baseDate").apply(lambda d: roc_auc_score(d[TARGET].astype(int), d.score))
q_tbl.round(4).to_csv(OUT / "p1_test_score_quintiles.csv")
print("\n[Test] realised 20-day excess return vs KOSPI by predicted-score quintile (5 = highest score)\n", q_tbl.round(4))
print(f"Top-Bottom spread / month: {(monthly[5] - monthly[1]).mean():.4f} | months Top>Bottom: "
      f"{(monthly[5] > monthly[1]).mean():.0%} ({len(monthly)} months)")
print(f"monthly AUC on Test: mean {monthly_auc.mean():.3f}, months > 0.5: {(monthly_auc > 0.5).mean():.0%}")

# 4) Variable importance: MDI + permutation on Test
rf = final.named_steps["model"]
feat_names = final.named_steps["preprocess"].get_feature_names_out()
orig = {f: next((c for c in CAT_COLS if f.startswith(c + "_")), f) for f in feat_names}
mdi = pd.Series(rf.feature_importances_, index=feat_names).groupby(orig).sum()
Xte = te[num_cols + CAT_COLS]
perm = permutation_importance(final, Xte, te[TARGET].astype(int), scoring="roc_auc", n_repeats=10,
                              random_state=42, n_jobs=-1)
perm = pd.Series(perm.importances_mean, index=Xte.columns)
imp = pd.DataFrame({"MDI_importance": mdi, "Permutation_AUC_drop(Test)": perm}).sort_values("MDI_importance", ascending=False)
imp.insert(0, "Rank", range(1, len(imp) + 1))
imp.round(4).to_csv(OUT / "p1_feature_importance.csv")
print("\n[Variable importance]\n", imp.round(4))

# 5) Relationship with Target: outperform rate & avg excess return by cross-sectional quintile (all labeled rows)
overall = df[TARGET].mean()
rel_rows = []
for var in [c for c in NUM_COLS if c not in MKT_COLS]:              # all stock-level variables, incl. flows
    q = df.groupby("baseDate")[var].transform(lambda s: pd.qcut(s.rank(method="first"), 5, labels=False) + 1
                                              if s.notna().sum() >= 5 else np.nan)
    g = df.groupby(q).agg(rate=(TARGET, "mean"), ex=("excess_ret_20", "mean"), n=(TARGET, "size"))
    for lvl, r in g.iterrows():
        rel_rows.append({"Variable": var, "Quintile": int(lvl), "N": int(r.n), "OutperformRate": round(r.rate, 4),
                         "AvgExcessRet20": round(r.ex, 4)})
for var in MKT_COLS:                 # market regime: same value per date
    q = pd.qcut(df[var].rank(method="dense"), 5, labels=False) + 1
    g = df.groupby(q).agg(rate=(TARGET, "mean"), ex=("excess_ret_20", "mean"), n=(TARGET, "size"))
    for lvl, r in g.iterrows():
        rel_rows.append({"Variable": var, "Quintile": int(lvl), "N": int(r.n), "OutperformRate": round(r.rate, 4),
                         "AvgExcessRet20": round(r.ex, 4)})
rel = pd.DataFrame(rel_rows)
rel.to_csv(OUT / "p1_variable_target_relationship.csv", index=False)
piv = rel.pivot(index="Variable", columns="Quintile", values="OutperformRate")
piv["Q5-Q1"] = piv[5] - piv[1]
piv = piv.reindex(piv["Q5-Q1"].abs().sort_values(ascending=False).index)
piv.round(4).to_csv(OUT / "p1_outperform_rate_pivot.csv")
print(f"\n[Outperform rate by quintile (1=lowest value, 5=highest), sorted by |Q5-Q1|] overall = {overall:.3f}\n", piv.round(3))
ind = df.groupby("IndustryCode").agg(rate=(TARGET, "mean"), n=(TARGET, "size"), names=("Name", lambda s: ", ".join(s.unique()[:3])))
ind = ind[ind.n >= 300].sort_values("rate")
ind.round(3).to_csv(OUT / "p1_industry_outperform.csv")
print("\n[Industry (n>=300) - lowest / highest outperform rate]\n", pd.concat([ind.head(4), ind.tail(4)]).round(3))

# ---- Charts ----
def clean(ax, grid_axis="y"):
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    ax.spines["left"].set_color(GRID); ax.spines["bottom"].set_color(GRID)
    ax.tick_params(colors=MUTED, length=0)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8); ax.set_axisbelow(True)

fig, ax = plt.subplots(figsize=(8, 7))
ip = imp.sort_values("MDI_importance")
ax.barh(ip.index, ip.MDI_importance, color=BLUE, height=0.6)
for i, v in enumerate(ip.MDI_importance):
    ax.text(v + 0.001, i, f"{v:.3f}", va="center", color=INK, fontsize=8)
clean(ax, "x"); ax.spines["left"].set_visible(False)
ax.set_title("변수 중요도 (Random Forest, MDI)", loc="left", color=INK, fontsize=13)
fig.tight_layout(); fig.savefig(OUT / "p1_feature_importance.png", dpi=150); plt.close(fig)

top = list(piv.index[:6])
fig, axes = plt.subplots(2, 3, figsize=(13, 7), sharey=True)
for ax, var in zip(axes.flat, top):
    r = rel[rel.Variable == var]
    ax.bar(r.Quintile.astype(str), r.OutperformRate, color=BLUE, width=0.6)
    ax.axhline(overall, color=ORANGE, linewidth=1.5, linestyle="--")
    for x, v in zip(r.Quintile.astype(str), r.OutperformRate):
        ax.text(x, v + 0.008, f"{v:.0%}", ha="center", color=INK, fontsize=9)
    clean(ax); ax.set_ylim(0.3, 0.58)
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
    ax.set_title(var, loc="left", color=INK)
    ax.set_xlabel("분위 (1=낮음 → 5=높음)", color=MUTED, fontsize=9)
fig.suptitle(f"Q5-Q1 차이가 큰 6개 변수의 분위별 아웃퍼폼 비율 (주황 점선 = 전체 평균 {overall:.1%})", x=0.01, ha="left", color=INK, fontsize=13)
fig.tight_layout(); fig.savefig(OUT / "p1_outperform_rate_by_variable.png", dpi=150); plt.close(fig)

fig, ax = plt.subplots(figsize=(7, 4.5))
vals = q_tbl.avg_excess_ret_20
ax.bar(vals.index.astype(str), vals, color=[ORANGE if v < 0 else BLUE for v in vals], width=0.6)
for x, v in zip(vals.index.astype(str), vals):
    ax.text(x, v + (0.0008 if v >= 0 else -0.0008), f"{v:+.2%}", ha="center", va="bottom" if v >= 0 else "top", color=INK, fontsize=9)
ax.axhline(0, color=MUTED, linewidth=0.8); clean(ax)
ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=1))
ax.set_xlabel("예측 점수 분위 (매월 200종목을 5그룹으로, 5=점수 최고)", color=MUTED, fontsize=9)
ax.set_title("Test 기간: 점수 분위별 실제 20일 초과수익률 (vs KOSPI)", loc="left", color=INK, fontsize=12)
fig.tight_layout(); fig.savefig(OUT / "p1_test_score_quintiles.png", dpi=150); plt.close(fig)
print("\nsaved outputs to", OUT)
