"""Practice #2 - Save the full Practice #1 process (imputation + one-hot + RF) as one Pipeline .pkl."""
import json
from pathlib import Path

import joblib
from sklearn.metrics import roc_auc_score

from stock_model import TARGET, build_pipeline, load, time_split

HERE = Path(__file__).parent
params = json.loads((HERE / "outputs" / "best_params.json").read_text())
threshold = params.pop("threshold")
params.pop("feature_set")

tr, va, te = time_split(load(HERE / "kospi200_train.csv"))
pipe = build_pipeline(**params).fit(tr, tr[TARGET].astype(int))   # same split / params / seed as Practice #1
pipe.outperform_threshold_ = threshold
joblib.dump(pipe, HERE / "kospi200_model.pkl")

loaded = joblib.load(HERE / "kospi200_model.pkl")
diff = abs(pipe.predict_proba(te)[:, 1] - loaded.predict_proba(te)[:, 1]).max()
print("pipeline steps:", [name for name, _ in loaded.steps])
print("max |diff| in test predictions after reload:", float(diff))
print("Test AUC (reloaded pkl):", round(roc_auc_score(te[TARGET].astype(int), loaded.predict_proba(te)[:, 1]), 4),
      "| threshold:", loaded.outperform_threshold_)
