"""Practice #2 - Save the full Practice #1 process (date features + imputation + one-hot + RF) as one Pipeline .pkl."""
import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.metrics import roc_auc_score

from churn_features import build_pipeline, split_60_20_20

HERE = Path(__file__).parent
params = json.loads((HERE / "outputs" / "best_params.json").read_text())
threshold = params.pop("threshold_f1_opt")

df = pd.read_csv("/Users/minjeong/Downloads/bank_churn_train.csv")
X_tr, X_va, X_te, y_tr, y_va, y_te = split_60_20_20(df)
pipe = build_pipeline(**params).fit(X_tr, y_tr)   # same split / params / seed as Practice #1
pipe.churn_threshold_ = threshold                  # F1-optimal cut-off chosen on Validation

joblib.dump(pipe, HERE / "bank_churn_model.pkl")

# Reload check: the saved file must reproduce the in-memory model exactly
loaded = joblib.load(HERE / "bank_churn_model.pkl")
p_mem, p_pkl = pipe.predict_proba(X_te)[:, 1], loaded.predict_proba(X_te)[:, 1]
print("pipeline steps:", [name for name, _ in loaded.steps])
print("max |diff| in test predictions after reload:", float(abs(p_mem - p_pkl).max()))
print("Test AUC (reloaded pkl):", round(roc_auc_score(y_te, p_pkl), 4), "| threshold:", loaded.churn_threshold_)
