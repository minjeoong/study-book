# FastAPI Integration 결과
- 판교 - 9반, 김민정

> 작성 방법
> - (Y/N) : Y 또는 N만 기입
> - (서술) : 확인한 내용을 1~2문장으로 기술
> - (값) : 터미널 출력 또는 응답에 보이는 값을 그대로 기입
> - 정답을 맞추는 것이 아니라, 관찰한 그대로 기입합니다.

---

## H. Health Check — 캡쳐: H.png
- `{"status":"ok"}` 응답이 확인되는가? (Y/N) : Y

## Chat Endpoint 테스트

### T1. 운영 매뉴얼 검색 — 캡쳐: T1.png
입력 : "데이터베이스 다운 시 대응 절차를 알려주세요."
- 정상 응답이 오는가? (Y/N) : Y
  - 응답 message 첫 문장 (값) : 데이터베이스 다운 시 대응 절차는 다음과 같습니다:
- tool_calls에 기록된 Tool 이름과 args (값) : `search_operations_manual` / `{"query": "데이터베이스 다운 대응", "top_k": 3}`
- 응답의 thread_id (값) : 9e3be108-f7c6-419d-9657-34940537563a

### T2. 모니터링 상태 확인 — 캡쳐: T2.png
입력 : "auth-service 시스템 상태가 어떤가요?"
- 정상 응답이 오는가? (Y/N) : Y
  - 응답 message 첫 문장 (값) : 현재 `auth-service`의 시스템 상태는 **degraded**입니다.
- tool_calls에 기록된 Tool 이름과 args (값) : `get_monitoring_status` / `{"system_name": "auth-service"}`

### T3. 같은 thread_id로 F/up — 캡쳐: T3.png
입력 : "방금 그 시스템에 대한 ticket을 검색해 주세요."
- 사용한 thread_id (값) : 9c388b8a-0215-4e00-b295-329ea0f17a54
- 응답의 thread_id가 요청과 동일한가? (Y/N) : Y
- 에이전트가 "그 시스템"을 auth-service로 인식했는가? (Y/N) : Y
  - tool_calls에 기록된 Tool 이름과 args (값) : `get_monitoring_status` / `{"system_name": "auth-service"}`, `search_jira_tickets` / `{"query": "auth-service", "max_results": 5}`
  - 판단 근거 (서술) : 이번 요청에서 `search_jira_tickets`가 `query: "auth-service"`로 호출됐고, 응답도 auth-service 관련 티켓(OPS-101, OPS-87)을 안내했다. tool_calls에 함께 보이는 `get_monitoring_status`는 T2에서 호출된 것으로, `main.py`가 thread의 전체 대화 기록에서 tool_calls를 모으기 때문에 같이 찍혔다.

## 에러 테스트

### E1. MCP Server 실행 막기 — 캡쳐: E1.png
동작 : `chmod 000 mcp-server/server.py` 후 /chat 요청
- curl에서 받은 응답 또는 에러 (값) : 응답 그대로 복사
  - 가이드 입력 "운영 매뉴얼 검색해 주세요." (HTTP 200) : `{"thread_id":"5c7177ef-cc58-47fa-a4ba-44b8c8623a70","message":"운영 매뉴얼에서 어떤 내용을 검색하고 싶으신가요? 구체적인 검색어를 알려주시면 관련된 절차를 찾아드리겠습니다.","tool_calls":[]}`
  - 검색어를 넣은 입력 "운영 매뉴얼에서 DB 다운 대응 절차를 검색해 주세요." (HTTP 500) : `Internal Server Error`
- 서버 터미널에 출력된 에러의 마지막 줄 (값) : `mcp.shared.exceptions.McpError: Connection closed`
- 사용자에게 어떻게 보인다고 판단하는가? (서술) : Tool 호출이 필요한 요청에서는 원인 설명 없이 `Internal Server Error`만 보여, 사용자는 무엇이 잘못됐는지 알 수 없다. 검색어가 없는 가이드 입력은 에이전트가 Tool을 부르지 않고 되물어서 장애가 드러나지 않고 정상처럼 보였다.
- 테스트 후 `chmod 644`로 원복했는가? (Y/N) : Y

### E2. 존재하지 않는 시스템 조회 — 캡쳐: E2.png
입력 : "non-existent-system 상태 알려주세요."
- 에러가 발생했는가, 정상 응답이 왔는가? (서술) : 에러 없이 정상 응답(HTTP 200)이 왔다. Tool이 `status: unknown`과 조회 가능한 서비스 목록을 돌려줘서, 에이전트가 등록되지 않은 서비스라고 안내했다.
  - 응답 message 첫 문장 (값) : "non-existent-system"은 모니터링 시스템에 등록되지 않은 서비스입니다.
- tool_calls에 기록된 Tool 이름과 args (값) : `get_monitoring_status` / `{"system_name": "non-existent-system"}`
