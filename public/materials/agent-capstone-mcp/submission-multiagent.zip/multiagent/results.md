# Multi-Agent Streaming 결과
- 판교 - 9반, 김민정

> 작성 방법
> - (Y/N) : Y 또는 N만 기입
> - (서술) : 확인한 내용을 1~2문장으로 기술
> - (값) : 화면 또는 로그에 보이는 값을 그대로 기입
> - 정답을 맞추는 것이 아니라, 관찰한 그대로 기입합니다.

---

## F1. Multi-agent 결과 확인 — 캡쳐: F1-single.png, F1-multi.png
질문 : "운영 매뉴얼과 최근 incident를 종합하여 장애 대응 가이드를 만들어 주세요."

- Single vs Multi mode의 UX 차이가 명확하게 확인되는가? (Y/N) : Y
  - 두 모드에서 화면에 나타난 순서 차이 (서술) : Single은 Plan·Task 없이 답변 토큰만 바로 흘러나와 1.7초 만에 완성되었다(도구 호출 없이 대상 서비스를 되묻는 답변). Multi는 Plan 카드 → Task 3개 목록 → task가 하나씩 대기·진행 중·완료로 바뀌며 순차 진행 → 구분선 아래 최종 응답 순서로 나타났다(11.2초).
- Multi-agent 진행 과정이 화면에서 잘 확인되는가? (Y/N) : Y
  - Plan 카드 내용 첫 문장 (값) : 운영 매뉴얼과 최근 incident를 분석하여 장애 대응 가이드를 작성합니다.
- 각 task의 상태 변화가 시각적으로 명확하게 확인되는가? (Y/N) : Y
  - 생성된 Task 수 (값) : 3
  - Task별 담당 agent, 순서대로 (값) : research, research, writing

## F2. 복잡한 질문 — 캡쳐: F2.png
질문 : "DB 다운 시 절차와 네트워크 장애 시 절차를 비교해서 알려주세요"

- Supervisor가 분해한 Task가 확인되는가? (Y/N) : Y
  - Task 목록, description과 agent (값) :
    - task_1 : DB 다운 시의 절차를 조사한다. (research)
    - task_2 : 네트워크 장애 시의 절차를 조사한다. (research)
    - task_3 : 조사한 DB 다운 시 절차와 네트워크 장애 시 절차를 비교하여 차이점과 유사점을 분석한다. (writing)
    - task_4 : 분석 결과를 바탕으로 사용자에게 명확한 비교 정보를 작성한다. (writing)
- 분해된 task 진행사항이 화면에서 확인되는가? (Y/N) : Y
- Writing task가 모든 결과를 통합하는가? (Y/N) : Y
  - 최종 응답에 DB, 네트워크 두 절차가 모두 비교되어 있는지와 그 근거 (서술) : 최종 응답이 "차이점"(문제의 본질·초기 진단·조치 방법)과 "유사점"으로 나뉘고, 항목마다 DB 다운과 네트워크 장애를 나란히 적어 두 research 결과가 모두 비교되어 있다. 다만 네트워크 전용 runbook이 없어, 네트워크 장애의 조치 방법에 DB runbook의 메모리·디스크 조치가 섞여 들어갔다.

## F3. 단순한 질문 — 캡쳐: F3.png
질문 : "안녕하세요"

- Supervisor가 단순한 질문에도 (과도하게) task를 분해하는가? (Y/N) : N
  - 생성된 Task 수와 담당 agent (값) : 1개, writing
  - 과도하다고 판단한 이유 또는 그렇지 않다고 판단한 이유 (서술) : research나 도구 호출 없이 writing task 1개로 바로 인사에 답해, 분해 자체는 과하지 않았다. 다만 인사 한 마디에도 Plan 카드가 뜨고 LLM을 두 번(planning·writing) 호출해 single 모드보다 응답이 무겁다(2.7초).
