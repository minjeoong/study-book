package com.skala.helpdesk.tool;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.model.ToolContext;

import com.skala.helpdesk.audit.AuditLogService;
import com.skala.helpdesk.domain.OrderRepository;
import com.skala.helpdesk.domain.TicketRepository;
import com.skala.helpdesk.domain.TicketStatus;
import com.skala.helpdesk.domain.TicketView;

/**
 * 승인 게이트와 중복 접수 방지(추가 구현 ②) 테스트.
 *
 * <p>승인 게이트의 핵심 주장은 "도구는 PENDING 까지만 만들 수 있다"이다. 이것은 프롬프트가
 * 아니라 코드로 보장되어야 하므로, 도구를 직접 불러 상태를 확인한다.
 */
class TicketToolsTest {

    private TicketRepository tickets;
    private TicketTools tools;

    @BeforeEach
    void setUp() {
        tickets = new TicketRepository();
        tools = new TicketTools(new OrderRepository(), tickets, new AuditLogService());
    }

    private ToolContext contextOf(String userId) {
        return new ToolContext(Map.of("userId", userId));
    }

    @Test
    @DisplayName("도구는 접수만 하고 상태는 PENDING 에 머문다")
    void 환불은_접수만_된다() {
        TicketView view = tools.requestRefund("12345", "단순 변심", contextOf("user1"));

        assertThat(view.status()).isEqualTo(TicketStatus.PENDING.name());
        assertThat(view.duplicate()).isFalse();
        assertThat(tickets.findByNo(view.ticketNo()).orElseThrow().status())
                .isEqualTo(TicketStatus.PENDING);
    }

    @Test
    @DisplayName("APPROVED 로 바꾸는 경로는 사람(관리자)만 부를 수 있다")
    void 사람이_승인해야_바뀐다() {
        TicketView view = tools.requestRefund("12345", "단순 변심", contextOf("user1"));

        // 도구에는 승인 메서드가 없다. 승인은 저장소를 통해 관리자 컨트롤러만 호출한다.
        tickets.decide(view.ticketNo(), TicketStatus.APPROVED, "admin");

        assertThat(tickets.findByNo(view.ticketNo()).orElseThrow().status())
                .isEqualTo(TicketStatus.APPROVED);
        assertThat(tickets.findByNo(view.ticketNo()).orElseThrow().decidedBy()).isEqualTo("admin");
    }

    @Test
    @DisplayName("남의 주문은 접수 자체가 되지 않는다")
    void 남의_주문은_접수되지_않는다() {
        assertThatThrownBy(() -> tools.requestRefund("99999", "단순 변심", contextOf("user1")))
                .isInstanceOf(IllegalArgumentException.class);

        assertThat(tickets.all()).isEmpty();
    }

    // ── 추가 구현 ② — 중복 접수 방지 ────────────────────────────

    @Test
    @DisplayName("같은 요청을 반복해도 티켓은 하나만 생긴다")
    void 동일_요청은_중복_접수되지_않는다() {
        TicketView first = tools.requestRefund("12345", "단순 변심", contextOf("user1"));
        TicketView second = tools.requestRefund("12345", "단순 변심", contextOf("user1"));

        assertThat(second.ticketNo()).isEqualTo(first.ticketNo());
        assertThat(first.duplicate()).isFalse();
        assertThat(second.duplicate()).isTrue();
        assertThat(tickets.all()).hasSize(1);
    }

    @Test
    @DisplayName("사유의 띄어쓰기가 달라도 같은 접수로 본다")
    void 사유_표기가_흔들려도_같은_접수다() {
        TicketView first = tools.requestRefund("12345", "단순 변심", contextOf("user1"));
        TicketView second = tools.requestRefund("12345", "단순변심", contextOf("user1"));

        assertThat(second.ticketNo()).isEqualTo(first.ticketNo());
        assertThat(tickets.all()).hasSize(1);
    }

    @Test
    @DisplayName("사유가 다르면 별개의 접수로 처리한다")
    void 사유가_다르면_별개_접수다() {
        tools.requestRefund("12345", "단순 변심", contextOf("user1"));
        tools.requestRefund("12345", "상품 하자", contextOf("user1"));

        assertThat(tickets.all()).hasSize(2);
    }

    @Test
    @DisplayName("다른 사용자의 동일 사유 접수와는 절대 섞이지 않는다")
    void 사용자가_다르면_키가_충돌하지_않는다() {
        tools.requestRefund("12345", "단순 변심", contextOf("user1"));
        tools.requestRefund("99999", "단순 변심", contextOf("user2"));

        assertThat(tickets.all()).hasSize(2);
        assertThat(tickets.all().stream().map(t -> t.userId()).distinct()).hasSize(2);
    }

    @Test
    @DisplayName("접수 상태 조회는 본인 건만 가능하다")
    void 접수_상태는_본인만_조회한다() {
        TicketView view = tools.requestRefund("12345", "단순 변심", contextOf("user1"));

        assertThat(tools.refundStatus(view.ticketNo(), contextOf("user1")).status())
                .isEqualTo(TicketStatus.PENDING.name());

        assertThatThrownBy(() -> tools.refundStatus(view.ticketNo(), contextOf("user2")))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
