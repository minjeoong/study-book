package com.skala.helpdesk.tool;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.model.ToolContext;

import com.skala.helpdesk.domain.OrderRepository;
import com.skala.helpdesk.domain.OrderView;

/**
 * Phase 4 — 도구 권한 검증 테스트.
 *
 * <p>여기서 검증하는 것은 "모델이 잘 판단하는가"가 아니라 <b>모델이 어떻게 판단하든
 * 코드가 막는가</b>이다. 그래서 LLM 없이 도구를 직접 호출해 확인한다 —
 * 권한 검증이 프롬프트가 아니라 코드에 있다는 사실 자체가 이 테스트로 증명된다.
 */
class OrderToolsTest {

    private final OrderTools tools = new OrderTools(new OrderRepository());

    private ToolContext contextOf(String userId) {
        return new ToolContext(Map.of("userId", userId));
    }

    @Test
    @DisplayName("본인 주문은 조회된다")
    void 본인_주문은_조회된다() {
        OrderView view = tools.getOrder("12345", contextOf("user1"));

        assertThat(view.orderId()).isEqualTo("12345");
        assertThat(view.status()).isEqualTo("배송완료");
        // 수령 후 경과일수는 도메인이 계산해 내려 준다 — 모델에게 날짜 계산을 시키지 않는다.
        assertThat(view.daysSinceDelivery()).isEqualTo(3);
    }

    @Test
    @DisplayName("남의 주문은 존재하더라도 조회되지 않는다")
    void 남의_주문은_조회되지_않는다() {
        // 99999 는 user2 소유다. user1 로는 '없는 주문'과 구분되지 않아야 한다.
        assertThatThrownBy(() -> tools.getOrder("99999", contextOf("user1")))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("찾을 수 없습니다");
    }

    @Test
    @DisplayName("존재하지 않는 주문과 남의 주문은 같은 메시지로 응답한다")
    void 존재여부를_구분해_알려주지_않는다() {
        String 남의주문 = catchMessage(() -> tools.getOrder("99999", contextOf("user1")));
        String 없는주문 = catchMessage(() -> tools.getOrder("00000", contextOf("user1")));

        // 메시지가 다르면 "그 주문은 존재하지만 네 것이 아니다"를 흘리는 정보 노출이 된다.
        assertThat(남의주문).isEqualTo(없는주문.replace("00000", "99999"));
    }

    @Test
    @DisplayName("toolContext 에 userId 가 없으면 조회를 거부한다(fail-closed)")
    void userId가_없으면_거부한다() {
        assertThatThrownBy(() -> tools.getOrder("12345", new ToolContext(Map.of())))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("userId");
    }

    private String catchMessage(Runnable runnable) {
        try {
            runnable.run();
            return "";
        } catch (Exception e) {
            return String.valueOf(e.getMessage());
        }
    }
}
