package com.skala.helpdesk.web;

import java.io.IOException;
import java.util.UUID;

import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Observability — 요청 추적 ID.
 *
 * <p>요청마다 짧은 traceId 를 발급해 MDC 에 넣는다. 컨트롤러 로그 · RAG 검색 로그 ·
 * 도구 감사 로그 · 토큰 계측 로그가 전부 같은 traceId 로 남으므로, 로그를 traceId 로
 * grep 하면 그 요청이 <b>컨트롤러 → 안전 필터 → 메모리 → RAG → 도구 → 모델</b> 순으로
 * 어디를 거쳤는지 한 줄씩 그대로 재구성된다.
 *
 * <p>응답 헤더 {@code X-Trace-Id} 와 구조화 응답의 {@code traceId} 필드로도 내려 준다 —
 * "안 돼요, traceId 3f9a1c2b 예요" 한마디면 로그에서 바로 찾을 수 있다.
 *
 * <p>필터 체인 맨 앞에 둔다. 인증 실패처럼 컨트롤러에 닿지 못한 요청도 추적 ID 를
 * 받아야 감사 로그에서 누락되지 않기 때문이다.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class TraceIdFilter extends OncePerRequestFilter {

    private static final String HEADER = "X-Trace-Id";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String traceId = UUID.randomUUID().toString().substring(0, 8);
        MDC.put("traceId", traceId);
        response.setHeader(HEADER, traceId);
        try {
            chain.doFilter(request, response);
        } finally {
            // 서블릿 스레드는 재사용되므로 반드시 비운다 — 비우지 않으면 다음 요청 로그에
            // 이전 요청의 traceId 가 찍혀 추적이 오히려 틀려진다.
            MDC.remove("traceId");
        }
    }
}
