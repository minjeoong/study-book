package com.skala.helpdesk.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.skala.helpdesk.config.HelpDeskProperties;

/**
 * Phase 2 — 사내 규정 문서 인제스트(Indexing).
 *
 * <p>읽기(Tika) → 나누기(TokenTextSplitter) → 메타데이터 보강 → 저장(VectorStore).
 * 같은 문서를 다시 넣으면 청크가 중복 적재되므로 source 기준으로 먼저 지우고 다시 넣는다
 * (인메모리 스토어라 삭제가 실패할 수 있어 방어적으로 감싼다).
 *
 * <p><b>Phase 2 심화 — 인제스트 품질 확인.</b> 인제스트는 "몇 건 넣었다"로 끝나면 안 된다.
 * 청크가 너무 크면 서로 다른 주제가 한 벡터에 뭉개져 검색이 엉뚱한 곳을 가리키고,
 * 너무 작으면 문맥이 끊겨 답변 근거로 못 쓴다. 그래서 넣은 청크를 그대로 보관해
 * {@link #inspect} 로 개수·길이 분포·본문 미리보기를 눈으로 확인할 수 있게 했고,
 * {@link #probe} 로 임의 질의의 실제 유사도 점수까지 볼 수 있게 했다.
 * 유사도 임계값을 얼마로 잡아야 하는지는 이 실측 없이는 결정할 수 없다.
 */
@Service
public class IngestService {

    private static final Logger log = LoggerFactory.getLogger(IngestService.class);

    private final VectorStore vectorStore;
    private final HelpDeskProperties props;

    /** 품질 확인용으로 보관하는 청크 원본. 운영에서는 별도 메타데이터 저장소가 대신한다. */
    private final Map<String, List<Document>> chunksBySource = new ConcurrentHashMap<>();

    public IngestService(VectorStore vectorStore, HelpDeskProperties props) {
        this.vectorStore = vectorStore;
        this.props = props;
    }

    public record IngestResult(String source, String docType, int chunks, int totalChars,
                               int minChars, int maxChars, int avgChars) {
    }

    /** 청크 하나의 요약 — 길이와 앞부분 미리보기만 보여 준다. */
    public record ChunkView(int index, String source, int chars, String preview) {
    }

    /** 임의 질의로 실제 검색을 돌려 본 결과 — 임계값 튜닝의 근거가 된다. */
    public record ProbeHit(int rank, String source, Double score, String preview) {
    }

    public IngestResult ingest(Resource file, String docType) {
        String source = file.getFilename() == null ? "unknown" : file.getFilename();
        deleteExisting(source);

        List<Document> raw = new TikaDocumentReader(file).get();

        // 청크 크기는 설정값(Phase 1)을 따른다. 규정 문서를 통째로 1청크로 넣으면
        // "반품 가능 기간"과 "반품 배송비"가 한 벡터에 뭉개져, 인접 주제(배송 규정의 배송비)에
        // 밀리는 현상이 실측됐다. 200토큰으로 잘게 나눠 주제를 분리한다.
        List<Document> chunks = TokenTextSplitter.builder()
                .withChunkSize(props.rag().chunkSize())
                .withMinChunkSizeChars(props.rag().minChunkSizeChars())
                .withKeepSeparator(true)
                .build()
                .apply(raw);

        List<Document> enriched = chunks.stream()
                .map(chunk -> {
                    Map<String, Object> meta = new HashMap<>(chunk.getMetadata());
                    meta.put("source", source);      // 출처 표시(Phase 3)의 근거가 되는 필드
                    meta.put("docType", docType);
                    return new Document(chunk.getText(), meta);
                })
                .toList();

        vectorStore.add(enriched);
        chunksBySource.put(source, enriched);

        IngestResult result = summarize(source, docType, enriched);
        log.info("인제스트 완료 source={} chunks={} avgChars={} (min={} max={})",
                source, result.chunks(), result.avgChars(), result.minChars(), result.maxChars());
        return result;
    }

    /** Phase 2 심화 — 실제로 저장된 청크를 그대로 꺼내 본다. */
    public List<ChunkView> inspect(String source, int previewChars) {
        List<ChunkView> views = new ArrayList<>();
        chunksBySource.forEach((src, docs) -> {
            if (source != null && !source.isBlank() && !src.equals(source)) {
                return;
            }
            for (int i = 0; i < docs.size(); i++) {
                String text = String.valueOf(docs.get(i).getText());
                views.add(new ChunkView(i, src, text.length(), preview(text, previewChars)));
            }
        });
        views.sort(Comparator.comparing(ChunkView::source).thenComparing(ChunkView::index));
        return views;
    }

    /**
     * Phase 2 심화 — 임계값을 정하기 위한 실측. 임계값을 <b>적용하지 않고</b> 검색해
     * 원점수를 그대로 보여 준다. 여기서 본 점수 분포로 {@code similarityThreshold} 를 정한다.
     */
    public List<ProbeHit> probe(String query, int topK) {
        List<Document> hits = vectorStore.similaritySearch(SearchRequest.builder()
                .query(query)
                .topK(topK)
                .similarityThreshold(0.0)
                .build());

        if (hits == null) {
            return List.of();
        }
        List<ProbeHit> results = new ArrayList<>();
        for (int i = 0; i < hits.size(); i++) {
            Document d = hits.get(i);
            results.add(new ProbeHit(i + 1,
                    String.valueOf(d.getMetadata().get("source")),
                    d.getScore(),
                    preview(String.valueOf(d.getText()), 90)));
        }
        return results;
    }

    public List<String> sources() {
        return chunksBySource.keySet().stream().sorted().toList();
    }

    public int totalChunks() {
        return chunksBySource.values().stream().mapToInt(List::size).sum();
    }

    private IngestResult summarize(String source, String docType, List<Document> docs) {
        int[] lengths = docs.stream().mapToInt(d -> String.valueOf(d.getText()).length()).toArray();
        int total = 0;
        int min = Integer.MAX_VALUE;
        int max = 0;
        for (int len : lengths) {
            total += len;
            min = Math.min(min, len);
            max = Math.max(max, len);
        }
        return new IngestResult(source, docType, docs.size(), total,
                lengths.length == 0 ? 0 : min, max,
                lengths.length == 0 ? 0 : total / lengths.length);
    }

    private String preview(String text, int chars) {
        String flat = text.replaceAll("\\s+", " ").trim();
        return flat.length() <= chars ? flat : flat.substring(0, chars) + "…";
    }

    private void deleteExisting(String source) {
        try {
            vectorStore.delete("source == '" + source + "'");
        } catch (Exception e) {
            log.debug("기존 청크 삭제를 건너뜁니다: {}", e.getMessage());
        }
    }
}
