package com.skala.helpdesk.domain;

/**
 * 도구·API 응답에 노출하는 티켓 정보.
 *
 * <p>{@code duplicate} 는 추가 구현 ②의 결과를 모델에게도 알려 주기 위한 필드다.
 * true 면 "새로 접수한 것이 아니라 이미 접수된 건을 그대로 돌려줬다"는 뜻이라,
 * 모델이 "중복 접수했습니다" 대신 "이미 접수된 건입니다"라고 안내할 수 있다.
 */
public record TicketView(String ticketNo, String status, boolean duplicate, String message) {
}
