package com.skala.helpdesk.web;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 장애 대응 — 실패도 서비스답게.
 *
 * <p>상세(스택트레이스·내부 메시지)는 로그에만 남기고 사용자에게는 안내 문구와 traceId 만 준다.
 * 예외 메시지를 그대로 내려 주면 내부 구조가 노출되고, 사용자는 어차피 그 메시지로
 * 아무것도 할 수 없다. traceId 하나면 운영자가 로그에서 그 요청을 바로 찾는다.
 *
 * <p>{@code AccessDeniedException} 은 여기서 잡지 않는다 — Spring Security 필터 단계에서
 * 401/403 으로 처리되어야 하고, 이 핸들러가 가로채면 권한 오류가 503 으로 둔갑한다.
 */
@RestControllerAdvice(basePackages = "com.skala.helpdesk.web")
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleBadRequest(IllegalArgumentException e) {
        String traceId = String.valueOf(MDC.get("traceId"));
        log.warn("[{}] 잘못된 요청: {}", traceId, e.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("message", String.valueOf(e.getMessage()), "traceId", traceId));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> handle(Exception e) {
        String traceId = String.valueOf(MDC.get("traceId"));
        log.error("[{}] 처리 실패", traceId, e);
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(Map.of("message", "잠시 후 다시 시도해 주세요.", "traceId", traceId));
    }
}
