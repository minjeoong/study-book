package com.skala.helpdesk.audit;

import java.util.ArrayList;
import java.util.List;

/**
 * 한 요청 안에서 <b>실제로 호출된 도구 이름</b>을 모은다.
 *
 * <p>구조화 응답(Phase 6)에 {@code toolsUsed} 를 넣으려면 "모델이 도구를 썼다고 말했는가"가
 * 아니라 "정말 실행됐는가"를 알아야 한다. 그래서 모델의 서술이 아니라
 * {@link ToolCallAuditAspect} 가 실제 호출을 가로챌 때 여기에 기록한다.
 *
 * <p>{@code .call()} 은 호출 스레드에서 동기로 끝나므로 ThreadLocal 로 충분하다.
 * 다만 스레드가 재사용되는 서블릿 컨테이너에서는 반드시 {@link #clear()} 로 비워야
 * 다음 요청에 이전 요청의 도구 이름이 새어 들어가지 않는다.
 */
public final class ToolCallTracker {

    private static final ThreadLocal<List<String>> CALLED = new ThreadLocal<>();

    private ToolCallTracker() {
    }

    public static void start() {
        CALLED.set(new ArrayList<>());
    }

    public static void record(String toolName) {
        List<String> called = CALLED.get();
        if (called != null && !called.contains(toolName)) {
            called.add(toolName);
        }
    }

    public static List<String> collected() {
        List<String> called = CALLED.get();
        return called == null ? List.of() : List.copyOf(called);
    }

    public static void clear() {
        CALLED.remove();
    }
}
