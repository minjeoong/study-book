package com.skala.helpdesk.web;

import java.util.List;
import java.util.Map;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skala.helpdesk.audit.AuditLogService;
import com.skala.helpdesk.domain.Ticket;
import com.skala.helpdesk.domain.TicketRepository;
import com.skala.helpdesk.domain.TicketStatus;
import com.skala.helpdesk.eval.EvaluationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * 사람 전용 승인 창구 — Human-in-the-loop (승인 게이트).
 *
 * <p><b>이 경로는 {@code AiConfig} 의 도구 목록에 없다.</b> 모델은 이 API 의 존재 자체를 모르므로
 * 절대 호출할 수 없다 — "모델이 접근할 수 없는 경로에 실제 처리를 둔다"는 원칙을 구조로
 * 강제한 것이다. {@code @PreAuthorize} 와 {@code SecurityConfig} 의 필터 체인이 이중으로
 * ROLE_ADMIN 을 요구한다.
 *
 * <p>승인·반려에는 <b>누가 결재했는지</b>({@code Authentication#getName()})를 함께 기록한다.
 * 승인 게이트의 목적은 "사람이 눌렀다"가 아니라 "누가 눌렀는지 남는다"이기 때문이다.
 */
@RestController
@RequestMapping("/helpdesk/admin")
@Tag(name = "4. 승인 게이트 · 감사 (관리자 전용)", description = "ROLE_ADMIN 만 접근할 수 있습니다")
public class AdminController {

    private final TicketRepository tickets;
    private final AuditLogService audit;
    private final EvaluationService evaluation;

    public AdminController(TicketRepository tickets, AuditLogService audit, EvaluationService evaluation) {
        this.tickets = tickets;
        this.audit = audit;
        this.evaluation = evaluation;
    }

    @GetMapping("/tickets/pending")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "승인 대기 티켓 목록")
    public List<Ticket> pending() {
        return tickets.pending();
    }

    @GetMapping("/tickets")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "전체 티켓 목록", description = "중복 접수 방지(Idempotency) 동작 확인에 사용합니다.")
    public List<Ticket> all() {
        return tickets.all();
    }

    @PostMapping("/tickets/{no}/approve")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "업무 요청 승인",
            description = "실제 처리는 이 버튼을 사람이 눌러야만 일어납니다. 모델은 이 경로를 도구로 가지고 있지 않습니다.")
    public Map<String, String> approve(@PathVariable String no, Authentication authentication) {
        return decide(no, TicketStatus.APPROVED, authentication.getName());
    }

    @PostMapping("/tickets/{no}/reject")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "업무 요청 반려")
    public Map<String, String> reject(@PathVariable String no, Authentication authentication) {
        return decide(no, TicketStatus.REJECTED, authentication.getName());
    }

    private Map<String, String> decide(String no, TicketStatus decision, String admin) {
        return tickets.decide(no, decision, admin)
                .map(t -> {
                    audit.log("TICKET_" + decision.name(), admin, t.orderId(), t.no());
                    return Map.of("ticketNo", t.no(), "status", t.status().name(), "decidedBy", admin);
                })
                .orElse(Map.of("ticketNo", no, "status", "NOT_FOUND", "decidedBy", admin));
    }

    @GetMapping("/audit")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "업무 이벤트 감사 기록",
            description = "누가·언제·어떤 업무 요청을 접수하고 결재했는지 확인합니다.")
    public List<AuditLogService.AuditEvent> auditTrail() {
        return audit.recent();
    }

    @PostMapping("/eval/run")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "[Evaluation] 골든 세트를 실행해 통과율을 측정한다",
            description = "실제 모델을 호출하므로 토큰 비용이 발생합니다. 튜닝 전후 비교에 사용합니다.")
    public EvaluationService.Report runEval(Authentication authentication) {
        return evaluation.run(authentication.getName());
    }
}
