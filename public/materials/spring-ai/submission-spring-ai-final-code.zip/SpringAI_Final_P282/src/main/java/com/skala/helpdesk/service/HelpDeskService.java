package com.skala.helpdesk.service;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.vectorstore.QuestionAnswerAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.metadata.Usage;
import org.springframework.ai.document.Document;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Service;

import com.skala.helpdesk.advisor.SafeGuardAdvisor;
import com.skala.helpdesk.audit.ToolCallTracker;
import com.skala.helpdesk.config.HelpDeskProperties;
import com.skala.helpdesk.web.dto.ChatAnswer;
import com.skala.helpdesk.web.dto.ChatRequest;
import com.skala.helpdesk.web.dto.SourceRef;

import io.micrometer.core.instrument.MeterRegistry;
import reactor.core.publisher.Flux;

/**
 * HelpDesk Agent 오케스트레이션 — 컨트롤러와 ChatClient 사이의 유일한 접점.
 *
 * <p>컨트롤러에는 RAG · 메모리 · 안전 필터 · 계측 코드가 한 줄도 없다. 전부 {@code AiConfig} 가
 * 조립한 Advisor 체인에 들어 있고, 이 서비스는 그 위에서
 * <b>"인증된 사용자 ID 확보 → 대화 ID 조합 → 호출 → 구조화 응답 조립 → 실패 시 폴백"</b>
 * 만 담당한다.
 *
 * <p><b>장애 대응(Fallback).</b> 모델 호출은 네트워크 너머의 외부 의존이라 반드시 실패한다.
 * 실패했을 때 스택트레이스를 사용자에게 보여 주는 대신, 폴백 문구 + traceId 를 담은
 * <b>정상 형태의 구조화 응답</b>을 {@code degraded=true} 로 내려 준다. 클라이언트 입장에서
 * 응답 스키마가 바뀌지 않으므로 화면이 깨지지 않고, 운영자는 {@code ai.fallback} 카운터로
 * 열화 빈도를 추적할 수 있다.
 */
@Service
public class HelpDeskService {

    private static final Logger log = LoggerFactory.getLogger(HelpDeskService.class);

    private final ChatClient helpDesk;
    private final ChatMemory chatMemory;
    private final HelpDeskProperties props;
    private final MeterRegistry registry;

    public HelpDeskService(ChatClient helpDeskChatClient,
                           ChatMemory chatMemory,
                           HelpDeskProperties props,
                           MeterRegistry registry) {
        this.helpDesk = helpDeskChatClient;
        this.chatMemory = chatMemory;
        this.props = props;
        this.registry = registry;
    }

    /** 대화 ID 규칙을 만드는 유일한 곳(Phase 5). 규칙이 흩어지면 남의 대화가 섞인다. */
    public static String conversationId(String userId, String sessionId) {
        return userId + ":" + sessionId;
    }

    /**
     * Phase 3 · 4 · 5 · 6 통합 — 한 턴 처리.
     */
    public ChatAnswer ask(String userId, ChatRequest request) {
        String sessionId = request.sessionIdOrDefault();
        String traceId = String.valueOf(MDC.get("traceId"));
        long started = System.nanoTime();

        log.info("[CHAT] traceId={} user={} session={} 질문=\"{}\"", traceId, userId, sessionId, request.message());

        ToolCallTracker.start();
        try {
            if (request.shouldSimulateFailure()) {
                // 장애 주입 — 폴백 경로가 실제로 동작하는지 확인하기 위한 통제된 실패다.
                throw new IllegalStateException("[fault-injection] 모델 호출 실패를 시뮬레이션했습니다.");
            }

            ChatClientResponse response = helpDesk.prompt()
                    .user(request.message())
                    // 도구가 읽는 통로 — 모델이 못 바꾼다.
                    .toolContext(Map.of("userId", userId))
                    .advisors(a -> a
                            .param(ChatMemory.CONVERSATION_ID, conversationId(userId, sessionId))
                            .param("userId", userId))
                    .call()
                    .chatClientResponse();

            return toAnswer(response, sessionId, traceId, elapsedMs(started));

        } catch (Exception e) {
            registry.counter("ai.fallback", "reason", e.getClass().getSimpleName()).increment();
            log.error("[FALLBACK] traceId={} 모델 호출 실패 — 폴백 응답으로 대체합니다", traceId, e);

            return new ChatAnswer(props.resilience().fallbackMessage(),
                    sessionId, traceId, List.of(), ToolCallTracker.collected(),
                    false, true, elapsedMs(started), null, null);

        } finally {
            ToolCallTracker.clear();
        }
    }

    /**
     * Phase 6 — SSE 스트리밍.
     *
     * <p>토큰이 생성되는 대로 흘려 보낸다. 전체 응답이 10초 걸려도 첫 글자는 1초 안에 보이므로
     * 체감 지연이 크게 줄어든다. {@code event} 이름으로 {@code token} 과 {@code done} 을
     * 구분해, 클라이언트가 "끝났다"를 문자열 비교가 아니라 이벤트 종류로 판단하게 한다.
     * 스트리밍 경로에서도 SafeGuard 가 그대로 동작한다({@code StreamAdvisor} 를 함께 구현했다).
     */
    public Flux<ServerSentEvent<String>> stream(String userId, ChatRequest request) {
        String sessionId = request.sessionIdOrDefault();
        String traceId = String.valueOf(MDC.get("traceId"));

        log.info("[STREAM] traceId={} user={} session={} 질문=\"{}\"", traceId, userId, sessionId, request.message());

        return helpDesk.prompt()
                .user(request.message())
                .toolContext(Map.of("userId", userId))
                .advisors(a -> a
                        .param(ChatMemory.CONVERSATION_ID, conversationId(userId, sessionId))
                        .param("userId", userId))
                .stream()
                .content()
                .map(token -> ServerSentEvent.builder(token).event("token").build())
                .concatWith(Flux.just(ServerSentEvent.builder("[DONE]").event("done").build()))
                .timeout(Duration.ofMillis(props.resilience().timeoutMs()))
                // 스트리밍 도중 끊겨도 연결을 그냥 죽이지 않고, 폴백 문구를 마지막 이벤트로 보낸다.
                .onErrorResume(e -> {
                    registry.counter("ai.fallback", "reason", "stream").increment();
                    log.error("[FALLBACK] traceId={} 스트리밍 실패", traceId, e);
                    return Flux.just(
                            ServerSentEvent.builder(props.resilience().fallbackMessage()).event("token").build(),
                            ServerSentEvent.builder("[DONE]").event("done").build());
                });
    }

    /** Phase 5 — 대화 이력 조회. Advisor 순서 실험(Security)의 검증 창구이기도 하다. */
    public List<Map<String, String>> history(String userId, String sessionId) {
        return chatMemory.get(conversationId(userId, sessionId)).stream()
                .map(m -> Map.of("role", m.getMessageType().getValue(), "text", String.valueOf(m.getText())))
                .toList();
    }

    // ── 응답 조립 ────────────────────────────────────────────────

    private ChatAnswer toAnswer(ChatClientResponse response, String sessionId, String traceId, long latencyMs) {
        String answer = response.chatResponse() == null || response.chatResponse().getResult() == null
                ? "" : response.chatResponse().getResult().getOutput().getText();

        boolean blocked = Boolean.TRUE.equals(response.context().get(SafeGuardAdvisor.BLOCKED));

        Integer promptTokens = null;
        Integer completionTokens = null;
        if (response.chatResponse() != null && response.chatResponse().getMetadata() != null) {
            Usage usage = response.chatResponse().getMetadata().getUsage();
            if (usage != null) {
                promptTokens = usage.getPromptTokens();
                completionTokens = usage.getCompletionTokens();
            }
        }

        return new ChatAnswer(answer, sessionId, traceId, sourcesOf(response),
                ToolCallTracker.collected(), blocked, false, latencyMs, promptTokens, completionTokens);
    }

    /**
     * Phase 3 — 출처는 모델의 서술이 아니라 실제 검색 결과에서 뽑는다.
     * 근거가 없었으면 빈 목록 — 그 자체가 "문서 밖 질문이었다"는 증거가 된다.
     */
    private List<SourceRef> sourcesOf(ChatClientResponse response) {
        Object raw = response.context().get(QuestionAnswerAdvisor.RETRIEVED_DOCUMENTS);
        if (!(raw instanceof List<?> docs)) {
            return List.of();
        }
        return docs.stream()
                .filter(Document.class::isInstance)
                .map(Document.class::cast)
                .map(d -> new SourceRef(
                        String.valueOf(d.getMetadata().get("source")),
                        d.getScore(),
                        snippet(String.valueOf(d.getText()))))
                .toList();
    }

    private String snippet(String text) {
        String flat = text.replaceAll("\\s+", " ").trim();
        return flat.length() <= 110 ? flat : flat.substring(0, 110) + "…";
    }

    private long elapsedMs(long startedNanos) {
        return (System.nanoTime() - startedNanos) / 1_000_000;
    }
}
