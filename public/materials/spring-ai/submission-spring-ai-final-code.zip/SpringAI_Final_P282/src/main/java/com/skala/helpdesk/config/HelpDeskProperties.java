package com.skala.helpdesk.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Phase 1 — 설정 외부화.
 *
 * <p>모델명 · 검색 파라미터 · 청크 크기 · 메모리 창 크기처럼 <b>운영 중에 바뀔 값</b>은
 * 코드가 아니라 {@code application.yml} 에 둔다. 특히 RAG 의 {@code topK} ·
 * {@code similarityThreshold} 와 인제스트의 {@code chunkSize} 는 품질을 좌우하는
 * 튜닝 손잡이라 재배포 없이 실험할 수 있어야 한다. 값이 코드에 흩어져 있으면
 * "무엇을 바꿔서 좋아졌는지"를 나중에 설명할 수 없다.
 *
 * <p>record 로 선언해 불변으로 두고, {@code @EnableConfigurationProperties} 로 등록한다.
 * 기본값을 생성자에서 채워 두었기 때문에 yml 에서 일부만 덮어써도 동작한다.
 */
@ConfigurationProperties(prefix = "helpdesk")
public record HelpDeskProperties(Rag rag, Memory memory, Resilience resilience, List<UserSpec> users) {

    public HelpDeskProperties {
        rag = rag == null ? new Rag(null, null, null, null) : rag;
        memory = memory == null ? new Memory(null) : memory;
        resilience = resilience == null ? new Resilience(null, null) : resilience;
        users = users == null ? List.of() : users;
    }

    /** RAG 검색 · 인제스트 튜닝 값. */
    public record Rag(Integer topK, Double similarityThreshold, Integer chunkSize, Integer minChunkSizeChars) {

        public Rag {
            topK = topK == null ? 4 : topK;
            // 실측 유사도(0.42/0.23) 기준으로 낮춰 잡았다 — 0.6 을 그대로 쓰면 정답 근거까지
            // 걸러져 "근거 없음"으로 오답한다(Phase 2 심화에서 실제로 확인했다).
            similarityThreshold = similarityThreshold == null ? 0.3 : similarityThreshold;
            // 규정 문서 하나를 통째로 1청크로 넣으면 "반품 기간"과 "반품 배송비"가 한 벡터에
            // 뭉개진다. 200 토큰으로 잘게 나눠 주제별로 분리한다.
            chunkSize = chunkSize == null ? 200 : chunkSize;
            minChunkSizeChars = minChunkSizeChars == null ? 80 : minChunkSizeChars;
        }
    }

    /** 대화 메모리 창 크기. */
    public record Memory(Integer maxMessages) {

        public Memory {
            maxMessages = maxMessages == null ? 20 : maxMessages;
        }
    }

    /** 장애 대응 — 모델 호출 타임아웃과 폴백 문구. */
    public record Resilience(Long timeoutMs, String fallbackMessage) {

        public Resilience {
            timeoutMs = timeoutMs == null ? 30_000L : timeoutMs;
            fallbackMessage = fallbackMessage == null
                    ? "지금은 AI 응답을 생성할 수 없어 잠시 후 다시 시도해 주세요. "
                      + "급한 업무는 HelpDesk 담당자에게 아래 추적 ID 와 함께 문의해 주세요."
                    : fallbackMessage;
        }
    }

    /**
     * 데모용 고정 계정 — 강의 실습 전용. 운영에서는 사내 SSO·LDAP 로 교체한다.
     * 계정을 코드에 하드코딩하지 않고 설정으로 분리해 두는 것만으로도 교체가 쉬워진다.
     */
    public record UserSpec(String username, String password, String roles) {
    }
}
