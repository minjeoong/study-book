package com.skala.helpdesk.config;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import com.skala.helpdesk.service.IngestService;

/**
 * 기동 시 사내 규정 문서를 자동으로 인제스트한다.
 *
 * <p>수동으로 {@code /helpdesk/ingest} 를 먼저 호출해야 하는 번거로움을 없애, 앱을 띄우자마자
 * 규정 질문을 바로 던져 볼 수 있게 한다. 인제스트는 임베딩 API 호출을 동반하므로
 * 기동 로그에 결과를 남겨 두면 "왜 답이 근거 없이 나오지?"를 가장 먼저 확인할 수 있다.
 */
@Component
public class DataInitializer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final IngestService ingestService;

    public DataInitializer(IngestService ingestService) {
        this.ingestService = ingestService;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        Resource[] docs = new PathMatchingResourcePatternResolver().getResources("classpath:/docs/*.md");
        Arrays.stream(docs).forEach(doc -> ingestService.ingest(doc, "policy"));
        log.info("사내 규정 문서 {}건 자동 인제스트 완료 — 총 청크 {}개", docs.length, ingestService.totalChunks());
    }
}
