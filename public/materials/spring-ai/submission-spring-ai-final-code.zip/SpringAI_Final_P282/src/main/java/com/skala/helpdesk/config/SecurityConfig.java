package com.skala.helpdesk.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Security — 인증·인가.
 *
 * <p><b>이 설정이 있어야 도구의 권한 검증이 의미를 갖는다.</b> 도구는 {@code ToolContext} 의
 * {@code userId} 를 믿고 동작하는데, 그 값이 인증되지 않은 임의의 문자열이라면
 * 권한 검증은 형식만 남는다. 여기서 확보한 인증 주체가
 * {@code ChatController → ToolContext → OrderRepository} 로 그대로 흘러가는 것이
 * 권한 체계 전체의 뿌리다.
 *
 * <p>승인 API({@code /helpdesk/admin/**})는 필터 체인과
 * {@code @PreAuthorize("hasRole('ADMIN')")} 양쪽에서 <b>이중으로</b> 막는다. 모델은 이 경로를
 * 도구로 가지고 있지 않아 애초에 호출할 수 없고, 사람이 직접 호출하더라도 관리자가 아니면 거부된다.
 *
 * <p>세션은 STATELESS 로 둔다 — 대화 맥락은 HTTP 세션이 아니라 {@code ChatMemory} 의
 * conversationId 가 관리하므로, 두 곳에 상태를 나눠 두면 어긋날 때 원인을 찾기 어렵다.
 */
@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService userDetailsService(HelpDeskProperties props, PasswordEncoder encoder) {
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
        props.users().forEach(u -> manager.createUser(User.withUsername(u.username())
                .password(encoder.encode(u.password()))
                .roles(u.roles())
                .build()));
        return manager;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        // 문서·헬스체크는 공개 — 실습 편의를 위한 선택이며 운영에서는 좁힌다.
                        .requestMatchers("/swagger-ui/**", "/swagger-ui.html", "/v3/api-docs/**",
                                "/actuator/**", "/console.html", "/favicon.ico").permitAll()
                        .requestMatchers("/helpdesk/admin/**").hasRole("ADMIN")
                        .requestMatchers("/helpdesk/**").authenticated()
                        .anyRequest().permitAll())
                .httpBasic(Customizer.withDefaults())
                .build();
    }
}
