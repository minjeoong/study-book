package com.skala.helpdesk.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;

/**
 * 채팅 요청.
 *
 * <p><b>{@code userId} 는 여기 없다.</b> 요청 본문으로 받으면 클라이언트가 아무 값이나 넣어
 * 남의 주문을 조회할 수 있다. 사용자 ID 는 오직 인증된 {@code Authentication#getName()}
 * 에서만 온다 — 필드를 아예 만들지 않는 것이 가장 확실한 방어다.
 *
 * <p>{@code simulateFailure} 는 장애 대응(Fallback) 검증용 결함 주입 스위치다.
 * 실제 모델 장애를 재현하기 어려우므로, 서비스 내부에서 예외를 일부러 던져
 * 폴백 경로가 정말 동작하는지 확인한다.
 */
public record ChatRequest(
        @NotBlank
        @Schema(description = "사용자 질문", example = "주문 12345 반품할 수 있어?")
        String message,

        @Schema(description = "대화 창 식별자. 같은 값을 쓰면 이전 대화를 기억한다.", example = "s1")
        String sessionId,

        @Schema(description = "장애 대응 검증용 결함 주입 스위치. true 면 모델 호출을 일부러 실패시킨다.",
                example = "false")
        Boolean simulateFailure) {

    public String sessionIdOrDefault() {
        return sessionId == null || sessionId.isBlank() ? "default" : sessionId;
    }

    public boolean shouldSimulateFailure() {
        return Boolean.TRUE.equals(simulateFailure);
    }
}
