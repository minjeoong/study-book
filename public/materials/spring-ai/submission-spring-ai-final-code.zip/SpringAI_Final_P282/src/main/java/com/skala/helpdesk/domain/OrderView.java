package com.skala.helpdesk.domain;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * 도구·API 응답에 노출하는 주문 정보. {@code ownerId} 는 절대 밖으로 내보내지 않는다.
 *
 * <p>{@code daysSinceDelivery} 를 <b>도메인 쪽에서 계산해</b> 내려 준다. 모델에게
 * "오늘 날짜와 수령일을 빼 보라"고 시키면 계산을 틀리는 일이 실제로 생기므로,
 * 숫자 계산처럼 결정적인 일은 코드가 하고 모델은 규정 해석만 하게 나눈다.
 */
public record OrderView(String orderId,
                        String item,
                        String status,
                        String orderedAt,
                        String deliveredAt,
                        String eta,
                        Integer daysSinceDelivery,
                        boolean madeToOrder) {

    public static OrderView from(Order order) {
        Integer days = order.deliveredAt() == null
                ? null
                : (int) ChronoUnit.DAYS.between(order.deliveredAt(), LocalDate.now());

        return new OrderView(
                order.id(),
                order.item(),
                order.status(),
                String.valueOf(order.orderedAt()),
                order.deliveredAt() == null ? "미수령" : order.deliveredAt().toString(),
                order.eta() == null ? "-" : order.eta().toString(),
                days,
                order.madeToOrder());
    }
}
