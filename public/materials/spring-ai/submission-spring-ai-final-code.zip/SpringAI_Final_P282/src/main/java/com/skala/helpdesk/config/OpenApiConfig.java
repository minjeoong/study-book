package com.skala.helpdesk.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;

/**
 * Swagger UI 문서화 + 로그인(Authorize) 버튼 노출.
 *
 * <p>{@link SecurityConfig} 가 HTTP Basic 인증을 강제하지만, 이 설정이 없으면 springdoc 은
 * 그 사실을 문서화하지 않아 Swagger UI 에 자물쇠 아이콘이 뜨지 않는다. 우측 상단 Authorize 에
 * user1/user1pass 를 한 번 입력하면 이후 모든 "Try it out" 호출에 인증 헤더가 자동으로 붙는다.
 */
@Configuration
@SecurityScheme(name = "basicAuth", type = SecuritySchemeType.HTTP, scheme = "basic")
public class OpenApiConfig {

    @Bean
    public OpenAPI helpDeskOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("SK 사내 AI Workforce HelpDesk Agent")
                        .version("1.0.0")
                        .description("""
                                SKALA 종합 실습 — RAG + Tool + Memory + 승인 게이트 + Security + Observability.
                                우측 상단 Authorize 에서 user1/user1pass(일반) 또는 admin/admin1234(관리자)로 로그인한 뒤 사용합니다."""))
                .addSecurityItem(new SecurityRequirement().addList("basicAuth"));
    }
}
