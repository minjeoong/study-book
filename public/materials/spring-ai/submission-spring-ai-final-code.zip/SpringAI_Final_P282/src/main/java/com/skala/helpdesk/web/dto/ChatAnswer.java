package com.skala.helpdesk.web.dto;

import java.util.List;

/**
 * Phase 6 — 구조화 응답.
 *
 * <p>답변 문자열 하나만 내려 주면 클라이언트는 "이게 규정 답변인지 도구 실행 결과인지",
 * "근거가 있었는지", "얼마나 느리고 비쌌는지"를 알 수 없어 결국 문자열을 파싱하게 된다.
 * 그래서 <b>사람이 읽을 답변</b>과 <b>기계가 쓸 메타데이터</b>를 분리해 내려 준다.
 *
 * <ul>
 *   <li>{@code sources} — 실제 검색된 근거(Phase 3)</li>
 *   <li>{@code toolsUsed} — 모델의 주장이 아니라 Aspect 가 확인한 실제 도구 실행 내역</li>
 *   <li>{@code traceId} — 로그와 응답을 잇는 열쇠. 장애 문의 한마디로 로그를 찾을 수 있다</li>
 *   <li>{@code blocked} — 안전 필터에 걸려 모델까지 가지 않은 턴인지</li>
 *   <li>{@code degraded} — 폴백 경로로 응답한 턴인지(정상 응답과 구분해야 한다)</li>
 * </ul>
 */
public record ChatAnswer(String answer,
                         String sessionId,
                         String traceId,
                         List<SourceRef> sources,
                         List<String> toolsUsed,
                         boolean blocked,
                         boolean degraded,
                         long latencyMs,
                         Integer promptTokens,
                         Integer completionTokens) {
}
