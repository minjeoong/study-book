package com.skala.helpdesk.domain;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Repository;

/**
 * 업무 요청 티켓 저장소.
 *
 * <p>접수({@link #createIdempotent})와 결재({@link #decide})를 서로 다른 API 경로로 분리한다.
 * 결재 경로는 도구 목록에 올라가지 않으므로 모델은 접수까지만 할 수 있다 — 실제 처리는
 * 사람이 {@code POST /helpdesk/admin/tickets/{no}/approve} 를 눌러야만 일어난다.
 *
 * <p><b>추가 구현 ② — 중복 접수 방지(Idempotency).</b>
 * LLM 은 같은 도구를 두 번 부를 수 있고(재시도·오해), 사용자도 "아까 그거 접수됐나요?"라며
 * 같은 요청을 반복한다. 그때마다 티켓이 새로 생기면 담당자가 같은 건을 여러 번 결재하게 된다.
 * 그래서 {@code idempotencyKey} 를 먼저 조회해 이미 있으면 <b>새로 만들지 않고 기존 티켓을
 * 그대로 돌려준다.</b> {@code computeIfAbsent} 로 원자적으로 처리해 동시 호출에도 안전하다.
 */
@Repository
public class TicketRepository {

    private final Map<String, Ticket> ticketsByNo = new ConcurrentHashMap<>();
    private final Map<String, String> noByIdempotencyKey = new ConcurrentHashMap<>();
    private final AtomicInteger sequence = new AtomicInteger(1000);

    /** 접수 결과 — 새로 만들었는지(신규) 기존 건을 돌려줬는지(중복)를 함께 알려 준다. */
    public record CreateResult(Ticket ticket, boolean duplicate) {
    }

    /**
     * 같은 idempotencyKey 로 다시 부르면 기존 티켓을 그대로 돌려준다.
     * 키 → 번호 매핑을 원자적으로 만들고, 그 결과가 방금 만든 것인지로 신규/중복을 판별한다.
     */
    public CreateResult createIdempotent(String idempotencyKey, String orderId, String userId, String reason) {
        boolean[] created = {false};

        String no = noByIdempotencyKey.computeIfAbsent(idempotencyKey, key -> {
            String newNo = "RF-" + sequence.incrementAndGet();
            ticketsByNo.put(newNo, new Ticket(newNo, orderId, userId, reason, key,
                    Instant.now(), TicketStatus.PENDING, null, null));
            created[0] = true;
            return newNo;
        });

        return new CreateResult(ticketsByNo.get(no), !created[0]);
    }

    public Optional<Ticket> findByNo(String no) {
        return Optional.ofNullable(ticketsByNo.get(no));
    }

    public List<Ticket> pending() {
        return ticketsByNo.values().stream()
                .filter(t -> t.status() == TicketStatus.PENDING)
                .sorted((a, b) -> a.no().compareTo(b.no()))
                .toList();
    }

    public List<Ticket> all() {
        return ticketsByNo.values().stream()
                .sorted((a, b) -> a.no().compareTo(b.no()))
                .toList();
    }

    /** 사람만 호출한다 — 컨트롤러가 {@code @PreAuthorize("hasRole('ADMIN')")} 로 보호한다. */
    public Optional<Ticket> decide(String no, TicketStatus decision, String admin) {
        return findByNo(no).map(t -> {
            Ticket decided = t.decide(decision, admin);
            ticketsByNo.put(no, decided);
            return decided;
        });
    }
}
