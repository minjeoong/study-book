package com.skala.helpdesk.advisor;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ai.chat.client.ChatClientRequest;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.api.CallAdvisor;
import org.springframework.ai.chat.client.advisor.api.CallAdvisorChain;
import org.springframework.ai.chat.metadata.Usage;
import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.MeterRegistry;

/**
 * Observability — 토큰 · 지연 · 비용 계측.
 *
 * <p>체인에서 가장 바깥(order 10)에 둬서 안전 필터에서 막히든 RAG·도구를 여러 번 거치든
 * 상관없이 <b>사용자가 체감하는 총 지연</b>을 잡는다. 안쪽에 두면 앞단에서 막힌 요청이
 * 계측에서 빠져 "왜 평균 지연이 실제보다 좋게 나오지?" 같은 착시가 생긴다.
 *
 * <p>토큰은 Micrometer 카운터로 누적하고, 단가를 곱해 <b>누적 비용(USD)</b>까지 게이지로
 * 노출한다. AI 서비스에서는 정확도만큼 비용이 운영 지표이기 때문이다.
 *
 * <p>확인: {@code GET /actuator/metrics/ai.tokens?tag=type:prompt} ·
 * {@code GET /actuator/metrics/ai.latency} · {@code GET /helpdesk/metrics}
 */
@Component
public class TokenMeterAdvisor implements CallAdvisor {

    private static final Logger log = LoggerFactory.getLogger(TokenMeterAdvisor.class);

    /** gpt-4o-mini 공개 단가(1K 토큰 기준, USD). 모델을 바꾸면 이 값도 함께 바꾼다. */
    private static final double PROMPT_USD_PER_1K = 0.00015;
    private static final double COMPLETION_USD_PER_1K = 0.00060;

    private final MeterRegistry registry;

    /** 누적 토큰·비용 — {@code /helpdesk/metrics} 가 한 번에 보여 주기 위한 스냅숏. */
    private final java.util.concurrent.atomic.AtomicLong promptTokens = new java.util.concurrent.atomic.AtomicLong();
    private final java.util.concurrent.atomic.AtomicLong completionTokens = new java.util.concurrent.atomic.AtomicLong();
    private final java.util.concurrent.atomic.AtomicLong calls = new java.util.concurrent.atomic.AtomicLong();
    private final java.util.concurrent.atomic.AtomicLong totalLatencyMs = new java.util.concurrent.atomic.AtomicLong();

    public TokenMeterAdvisor(MeterRegistry registry) {
        this.registry = registry;
        registry.gauge("ai.cost.usd", this, TokenMeterAdvisor::estimatedCostUsd);
    }

    @Override
    public ChatClientResponse adviseCall(ChatClientRequest request, CallAdvisorChain chain) {
        long started = System.nanoTime();
        ChatClientResponse response = chain.nextCall(request);
        long elapsedNanos = System.nanoTime() - started;
        long elapsedMs = elapsedNanos / 1_000_000;

        registry.timer("ai.latency", "phase", "model").record(elapsedNanos, TimeUnit.NANOSECONDS);
        calls.incrementAndGet();
        totalLatencyMs.addAndGet(elapsedMs);

        if (response.chatResponse() != null && response.chatResponse().getMetadata() != null) {
            Usage usage = response.chatResponse().getMetadata().getUsage();
            if (usage != null) {
                long prompt = nullSafe(usage.getPromptTokens());
                long completion = nullSafe(usage.getCompletionTokens());

                registry.counter("ai.tokens", "type", "prompt").increment(prompt);
                registry.counter("ai.tokens", "type", "completion").increment(completion);
                promptTokens.addAndGet(prompt);
                completionTokens.addAndGet(completion);

                log.info("[METRICS] traceId={} promptTokens={} completionTokens={} elapsedMs={} costUsd={}",
                        MDC.get("traceId"), prompt, completion, elapsedMs,
                        "%.6f".formatted(costOf(prompt, completion)));
            }
        }
        return response;
    }

    // ── 스냅숏 조회 (MetricsController 가 읽는다) ────────────────────

    public long promptTokens() {
        return promptTokens.get();
    }

    public long completionTokens() {
        return completionTokens.get();
    }

    public long calls() {
        return calls.get();
    }

    public long averageLatencyMs() {
        long n = calls.get();
        return n == 0 ? 0 : totalLatencyMs.get() / n;
    }

    public double estimatedCostUsd() {
        return costOf(promptTokens.get(), completionTokens.get());
    }

    private double costOf(long prompt, long completion) {
        return prompt / 1000.0 * PROMPT_USD_PER_1K + completion / 1000.0 * COMPLETION_USD_PER_1K;
    }

    private long nullSafe(Integer value) {
        return value == null ? 0L : value.longValue();
    }

    @Override
    public String getName() {
        return "tokenMeter";
    }

    /** 가장 바깥 — 안전 필터·RAG·도구를 포함한 전체 시간을 재야 하기 때문이다. */
    @Override
    public int getOrder() {
        return 10;
    }
}
