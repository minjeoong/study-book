package com.skala.helpdesk.eval;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.skala.helpdesk.service.HelpDeskService;
import com.skala.helpdesk.web.dto.ChatAnswer;
import com.skala.helpdesk.web.dto.ChatRequest;
import com.skala.helpdesk.web.dto.SourceRef;

/**
 * Evaluation — 골든 세트 실행기.
 *
 * <p>{@link GoldenSet} 의 각 케이스를 <b>실제 서비스 경로 그대로</b>(HelpDeskService →
 * Advisor 체인 → 모델) 태워 채점한다. 별도 목킹 경로로 평가하면 실제 서비스와 다른 것을
 * 재는 셈이 되어 지표를 믿을 수 없다.
 *
 * <p>케이스마다 <b>새 sessionId</b> 를 쓴다 — 앞 케이스의 대화 이력이 남아 있으면
 * 뒷 케이스가 그 문맥 덕분에 맞히는 일이 생겨, 각 케이스를 독립적으로 평가할 수 없다.
 */
@Service
public class EvaluationService {

    private static final Logger log = LoggerFactory.getLogger(EvaluationService.class);

    /**
     * 골든 세트의 주문 케이스(12345 · 12346)는 데모 계정 {@code user1} 소유다.
     * 평가를 호출한 관리자 계정으로 그대로 돌리면 권한 검증에 막혀 도구 케이스가 전부 실패한다 —
     * 그것은 품질 저하가 아니라 데이터 소유자가 다른 것뿐이므로, 평가는 항상 고정된
     * 평가용 주체로 실행한다. 실제 사용자를 사칭하는 것이 아니라 평가 전용 컨텍스트다.
     */
    public static final String EVAL_SUBJECT = "user1";

    private final HelpDeskService helpDesk;

    public EvaluationService(HelpDeskService helpDesk) {
        this.helpDesk = helpDesk;
    }

    public record CaseResult(String id,
                             String question,
                             String intent,
                             boolean keywordPass,
                             boolean sourcePass,
                             boolean toolPass,
                             boolean pass,
                             List<String> missingKeywords,
                             List<String> actualSources,
                             List<String> actualTools,
                             long latencyMs,
                             Integer promptTokens,
                             Integer completionTokens,
                             String answer) {
    }

    public record Report(int total, int passed, int failed, String passRate,
                         long totalPromptTokens, long totalCompletionTokens,
                         long avgLatencyMs, List<CaseResult> results) {
    }

    public Report run(String triggeredBy) {
        List<CaseResult> results = new ArrayList<>();
        String runId = UUID.randomUUID().toString().substring(0, 6);
        log.info("[EVAL] 골든 세트 실행 시작 runId={} 요청자={} 평가주체={}", runId, triggeredBy, EVAL_SUBJECT);

        for (GoldenSet.Case c : GoldenSet.cases()) {
            // 케이스마다 새 대화 창 — 앞 케이스의 문맥이 뒤 케이스를 도와주면 안 된다.
            ChatRequest request = new ChatRequest(c.question(), "eval-" + runId + "-" + c.id(), false);
            ChatAnswer answer = helpDesk.ask(EVAL_SUBJECT, request);

            List<String> missing = missingKeywords(answer.answer(), c.expectedKeywords());
            List<String> sources = answer.sources().stream().map(SourceRef::source).distinct().toList();

            boolean keywordPass = missing.isEmpty();
            boolean sourcePass = c.expectedSource() == null || sources.contains(c.expectedSource());
            boolean toolPass = c.expectedTool() == null || answer.toolsUsed().contains(c.expectedTool());

            CaseResult result = new CaseResult(c.id(), c.question(), c.intent(),
                    keywordPass, sourcePass, toolPass,
                    keywordPass && sourcePass && toolPass,
                    missing, sources, answer.toolsUsed(),
                    answer.latencyMs(), answer.promptTokens(), answer.completionTokens(),
                    answer.answer());

            log.info("[EVAL] {} pass={} (keyword={} source={} tool={})",
                    c.id(), result.pass(), keywordPass, sourcePass, toolPass);
            results.add(result);
        }

        long passed = results.stream().filter(CaseResult::pass).count();
        long promptTokens = results.stream().mapToLong(r -> r.promptTokens() == null ? 0 : r.promptTokens()).sum();
        long completionTokens = results.stream().mapToLong(r -> r.completionTokens() == null ? 0 : r.completionTokens()).sum();
        long avgLatency = results.isEmpty() ? 0
                : results.stream().mapToLong(CaseResult::latencyMs).sum() / results.size();

        return new Report(results.size(), (int) passed, results.size() - (int) passed,
                "%.0f%%".formatted(results.isEmpty() ? 0.0 : passed * 100.0 / results.size()),
                promptTokens, completionTokens, avgLatency, results);
    }

    /**
     * 동의 표현 그룹({@code "불가|어렵"}) 중 하나도 나오지 않은 그룹만 돌려준다.
     * 공백을 제거하고 비교해 "7 일" 처럼 띄어쓰기가 흔들리는 경우를 흡수한다.
     */
    private List<String> missingKeywords(String answer, List<String> expected) {
        String normalized = answer == null ? "" : answer.replaceAll("\\s+", "");
        return expected.stream()
                .filter(group -> Arrays.stream(group.split("\\|"))
                        .noneMatch(alt -> normalized.contains(alt.replaceAll("\\s+", ""))))
                .toList();
    }
}
