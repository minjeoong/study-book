package com.skala.helpdesk.advisor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ai.chat.client.ChatClientRequest;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.api.CallAdvisor;
import org.springframework.ai.chat.client.advisor.api.CallAdvisorChain;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.stereotype.Component;

/**
 * Audit — 대화 턴 감사 로그.
 *
 * <p>인젝션 차단({@link SafeGuardAdvisor}, order 100)보다 <b>안쪽</b>(order 900)에 둔다.
 * 그래서 이 로그에 남았다는 사실 자체가 "차단되지 않고 정상 처리된 대화"라는 증거가 된다.
 * 차단된 턴은 SafeGuard 가 {@code event=INJECTION_BLOCKED} 로 따로 남기므로,
 * 두 로그를 합치면 전체 요청이 빠짐없이 재구성된다.
 *
 * <p>질문 원문은 남기되 답변은 <b>길이만</b> 남긴다 — 감사 목적에는 "무엇을 물었는가"가
 * 필요하고, 답변 전문까지 장기 보관하면 로그 자체가 개인정보 저장소가 되기 때문이다.
 */
@Component
public class AuditAdvisor implements CallAdvisor {

    private static final Logger audit = LoggerFactory.getLogger("AI_CHAT_AUDIT");

    @Override
    public ChatClientResponse adviseCall(ChatClientRequest request, CallAdvisorChain chain) {
        String userId = String.valueOf(request.context().get("userId"));
        String sessionId = String.valueOf(request.context().get(ChatMemory.CONVERSATION_ID));
        String question = request.prompt().getUserMessage() == null
                ? "" : request.prompt().getUserMessage().getText();

        ChatClientResponse response = chain.nextCall(request);

        String answer = response.chatResponse() == null || response.chatResponse().getResult() == null
                ? "" : String.valueOf(response.chatResponse().getResult().getOutput().getText());

        audit.info("event=CHAT_TURN traceId={} user={} session={} question=\"{}\" answerChars={}",
                MDC.get("traceId"), userId, sessionId, question, answer.length());

        return response;
    }

    @Override
    public String getName() {
        return "audit";
    }

    /** 인젝션 가드(100)보다 안쪽 — 차단된 턴은 여기까지 오지 않는다. */
    @Override
    public int getOrder() {
        return 900;
    }
}
