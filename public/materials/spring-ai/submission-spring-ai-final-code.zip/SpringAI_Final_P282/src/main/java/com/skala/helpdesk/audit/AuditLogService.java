package com.skala.helpdesk.audit;

import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

/**
 * 비즈니스 이벤트 감사 로그 — 환불 접수·관리자 승인처럼 "누가·언제·무엇을" 남겨야 하는
 * 업무 이벤트 전용.
 *
 * <p>도구 호출 자체의 감사는 {@link ToolCallAuditAspect} 가 모든 {@code @Tool} 을 가로채
 * 자동으로 남긴다. 여기서는 그중에서도 나중에 되돌아봐야 하는 <b>업무 이벤트</b>만
 * 한 번 더 구조화해 남긴다(REFUND_REQUESTED · TICKET_APPROVED 등).
 * 로거를 {@code AI_CHAT_AUDIT} 로 분리해, 운영에서 별도 파일·보존 기간을 적용하기 쉽게 한다.
 *
 * <p>최근 이벤트는 메모리에도 링버퍼로 남겨 {@code GET /helpdesk/admin/audit} 로
 * 확인할 수 있게 했다 — 감사 기록이 "로그 파일에만 있다"면 검증 화면을 만들 수 없기 때문이다.
 */
@Component
public class AuditLogService {

    private static final Logger audit = LoggerFactory.getLogger("AI_CHAT_AUDIT");
    private static final int MAX_KEPT = 200;

    public record AuditEvent(String at, String event, String userId, String target, String ref, String traceId) {
    }

    private final Deque<AuditEvent> recent = new ArrayDeque<>();

    public void log(String event, String userId, String targetId, String refNo) {
        String traceId = String.valueOf(MDC.get("traceId"));
        audit.info("event={} user={} target={} ref={} traceId={}", event, userId, targetId, refNo, traceId);

        synchronized (recent) {
            recent.addFirst(new AuditEvent(Instant.now().toString(), event, userId, targetId, refNo, traceId));
            while (recent.size() > MAX_KEPT) {
                recent.removeLast();
            }
        }
    }

    public List<AuditEvent> recent() {
        synchronized (recent) {
            return List.copyOf(recent);
        }
    }
}
