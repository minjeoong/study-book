package com.skala.helpdesk.web;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.skala.helpdesk.service.IngestService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Phase 2 · Phase 2 심화 — 인제스트와 품질 확인 창구.
 *
 * <p>인제스트를 "한 번 돌리고 끝"이 아니라 <b>다시 돌리고 결과를 눈으로 확인할 수 있는 기능</b>
 * 으로 만들어 둔다. 청크 전략을 바꿨을 때 재인제스트 → inspect → probe → eval 순으로
 * 돌리면 변경의 효과를 수치로 비교할 수 있다.
 */
@RestController
@RequestMapping("/helpdesk/ingest")
@Tag(name = "2. 문서 인제스트 · 품질 확인", description = "사내 규정 문서 적재와 청크 품질 점검")
public class IngestController {

    private final IngestService ingest;

    public IngestController(IngestService ingest) {
        this.ingest = ingest;
    }

    @PostMapping
    @Operation(summary = "사내 규정 문서를 다시 인제스트한다",
            description = "classpath:/docs/*.md 를 읽어 청크로 나눈 뒤 VectorStore 에 적재합니다. 같은 source 는 먼저 삭제하므로 중복 적재되지 않습니다.")
    public List<IngestService.IngestResult> reingest() throws Exception {
        Resource[] docs = new PathMatchingResourcePatternResolver().getResources("classpath:/docs/*.md");
        return Arrays.stream(docs).map(doc -> ingest.ingest(doc, "policy")).toList();
    }

    @GetMapping("/status")
    @Operation(summary = "적재 현황 요약")
    public Map<String, Object> status() {
        return Map.of("sources", ingest.sources(), "totalChunks", ingest.totalChunks());
    }

    @GetMapping("/chunks")
    @Operation(summary = "[Phase 2 심화] 저장된 청크를 그대로 열어 본다",
            description = "청크 개수와 글자 수 분포를 눈으로 확인합니다. 청크가 너무 크면 주제가 뭉개지고, 너무 작으면 문맥이 끊깁니다.")
    public List<IngestService.ChunkView> chunks(
            @RequestParam(required = false) String source,
            @RequestParam(defaultValue = "120") int previewChars) {
        return ingest.inspect(source, previewChars);
    }

    @GetMapping("/probe")
    @Operation(summary = "[Phase 2 심화] 임계값 없이 검색해 실제 유사도 점수를 본다",
            description = "similarityThreshold 를 얼마로 잡아야 하는지는 이 실측 점수 분포를 보고 결정합니다.")
    public List<IngestService.ProbeHit> probe(@RequestParam String query,
                                              @RequestParam(defaultValue = "5") int topK) {
        return ingest.probe(query, topK);
    }
}
