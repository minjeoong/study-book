package com.skala.helpdesk.domain;

import java.time.Instant;

/**
 * 교환·환불 업무 요청 티켓.
 *
 * <p>도구는 이 레코드를 {@link TicketStatus#PENDING} 상태로만 만들 수 있다.
 * {@code idempotencyKey} 는 추가 구현 ②(중복 접수 방지)에서 같은 요청이 반복될 때
 * 같은 티켓으로 수렴시키기 위한 키다.
 */
public record Ticket(String no,
                     String orderId,
                     String userId,
                     String reason,
                     String idempotencyKey,
                     Instant requestedAt,
                     TicketStatus status,
                     String decidedBy,
                     Instant decidedAt) {

    public Ticket decide(TicketStatus decision, String admin) {
        return new Ticket(no, orderId, userId, reason, idempotencyKey, requestedAt,
                decision, admin, Instant.now());
    }
}
