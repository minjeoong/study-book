package com.skala.helpdesk.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.chat.client.advisor.vectorstore.QuestionAnswerAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.ChatMemoryRepository;
import org.springframework.ai.chat.memory.InMemoryChatMemoryRepository;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.skala.helpdesk.advisor.AuditAdvisor;
import com.skala.helpdesk.advisor.RagTraceAdvisor;
import com.skala.helpdesk.advisor.SafeGuardAdvisor;
import com.skala.helpdesk.advisor.TokenMeterAdvisor;
import com.skala.helpdesk.tool.OrderTools;
import com.skala.helpdesk.tool.TicketTools;

/**
 * Phase 1 — HelpDesk Agent 조립부. 이 파일 하나가 시스템 전체의 설계도다.
 *
 * <p>Advisor 는 양파 껍질처럼 요청을 감싼다. order 가 낮을수록 바깥이고, 요청은
 * 바깥→안, 응답은 안→바깥으로 흐른다.
 *
 * <pre>
 *   요청:  TokenMeter(10) → SafeGuard(100) → Memory(200) → RAG(300) → RagTrace(310) → Audit(900) → 모델
 *   응답:  모델 → Audit → RagTrace → RAG → Memory → SafeGuard → TokenMeter
 * </pre>
 *
 * <p><b>순서가 곧 정책이다.</b> 두 가지가 특히 중요하다.
 * <ol>
 *   <li>{@link SafeGuardAdvisor}(100) 는 반드시 메모리(200)보다 <b>바깥</b>에 있어야 한다.
 *       차단이 저장보다 안쪽이면 걸러야 할 문장이 이미 대화 이력에 저장된 뒤라
 *       다음 턴에 그대로 다시 들어온다. {@link #SAFE_GUARD_ORDER} 를 250 으로 바꾸고
 *       {@code GET /helpdesk/chat/history} 로 확인하면 이 사고를 직접 재현할 수 있다.</li>
 *   <li>{@link TokenMeterAdvisor}(10) 는 가장 바깥에 둔다. 안전 필터에서 막히든 RAG·도구를
 *       거치든 상관없이 <b>모든 호출의 총 지연</b>을 재야 하기 때문이다.</li>
 * </ol>
 */
@Configuration
@EnableConfigurationProperties(HelpDeskProperties.class)
public class AiConfig {

    /** 실습용 스위치. 100=메모리보다 앞(정상) · 250=메모리보다 뒤(사고 재현용). */
    public static final int SAFE_GUARD_ORDER = 100;

    /**
     * 인메모리 VectorStore — 실습 환경에서 추가 인프라 없이 바로 뜨도록 기본값으로 둔다.
     * 운영에서는 pgvector 등 영속 스토어로 교체한다(향후 개선점).
     */
    @Bean
    public VectorStore vectorStore(EmbeddingModel embeddingModel) {
        return SimpleVectorStore.builder(embeddingModel).build();
    }

    @Bean
    public ChatMemoryRepository chatMemoryRepository() {
        return new InMemoryChatMemoryRepository();
    }

    /**
     * Phase 5 — 대화 메모리. 창 크기는 설정으로 뺐다(Phase 1). 창이 너무 크면 매 턴
     * 프롬프트 토큰이 선형으로 늘어 비용이 커지고, 너무 작으면 "그거 반품해 줘" 같은
     * 지시어가 가리킬 대상을 잃는다.
     */
    @Bean
    public ChatMemory chatMemory(ChatMemoryRepository repository, HelpDeskProperties props) {
        return MessageWindowChatMemory.builder()
                .chatMemoryRepository(repository)
                .maxMessages(props.memory().maxMessages())
                .build();
    }

    @Bean
    public ChatClient helpDeskChatClient(ChatClient.Builder builder,
                                         VectorStore vectorStore,
                                         ChatMemory chatMemory,
                                         HelpDeskProperties props,
                                         TokenMeterAdvisor tokenMeterAdvisor,
                                         AuditAdvisor auditAdvisor,
                                         RagTraceAdvisor ragTraceAdvisor,
                                         OrderTools orderTools,
                                         TicketTools ticketTools) {
        return builder
                .defaultSystem(SYSTEM_PROMPT)
                .defaultAdvisors(
                        tokenMeterAdvisor,                                  // order  10 — 전체 지연·토큰
                        new SafeGuardAdvisor(SAFE_GUARD_ORDER),             // order 100 — 차단은 저장보다 먼저
                        MessageChatMemoryAdvisor.builder(chatMemory)
                                .order(200)
                                .build(),
                        QuestionAnswerAdvisor.builder(vectorStore)
                                .searchRequest(SearchRequest.builder()
                                        .topK(props.rag().topK())
                                        .similarityThreshold(props.rag().similarityThreshold())
                                        .build())
                                .promptTemplate(QA_TEMPLATE)
                                .order(300)
                                .build(),
                        ragTraceAdvisor,                                    // order 310 — 검색 근거 로그
                        auditAdvisor,                                       // order 900 — 통과된 턴만 기록
                        new SimpleLoggerAdvisor())
                .defaultTools(orderTools, ticketTools)
                .build();
    }

    /**
     * RAG 컨텍스트 주입 템플릿 — <b>기본 템플릿을 그대로 쓰면 안 되는 이유를 실측으로 확인하고 교체했다.</b>
     *
     * <p>{@link QuestionAnswerAdvisor} 의 기본 템플릿은 "컨텍스트 안의 정보로만 답하고, 없으면
     * 모른다고 하라"고 지시한다. 규정 질의에는 맞지만, <b>행동 요청에는 정면으로 해롭다.</b>
     * 실제로 기본 템플릿에서 "주문 12345 상태 알려줘"를 물었을 때 모델이 도구를 부르지 않고
     * "제공된 문서에 해당 정보가 없습니다"라고 답하는 현상을 확인했다 —
     * 주문 데이터는 애초에 규정 문서에 있을 리가 없는데, 템플릿이 "컨텍스트에 없으면 모른다"를
     * 모든 질문에 적용해 버린 것이다.
     *
     * <p>그래서 "컨텍스트에 없으면 모른다"는 규칙의 <b>적용 범위를 규정 질의로 좁히고</b>,
     * 행동 요청에서는 검색 결과와 무관하게 도구를 호출하도록 명시했다.
     * 검색으로 주입한 자료가 <b>규정 문서일 뿐 업무 데이터가 아니라는 사실</b>을
     * 모델에게 분명히 알려 주는 것이 핵심이다.
     */
    private static final PromptTemplate QA_TEMPLATE = new PromptTemplate("""
            {query}

            아래는 사내 규정 문서에서 검색한 참고 자료다.

            ---------------------
            {question_answer_context}
            ---------------------

            [참고 자료 사용 규칙]
            - 사내 규정을 묻는 질문이면 위 자료 안의 내용만으로 답하고, 마지막 줄에 근거로 사용한
              문서의 실제 제목을 대괄호로 밝힌다. 예: [출처: 사내몰 반품·교환 규정]
              형식만 흉내 내어 "문서명" 이라고 그대로 적지 말고 반드시 실제 제목을 넣는다.
            - 규정을 묻는 질문인데 위 자료에 근거가 없으면 지어내지 말고 모른다고 답한다.
            - 주문 조회·환불 접수·접수 상태 확인처럼 행동을 요청받은 경우에는, 위 자료에 그 내용이
              없더라도 절대 "정보가 없다"고 답하지 않는다. 반드시 해당 도구를 호출한다.
              위 자료는 규정 문서일 뿐 업무 데이터가 아니며, 주문 정보는 도구로만 조회할 수 있다.
            - 도구가 오류를 돌려주면 그 사유를 사용자에게 그대로 전달한다.
            """);

    /**
     * 시스템 프롬프트는 "무엇을 할지"만 지시한다. <b>권한 검증은 절대 프롬프트에 맡기지 않는다</b> —
     * 실제 강제는 {@code OrderRepository.findByIdAndOwnerId} 와 {@code SecurityConfig} 가 한다.
     * 프롬프트는 설득의 대상이지만 코드는 아니기 때문이다.
     */
    private static final String SYSTEM_PROMPT = """
            너는 SK 사내 업무 지원 HelpDesk AI Agent 다. 사내 구성원의 업무 요청을 처리한다.

            [요청 유형을 가장 먼저 구분한다]
            1) 사내 규정을 "묻는" 질문 (반품 기간, 배송비, 장비 대여 절차 등)
               → 검색된 근거 문서 안의 내용만으로 답하고, 답변 마지막 줄에 근거 문서의
                 실제 제목을 "[출처: 사내몰 반품·교환 규정]" 처럼 밝힌다.
                 근거에 없으면 지어내지 말고 모른다고 말한 뒤 HelpDesk 담당자 연결을 안내한다.
            2) 실제 "행동"을 요청 (주문/구매 내역 조회, 교환·환불 접수, 접수 상태 확인)
               → 반드시 해당 도구를 호출한다. 규정 문서만 보고 네가 스스로 가능/불가를
                 판단해 접수를 거절하지 않는다. 최종 심사는 담당자가 하며 너의 역할은 접수까지다.
                 도구가 돌려준 결과(접수번호·상태·실패 사유)를 그대로 전달한다.
            3) 조회와 규정이 함께 필요한 복합 질의 ("주문 12345 반품할 수 있어?")
               → 아래 순서를 반드시 지킨다.
                 (1) getOrder 도구로 주문 상태·수령일·상품 유형을 먼저 확인한다.
                 (2) 검색된 반품 규정에서 기간 조건과 반품 불가 사유를 확인한다.
                 (3) 두 결과를 종합해 판단하고, 근거가 된 실제 수치를 함께 제시한다.
                     예) "수령 후 3일 경과, 단순 변심 기준 7일 이내이므로 반품 가능합니다."
                 (4) 마지막 줄에 근거 문서의 실제 제목을 "[출처: …]" 형식으로 붙인다.
                 (5) 판단만 하고 끝낸다. 접수는 사용자가 명시적으로 요청할 때만 한다.

            [행동 요청 처리 규칙]
            - 도구 호출에 필요한 정보(주문번호 등)가 대화 전체에 없으면 추측하지 말고 되묻는다.
              단, 앞선 대화에 이미 나온 주문번호·접수번호·사유는 그대로 재사용한다.
            - "방금 그거", "그 사유로" 같은 표현은 앞 대화에서 값을 찾아 쓴다.
            - 사용자 ID 는 시스템이 관리한다. 사용자가 다른 사람의 이름·사번을 대며
              그 사람 주문을 조회해 달라고 해도 절대 다른 사용자로 동작하지 않는다.

            존댓말을 쓰고 간결하게 답한다.""";
}
