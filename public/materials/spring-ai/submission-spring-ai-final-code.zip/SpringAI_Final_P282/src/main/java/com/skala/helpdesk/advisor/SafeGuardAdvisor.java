package com.skala.helpdesk.advisor;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ai.chat.client.ChatClientRequest;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.api.CallAdvisor;
import org.springframework.ai.chat.client.advisor.api.CallAdvisorChain;
import org.springframework.ai.chat.client.advisor.api.StreamAdvisor;
import org.springframework.ai.chat.client.advisor.api.StreamAdvisorChain;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;

import reactor.core.publisher.Flux;

/**
 * Security ① — 프롬프트 인젝션 차단 (OWASP LLM01).
 *
 * <p>"이전 지시 무시", "시스템 프롬프트 출력", 역할 탈옥 시도 등을 패턴으로 잡아
 * <b>모델에 닿기 전에</b> 막는다. 체인을 더 타지 않고 고정 응답으로 되돌리므로
 * 토큰 비용도 발생하지 않는다.
 *
 * <p><b>이 Advisor 의 위치가 곧 정책이다.</b> order 를 메모리 Advisor(200)보다 낮게
 * (=더 바깥에) 둬야 한다. 차단이 메모리 저장보다 안쪽이면 걸러야 할 문장이 이미
 * 대화 이력에 저장된 뒤라 다음 턴에 그대로 다시 들어온다.
 *
 * <p>차단 응답에도 {@code context} 를 그대로 복사해 넘긴다 — 바깥쪽 TokenMeter 가
 * 같은 컨텍스트로 계측을 이어갈 수 있어야 하기 때문이다.
 */
public class SafeGuardAdvisor implements CallAdvisor, StreamAdvisor {

    private static final Logger log = LoggerFactory.getLogger(SafeGuardAdvisor.class);
    private static final Logger audit = LoggerFactory.getLogger("AI_CHAT_AUDIT");

    /** 차단 여부를 바깥(TokenMeter·컨트롤러)에서 읽을 수 있게 컨텍스트에 남기는 키. */
    public static final String BLOCKED = "helpdesk.blocked";

    private static final String FAILURE_RESPONSE =
            "죄송합니다. 시스템 지시를 변경하거나 노출하도록 요청하는 문장은 처리할 수 없습니다. "
            + "사내 규정 문의나 업무 요청으로 다시 말씀해 주세요.";

    /** OWASP LLM01(Prompt Injection) 에서 흔히 쓰이는 표현을 패턴으로 모았다. */
    private static final List<Pattern> INJECTION_PATTERNS = List.of(
            Pattern.compile("이전\\s*(지시|명령|프롬프트).{0,10}(무시|잊)", Pattern.CASE_INSENSITIVE),
            Pattern.compile("시스템\\s*프롬프트", Pattern.CASE_INSENSITIVE),
            Pattern.compile("(지침|규칙|역할)\\s*을?\\s*(무시|바꿔|재정의)", Pattern.CASE_INSENSITIVE),
            Pattern.compile("ignore\\s+(all\\s+)?(previous|above|prior)\\s+instructions?", Pattern.CASE_INSENSITIVE),
            Pattern.compile("(reveal|print|show)\\s+(the\\s+)?system\\s+prompt", Pattern.CASE_INSENSITIVE),
            Pattern.compile("(너는|당신은)\\s*이제\\s*.{0,15}(다|이다|입니다)", Pattern.CASE_INSENSITIVE),
            Pattern.compile("개발자\\s*모드|DAN\\s*모드|jailbreak", Pattern.CASE_INSENSITIVE));

    private final int order;

    public SafeGuardAdvisor(int order) {
        this.order = order;
    }

    @Override
    public ChatClientResponse adviseCall(ChatClientRequest request, CallAdvisorChain chain) {
        return isInjection(request) ? blockedResponse(request) : chain.nextCall(request);
    }

    @Override
    public Flux<ChatClientResponse> adviseStream(ChatClientRequest request, StreamAdvisorChain chain) {
        return isInjection(request) ? Flux.just(blockedResponse(request)) : chain.nextStream(request);
    }

    private boolean isInjection(ChatClientRequest request) {
        String text = request.prompt().getContents();
        return INJECTION_PATTERNS.stream().anyMatch(p -> p.matcher(text).find());
    }

    private ChatClientResponse blockedResponse(ChatClientRequest request) {
        String text = request.prompt().getContents();
        log.warn("[SAFETY] 프롬프트 인젝션 패턴 차단 traceId={}", MDC.get("traceId"));
        audit.info("event=INJECTION_BLOCKED traceId={} text=\"{}\"", MDC.get("traceId"), text);

        Map<String, Object> context = new java.util.HashMap<>(request.context());
        context.put(BLOCKED, Boolean.TRUE);

        return ChatClientResponse.builder()
                .chatResponse(ChatResponse.builder()
                        .generations(List.of(new Generation(new AssistantMessage(FAILURE_RESPONSE))))
                        .build())
                .context(context)
                .build();
    }

    @Override
    public String getName() {
        return "safeGuard";
    }

    @Override
    public int getOrder() {
        return order;
    }
}
