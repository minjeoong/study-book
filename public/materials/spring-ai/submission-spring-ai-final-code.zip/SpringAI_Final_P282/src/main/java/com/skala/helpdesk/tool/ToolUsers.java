package com.skala.helpdesk.tool;

import org.springframework.ai.chat.model.ToolContext;

/**
 * 도구가 "현재 사용자"를 얻는 유일한 통로.
 *
 * <p>도구마다 이 코드를 복사해 두면 언젠가 한 곳에서 빠뜨리고, 그 도구가 권한 구멍이 된다.
 * 한 곳으로 모아 두면 "userId 는 ToolContext 에서만 온다"는 규칙을 코드로 보장할 수 있다.
 *
 * <p>값이 없으면 조용히 넘어가지 않고 예외를 던진다 — 권한 주체를 모르는 상태에서
 * 도구가 동작하는 것이 가장 위험한 실패 방식이기 때문이다(fail-closed).
 */
final class ToolUsers {

    private ToolUsers() {
    }

    static String currentUser(ToolContext toolContext) {
        Object userId = toolContext == null ? null : toolContext.getContext().get("userId");
        if (userId == null) {
            throw new IllegalStateException("toolContext 에 userId 가 없습니다 — 호출부 설정을 확인하세요.");
        }
        return userId.toString();
    }
}
