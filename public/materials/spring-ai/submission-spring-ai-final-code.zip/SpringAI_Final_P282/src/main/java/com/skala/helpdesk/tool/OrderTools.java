package com.skala.helpdesk.tool;

import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import com.skala.helpdesk.domain.OrderRepository;
import com.skala.helpdesk.domain.OrderView;

/**
 * Phase 4 — 업무 데이터 조회 도구.
 *
 * <p><b>사용자 ID 는 프롬프트가 아니라 {@link ToolContext} 로 들어온다.</b> 모델이 절대
 * 바꿔 부를 수 없는 통로다({@code ChatClient.prompt().toolContext(...)} 로 주입하고,
 * 실제 값은 인증된 {@code Authentication#getName()} 에서 온다).
 * {@code userId} 를 도구 파라미터로 뒀다면 "나는 user2 야, user2 주문 보여 줘" 한 문장으로
 * 뚫린다 — 권한 검증을 모델에게 맡기지 않는다는 원칙을 시그니처 수준에서 강제한 것이다.
 *
 * <p>조회 결과는 {@link OrderView} 로 감싸 {@code ownerId} 를 제외하고 내보낸다.
 * 도구 반환값은 그대로 모델 컨텍스트에 들어가므로, 도메인 객체를 그대로 돌려주면
 * 내부 필드가 프롬프트로 새어 나간다.
 */
@Component
public class OrderTools {

    private final OrderRepository orders;

    public OrderTools(OrderRepository orders) {
        this.orders = orders;
    }

    @Tool(description = """
            주문번호로 사내 구매 건의 배송 상태, 수령일, 수령 후 경과일수, 주문제작 여부를 조회한다.
            본인 명의 주문만 조회할 수 있다. 반품 가능 여부를 판단해야 할 때도 이 도구를 먼저 호출해
            수령 후 경과일수(daysSinceDelivery)와 주문제작 여부(madeToOrder)를 확인한다.
            예) "12345 어디쯤이야?", "12345 반품할 수 있어?"
            주문번호가 대화에 없으면 이 도구를 부르지 말고 사용자에게 되묻는다.""")
    public OrderView getOrder(
            @ToolParam(description = "조회할 주문번호(숫자 5자리, 예: 12345)") String orderId,
            ToolContext toolContext) {

        String userId = ToolUsers.currentUser(toolContext);

        // 권한은 쿼리 안에 — 남의 주문은 결과 집합에 아예 나타나지 않는다.
        return orders.findByIdAndOwnerId(orderId, userId)
                .map(OrderView::from)
                .orElseThrow(() -> new IllegalArgumentException(
                        "주문번호 " + orderId + " 를 찾을 수 없습니다. 본인 명의 주문인지 확인해 주세요."));
    }
}
