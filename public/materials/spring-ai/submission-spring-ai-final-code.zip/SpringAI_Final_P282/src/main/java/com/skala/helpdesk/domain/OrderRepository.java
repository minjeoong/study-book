package com.skala.helpdesk.domain;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Repository;

/**
 * 주문 저장소 — 데모용 인메모리 구현.
 *
 * <p>{@link #findByIdAndOwnerId} 하나가 이 프로젝트 보안 설계의 핵심이다. 주문번호만으로
 * 찾지 않고 소유자 조건을 <b>쿼리 안에 함께</b> 건다 — "조회는 됐는데 권한이 없어서 막았다"가
 * 아니라 애초에 남의 주문은 결과 집합에 존재하지 않는다. 그래서 "없음"과 "권한 없음"을
 * 구분해 알려 줄 수 없고(그 구분 자체가 주문 존재 여부를 흘리는 정보 노출이다),
 * 두 경우 모두 같은 메시지로 응답한다.
 *
 * <p>수령일은 고정 날짜가 아니라 오늘 기준 상대일로 만든다. 실습을 언제 재현하더라도
 * "수령 후 3일(반품 가능) / 20일(기간 초과)" 시나리오가 항상 성립해야 하기 때문이다.
 */
@Repository
public class OrderRepository {

    private final Map<String, Order> orders = new LinkedHashMap<>();

    public OrderRepository() {
        LocalDate today = LocalDate.now();

        // 수령 후 3일 — 단순 변심 7일 이내라 반품 가능해야 한다.
        put(new Order("12345", "user1", "무선 헤드셋(사내 비품)", "배송완료",
                today.minusDays(6), today.minusDays(3), today.minusDays(3), false));

        // 수령 후 20일 — 단순 변심 7일을 넘겨 반품 불가로 판단되어야 한다.
        put(new Order("12346", "user1", "USB-C 도킹 허브", "배송완료",
                today.minusDays(24), today.minusDays(20), today.minusDays(20), false));

        // 주문제작 — 기간과 무관하게 단순 변심 반품 불가 사유에 해당한다.
        put(new Order("12347", "user1", "사번 각인 명함지갑(주문제작)", "배송완료",
                today.minusDays(5), today.minusDays(2), today.minusDays(2), true));

        // 다른 사용자 소유 — 권한 검증(교차 조회 차단) 확인용.
        put(new Order("99999", "user2", "모니터암", "배송중",
                today.minusDays(1), null, today.plusDays(2), false));
    }

    private void put(Order order) {
        orders.put(order.id(), order);
    }

    /** 권한은 쿼리 안에 — orderId 뿐 아니라 ownerId 까지 같이 걸어야 남의 주문이 새지 않는다. */
    public Optional<Order> findByIdAndOwnerId(String orderId, String ownerId) {
        return Optional.ofNullable(orders.get(orderId))
                .filter(o -> o.ownerId().equals(ownerId));
    }
}
