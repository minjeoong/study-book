package com.skala.helpdesk.advisor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ai.chat.client.ChatClientRequest;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.api.AdvisorChain;
import org.springframework.ai.chat.client.advisor.api.BaseAdvisor;
import org.springframework.ai.chat.client.advisor.vectorstore.QuestionAnswerAdvisor;
import org.springframework.ai.document.Document;
import org.springframework.stereotype.Component;

/**
 * Observability — RAG 근거 검색 추적 로그.
 *
 * <p>{@link QuestionAnswerAdvisor}(order 300) 바로 안쪽(order 310)에 붙어, 그 순간 컨텍스트에
 * 쌓인 검색 결과 개수 · 유사도 점수 · 출처를 traceId 와 함께 남긴다.
 * "검색 3건(0.42/0.38/0.31) → 도구 호출 → 응답" 형태의 end-to-end 로그가 만들어진다.
 *
 * <p>근거가 0건이면 그 사실 자체도 남긴다 — 나중에 "모른다고 답했어야 할 질문에
 * 지어내지 않았는지"를 로그만으로 검증할 수 있어야 하기 때문이다.
 */
@Component
public class RagTraceAdvisor implements BaseAdvisor {

    private static final Logger log = LoggerFactory.getLogger(RagTraceAdvisor.class);

    @Override
    public ChatClientRequest before(ChatClientRequest request, AdvisorChain chain) {
        Object raw = request.context().get(QuestionAnswerAdvisor.RETRIEVED_DOCUMENTS);
        if (raw instanceof List<?> docs && !docs.isEmpty()) {
            String detail = docs.stream()
                    .filter(Document.class::isInstance)
                    .map(Document.class::cast)
                    .map(d -> "%s(%s)".formatted(
                            d.getMetadata().get("source"),
                            d.getScore() == null ? "?" : "%.2f".formatted(d.getScore())))
                    .reduce((a, b) -> a + " / " + b)
                    .orElse("?");
            log.info("[RAG] traceId={} 검색 {}건 → {}", MDC.get("traceId"), docs.size(), detail);
        } else {
            log.info("[RAG] traceId={} 근거 문서 없음 — 모델은 모른다고 답해야 한다", MDC.get("traceId"));
        }
        return request;
    }

    @Override
    public ChatClientResponse after(ChatClientResponse response, AdvisorChain chain) {
        return response;
    }

    @Override
    public String getName() {
        return "ragTrace";
    }

    @Override
    public int getOrder() {
        return 310;
    }
}
