package com.skala.helpdesk.web;

import java.util.List;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.skala.helpdesk.service.HelpDeskService;
import com.skala.helpdesk.web.dto.ChatAnswer;
import com.skala.helpdesk.web.dto.ChatRequest;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import reactor.core.publisher.Flux;

/**
 * HelpDesk Agent 진입점 (Phase 3 · 4 · 5 · 6).
 *
 * <p>컨트롤러의 역할은 하나다 — <b>인증된 사용자 ID 를 확보해 서비스로 넘기는 것</b>.
 * RAG · 메모리 · 안전 필터 · 계측은 전부 Advisor 체인에 들어 있어 여기에는 한 줄도 없다.
 * 관심사가 이렇게 분리되어 있으면 "RAG 를 끄고 싶다"는 요구가 왔을 때 컨트롤러를
 * 건드리지 않고 조립부만 바꾸면 된다.
 *
 * <p>사용자 ID 는 요청 파라미터가 아니라 {@link Authentication#getName()} 에서만 얻는다.
 * Swagger 로 시험할 때는 우측 상단 Authorize 로 먼저 로그인한다.
 */
@RestController
@RequestMapping("/helpdesk")
@Tag(name = "1. HelpDesk Agent", description = "사내 규정 질의 · 업무 데이터 조회 · 업무 요청 접수")
public class ChatController {

    private final HelpDeskService helpDesk;

    public ChatController(HelpDeskService helpDesk) {
        this.helpDesk = helpDesk;
    }

    @PostMapping("/chat")
    @Operation(summary = "HelpDesk Agent 에게 요청한다 (구조화 응답)",
            description = """
                    규정 질의는 RAG 가, 주문 조회·환불 접수는 Tool 이 처리합니다.
                    응답에는 답변 문장과 함께 실제 검색된 출처, 실행된 도구, 추적 ID, 토큰·지연이 함께 내려갑니다.
                    userId 는 요청 본문이 아니라 로그인 계정에서 옵니다.""")
    public ChatAnswer chat(@Valid @RequestBody ChatRequest request, Authentication authentication) {
        return helpDesk.ask(authentication.getName(), request);
    }

    @PostMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @Operation(summary = "토큰이 생성되는 대로 흘려 보낸다 (SSE)",
            description = """
                    event 이름으로 token 과 done 을 구분합니다.
                    curl 로 확인할 때는 -N 옵션을 반드시 붙여야 버퍼링 없이 스트리밍이 보입니다.""")
    public Flux<ServerSentEvent<String>> stream(@Valid @RequestBody ChatRequest request,
                                                Authentication authentication) {
        return helpDesk.stream(authentication.getName(), request);
    }

    @GetMapping("/chat/history")
    @Operation(summary = "대화 이력 조회",
            description = "Advisor 순서 검증용 — 차단됐어야 할 문장이 메모리에 남아 있는지 확인합니다.")
    public List<Map<String, String>> history(@RequestParam(defaultValue = "default") String sessionId,
                                             Authentication authentication) {
        return helpDesk.history(authentication.getName(), sessionId);
    }
}
