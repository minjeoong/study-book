package com.skala.helpdesk.tool;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import com.skala.helpdesk.audit.AuditLogService;
import com.skala.helpdesk.domain.OrderRepository;
import com.skala.helpdesk.domain.TicketRepository;
import com.skala.helpdesk.domain.TicketView;

/**
 * Phase 4 — 업무 요청(교환·환불) 접수 도구 + 승인 게이트.
 *
 * <p><b>자율성의 크기는 되돌릴 수 있는 정도에 맞춘다.</b> 조회는 도구가 자유롭게 하지만,
 * 환불처럼 되돌리기 어려운 쓰기 작업은 도구가 <b>접수만</b> 하고 상태를 {@code PENDING} 으로
 * 남긴다. 실제 승인·처리는 {@code POST /helpdesk/admin/tickets/{no}/approve}(사람 전용,
 * ROLE_ADMIN)로만 가능하며, 이 경로는 모델에게 도구로 등록되지 않으므로 모델은 승인 자체를
 * 실행할 수 없다 — Human-in-the-loop 를 문서가 아니라 구조로 강제한 것이다.
 *
 * <p><b>추가 구현 ② — 중복 접수 방지.</b> 접수 키를
 * {@code sha256(userId + orderId + 정규화한 사유)} 로 만든다. 사용자 ID 를 키에 넣기 때문에
 * 다른 사람의 접수와 절대 충돌하지 않고, 사유를 공백 제거·소문자화해 정규화하기 때문에
 * "단순 변심" 과 "단순변심" 이 별개 티켓으로 갈라지지 않는다.
 */
@Component
public class TicketTools {

    private final OrderRepository orders;
    private final TicketRepository tickets;
    private final AuditLogService audit;

    public TicketTools(OrderRepository orders, TicketRepository tickets, AuditLogService audit) {
        this.orders = orders;
        this.tickets = tickets;
        this.audit = audit;
    }

    @Tool(description = """
            교환·환불을 접수한다. 실제 환불 처리가 아니라 접수만 하며, 담당자 승인 후 처리된다.
            사용자가 명시적으로 환불·반품·교환을 요청했을 때만 부른다.
            주문번호와 사유가 모두 있어야 하고, 둘 중 하나라도 없으면 도구를 부르지 말고 되묻는다.
            "반품 가능한지"만 물어본 경우에는 부르지 않는다.""")
    public TicketView requestRefund(
            @ToolParam(description = "환불·교환 대상 주문번호(숫자 5자리)") String orderId,
            @ToolParam(description = "요청 사유(사용자가 말한 그대로, 예: 단순 변심)") String reason,
            ToolContext toolContext) {

        String userId = ToolUsers.currentUser(toolContext);

        // 권한 먼저 — 남의 주문은 접수 자체가 안 된다.
        orders.findByIdAndOwnerId(orderId, userId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "주문번호 " + orderId + " 를 찾을 수 없습니다. 본인 명의 주문인지 확인해 주세요."));

        String key = idempotencyKey(userId, orderId, reason);
        TicketRepository.CreateResult result = tickets.createIdempotent(key, orderId, userId, reason);

        audit.log(result.duplicate() ? "REFUND_REQUEST_DEDUPLICATED" : "REFUND_REQUESTED",
                userId, orderId, result.ticket().no());

        String message = result.duplicate()
                ? "이미 동일한 내용으로 접수된 건이 있어 기존 접수번호를 그대로 안내합니다. 중복 접수되지 않았습니다."
                : "접수되었습니다. 담당자 승인 후 처리됩니다.";

        return new TicketView(result.ticket().no(), result.ticket().status().name(),
                result.duplicate(), message);
    }

    @Tool(description = "접수번호로 교환·환불 요청의 처리 상태를 조회한다. 접수 시 안내받은 번호(RF-로 시작)가 필요하다.")
    public TicketView refundStatus(
            @ToolParam(description = "접수번호(예: RF-1001)") String ticketNo,
            ToolContext toolContext) {

        String userId = ToolUsers.currentUser(toolContext);

        return tickets.findByNo(ticketNo)
                // 본인 접수 건만 — 접수번호가 순번이라 추측이 쉬우므로 소유자 확인이 반드시 필요하다.
                .filter(t -> t.userId().equals(userId))
                .map(t -> new TicketView(t.no(), t.status().name(), false, "현재 상태: " + t.status()))
                .orElseThrow(() -> new IllegalArgumentException(
                        "접수번호 " + ticketNo + " 를 찾을 수 없습니다."));
    }

    /**
     * 같은 사람이 같은 주문에 같은 사유로 요청하면 항상 같은 키가 나온다.
     * 사유는 공백 제거·소문자화로 정규화해 표기 흔들림을 흡수한다.
     */
    private String idempotencyKey(String userId, String orderId, String reason) {
        String normalized = reason == null ? "" : reason.replaceAll("\\s+", "").toLowerCase();
        String raw = userId + "|" + orderId + "|" + normalized;
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest).substring(0, 32);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 을 사용할 수 없습니다.", e);
        }
    }
}
