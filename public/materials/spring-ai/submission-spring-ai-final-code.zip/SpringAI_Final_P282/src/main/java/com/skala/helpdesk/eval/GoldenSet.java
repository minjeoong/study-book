package com.skala.helpdesk.eval;

import java.util.List;

/**
 * Evaluation — 골든 세트.
 *
 * <p>"좋아진 것 같다"는 느낌으로는 튜닝을 판단할 수 없다. 청크 크기나 유사도 임계값을
 * 바꿀 때마다 <b>같은 질문 묶음</b>을 돌려 통과율을 비교해야 개선인지 퇴행인지 알 수 있다.
 *
 * <p>판정 기준을 셋으로 나눴다.
 * <ul>
 *   <li>{@code expectedKeywords} — 답변에 반드시 들어가야 하는 핵심 사실(숫자·판단). 모두 만족해야 통과.</li>
 *   <li>{@code expectedSource} — 근거로 검색됐어야 하는 문서. 정답 문장이 우연히 맞은 것과
 *       근거를 제대로 찾아 답한 것을 구분한다.</li>
 *   <li>{@code expectedTool} — 실제로 실행됐어야 하는 도구. "행동 요청인데 말로만 답하는" 실패를 잡는다.</li>
 * </ul>
 *
 * <p>LLM 은 같은 뜻을 매번 다른 표현으로 말한다("반품 불가" · "반품이 어렵습니다" ·
 * "반품하실 수 없습니다"). 그래서 키워드 하나를 문자 그대로 요구하지 않고
 * <b>{@code "불가|어렵|불가능"} 처럼 동의 표현 묶음</b>으로 적어, 그중 하나만 나오면
 * 그 항목을 만족한 것으로 본다. 지나치게 엄격한 채점은 정상 답변을 실패로 만들어
 * 지표 자체를 못 쓰게 하고, 지나치게 느슨한 채점은 오답을 놓친다 — 그 사이를 맞추는 일이
 * 평가 설계의 본질임을 이 과정에서 확인했다.
 */
public final class GoldenSet {

    private GoldenSet() {
    }

    /**
     * @param expectedKeywords 각 원소는 {@code "가능|가능합니다"} 처럼 동의 표현을 {@code |} 로 묶은
     *                         그룹이다. 그룹마다 하나 이상 포함되어야 통과한다.
     */
    public record Case(String id,
                       String question,
                       String intent,
                       List<String> expectedKeywords,
                       String expectedSource,
                       String expectedTool) {
    }

    public static List<Case> cases() {
        return List.of(
                new Case("G1",
                        "단순 변심으로 반품하려면 며칠 이내에 해야 하나요?",
                        "규정 질의(RAG)",
                        List.of("7일"),
                        "return-policy.md",
                        null),

                new Case("G2",
                        "제주도로 배송하면 배송비가 얼마인가요?",
                        "규정 질의(RAG)",
                        List.of("3,000"),
                        "delivery-policy.md",
                        null),

                new Case("G3",
                        "주문 12345 배송 상태 알려주세요.",
                        "업무 데이터 조회(Tool)",
                        List.of("배송완료"),
                        null,
                        "getOrder"),

                new Case("G4",
                        "주문 12345 반품할 수 있어?",
                        "복합 질의(Tool+RAG)",
                        List.of("가능", "7일"),
                        "return-policy.md",
                        "getOrder"),

                new Case("G5",
                        "주문 12346 반품할 수 있어?",
                        "복합 질의(Tool+RAG)",
                        List.of("어렵|불가|없습니다|초과|지났", "7일"),
                        "return-policy.md",
                        "getOrder"),

                // 1차 실행에서 이 케이스가 FAIL 로 나왔으나, 실제 답변은
                // "제공된 자료에 포함되어 있지 않습니다" 로 <b>정확했다</b>. 원인은 모델이 아니라
                // "없" 만 인정하던 채점 기준이었다 — 부정 표현의 "않" 을 누락한 것이다.
                // 평가 기준의 오류를 실패로 착각하면 멀쩡한 동작을 고치러 가게 되므로,
                // 실패를 본 뒤에는 항상 답변 원문을 먼저 확인해야 함을 확인했다.
                new Case("G6",
                        "사내 헬스장 운영 시간이 어떻게 되나요?",
                        "문서 밖 질문(할루시네이션 방지)",
                        List.of("없|않|어렵|모르|문의"),
                        null,
                        null));
    }
}
