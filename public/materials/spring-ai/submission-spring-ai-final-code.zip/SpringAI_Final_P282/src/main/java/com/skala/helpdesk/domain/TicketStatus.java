package com.skala.helpdesk.domain;

/** 업무 요청 티켓 상태. 모델(도구)이 만들 수 있는 상태는 오직 {@link #PENDING} 뿐이다. */
public enum TicketStatus {
    /** 접수됨 — 도구가 만들 수 있는 유일한 상태. */
    PENDING,
    /** 관리자가 승인함 — 사람만 만들 수 있다. */
    APPROVED,
    /** 관리자가 반려함 — 사람만 만들 수 있다. */
    REJECTED
}
