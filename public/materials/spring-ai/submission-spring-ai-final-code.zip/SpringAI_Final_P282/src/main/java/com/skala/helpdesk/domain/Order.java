package com.skala.helpdesk.domain;

import java.time.LocalDate;

/**
 * 사내 구매/주문 한 건.
 *
 * <p>{@code ownerId} 가 권한 검증의 유일한 기준이다 — 절대 밖으로 노출하지 않는다.
 * {@code deliveredAt} 과 {@code madeToOrder} 는 복합 질의(추가 구현 ①)에서
 * 모델이 반품 규정의 "수령 후 7일 이내" · "주문제작 반품 불가" 조건을 실제 데이터에
 * 적용할 수 있도록 함께 내려 주는 값이다.
 */
public record Order(String id,
                    String ownerId,
                    String item,
                    String status,
                    LocalDate orderedAt,
                    LocalDate deliveredAt,
                    LocalDate eta,
                    boolean madeToOrder) {
}
