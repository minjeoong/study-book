package com.skala.helpdesk.web;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skala.helpdesk.advisor.TokenMeterAdvisor;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.search.Search;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Observability — 운영 지표 한 화면.
 *
 * <p>{@code /actuator/metrics/...} 는 지표마다 따로 열어 봐야 해서 "지금 이 서비스가
 * 얼마나 쓰였고 얼마나 들었는지"를 한눈에 보기 어렵다. 운영자가 실제로 궁금해하는 값
 * (호출 수 · 토큰 · 예상 비용 · 평균 지연 · 도구 성공/실패 · 폴백 횟수)만 모아 한 번에 준다.
 *
 * <p>Prometheus 연동은 {@code /actuator/prometheus} 로 그대로 살아 있다 —
 * 이 화면은 그것을 대체하는 것이 아니라 실습·데모에서 눈으로 확인하기 위한 요약이다.
 */
@RestController
@RequestMapping("/helpdesk/metrics")
@Tag(name = "3. 관측성 (Observability)", description = "토큰 · 비용 · 지연 · 도구 호출 · 폴백 요약")
public class MetricsController {

    private final TokenMeterAdvisor tokenMeter;
    private final MeterRegistry registry;

    public MetricsController(TokenMeterAdvisor tokenMeter, MeterRegistry registry) {
        this.tokenMeter = tokenMeter;
        this.registry = registry;
    }

    @GetMapping
    @Operation(summary = "토큰 · 비용 · 지연 · 도구 호출 요약")
    public Map<String, Object> summary() {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("modelCalls", tokenMeter.calls());
        out.put("promptTokens", tokenMeter.promptTokens());
        out.put("completionTokens", tokenMeter.completionTokens());
        out.put("totalTokens", tokenMeter.promptTokens() + tokenMeter.completionTokens());
        out.put("estimatedCostUsd", "%.6f".formatted(tokenMeter.estimatedCostUsd()));
        out.put("avgLatencyMs", tokenMeter.averageLatencyMs());
        out.put("toolCallsOk", counter("ai.tool.calls", "result", "ok"));
        out.put("toolCallsFail", counter("ai.tool.calls", "result", "fail"));
        out.put("fallbackCount", counterByName("ai.fallback"));
        return out;
    }

    private double counter(String name, String tagKey, String tagValue) {
        return Search.in(registry).name(name).tag(tagKey, tagValue).counters()
                .stream().mapToDouble(io.micrometer.core.instrument.Counter::count).sum();
    }

    private double counterByName(String name) {
        return Search.in(registry).name(name).counters()
                .stream().mapToDouble(io.micrometer.core.instrument.Counter::count).sum();
    }
}
