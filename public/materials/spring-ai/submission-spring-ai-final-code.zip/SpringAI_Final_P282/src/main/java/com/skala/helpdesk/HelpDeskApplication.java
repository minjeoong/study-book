package com.skala.helpdesk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * SKALA 종합 실습 — SK 사내 AI Workforce HelpDesk Agent.
 *
 * <p>사내 구성원이 자연어로 던진 요청 하나를 "규정 검색(RAG) → 업무 데이터 조회(Tool) →
 * 업무 요청 접수(Tool) → 관리자 승인(Human-in-the-loop)"까지 한 흐름으로 처리한다.
 *
 * <p>{@code ./gradlew bootRun} 으로 띄운 뒤 {@code /swagger-ui.html} 또는
 * {@code /console.html} 에서 확인한다. 기동 시 {@code docs/*.md} 사내 규정 문서를
 * 자동으로 인제스트하므로 별도 준비 없이 바로 질문할 수 있다.
 */
@SpringBootApplication
public class HelpDeskApplication {

    public static void main(String[] args) {
        SpringApplication.run(HelpDeskApplication.class, args);
    }
}
