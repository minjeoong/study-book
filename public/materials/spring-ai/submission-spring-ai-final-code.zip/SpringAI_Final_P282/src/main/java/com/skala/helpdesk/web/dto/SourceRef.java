package com.skala.helpdesk.web.dto;

/**
 * Phase 3 — 출처 한 건.
 *
 * <p>모델이 답변 문장 안에 적어 준 인용이 아니라, {@code QuestionAnswerAdvisor} 가
 * <b>실제로 검색해 컨텍스트에 남긴 문서</b>에서 뽑는다. 모델의 서술을 믿으면
 * 근거 없이 "[출처: 반품규정]" 이라고 써 놓은 답변도 출처가 있는 것처럼 보인다.
 * 검색 결과 자체를 근거로 삼아야 "출처가 붙는다"는 요구사항이 흔들리지 않는다.
 *
 * <p>유사도 점수({@code score})와 인용 구간({@code snippet})까지 함께 내려 주므로,
 * 사용자는 "이 답이 어느 문장에서 나왔는지"를 눈으로 확인할 수 있다.
 */
public record SourceRef(String source, Double score, String snippet) {
}
