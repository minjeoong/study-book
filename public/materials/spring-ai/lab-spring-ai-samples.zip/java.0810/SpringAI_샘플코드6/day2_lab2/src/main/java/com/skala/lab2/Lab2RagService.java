package com.skala.lab2;

import java.time.Duration;
import java.util.List;

import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;

/**
 * Step 2(검색) · Step 3(근거 답변) · 관측성(확장 과제).
 *
 * <p>답변을 만들기 전에 검색부터 눈으로 본다 — {@link #retrieve} 가 그 용도다.
 * {@link #ask} 는 검색 결과가 비어 있으면 모델을 아예 부르지 않고,
 * 결과가 있으면 [근거] 블록만으로 답하게 하고 구조화 출력으로 근거 사용 여부를 받는다.
 */
@Service
public class Lab2RagService {

    private static final Logger log = LoggerFactory.getLogger(Lab2RagService.class);

    private static final String SYSTEM_PROMPT = """
            아래 [근거]만 사용해 답한다. 질문에 대한 답이 [근거] 안에 없으면
            "확인되지 않습니다"라고만 답하고 sources 는 빈 배열, grounded 는 false 로 한다.
            추측하거나 일반 상식으로 채우지 않는다 — 근거에 실제로 등장한 사실만 사용한다.
            sources 필드에는 각 [근거 N] 옆 괄호의 "출처: " 뒤에 오는 식별자만 담는다
            (예: "return-policy"). "출처:"라는 접두어나 대괄호는 붙이지 않는다.
            """;

    private final ChatClient chat;
    private final VectorStore vectorStore;
    private final Lab2Properties props;
    private final MeterRegistry meterRegistry;

    public Lab2RagService(ChatClient lab2ChatClient, VectorStore vectorStore,
                           Lab2Properties props, MeterRegistry meterRegistry) {
        this.chat = lab2ChatClient;
        this.vectorStore = vectorStore;
        this.props = props;
        this.meterRegistry = meterRegistry;
    }

    /** 확장 과제 — 검색/생성 구간별 소요시간을 함께 반환한다({@code /lab2/ask} 응답 헤더로 노출). */
    public record AskOutcome(AnswerDto answer, long retrieveMs, long generateMs) {
        public long totalMs() {
            return retrieveMs + generateMs;
        }
    }

    /** {@code GET /lab2/retrieve} — 답변을 만들기 전에 이것부터 만든다. 점수를 반드시 노출한다. */
    public List<Chunk> retrieve(String question, int topK) {
        return retrieveDocuments(question, topK).stream()
                .map(d -> new Chunk(
                        String.valueOf(d.getMetadata().get("source")),
                        d.getScore(),
                        snippet(d.getText(), 120)))
                .toList();
    }

    List<Document> retrieveDocuments(String question, int topK) {
        List<Document> hits = vectorStore.similaritySearch(SearchRequest.builder()
                .query(question)
                .topK(topK)
                .similarityThreshold(props.similarityThreshold()) // 낮은 점수는 근거가 아니다
                .build());
        return hits == null ? List.of() : hits;
    }

    /** {@code POST /lab2/ask} 가 부르는 진입점 — 골든 세트 테스트도 이 메서드를 직접 호출한다. */
    public AnswerDto ask(String question) {
        return askWithTiming(question).answer();
    }

    public AskOutcome askWithTiming(String question) {
        long retrieveStart = System.nanoTime();
        List<Document> docs = retrieveDocuments(question, props.topK());
        long retrieveMs = Duration.ofNanos(System.nanoTime() - retrieveStart).toMillis();

        if (docs.isEmpty()) {
            recordMetrics(retrieveMs, 0, false);
            return new AskOutcome(AnswerDto.unknown(), retrieveMs, 0); // 근거가 없으면 모델을 부르지 않는다
        }

        long generateStart = System.nanoTime();
        AnswerDto answer = chat.prompt()
                .system(SYSTEM_PROMPT)
                .user(u -> u.text("[근거]\n{context}\n\n[질문] {question}")
                        .param("context", formatContext(docs))
                        .param("question", question))
                .call()
                .entity(AnswerDto.class); // 구조화 출력 — 문자열 파싱 금지
        long generateMs = Duration.ofNanos(System.nanoTime() - generateStart).toMillis();

        long totalMs = retrieveMs + generateMs;
        if (totalMs > 5000) {
            log.warn("응답 지연 감지 question='{}' retrieveMs={} generateMs={}", question, retrieveMs, generateMs);
        }
        recordMetrics(retrieveMs, generateMs, answer.grounded());
        return new AskOutcome(answer, retrieveMs, generateMs);
    }

    private void recordMetrics(long retrieveMs, long generateMs, boolean grounded) {
        meterRegistry.timer("lab2.ask.retrieve").record(Duration.ofMillis(retrieveMs));
        meterRegistry.timer("lab2.ask.generate").record(Duration.ofMillis(generateMs));
        meterRegistry.counter("lab2.ask.grounded", "grounded", String.valueOf(grounded)).increment();
    }

    /** 모델에게 출처를 명시적으로 보여준다 — 인용을 "지어내지" 않고 그대로 베끼게 하기 위해서다. */
    private static String formatContext(List<Document> docs) {
        StringBuilder sb = new StringBuilder();
        int i = 1;
        for (Document d : docs) {
            sb.append("[근거 ").append(i++).append("] (출처: ")
                    .append(d.getMetadata().get("source")).append(")\n")
                    .append(d.getText()).append("\n\n");
        }
        return sb.toString();
    }

    private static String snippet(String text, int maxLen) {
        if (text == null) {
            return "";
        }
        String s = text.strip().replaceAll("\\s+", " ");
        return s.length() <= maxLen ? s : s.substring(0, maxLen) + "…";
    }
}
