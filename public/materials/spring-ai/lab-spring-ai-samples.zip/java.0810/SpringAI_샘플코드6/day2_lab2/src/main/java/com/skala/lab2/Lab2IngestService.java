package com.skala.lab2;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.transformer.splitter.TextSplitter;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Service;

/**
 * Step 1 인제스트 — 읽기 → 분할 → 메타데이터 보강 → 저장.
 *
 * <p>출처(source)·버전(version)은 <b>이 시점에만</b> 넣을 수 있다. 나중에 검색·답변
 * 단계에서는 이미 저장된 메타데이터를 읽기만 할 뿐 새로 채울 수 없다.
 *
 * <p>재인제스트로 중복이 쌓이지 않도록, 같은 출처의 기존 청크를 지운 뒤 다시 넣는다
 * (delete-then-add). 그래서 {@code /lab2/ingest} 를 몇 번을 호출해도 청크 수가 같다.
 */
@Service
public class Lab2IngestService {

    private static final Logger log = LoggerFactory.getLogger(Lab2IngestService.class);

    private final VectorStore vectorStore;
    private final Lab2Properties props;

    public Lab2IngestService(VectorStore vectorStore, Lab2Properties props) {
        this.vectorStore = vectorStore;
        this.props = props;
    }

    public record IngestResult(String source, int chunks) {
    }

    /** classpath:/docs/*.md 를 모두 인제스트한다 — {@code POST /lab2/ingest} 가 부르는 진입점. */
    public List<IngestResult> ingestSampleDocs() {
        try {
            Resource[] docs = new PathMatchingResourcePatternResolver()
                    .getResources("classpath:/docs/*.md");
            return Arrays.stream(docs)
                    .map(doc -> ingest(doc, sourceOf(doc), props.docVersion()))
                    .toList();
        } catch (IOException e) {
            throw new IllegalStateException("샘플 문서 로딩 실패", e);
        }
    }

    /**
     * 문서 한 건을 인제스트한다.
     *
     * @param file    읽어 들일 문서(Tika 가 PDF·DOCX·HTML·MD 를 모두 처리한다)
     * @param source  출처 식별자(재인제스트 시 이 값 기준으로 기존 청크를 지운다)
     * @param version 문서 버전 태그
     */
    public IngestResult ingest(Resource file, String source, String version) {
        deleteExisting(source);

        // ① Read
        List<Document> raw = new TikaDocumentReader(file).get();

        // ② Split — 청크 크기·겹침은 실험표(Step 5)의 대상. application.yml 의 lab2.* 로 조정한다.
        List<Document> chunks = buildSplitter().apply(raw);

        // ③ Enrich — 인제스트 때 안 넣은 메타데이터는 나중에 넣을 수 없다
        List<Document> enriched = chunks.stream()
                .map(chunk -> {
                    Map<String, Object> meta = new HashMap<>(chunk.getMetadata());
                    meta.put("source", source);
                    meta.put("version", version);
                    return new Document(chunk.getText(), meta);
                })
                .toList();

        // ④ Store — 임베딩 + 저장
        vectorStore.add(enriched);
        log.info("인제스트 완료 source={} chunks={}", source, enriched.size());

        return new IngestResult(source, enriched.size());
    }

    /**
     * 조합 F(겹침 20%) 실험용 — {@code chunkOverlapRatio} 가 0 이면 기존
     * {@code TokenTextSplitter}(겹침 없음)를 그대로 쓰고, 0보다 크면 겹침을 지원하는
     * {@link OverlappingTokenTextSplitter} 로 전환한다. 기준 조합(A)의 동작은 그대로 유지된다.
     */
    private TextSplitter buildSplitter() {
        if (props.chunkOverlapRatio() > 0) {
            return new OverlappingTokenTextSplitter(props.chunkSize(), props.chunkOverlapRatio());
        }
        return TokenTextSplitter.builder()
                .withChunkSize(props.chunkSize())
                .withMinChunkSizeChars(props.minChunkSizeChars())
                .withKeepSeparator(true)
                .build();
    }

    /** 재색인 대비 — 같은 출처의 기존 청크를 모두 지운다(중복 적재 방지). */
    private void deleteExisting(String source) {
        try {
            vectorStore.delete("source == '" + source + "'");
        } catch (Exception e) {
            // 인메모리 스토어 등 필터 삭제를 지원하지 않는 구현도 있다
            log.debug("기존 청크 삭제를 건너뛴다: {}", e.getMessage());
        }
    }

    private static String sourceOf(Resource doc) {
        String filename = doc.getFilename();
        if (filename == null) {
            return "unknown";
        }
        int dot = filename.lastIndexOf('.');
        return dot > 0 ? filename.substring(0, dot) : filename;
    }
}
