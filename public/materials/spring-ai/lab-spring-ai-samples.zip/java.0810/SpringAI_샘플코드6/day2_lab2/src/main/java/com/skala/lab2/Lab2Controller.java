package com.skala.lab2;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Day 2 실습 — 사내 문서 Q&A.
 *
 * <p>순서를 지킨다: 인제스트 → 검색(눈으로 확인) → 답변. 답이 이상하면
 * {@code /lab2/retrieve} 부터 본다 — 근거 자체가 없는지, 근거는 있는데 못 쓰는지가 갈린다.
 */
@RestController
@RequestMapping("/lab2")
public class Lab2Controller {

    private final Lab2IngestService ingest;
    private final Lab2RagService rag;
    private final Lab2Properties props;

    public Lab2Controller(Lab2IngestService ingest, Lab2RagService rag, Lab2Properties props) {
        this.ingest = ingest;
        this.rag = rag;
        this.props = props;
    }

    /**
     * classpath:/docs/*.md 를 인제스트한다. 몇 번을 호출해도 청크 수가 같다(재색인 시 삭제 후 삽입).
     * curl -X POST localhost:8080/lab2/ingest
     */
    @PostMapping("/ingest")
    public List<Lab2IngestService.IngestResult> ingest() {
        return ingest.ingestSampleDocs();
    }

    /**
     * 답변을 만들기 전에 이것부터 만든다 — 점수를 반드시 노출한다.
     * curl 'localhost:8080/lab2/retrieve?q=제주도는 배송비가 더 드나요?'
     */
    @GetMapping("/retrieve")
    public List<Chunk> retrieve(@RequestParam String q,
                                 @RequestParam(required = false) Integer topK) {
        return rag.retrieve(q, topK != null ? topK : props.topK());
    }

    /**
     * 근거 기반 답변 — 구조화 출력(answer·sources·grounded). 근거가 없으면 모델을 부르지 않는다.
     * curl -X POST 'localhost:8080/lab2/ask?question=단순 변심 반품은 며칠 이내인가요?'
     */
    @PostMapping("/ask")
    public ResponseEntity<AnswerDto> ask(@RequestParam String question) {
        Lab2RagService.AskOutcome outcome = rag.askWithTiming(question);
        return ResponseEntity.ok()
                .header("X-Retrieve-Ms", String.valueOf(outcome.retrieveMs()))
                .header("X-Generate-Ms", String.valueOf(outcome.generateMs()))
                .header("X-Total-Ms", String.valueOf(outcome.totalMs()))
                .body(outcome.answer());
    }
}
