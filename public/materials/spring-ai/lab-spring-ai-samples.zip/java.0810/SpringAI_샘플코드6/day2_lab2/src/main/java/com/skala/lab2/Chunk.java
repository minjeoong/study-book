package com.skala.lab2;

/**
 * 검색 결과 한 건 — 답변을 만들기 전에 눈으로 확인하기 위한 형태.
 *
 * @param source  이 청크가 나온 문서(출처)
 * @param score   유사도 점수 — 감이 아니라 숫자로 판단한다
 * @param snippet 청크 본문 일부(미리보기)
 */
public record Chunk(String source, Double score, String snippet) {
}
