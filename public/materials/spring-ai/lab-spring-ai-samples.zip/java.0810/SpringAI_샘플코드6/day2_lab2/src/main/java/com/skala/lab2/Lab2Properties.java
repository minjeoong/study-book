package com.skala.lab2;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Day 2 실습 — RAG 실험 파라미터를 코드가 아니라 설정으로 바꾼다.
 *
 * <p>Step 5(실험표)는 "한 번에 하나만 바꾼다"가 원칙이다. 청크 크기 · top-k ·
 * 임계값 · 겹침 비율을 여기 모아 두면 {@code application.yml} 이나
 * {@code --lab2.chunk-size=200} 커맨드라인 인자만으로 조합 A~F 를 재현할 수 있다.
 *
 * @param chunkSize            토큰 단위 청크 크기
 * @param minChunkSizeChars    이보다 작은 청크는 앞 청크에 합친다
 * @param chunkOverlapRatio    청크 간 겹침 비율(0.0~1.0). 0 이면 기존 TokenTextSplitter(겹침 없음)를
 *                             그대로 쓰고, 0보다 크면 겹침을 지원하는 스플리터로 전환한다
 *                             (Spring AI 의 TokenTextSplitter 자체는 겹침을 지원하지 않는다)
 * @param topK                 검색 시 가져올 청크 수
 * @param similarityThreshold  이 점수 미만은 근거로 보지 않는다
 * @param docVersion           인제스트 시 문서에 붙일 버전 태그
 */
@ConfigurationProperties(prefix = "lab2")
public record Lab2Properties(
        int chunkSize,
        int minChunkSizeChars,
        double chunkOverlapRatio,
        int topK,
        double similarityThreshold,
        String docVersion) {
}
