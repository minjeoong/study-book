package com.skala.lab2;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.InputStream;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Step 4 — 골든 세트로 측정한다.
 *
 * <p>느낌으로 고치면 고쳤는지 알 수 없다. 기준선(10문항 중 8문항 통과)을 코드에 박아 둔다.
 * 정답 목록은 {@code src/test/resources/golden.json} 에 외부화되어 있다 — 표현을 바꾼 질문
 * (paraphrase) 쌍이 섞여 있어 검색이 표현에 얼마나 흔들리는지도 함께 확인한다. 마지막 문항
 * (우주 배송)이 핵심이다 — 문서에 없는 것을 지어내지 않는지 본다.
 *
 * <p>실제 OpenAI 호출이 필요해 비용이 든다. {@code @Tag("eval")} 로 기본
 * {@code ./gradlew test} 에서는 제외되며, {@code ./gradlew test -Peval} 로 실행할 때만
 * 포함된다(build.gradle 참고). {@code -Peval} 로 실행했는데 {@code OPENAI_API_KEY} 가
 * 없으면 그때는 스킵한다.
 */
@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Tag("eval")
class Lab2GoldenSetTest {

    private static final Logger log = LoggerFactory.getLogger(Lab2GoldenSetTest.class);

    @Autowired
    private Lab2IngestService ingestService;

    @Autowired
    private Lab2RagService ragService;

    record Golden(String q, List<String> must, String src) {
    }

    private List<Golden> golden;

    @BeforeAll
    void 인제스트로_시작한다() throws Exception {
        Assumptions.assumeTrue(hasApiKey(), "OPENAI_API_KEY 가 없어 골든 세트를 스킵한다");
        golden = loadGolden();
        ingestService.ingestSampleDocs();
    }

    @Test
    void 골든_세트_10문항_중_8문항_이상_통과한다() {
        Assumptions.assumeTrue(hasApiKey(), "OPENAI_API_KEY 가 없어 골든 세트를 스킵한다");

        int pass = 0;
        for (Golden g : golden) {
            AnswerDto a = ragService.ask(g.q());

            boolean hit = g.must().stream().allMatch(k -> a.answer().contains(k));
            boolean cite = g.src() == null
                    || a.sources().stream().anyMatch(s -> s.contains(g.src()));

            if (hit && cite) {
                pass++;
            } else {
                // 실패를 두 종류로 나눠 적는다 — 고칠 곳이 완전히 다르다
                // ㉠ 근거를 못 찾았다 → 청킹 · 임베딩 · top-k · 질문 변환
                // ㉡ 찾고도 잘못 답했다 → 프롬프트 · 모델 · 근거 포맷
                log.warn("실패: {}\n 답변: {}\n 출처: {}", g.q(), a.answer(), a.sources());
            }
        }
        log.info("통과 {}/{}", pass, golden.size());
        assertThat(pass).isGreaterThanOrEqualTo(8);
    }

    /** {@code src/test/resources/golden.json} 을 읽어 온다 — 정답은 코드가 아니라 데이터다. */
    private static List<Golden> loadGolden() throws Exception {
        try (InputStream in = Lab2GoldenSetTest.class.getResourceAsStream("/golden.json")) {
            return new ObjectMapper().readValue(in, new TypeReference<List<Golden>>() {
            });
        }
    }

    private static boolean hasApiKey() {
        String key = System.getenv("OPENAI_API_KEY");
        return key != null && !key.isBlank() && !"not-set".equals(key);
    }
}
