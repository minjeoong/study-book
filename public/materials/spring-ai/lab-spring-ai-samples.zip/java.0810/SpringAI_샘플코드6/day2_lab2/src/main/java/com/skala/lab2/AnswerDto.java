package com.skala.lab2;

import java.util.List;

/**
 * 근거 기반 답변의 구조화 출력.
 *
 * <p>문자열을 파싱해 출처를 뽑아내지 않는다 — {@code ChatClient.entity(AnswerDto.class)}
 * 로 모델이 이 스키마에 맞춰 직접 채우게 한다.
 *
 * @param answer   사용자에게 보여줄 답변 본문
 * @param sources  실제로 사용한 근거 문서의 출처 목록
 * @param grounded 근거 문서 안에서 답을 찾았는지 여부
 */
public record AnswerDto(String answer, List<String> sources, boolean grounded) {

    /** 근거가 아예 없을 때 — 모델을 부르지 않고 즉시 반환한다. */
    static AnswerDto unknown() {
        return new AnswerDto("확인되지 않습니다.", List.of(), false);
    }
}
