package com.skala.lab2;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 근거 기반 답변 전용 ChatClient.
 *
 * <p>temperature 0 — "근거에 없으면 확인되지 않는다"고 말하는 일은 창의성이 아니라
 * 일관성이 중요하다. 매번 같은 근거에 같은 결론을 내야 골든 세트가 의미가 있다.
 */
@Configuration
public class ChatClientConfig {

    @Bean
    public ChatClient lab2ChatClient(ChatClient.Builder builder) {
        return builder
                .defaultOptions(ChatOptions.builder()
                        .temperature(0.0)
                        .build())
                .defaultAdvisors(new SimpleLoggerAdvisor())
                .build();
    }
}
