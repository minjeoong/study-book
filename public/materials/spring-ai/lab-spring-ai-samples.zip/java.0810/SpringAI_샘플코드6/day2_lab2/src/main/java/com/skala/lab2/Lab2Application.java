package com.skala.lab2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Day 2 실습 — 사내 문서 Q&A(RAG).
 *
 * <p>파이프라인: 읽기 → 분할 → 임베딩 → 저장 → 검색 → 생성.
 * 먼저 {@code POST /lab2/ingest} 로 {@code resources/docs/*.md} 를 적재한 뒤,
 * {@code GET /lab2/retrieve} 로 검색 결과(점수 포함)를 눈으로 확인하고,
 * {@code POST /lab2/ask} 로 근거 기반 답변(구조화 출력)을 받는다.
 *
 * <pre>
 *   ./gradlew bootRun          # http://localhost:8080
 *   http://localhost:8080/swagger-ui.html
 * </pre>
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class Lab2Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab2Application.class, args);
    }
}
