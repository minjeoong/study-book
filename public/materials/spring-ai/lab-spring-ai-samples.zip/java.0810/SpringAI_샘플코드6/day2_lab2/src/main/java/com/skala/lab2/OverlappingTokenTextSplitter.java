package com.skala.lab2;

import java.util.ArrayList;
import java.util.List;

import com.knuddels.jtokkit.Encodings;
import com.knuddels.jtokkit.api.Encoding;
import com.knuddels.jtokkit.api.EncodingRegistry;
import com.knuddels.jtokkit.api.EncodingType;
import com.knuddels.jtokkit.api.IntArrayList;

import org.springframework.ai.transformer.splitter.TextSplitter;

/**
 * 실험표(Step 5) 조합 F(겹침 20%) 전용 스플리터.
 *
 * <p>Spring AI 의 {@code TokenTextSplitter} 는 청크 겹침(overlap)을 지원하지 않는다 — 토큰을
 * {@code chunkSize} 만큼씩 끊어서 다음 청크로 넘어갈 뿐, 이전 청크와 겹치는 구간을 두지 않는다.
 * 그래서 "겹침이 잘린 문장 문제를 줄이는지"를 실측하려면 겹침을 직접 구현해야 했다.
 *
 * <p>토큰 윈도우를 {@code chunkSize} 가 아니라 {@code chunkSize - overlapTokens} 간격(stride)으로
 * 이동시키는 방식으로 겹침을 만든다. {@code overlapRatio == 0} 이면 stride == chunkSize 가 되어
 * 겹침이 전혀 없는 것과 동일하다.
 */
class OverlappingTokenTextSplitter extends TextSplitter {

    private static final EncodingRegistry REGISTRY = Encodings.newLazyEncodingRegistry();
    private static final Encoding ENCODING = REGISTRY.getEncoding(EncodingType.CL100K_BASE);

    private final int chunkSize;
    private final int strideTokens;

    OverlappingTokenTextSplitter(int chunkSize, double overlapRatio) {
        this.chunkSize = chunkSize;
        int overlapTokens = (int) Math.round(chunkSize * overlapRatio);
        this.strideTokens = Math.max(1, chunkSize - overlapTokens);
    }

    @Override
    protected List<String> splitText(String text) {
        List<Integer> tokens = ENCODING.encode(text).boxed();
        List<String> chunks = new ArrayList<>();
        for (int start = 0; start < tokens.size(); start += strideTokens) {
            int end = Math.min(start + chunkSize, tokens.size());
            String chunkText = decode(tokens.subList(start, end)).trim();
            if (!chunkText.isEmpty()) {
                chunks.add(chunkText);
            }
            if (end == tokens.size()) {
                break;
            }
        }
        return chunks;
    }

    private static String decode(List<Integer> tokens) {
        IntArrayList array = new IntArrayList(tokens.size());
        tokens.forEach(array::add);
        return ENCODING.decode(array);
    }
}
