# day2_lab2 — Day 2 실습 · 사내 문서 Q&A(RAG)

읽기 → 분할 → 임베딩 → 저장 → 검색 → 생성. 6단계를 코드로 만든다.

**혼자 돈다.** 이 폴더만 열어 `./gradlew bootRun` 하면 끝이고, 다른 장 폴더를 참조하지 않는다.

---

## 실행

```bash
export OPENAI_API_KEY="sk-..."   # 소스·깃에 절대 커밋하지 않는다
./gradlew bootRun          # http://localhost:8080
```

- Swagger UI — <http://localhost:8080/swagger-ui.html>
- 키가 없어도 앱은 뜬다(`${OPENAI_API_KEY:not-set}`). 모델·임베딩을 실제로 부르는
  엔드포인트에서만 401 이 난다.

---

## 무엇이 들어 있나

| 파일 | 무엇을 보나 |
| --- | --- |
| `Lab2IngestService.java` | 읽기(Tika) → 나누기(TokenTextSplitter) → **메타데이터 보강**(source·version) → 저장. 재색인 시 삭제 후 삽입으로 중복 방지 |
| `Lab2RagService.java` | 검색(`retrieve`) · 근거 기반 답변(`ask`, 구조화 출력) · 구간별 소요시간 계측 |
| `Lab2Controller.java` | `/lab2/ingest` · `/lab2/retrieve` · `/lab2/ask` |
| `Lab2Properties.java` | 실험표(Step 5)용 파라미터 외부화(`lab2.*`) |
| `AnswerDto.java` / `Chunk.java` | 구조화 응답 — 문자열 파싱 금지 |
| `OverlappingTokenTextSplitter.java` | 실험표 조합 F(겹침 20%) 전용 — `TokenTextSplitter` 는 겹침을 지원하지 않아 직접 구현 |
| `resources/docs/*.md` | 반품(return-policy) · 배송(shipping-policy) · 멤버십(membership) 샘플 규정 |
| `src/test/.../Lab2GoldenSetTest.java` | 골든 세트 10문항, 8/10 이상 통과가 기준선(`golden.json` 로딩) |
| `src/test/resources/golden.json` | 정답 목록 — 코드가 아니라 데이터로 관리 |

---

## 엔드포인트

```bash
# ① 인제스트 — 몇 번을 호출해도 청크 수가 같다(재색인)
curl -X POST localhost:8080/lab2/ingest
#   [{"source":"return-policy","chunks":N}, {"source":"shipping-policy","chunks":N}, {"source":"membership","chunks":N}]

# ② 검색만 먼저 본다 — 점수를 반드시 노출한다
curl 'localhost:8080/lab2/retrieve?q=제주도는 배송비가 더 드나요?&topK=4'

# ③ 근거 기반 답변 — answer · sources · grounded
curl -X POST 'localhost:8080/lab2/ask?question=단순 변심 반품은 며칠 이내인가요?'

# ④ 문서에 없는 질문은 지어내지 않는다
curl -X POST 'localhost:8080/lab2/ask?question=우주 배송도 되나요?'
#   → {"answer":"확인되지 않습니다.","sources":[],"grounded":false}
```

`/lab2/ask` 응답 헤더에 `X-Retrieve-Ms` · `X-Generate-Ms` · `X-Total-Ms` 가 함께 온다 —
"응답이 5초를 넘는다" 같은 문제를 감이 아니라 구간별 숫자로 진단하기 위해서다.

---

## 골든 세트

골든 세트(`Lab2GoldenSetTest`)는 실제 OpenAI 를 호출해 비용이 든다. `@Tag("eval")` 로
기본 `./gradlew test` 에서는 **제외**되고, `-Peval` 플래그를 줄 때만 실행된다.

```bash
./gradlew test                    # 골든 세트 제외 — 비용 없이 빌드만 확인
./gradlew test -Peval             # 골든 세트 포함 — 실제 OpenAI 호출
```

정답 목록은 코드가 아니라 `src/test/resources/golden.json` 데이터로 관리한다. `-Peval` 로
실행했는데 `OPENAI_API_KEY` 가 없으면 그때는 스킵한다. 실패 항목은
"㉠ 근거를 못 찾았다"(검색 문제)와 "㉡ 찾고도 잘못 답했다"(생성 문제)를 구분해 로그로 남긴다.

---

## 실험표(Step 5) — `application.yml` 의 `lab2.*` 만 바꿔서 재현한다

아래는 `-Peval` 로 실제 골든 세트를 조합별로 재실행해 측정한 값이다(2026-08-19).

| 조합 | chunk-size | top-k | threshold | 겹침 | 통과율 | 관찰 |
| --- | --- | --- | --- | --- | --- | --- |
| A(기준선) | 400 | 4 | 0.15 | 0% | 10/10 | 청크 2/2/2 |
| B | 200 | 4 | 0.15 | 0% | 10/10 | 청크 3/4/3로 증가, 통과율 동일 |
| C | 800 | 4 | 0.15 | 0% | 10/10 | 청크 1/1/1(문서 전체가 한 청크) |
| D | 400 | 8 | 0.15 | 0% | 10/10 | top-k 증가는 이 규모에서 효과 없음 |
| E | 400 | 4 | 0.7 | 0% | 1/10 | 근거를 거의 찾지 못함 — `BUILD FAILED` |
| F | 400 | 4 | 0.15 | 20% | 9/10 | 청크 2/2/2, "제주도 배송비" 1건 실패(표현 문제) |

```bash
LAB2_CHUNKSIZE=200 ./gradlew test -Peval --tests Lab2GoldenSetTest
LAB2_TOPK=8 ./gradlew test -Peval --tests Lab2GoldenSetTest
LAB2_SIMILARITYTHRESHOLD=0.7 ./gradlew test -Peval --tests Lab2GoldenSetTest
LAB2_CHUNKOVERLAPRATIO=0.2 ./gradlew test -Peval --tests Lab2GoldenSetTest
```

---

## 참고
- 버전은 Spring Boot 3.5.16 · Spring AI 1.1.8(`build.gradle` 의 `springAiVersion` 한 줄).
- `ch07_rag`(`QuestionAnswerAdvisor` 기반)와 달리, 이 모듈은 검색 → 프롬프트 조립 →
  구조화 출력을 직접 구현한다 — 각 단계를 눈으로 확인하는 것이 이 실습의 목적이다.
