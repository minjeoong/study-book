package com.skala.ch03.day1.service;

import com.skala.ch03.day1.domain.Order;
import com.skala.ch03.day1.domain.OrderNotFoundException;
import com.skala.ch03.day1.repository.OrderRepository;
import com.skala.ch03.day1.web.SummaryResponse;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Day 1 실습 — Step 2. 업무 흐름은 여기.
 *
 * <p>1장에서 만든 계층(OrderRepository)을 그대로 쓴다.
 * 주문을 못 찾으면 모델을 부르지 않는다 — 권한은 쿼리 안에 있다.
 * 서비스는 무엇을 하는가만 읽혀야 한다.
 */
@Service
@Transactional(readOnly = true)
public class OrderSummaryService {

    private final OrderRepository orders;
    private final ChatClient summaryChat;

    public OrderSummaryService(OrderRepository orders, ChatClient summaryChatClient) {
        this.orders = orders;
        this.summaryChat = summaryChatClient;
    }

    public SummaryResponse summarize(String orderId, String userId) {
        Order order = orders.findByIdAndOwnerId(orderId, userId)
                .orElseThrow(() -> new OrderNotFoundException(orderId));

        String eta = order.getEta() != null ? order.getEta().toString() : "없음";

        String summary;
        try {
            summary = summaryChat.prompt()
                    .user(u -> u.text("주문번호 {id} · 상품 {item} · 상태 {status} · 도착예정 {eta}"
                                    + "\n위 정보를 한 문장으로 요약해 줘. 도착예정이 \"없음\"이면 도착 예정 정보가 없다고 알려줘.")
                            .param("id", order.getId())
                            .param("item", order.getItem())
                            .param("status", order.getStatus().label())
                            .param("eta", eta))
                    .call().content();
        } catch (Exception e) {
            // AI 가 죽어도 주문 정보는 보여 준다
            summary = order.getItem() + " · " + order.getStatus().label();
        }

        return new SummaryResponse(order.getId(), summary);
    }
}
