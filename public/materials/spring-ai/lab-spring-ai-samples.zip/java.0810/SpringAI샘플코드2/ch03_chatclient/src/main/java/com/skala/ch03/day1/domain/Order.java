package com.skala.ch03.day1.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;

// 엔티티는 밖으로 나가지 않는다 — API 로는 SummaryResponse 만 노출한다.
// 테이블명은 "orders" — ORDER 는 SQL 예약어라 그대로 쓰면 DDL 이 깨진다.
@Entity
@Table(name = "orders")
public class Order {

    @Id
    private String id;

    private String ownerId;   // 내부 전용 — 응답에 없다
    private String item;

    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    private LocalDate eta;
    private BigDecimal cost;  // 원가 — 절대 노출하면 안 된다

    protected Order() {
        // JPA
    }

    public Order(String id, String ownerId, String item, OrderStatus status, LocalDate eta, BigDecimal cost) {
        this.id = id;
        this.ownerId = ownerId;
        this.item = item;
        this.status = status;
        this.eta = eta;
        this.cost = cost;
    }

    public String getId() {
        return id;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public String getItem() {
        return item;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public LocalDate getEta() {
        return eta;
    }
}
