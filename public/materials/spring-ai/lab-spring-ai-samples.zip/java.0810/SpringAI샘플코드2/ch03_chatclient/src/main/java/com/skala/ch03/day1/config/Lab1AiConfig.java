package com.skala.ch03.day1.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Day 1 실습 — Step 1. ChatClient 빈 만들기.
 *
 * <p>용도별로 빈을 나누고, 온도·토큰 상한을 빈에서 못 박고,
 * 시스템 프롬프트에 거절 규칙을 함께 넣는다.
 */
@Configuration
class Lab1AiConfig {

    /** 요약 전용 클라이언트 — 매번 같은 결과가 나와야 하므로 temperature 0, 길게 쓸 이유가 없으므로 토큰 상한. */
    @Bean
    ChatClient summaryChatClient(ChatClient.Builder builder) {
        return builder
                .defaultSystem("""
                        너는 이커머스 주문 상담 도우미다.
                        주어진 주문 정보만 사용해 한국어 한 문장으로 요약한다.
                        추측하지 않는다. 정보가 부족하면 "정보가 부족합니다"라고 답한다.
                        """)
                .defaultOptions(ChatOptions.builder()
                        .temperature(0.0)
                        .maxTokens(120)
                        .build())
                .build();
    }
}
