package com.skala.ch03.day1.web;

public record ErrorResponse(String message, String traceId) {
}
