package com.skala.lab4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 4장 실습 · 용도별 ChatClient 빈 두 개
 *
 * <p>이 폴더 하나가 실습 하나다. VS Code 로 이 폴더를 열고 F5 를 누르면 뜬다.
 * 터미널이면 {@code ./gradlew bootRun}.
 */
@SpringBootApplication
public class LabApplication {

    public static void main(String[] args) {
        SpringApplication.run(LabApplication.class, args);
    }
}
