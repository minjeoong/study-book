# 07_계층위에AI얹기_주문요약

**Day 1 실습 · 계층 위에 AI 얹기 — 주문 요약 API (90분)**

1장에서 배운 Controller·Service·Repository 계층 위에, 3장에서 배운 ChatClient를 얹어
하나의 엔드포인트(`GET /lab1/orders/{id}/summary`)로 완성하는 실습이다.
컨트롤러는 AI를 모르고, ChatClient는 Config에서 빈으로 구성하고, 업무 흐름은 Service가 쥔다.

## 실행

```bash
export OPENAI_API_KEY="sk-..."
./gradlew bootRun          # VS Code 는 F5
```

키가 없어도 기동은 되지만(더미 검증만 통과), 실제 요약 호출은 실패하고 폴백 문구로 대체된다.

## 확인

```bash
# 정상 — 200, 한 문장 요약
curl 'localhost:8080/lab1/orders/12345/summary?userId=user1'

# 남의 주문 — 404 (99999는 user2 소유)
curl 'localhost:8080/lab1/orders/99999/summary?userId=user1'

# 없는 주문 — 404
curl 'localhost:8080/lab1/orders/00000/summary?userId=user1'

# 재현성 — 같은 입력으로 3회, 온도 0이라 문장이 거의 같다
for i in 1 2 3; do curl -s 'localhost:8080/lab1/orders/12345/summary?userId=user1'; echo; done
```

Swagger UI — <http://localhost:8080/swagger-ui.html> → "Day1 실습 · 주문 요약" 태그
토큰 사용량 — <http://localhost:8080/actuator/metrics/ai.tokens>

## 시드 데이터

기동마다 인메모리 H2에 다시 채워진다 (`OrderDataSeeder`).

| 주문번호  | 소유자  | 상품        | 상태     |
|-------|------|-----------|--------|
| 12345 | user1 | 무선 이어폰    | 배송 중   |
| 12346 | user1 | 블루투스 스피커  | 상품 준비 중 |
| 12347 | user1 | 노트북 파우치   | 배송 완료  |
| 99999 | user2 | 게이밍 마우스   | 배송 중   |

## 이 폴더에 있는 것

```
src/main/java/com/skala/day1/
    Day1Application.java
    domain/        Order, OrderStatus, OrderNotFoundException     ← 1장 계층
    repository/     OrderRepository, OrderDataSeeder               ← 1장 계층
    config/         Lab1AiConfig                                   ← 요약 전용 ChatClient 빈
    service/        OrderSummaryService                            ← 업무 흐름 + AI 호출 + 폴백
    web/            OrderSummaryController, SummaryResponse,
                    ErrorResponse, Lab1ExceptionHandler
```

## 실험해 볼 것 (교재 그대로)

| 바꿔 볼 것 | 어떻게 | 무엇을 관찰하나 |
|---|---|---|
| 온도 | `Lab1AiConfig`의 `0.0` → `0.9`로 바꿔 5회 호출 | 문장이 매번 달라진다 |
| maxTokens | `120` → `20` | 문장이 중간에서 끊긴다 |
| 정보 누락 | 프롬프트에서 `eta` 파라미터를 빼 본다 | "정보가 부족합니다"가 나오나 |
| 모델 교체 | `gpt-4o-mini` → `gpt-4o` | 품질과 지연의 차이 |

## 완료 기준 (8개 중 6개 이상)

1. `GET /lab1/orders/12345/summary?userId=user1` → 200
2. 권한 격리 — `99999` 요청이 404
3. 계층 분리 — 컨트롤러에 `ChatClient`가 없다
4. 빈 구성 — `ChatClient` 빈이 config에 하나
5. 옵션 고정 — 같은 입력에 거의 같은 답 (온도 0)
6. 문서화 — Swagger에 설명·예시·404가 보인다
7. 실패 처리 — 모델 외 예상 못 한 오류는 503 + traceId
8. 폴백 — AI 요약이 실패해도 주문 정보(상품·상태)는 나간다

막히면 `03_작명봇`, `04_말투바꾸기` (ChatClient 사용례)와 `01_간식추천_3계층` (계층 구조)를 열어 비교해 본다.
