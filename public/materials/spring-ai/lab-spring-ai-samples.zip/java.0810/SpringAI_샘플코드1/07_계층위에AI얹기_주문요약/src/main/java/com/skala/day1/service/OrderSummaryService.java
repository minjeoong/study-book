package com.skala.day1.service;

import com.skala.day1.domain.Order;
import com.skala.day1.domain.OrderNotFoundException;
import com.skala.day1.repository.OrderRepository;
import com.skala.day1.web.SummaryResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class OrderSummaryService {

    private static final Logger log = LoggerFactory.getLogger(OrderSummaryService.class);

    private final OrderRepository orders;      // 1장에서 만든 계층을 그대로
    private final ChatClient summaryChat;

    public OrderSummaryService(OrderRepository orders, ChatClient summaryChatClient) {
        this.orders = orders;
        this.summaryChat = summaryChatClient;
    }

    public SummaryResponse summarize(String orderId, String userId) {
        Order order = orders.findByIdAndOwnerId(orderId, userId)   // 권한은 쿼리 안에
                .orElseThrow(() -> new OrderNotFoundException(orderId));

        String summary;
        try {
            summary = summaryChat.prompt()
                    .user(u -> u.text("주문번호 {id} · 상품 {item} · 상태 {status} · 도착예정 {eta}"
                                    + "\n위 정보를 한 문장으로 요약해 줘.")
                            .param("id", order.getId())
                            .param("item", order.getItem())
                            .param("status", order.getStatus().label())
                            .param("eta", order.getEta().toString()))
                    .call().content();
        } catch (Exception e) {
            // AI 가 실패해도 화면은 살린다 — 요약은 부가 정보다. 상세는 로그에만 남긴다.
            log.warn("주문 요약 모델 호출 실패, 폴백으로 대체한다. orderId={}", orderId, e);
            summary = order.getItem() + " · " + order.getStatus().label();
        }
        return new SummaryResponse(order.getId(), summary);
    }
}
