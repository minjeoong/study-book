package com.skala.day1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Day 1 실습 · 계층 위에 AI 얹기 — 주문 요약 API
 *
 * <p>이 폴더 하나가 실습 하나다. VS Code 로 이 폴더를 열고 F5 를 누르면 뜬다.
 * 터미널이면 {@code ./gradlew bootRun}.
 */
@SpringBootApplication
public class Day1Application {

    public static void main(String[] args) {
        SpringApplication.run(Day1Application.class, args);
    }
}
