package com.skala.day1.repository;

import com.skala.day1.domain.Order;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, String> {

    // 소유자 조건을 쿼리에 넣는다 — 이 한 줄이 권한 경계다
    Optional<Order> findByIdAndOwnerId(String id, String ownerId);
}
