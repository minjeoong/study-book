package com.skala.day1;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.skala.day1.domain.Order;
import com.skala.day1.domain.OrderNotFoundException;
import com.skala.day1.domain.OrderStatus;
import com.skala.day1.repository.OrderRepository;
import com.skala.day1.service.OrderSummaryService;
import com.skala.day1.web.SummaryResponse;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.client.ChatClient;

// 스프링 부트 컨텍스트 없이 순수 Mockito 로 뜬다 — 3장에서 배운 그대로.
class OrderSummaryServiceTest {

    private final Order order = new Order("12345", "user1", "무선 이어폰",
            OrderStatus.SHIPPING, LocalDate.now().plusDays(2), new BigDecimal("89000"));

    @Test
    void 남의_주문이거나_없는_주문이면_예외를_던진다() {
        OrderRepository repository = mock(OrderRepository.class);
        when(repository.findByIdAndOwnerId("99999", "user1")).thenReturn(Optional.empty());
        OrderSummaryService service = new OrderSummaryService(repository, mock(ChatClient.class));

        assertThatThrownBy(() -> service.summarize("99999", "user1"))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @Test
    void 모델_호출이_실패해도_주문_정보로_폴백한다() {
        OrderRepository repository = mock(OrderRepository.class);
        when(repository.findByIdAndOwnerId("12345", "user1")).thenReturn(Optional.of(order));

        ChatClient chatClient = mock(ChatClient.class, RETURNS_DEEP_STUBS);
        when(chatClient.prompt().user(any(java.util.function.Consumer.class)).call().content())
                .thenThrow(new RuntimeException("모델 타임아웃"));

        OrderSummaryService service = new OrderSummaryService(repository, chatClient);
        SummaryResponse response = service.summarize("12345", "user1");

        assertThat(response.orderId()).isEqualTo("12345");
        assertThat(response.summary()).contains("무선 이어폰").contains("배송 중");
    }
}
