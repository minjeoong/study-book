package com.skala.day1.repository;

import com.skala.day1.domain.Order;
import com.skala.day1.domain.OrderStatus;
import java.math.BigDecimal;
import java.time.LocalDate;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

// 실습용 시드 데이터 — 1장에서 만든 계층(ch02/orders)에 이미 있던 데이터라고 가정한다.
// 12345·12346·12347 은 user1 소유, 99999 는 user2 소유다.
@Component
class OrderDataSeeder implements CommandLineRunner {

    private final OrderRepository orders;

    OrderDataSeeder(OrderRepository orders) {
        this.orders = orders;
    }

    @Override
    public void run(String... args) {
        orders.save(new Order("12345", "user1", "무선 이어폰", OrderStatus.SHIPPING,
                LocalDate.now().plusDays(2), new BigDecimal("89000")));
        orders.save(new Order("12346", "user1", "블루투스 스피커", OrderStatus.PREPARING,
                LocalDate.now().plusDays(4), new BigDecimal("65000")));
        orders.save(new Order("12347", "user1", "노트북 파우치", OrderStatus.DELIVERED,
                LocalDate.now().minusDays(1), new BigDecimal("32000")));
        orders.save(new Order("99999", "user2", "게이밍 마우스", OrderStatus.SHIPPING,
                LocalDate.now().plusDays(3), new BigDecimal("54000")));
    }
}
