package com.skala.lab5;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * v2 의 출력 형식(이모지3개 | 20자 이내)만 검증한다.
 * 어떤 이모지·어떤 문장이 나오는지는 호출마다 달라도 되므로 내용은 검증하지 않는다.
 */
@SpringBootTest
class SummaryLabTest {

    @Autowired
    private SummaryLab lab;

    @Test
    void 형식이_지켜진다() {
        String out = lab.v2("오늘 배포 실패로 밤샘했다");

        assertThat(out).contains("|");

        String[] parts = out.split("\\|", 2);
        String 이모지 = parts[0].trim();
        String 요약 = parts[1].trim();

        assertThat(이모지).isNotEmpty();
        assertThat(요약.length()).isLessThanOrEqualTo(20);
    }
}
