package com.skala.lab3.web;

/**
 * 대화 ID(=ChatMemory 의 conversationId) 규칙을 만드는 유일한 곳(요구사항 5).
 *
 * <p>규칙이 흩어지면 남의 대화가 섞이는 사고가 난다 — 메모리에서 가장 흔하고
 * 가장 늦게 발견되는 버그다. {@code userId}(인증 주체) 와 {@code sessionId}(클라이언트가
 * 지정한 대화 창) 를 항상 이 메서드로만 조합한다.
 */
public final class ConversationIds {

    private ConversationIds() {
    }

    public static String of(String userId, String sessionId) {
        return userId + ":" + sessionId;
    }
}
