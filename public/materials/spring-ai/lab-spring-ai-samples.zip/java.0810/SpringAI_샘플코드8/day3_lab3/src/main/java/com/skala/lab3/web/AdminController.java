package com.skala.lab3.web;

import java.util.List;
import java.util.Map;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skala.lab3.domain.RefundTicket;
import com.skala.lab3.domain.TicketRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * 사람 전용 승인 화면 (요구사항 3 — 승인 게이트).
 *
 * <p>이 경로는 {@code ChatClientConfig} 의 도구 목록에 없다. 모델은 이 API 의 존재 자체를
 * 모르므로 절대 호출할 수 없다 — "모델이 접근할 수 없는 경로에 실제 처리를 둔다"는
 * 원칙을 코드로 강제한 것이다. {@code @PreAuthorize} 와 {@code SecurityConfig} 의
 * 필터 체인이 이중으로 ROLE_ADMIN 을 요구한다.
 */
@RestController
@RequestMapping("/lab3/admin")
@Tag(name = "Day3 · 승인(관리자 전용)")
public class AdminController {

    private final TicketRepository tickets;

    public AdminController(TicketRepository tickets) {
        this.tickets = tickets;
    }

    @GetMapping("/tickets/pending")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "승인 대기 환불 티켓 목록")
    public List<RefundTicket> pending() {
        return tickets.pending();
    }

    @PostMapping("/tickets/{no}/approve")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "환불 승인", description = "실제 처리는 이 버튼을 사람이 눌러야만 일어난다.")
    public Map<String, String> approve(@PathVariable String no) {
        return tickets.approve(no)
                .map(t -> Map.of("ticketNo", t.no(), "status", t.status().name()))
                .orElse(Map.of("ticketNo", no, "status", "NOT_FOUND"));
    }
}
