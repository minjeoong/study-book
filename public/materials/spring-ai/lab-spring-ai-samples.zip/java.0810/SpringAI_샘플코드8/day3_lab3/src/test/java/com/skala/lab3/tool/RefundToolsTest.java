package com.skala.lab3.tool;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.model.ToolContext;

import com.skala.lab3.audit.AuditLogService;
import com.skala.lab3.domain.OrderRepository;
import com.skala.lab3.domain.TicketRepository;
import com.skala.lab3.domain.TicketStatus;

/** 환불 접수는 항상 PENDING 으로만 남는다 — 승인 게이트(요구사항 3 · 확인 항목 #3). */
class RefundToolsTest {

    private final TicketRepository ticketRepository = new TicketRepository();
    private final RefundTools tools = new RefundTools(new OrderRepository(), ticketRepository, new AuditLogService());

    @Test
    @DisplayName("본인 주문 환불 요청은 PENDING 상태로 접수된다 — 도구는 승인할 수 없다")
    void 환불은_접수만_된다() {
        var result = tools.requestRefund("12345", "단순 변심", new ToolContext(Map.of("userId", "user1")));

        assertThat(result.status()).isEqualTo(TicketStatus.PENDING.name());
        assertThat(ticketRepository.findByNo(result.ticketNo()).orElseThrow().status())
                .isEqualTo(TicketStatus.PENDING);
    }

    @Test
    @DisplayName("타인의 주문번호로는 환불 접수도 되지 않는다")
    void 타인_주문은_환불_접수도_안된다() {
        assertThatThrownBy(() -> tools.requestRefund("99999", "변심", new ToolContext(Map.of("userId", "user1"))))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("주문을 찾을 수 없습니다.");
    }

    @Test
    @DisplayName("접수 티켓은 사람이 승인해야만 APPROVED 로 바뀐다")
    void 사람이_승인해야_바뀐다() {
        var ticket = tools.requestRefund("12345", "단순 변심", new ToolContext(Map.of("userId", "user1")));

        var approved = ticketRepository.approve(ticket.ticketNo()).orElseThrow();

        assertThat(approved.status()).isEqualTo(TicketStatus.APPROVED);
    }
}
