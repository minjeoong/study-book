package com.skala.lab3.domain;

import java.time.LocalDate;

/** 주문 한 건. {@code ownerId} 가 권한 검증의 기준이다. */
public record Order(String id, String ownerId, String item, String status, LocalDate eta) {
}
