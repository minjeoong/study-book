package com.skala.lab3.advisor;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ai.chat.client.ChatClientRequest;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.api.CallAdvisor;
import org.springframework.ai.chat.client.advisor.api.CallAdvisorChain;
import org.springframework.ai.chat.metadata.Usage;
import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.MeterRegistry;

/**
 * 관측성 Advisor — 토큰 · 지연 계측 (요구사항 8).
 *
 * <p>체인에서 가장 바깥(order 가 가장 낮음)에 둬서, 안전 필터에서 막히든
 * RAG·도구를 거치든 상관없이 <b>모든 호출의 총 지연</b>을 잡는다.
 *
 * <p>확인: {@code GET /actuator/metrics/ai.tokens?tag=type:prompt} ·
 * {@code GET /actuator/metrics/ai.latency}
 */
@Component
public class MetricsAdvisor implements CallAdvisor {

    private static final Logger log = LoggerFactory.getLogger(MetricsAdvisor.class);

    private final MeterRegistry registry;

    public MetricsAdvisor(MeterRegistry registry) {
        this.registry = registry;
    }

    @Override
    public ChatClientResponse adviseCall(ChatClientRequest request, CallAdvisorChain chain) {
        long started = System.nanoTime();
        ChatClientResponse response = chain.nextCall(request);
        long elapsedNanos = System.nanoTime() - started;

        registry.timer("ai.latency", "phase", "model").record(elapsedNanos, TimeUnit.NANOSECONDS);

        if (response.chatResponse() != null && response.chatResponse().getMetadata() != null) {
            Usage usage = response.chatResponse().getMetadata().getUsage();
            if (usage != null) {
                registry.counter("ai.tokens", "type", "prompt").increment(nullSafe(usage.getPromptTokens()));
                registry.counter("ai.tokens", "type", "completion").increment(nullSafe(usage.getCompletionTokens()));

                log.info("[METRICS] traceId={} promptTokens={} completionTokens={} elapsedMs={}",
                        MDC.get("traceId"), usage.getPromptTokens(), usage.getCompletionTokens(),
                        elapsedNanos / 1_000_000);
            }
        }
        return response;
    }

    private double nullSafe(Integer value) {
        return value == null ? 0 : value;
    }

    @Override
    public String getName() {
        return "metrics";
    }

    /** 가장 바깥 — 안전 필터·RAG·도구를 포함한 전체 시간을 재야 하기 때문이다. */
    @Override
    public int getOrder() {
        return 10;
    }
}
