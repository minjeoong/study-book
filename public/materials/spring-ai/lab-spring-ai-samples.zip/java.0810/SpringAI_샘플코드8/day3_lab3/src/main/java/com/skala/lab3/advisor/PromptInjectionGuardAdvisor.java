package com.skala.lab3.advisor;

import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ai.chat.client.ChatClientRequest;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.api.CallAdvisor;
import org.springframework.ai.chat.client.advisor.api.CallAdvisorChain;
import org.springframework.ai.chat.client.advisor.api.StreamAdvisor;
import org.springframework.ai.chat.client.advisor.api.StreamAdvisorChain;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;

import reactor.core.publisher.Flux;

/**
 * 안전 Advisor ① — 프롬프트 인젝션 차단 (요구사항 6).
 *
 * <p>"이전 지시 무시", "시스템 프롬프트 출력", 역할 탈옥 시도 등을 패턴으로 잡아
 * <b>모델에 닿기 전에</b> 막는다. {@code SafeGuardAdvisor} 와 같은 방식(체인을 타지 않고
 * 고정 응답으로 되돌린다)이지만, 대상이 개인정보가 아니라 <b>지시 조작 패턴</b>이라는 점이 다르다.
 *
 * <p><b>순서가 곧 정책이다</b>: order 를 {@link org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor}
 * 보다 낮게(더 바깥에) 둬야 한다. 차단이 메모리 저장보다 뒤에 있으면, 걸러야 할 문장이
 * 이미 대화 이력에 저장된 뒤라 다음 턴에 그대로 다시 들어온다.
 */
public class PromptInjectionGuardAdvisor implements CallAdvisor, StreamAdvisor {

    private static final Logger log = LoggerFactory.getLogger(PromptInjectionGuardAdvisor.class);
    private static final Logger audit = LoggerFactory.getLogger("AI_CHAT_AUDIT");

    private static final String FAILURE_RESPONSE =
            "죄송합니다. 시스템 지시를 변경하거나 노출하도록 요청하는 문장은 처리할 수 없습니다.";

    /** OWASP LLM01(Prompt Injection) 에서 흔히 쓰이는 표현을 패턴으로 모았다. */
    private static final List<Pattern> INJECTION_PATTERNS = List.of(
            Pattern.compile("이전\\s*(지시|명령|프롬프트).{0,10}(무시|잊)", Pattern.CASE_INSENSITIVE),
            Pattern.compile("시스템\\s*프롬프트", Pattern.CASE_INSENSITIVE),
            Pattern.compile("(지침|규칙|역할)\\s*을?\\s*(무시|바꿔|재정의)", Pattern.CASE_INSENSITIVE),
            Pattern.compile("ignore\\s+(all\\s+)?(previous|above|prior)\\s+instructions?", Pattern.CASE_INSENSITIVE),
            Pattern.compile("(reveal|print|show)\\s+(the\\s+)?system\\s+prompt", Pattern.CASE_INSENSITIVE),
            Pattern.compile("(너는|당신은)\\s*이제\\s*.{0,15}(다|이다|입니다)", Pattern.CASE_INSENSITIVE),
            Pattern.compile("개발자\\s*모드|DAN\\s*모드|jailbreak", Pattern.CASE_INSENSITIVE));

    private final int order;

    public PromptInjectionGuardAdvisor(int order) {
        this.order = order;
    }

    @Override
    public ChatClientResponse adviseCall(ChatClientRequest request, CallAdvisorChain chain) {
        if (isInjection(request)) {
            return blockedResponse(request);
        }
        return chain.nextCall(request);
    }

    @Override
    public Flux<ChatClientResponse> adviseStream(ChatClientRequest request, StreamAdvisorChain chain) {
        if (isInjection(request)) {
            return Flux.just(blockedResponse(request));
        }
        return chain.nextStream(request);
    }

    private boolean isInjection(ChatClientRequest request) {
        String text = request.prompt().getContents();
        return INJECTION_PATTERNS.stream().anyMatch(p -> p.matcher(text).find());
    }

    private ChatClientResponse blockedResponse(ChatClientRequest request) {
        String text = request.prompt().getContents();
        log.warn("[SAFETY] 프롬프트 인젝션 패턴 차단 traceId={} text={}", MDC.get("traceId"), text);
        audit.info("event=INJECTION_BLOCKED traceId={} text={}", MDC.get("traceId"), text);

        return ChatClientResponse.builder()
                .chatResponse(ChatResponse.builder()
                        .generations(List.of(new Generation(new AssistantMessage(FAILURE_RESPONSE))))
                        .build())
                .context(java.util.Map.copyOf(request.context()))
                .build();
    }

    @Override
    public String getName() {
        return "promptInjectionGuard";
    }

    @Override
    public int getOrder() {
        return order;
    }
}
