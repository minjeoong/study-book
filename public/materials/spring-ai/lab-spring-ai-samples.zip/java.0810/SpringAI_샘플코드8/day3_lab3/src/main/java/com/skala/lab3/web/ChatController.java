package com.skala.lab3.web;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.vectorstore.QuestionAnswerAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.document.Document;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * 상담 에이전트 진입점 — 규정(RAG) + 주문(Tool) 통합 (요구사항 1 · 4 · 5).
 *
 * <p>컨트롤러에는 RAG · 메모리 · 안전 필터 · 계측 코드가 한 줄도 없다. 전부
 * {@code ChatClientConfig} 가 조립한 Advisor 체인에 들어 있다 — 컨트롤러의 역할은
 * "인증된 사용자 ID 를 확보해 ToolContext 로 넘기는 것" 뿐이다.
 *
 * <p>사용자 ID 는 요청 파라미터가 아니라 {@link Authentication#getName()} 에서만 얻는다.
 * Swagger 로 시험할 때는 우측 상단 Authorize 로 user1/user2 계정을 먼저 로그인한다.
 */
@RestController
@RequestMapping("/lab3")
@Tag(name = "Day3 · 상담 에이전트")
public class ChatController {

    private static final Logger log = LoggerFactory.getLogger(ChatController.class);

    private final ChatClient assistant;
    private final ChatMemory chatMemory;

    public ChatController(ChatClient assistantChatClient, ChatMemory chatMemory) {
        this.assistant = assistantChatClient;
        this.chatMemory = chatMemory;
    }

    @PostMapping("/chat")
    @Operation(summary = "상담 에이전트에게 묻는다",
            description = "주문 조회·환불 접수는 도구가, 배송·반품 규정은 RAG 가 답한다. userId 는 로그인 계정에서 온다.")
    public ChatTurnResponse chat(@RequestBody ChatRequest request, Authentication authentication) {
        String userId = authentication.getName();
        String sessionId = request.sessionId() == null || request.sessionId().isBlank() ? "default" : request.sessionId();
        String conversationId = ConversationIds.of(userId, sessionId);

        log.info("[CHAT] traceId={} user={} session={} 질문=\"{}\"", MDC.get("traceId"), userId, sessionId, request.message());

        ChatClientResponse response = assistant.prompt()
                .user(request.message())
                .toolContext(Map.of("userId", userId))          // 도구가 읽는 통로 — 모델이 못 바꾼다
                .advisors(a -> a
                        .param(ChatMemory.CONVERSATION_ID, conversationId)
                        .param("userId", userId))                // Advisor(감사 로그)가 읽는 통로
                .call()
                .chatClientResponse();

        String answer = response.chatResponse().getResult().getOutput().getText();
        return new ChatTurnResponse(answer, sessionId, MDC.get("traceId"), sourcesOf(response));
    }

    /**
     * 모델의 서술이 아니라 QuestionAnswerAdvisor 가 실제로 검색해 남긴 문서 목록에서
     * 출처 파일명을 뽑는다(요구사항 4). 근거가 없었으면 빈 목록 — 그 자체가 "문서 밖 질문"의 증거다.
     */
    @SuppressWarnings("unchecked")
    private List<String> sourcesOf(ChatClientResponse response) {
        Object raw = response.context().get(QuestionAnswerAdvisor.RETRIEVED_DOCUMENTS);
        if (!(raw instanceof List<?> docs)) {
            return List.of();
        }
        return ((List<Document>) docs).stream()
                .map(d -> String.valueOf(d.getMetadata().get("source")))
                .distinct()
                .toList();
    }

    @GetMapping("/chat/history")
    @Operation(summary = "대화 이력 조회", description = "Advisor 순서 실험(요구사항 6) 확인용 — 차단됐어야 할 문장이 남아 있는지 본다.")
    public List<Map<String, String>> history(@RequestParam(defaultValue = "default") String sessionId,
                                              Authentication authentication) {
        String conversationId = ConversationIds.of(authentication.getName(), sessionId);
        return chatMemory.get(conversationId).stream()
                .map(m -> Map.of("role", m.getMessageType().getValue(), "text", String.valueOf(m.getText())))
                .toList();
    }
}
