package com.skala.lab3.config;

import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.ChatMemoryRepository;
import org.springframework.ai.chat.memory.InMemoryChatMemoryRepository;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 대화 메모리(요구사항 5 — 멀티턴). 대화 ID(=세션) 규칙은 {@code ChatMemory.CONVERSATION_ID}
 * 파라미터 한 곳으로 모으고, 컨트롤러는 항상 "사용자+세션"을 조합해 이 값을 만든다
 * (남의 대화가 섞이는 사고를 막는 유일한 방법은 이 조합을 흩어 두지 않는 것이다).
 */
@Configuration
public class ChatMemoryConfig {

    @Bean
    public ChatMemoryRepository chatMemoryRepository() {
        return new InMemoryChatMemoryRepository();
    }

    @Bean
    public ChatMemory chatMemory(ChatMemoryRepository repository) {
        return MessageWindowChatMemory.builder()
                .chatMemoryRepository(repository)
                .maxMessages(20)
                .build();
    }
}
