package com.skala.lab3.audit;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.MeterRegistry;

/**
 * 모든 {@code @Tool} 호출을 한 곳에서 감사·계측한다(요구사항 7 · 8).
 *
 * <p>도구가 늘어나도 이 파일 하나만 있으면 "어떤 도구가, 누가, 언제, 성공했는지"를
 * 빠짐없이 추적할 수 있다. 도구마다 로깅 코드를 넣으면 반드시 빠뜨리는 곳이 생긴다.
 *
 * <p>확인: {@code GET /actuator/metrics/ai.tool.calls?tag=result:fail}
 */
@Aspect
@Component
public class ToolCallAuditAspect {

    private static final Logger audit = LoggerFactory.getLogger("AI_TOOL_AUDIT");

    private final MeterRegistry registry;

    public ToolCallAuditAspect(MeterRegistry registry) {
        this.registry = registry;
    }

    @Around("@annotation(org.springframework.ai.tool.annotation.Tool)")
    public Object auditToolCall(ProceedingJoinPoint joinPoint) throws Throwable {
        String tool = joinPoint.getSignature().getName();
        String args = mask(Arrays.toString(joinPoint.getArgs()));
        long started = System.nanoTime();
        boolean ok = true;

        try {
            Object result = joinPoint.proceed();
            audit.info("tool={} args={} status=OK elapsedMs={} traceId={}",
                    tool, args, elapsedMs(started), MDC.get("traceId"));
            return result;

        } catch (Throwable e) {
            ok = false;
            audit.warn("tool={} args={} status=FAIL error={} elapsedMs={} traceId={}",
                    tool, args, e.getMessage(), elapsedMs(started), MDC.get("traceId"));
            throw e;

        } finally {
            registry.counter("ai.tool.calls", "tool", tool, "result", ok ? "ok" : "fail").increment();
        }
    }

    private long elapsedMs(long startedNanos) {
        return (System.nanoTime() - startedNanos) / 1_000_000;
    }

    /** 인자에 개인정보·민감정보가 섞여 들어올 수 있어 로그에 남기기 전에 가린다. */
    private String mask(String raw) {
        return raw
                .replaceAll("\\d{6}-\\d{7}", "******-*******")
                .replaceAll("\\d{4}-\\d{4}-\\d{4}-\\d{4}", "****-****-****-****")
                .replaceAll("[\\w.+-]+@[\\w-]+\\.[\\w.]+", "***@***");
    }
}
