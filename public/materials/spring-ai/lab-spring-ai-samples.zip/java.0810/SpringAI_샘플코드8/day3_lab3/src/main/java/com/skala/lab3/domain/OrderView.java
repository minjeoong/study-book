package com.skala.lab3.domain;

/** 도구·API 응답에 노출하는 주문 정보. {@code ownerId} 는 절대 밖으로 내보내지 않는다. */
public record OrderView(String orderId, String item, String status, String eta) {

    public static OrderView from(Order order) {
        return new OrderView(order.id(), order.item(), order.status(), order.eta().toString());
    }
}
