package com.skala.lab3.domain;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Repository;

/**
 * 주문 저장소 — 데모용 인메모리 구현.
 *
 * <p>{@link #findByIdAndOwnerId} 하나가 이 실습의 핵심이다. 주문번호만으로 찾지 않고
 * 소유자 조건을 쿼리 안에 함께 건다 — "조회는 됐는데 권한이 없어서 막았다"가 아니라
 * <b>애초에 남의 주문은 결과 집합에 존재하지 않는다.</b> 그래서 존재 여부와 권한 여부를
 * 구분해 알려 줄 수 없고(그 자체가 정보 노출이다), 두 경우 모두 "찾을 수 없다"로 응답한다.
 */
@Repository
public class OrderRepository {

    private static final Map<String, Order> ORDERS = Map.of(
            "12345", new Order("12345", "user1", "무선 이어폰", "배송중", LocalDate.of(2026, 8, 22)),
            "12346", new Order("12346", "user1", "USB-C 케이블", "배송완료", LocalDate.of(2026, 8, 10)),
            "99999", new Order("99999", "user2", "노트북 스탠드", "결제완료", LocalDate.of(2026, 8, 25)));

    /** 권한은 쿼리 안에 — orderId 뿐 아니라 ownerId 까지 같이 걸어야 남의 주문이 새지 않는다. */
    public Optional<Order> findByIdAndOwnerId(String orderId, String ownerId) {
        return Optional.ofNullable(ORDERS.get(orderId))
                .filter(o -> o.ownerId().equals(ownerId));
    }
}
