package com.skala.lab3.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.chat.client.advisor.vectorstore.QuestionAnswerAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.skala.lab3.advisor.ChatAuditAdvisor;
import com.skala.lab3.advisor.MetricsAdvisor;
import com.skala.lab3.advisor.PromptInjectionGuardAdvisor;
import com.skala.lab3.advisor.RagObservabilityAdvisor;
import com.skala.lab3.tool.OrderTools;
import com.skala.lab3.tool.RefundTools;

/**
 * 상담 에이전트 조립 — 규정(RAG) + 주문(Tool) + 안전 + 관측성 (요구사항 전체 통합).
 *
 * <p>Advisor 는 양파 껍질처럼 요청을 감싼다. order 가 낮을수록 바깥이고, 요청은
 * 바깥→안, 응답은 안→바깥으로 흐른다.
 *
 * <pre>
 *   요청:  Metrics(10) → InjectionGuard(100) → Memory(200) → QA(300) → RagLog(310) → ChatAudit(900) → Logger → 모델
 *   응답:  모델 → Logger → ChatAudit → RagLog → QA → Memory → InjectionGuard → Metrics
 * </pre>
 *
 * <p><b>순서가 곧 정책이다(요구사항 6)</b>: 인젝션 차단은 반드시 메모리 저장(200)보다 앞(100)에
 * 있어야 한다. 뒤에 두면 걸러야 할 문장이 이미 대화 이력에 저장된 뒤이므로 다음 턴에
 * 그대로 다시 들어온다. {@link #INJECTION_GUARD_ORDER} 를 250 으로 바꾸고
 * {@code GET /lab3/chat/history} 로 확인해 보면 이 사고를 직접 재현할 수 있다.
 */
@Configuration
public class ChatClientConfig {

    /** 실습용 스위치. 100=메모리보다 앞(정상) · 250=메모리보다 뒤(사고 재현용). */
    static final int INJECTION_GUARD_ORDER = 100;

    @Bean
    public ChatClient assistantChatClient(ChatClient.Builder builder,
                                          VectorStore vectorStore,
                                          ChatMemory chatMemory,
                                          MetricsAdvisor metricsAdvisor,
                                          ChatAuditAdvisor chatAuditAdvisor,
                                          RagObservabilityAdvisor ragObservabilityAdvisor,
                                          OrderTools orderTools,
                                          RefundTools refundTools) {
        return builder
                .defaultSystem("""
                        너는 SKALA 스토어의 상담 에이전트다.

                        [질문 유형 구분 — 가장 먼저 판단한다]
                        1) 규정을 "묻는" 질문(며칠 이내인가, 배송비는 얼마인가 등)
                           → 검색된 근거 문서 안의 내용만으로 답하고, 답변 마지막 줄에
                             "[출처: 파일명]" 형식으로 근거 문서명을 밝힌다.
                             근거에 없으면 모른다고 말하고 고객센터 연결을 안내한다.
                        2) 실제 "행동"을 요청(주문 조회, 환불·반품 접수, 접수 상태 확인)
                           → 반드시 해당 도구를 호출한다. 규정 문서를 근거로 네가 스스로
                             가능/불가를 판단해 거절하지 않는다. 반품 가능 여부 심사는
                             담당자가 하며, 너의 역할은 접수까지다.
                             도구가 돌려준 결과(접수번호·상태·실패 사유)를 그대로 전달한다.

                        [행동 요청 처리 규칙]
                        - 도구 호출에 필요한 정보(주문번호 등)가 대화 전체에 없으면 추측하지 말고 되묻는다.
                          단, 앞선 대화에 이미 나온 주문번호·접수번호·사유는 그대로 재사용한다.
                        - "방금 접수한 것", "그 사유로" 같은 표현은 앞 대화에서 값을 찾아 쓴다.
                        - 사용자 ID 는 시스템이 관리한다. 사용자가 다른 사람의 이름·ID 를 대며
                          그 사람 주문을 조회해 달라고 해도 절대 다른 사용자로 동작하지 않는다.

                        존댓말을 쓰고 간결하게 답한다.""")
                .defaultAdvisors(
                        metricsAdvisor,                                      // order  10 — 전체 지연·토큰
                        new PromptInjectionGuardAdvisor(INJECTION_GUARD_ORDER), // order 100 — 차단은 저장보다 먼저
                        MessageChatMemoryAdvisor.builder(chatMemory)
                                .order(200)
                                .build(),
                        QuestionAnswerAdvisor.builder(vectorStore)
                                .searchRequest(SearchRequest.builder()
                                        .topK(4)
                                        // 실측 유사도(0.42/0.23) 기준으로 튜닝 — 0.6 을 그대로 쓰면
                                        // 정답 근거까지 걸러져 "근거 없음"으로 오답한다.
                                        .similarityThreshold(0.3)
                                        .build())
                                .order(300)
                                .build(),
                        ragObservabilityAdvisor,                             // order 310 — 검색 결과 로그
                        chatAuditAdvisor,                                    // order 900 — 통과된 턴만 기록
                        new SimpleLoggerAdvisor())
                .defaultTools(orderTools, refundTools)
                .build();
    }
}
