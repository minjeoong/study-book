package com.skala.lab3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Day 3 종합 실습 — 규정(RAG) + 주문(Tool) 상담 에이전트.
 *
 * <p>{@code ./gradlew bootRun} 으로 띄운 뒤 {@code /swagger-ui.html} 에서 확인한다.
 * 시작 시 {@code docs/*.md} 규정 문서를 자동으로 인제스트하므로 별도 준비 없이 바로
 * 질문을 던질 수 있다.
 */
@SpringBootApplication
public class Day3Lab3Application {

    public static void main(String[] args) {
        SpringApplication.run(Day3Lab3Application.class, args);
    }
}
