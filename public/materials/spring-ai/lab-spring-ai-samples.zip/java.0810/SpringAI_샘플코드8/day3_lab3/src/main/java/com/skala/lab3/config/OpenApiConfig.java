package com.skala.lab3.config;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Swagger UI에 로그인(Authorize) 버튼을 노출한다.
 *
 * <p>SecurityConfig가 HTTP Basic 인증을 강제하지만, 이 설정이 없으면 springdoc은
 * 그 사실을 문서화하지 않아 Swagger UI에 자물쇠 아이콘이 뜨지 않는다. 우측 상단
 * Authorize에 user1/user1pass 등을 한 번만 입력하면 이후 모든 "Try it out" 호출에
 * 자동으로 인증 헤더가 붙는다.
 */
@Configuration
@SecurityScheme(name = "basicAuth", type = SecuritySchemeType.HTTP, scheme = "basic")
public class OpenApiConfig {

    @Bean
    public OpenAPI day3OpenApi() {
        return new OpenAPI().addSecurityItem(new SecurityRequirement().addList("basicAuth"));
    }
}
