package com.skala.lab3.domain;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Repository;

/**
 * 환불 티켓 저장소.
 *
 * <p>접수({@link #create})와 승인({@link #approve})을 서로 다른 API 경로로 분리한다.
 * 승인 경로는 도구 목록에 올라가지 않으므로 모델은 접수까지만 할 수 있다 — 실제 처리는
 * 사람이 {@code POST /lab3/admin/tickets/{no}/approve} 를 눌러야만 일어난다.
 */
@Repository
public class TicketRepository {

    private final Map<String, RefundTicket> tickets = new ConcurrentHashMap<>();
    private final AtomicInteger sequence = new AtomicInteger(1000);

    public RefundTicket create(String orderId, String userId, String reason) {
        String no = "RF-" + sequence.incrementAndGet();
        RefundTicket ticket = new RefundTicket(no, orderId, userId, reason, Instant.now(), TicketStatus.PENDING);
        tickets.put(no, ticket);
        return ticket;
    }

    public Optional<RefundTicket> findByNo(String no) {
        return Optional.ofNullable(tickets.get(no));
    }

    public List<RefundTicket> pending() {
        return tickets.values().stream()
                .filter(t -> t.status() == TicketStatus.PENDING)
                .toList();
    }

    /** 사람만 호출한다(컨트롤러가 {@code @PreAuthorize("hasRole('ADMIN')")} 로 보호한다). */
    public Optional<RefundTicket> approve(String no) {
        return findByNo(no).map(t -> {
            RefundTicket approved = t.approve();
            tickets.put(no, approved);
            return approved;
        });
    }
}
