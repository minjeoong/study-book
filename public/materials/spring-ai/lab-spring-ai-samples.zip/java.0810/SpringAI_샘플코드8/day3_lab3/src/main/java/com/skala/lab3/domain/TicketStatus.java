package com.skala.lab3.domain;

/** 환불 티켓의 상태. 모델(도구)이 만들 수 있는 상태는 오직 {@link #PENDING} 뿐이다. */
public enum TicketStatus {
    PENDING,
    APPROVED
}
