package com.skala.lab3.tool;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.model.ToolContext;

import com.skala.lab3.domain.OrderRepository;

/**
 * 도구는 모델 없이도 테스트할 수 있다 — 특히 권한 검증은 모델을 거치지 않고
 * 직접 확인하는 편이 확실하다(요구사항 2 · 확인 항목 #2).
 */
class OrderToolsTest {

    private final OrderTools tools = new OrderTools(new OrderRepository());

    @Test
    @DisplayName("본인 주문은 조회된다")
    void 본인_주문은_조회된다() {
        var result = tools.getOrder("12345", new ToolContext(Map.of("userId", "user1")));

        assertThat(result.orderId()).isEqualTo("12345");
        assertThat(result.status()).isEqualTo("배송중");
    }

    @Test
    @DisplayName("타인의 주문번호를 대면 조회되지 않는다 — ID 주입 방어")
    void 타인_주문은_조회되지_않는다() {
        // 99999 는 user2 의 주문이다. user1 이 이 번호를 대도 막혀야 한다.
        assertThatThrownBy(() -> tools.getOrder("99999", new ToolContext(Map.of("userId", "user1"))))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("주문을 찾을 수 없습니다.");
    }

    @Test
    @DisplayName("없는 주문번호도 같은 문구로 응답한다 — 존재 여부를 구분해 알려주면 그 자체가 정보 노출이다")
    void 없는_주문도_같은_문구다() {
        assertThatThrownBy(() -> tools.getOrder("00000", new ToolContext(Map.of("userId", "user1"))))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("주문을 찾을 수 없습니다.");
    }

    @Test
    @DisplayName("toolContext 에 userId 가 없으면 즉시 실패한다")
    void 컨텍스트가_없으면_실패한다() {
        assertThatThrownBy(() -> tools.getOrder("12345", new ToolContext(Map.of())))
                .isInstanceOf(IllegalStateException.class);
    }
}
