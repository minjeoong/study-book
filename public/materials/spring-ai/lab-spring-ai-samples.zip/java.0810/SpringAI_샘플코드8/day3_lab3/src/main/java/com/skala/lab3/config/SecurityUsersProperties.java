package com.skala.lab3.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * {@code application.yml} 의 {@code lab3.users} 를 바인딩한다.
 * 데모 계정을 코드에 하드코딩하지 않고 설정으로 분리해 두는 것만으로도
 * 운영 전환 시 자격 증명 저장소(LDAP·DB)로 바꿔 끼우기 쉬워진다.
 */
@ConfigurationProperties(prefix = "lab3")
public record SecurityUsersProperties(List<UserSpec> users) {

    public record UserSpec(String username, String password, String roles) {
    }
}
