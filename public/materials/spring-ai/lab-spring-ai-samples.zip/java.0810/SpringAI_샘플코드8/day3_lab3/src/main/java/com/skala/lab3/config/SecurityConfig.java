package com.skala.lab3.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

/**
 * 추가 구현 ② — 인증·인가 (요구사항 2 · 3 을 코드로 강제한다).
 *
 * <p>{@code userId} 를 요청 파라미터로 받으면 클라이언트가 아무 값이나 넣어 남의 주문을
 * 조회할 수 있다. 여기서는 {@code userId} 를 <b>절대 파라미터로 받지 않고</b>
 * {@code Authentication#getName()} 에서만 얻는다({@code web.ChatController} 참고) —
 * 그 값이 그대로 {@code ToolContext} 로 흘러 도구의 권한 검증에 쓰인다.
 *
 * <p>승인 API({@code /lab3/admin/**})는 {@code @PreAuthorize("hasRole('ADMIN')")} 와
 * 필터 체인 양쪽에서 이중으로 막는다 — 모델은 이 경로를 도구로 가지고 있지 않으므로
 * 애초에 호출할 수 없고, 사람이 직접 호출하더라도 관리자가 아니면 거부된다.
 */
@Configuration
@EnableMethodSecurity
@EnableConfigurationProperties(SecurityUsersProperties.class)
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService userDetailsService(SecurityUsersProperties props, PasswordEncoder encoder) {
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
        props.users().forEach(u -> manager.createUser(User.withUsername(u.username())
                .password(encoder.encode(u.password()))
                .roles(u.roles())
                .build()));
        return manager;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/swagger-ui/**", "/swagger-ui.html", "/v3/api-docs/**",
                                "/actuator/**").permitAll()
                        .requestMatchers("/lab3/admin/**").hasRole("ADMIN")
                        .requestMatchers("/lab3/**").authenticated()
                        .anyRequest().permitAll())
                .httpBasic(Customizer.withDefaults())
                .build();
    }
}
