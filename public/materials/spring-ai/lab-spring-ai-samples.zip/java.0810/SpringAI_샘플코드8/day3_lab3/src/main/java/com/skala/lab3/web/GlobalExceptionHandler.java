package com.skala.lab3.web;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 상세는 로그에만 남기고 사용자에게는 traceId 만 준다.
 * "안 돼요, traceId abcd1234 예요" 한마디면 로그에서 그 요청을 바로 찾는다.
 */
@RestControllerAdvice(basePackages = "com.skala.lab3.web")
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> handle(Exception e) {
        String traceId = MDC.get("traceId");
        log.error("[{}] 처리 실패", traceId, e);
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(Map.of("message", "잠시 후 다시 시도해 주세요.", "traceId", String.valueOf(traceId)));
    }
}
