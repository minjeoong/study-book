package com.skala.lab3.web;

/** {@code userId} 는 여기 없다 — 인증된 사용자에서만 얻는다(요구사항 2). */
public record ChatRequest(String message, String sessionId) {
}
