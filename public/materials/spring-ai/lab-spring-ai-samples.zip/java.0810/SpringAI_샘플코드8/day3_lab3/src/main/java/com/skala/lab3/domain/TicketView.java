package com.skala.lab3.domain;

/** 도구·API 응답에 노출하는 환불 티켓 정보. */
public record TicketView(String ticketNo, String status, String message) {
}
