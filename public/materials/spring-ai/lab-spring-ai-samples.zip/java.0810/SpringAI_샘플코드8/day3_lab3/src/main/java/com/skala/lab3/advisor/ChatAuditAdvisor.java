package com.skala.lab3.advisor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ai.chat.client.ChatClientRequest;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.api.CallAdvisor;
import org.springframework.ai.chat.client.advisor.api.CallAdvisorChain;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.stereotype.Component;

/**
 * 안전 Advisor ② — 감사 로그 (요구사항 6 · 7).
 *
 * <p>인젝션 차단({@link PromptInjectionGuardAdvisor}, order 100)보다 안쪽(order 900)에 둬서,
 * <b>차단되지 않고 실제로 모델까지 도달한 턴만</b> "누가·어떤 세션에서·무엇을 물어
 * 무엇을 받았는지"를 남긴다. 차단된 턴은 인젝션 가드 자신의 로그에 별도로 남으므로
 * 이 Advisor 의 로그에 있다는 것 자체가 "정상적으로 처리된 대화"라는 증거가 된다.
 */
@Component
public class ChatAuditAdvisor implements CallAdvisor {

    private static final Logger audit = LoggerFactory.getLogger("AI_CHAT_AUDIT");

    @Override
    public ChatClientResponse adviseCall(ChatClientRequest request, CallAdvisorChain chain) {
        String userId = String.valueOf(request.context().get("userId"));
        String sessionId = String.valueOf(request.context().get(ChatMemory.CONVERSATION_ID));
        String question = request.prompt().getUserMessage() == null
                ? "" : request.prompt().getUserMessage().getText();

        ChatClientResponse response = chain.nextCall(request);

        String answer = response.chatResponse() == null || response.chatResponse().getResult() == null
                ? "" : String.valueOf(response.chatResponse().getResult().getOutput().getText());

        audit.info("event=CHAT_TURN traceId={} user={} session={} question=\"{}\" answerChars={}",
                MDC.get("traceId"), userId, sessionId, question, answer.length());

        return response;
    }

    @Override
    public String getName() {
        return "chatAudit";
    }

    /** 인젝션 가드(100)보다 안쪽 — 차단된 턴은 여기까지 오지 않는다. */
    @Override
    public int getOrder() {
        return 900;
    }
}
