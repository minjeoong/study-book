package com.skala.lab3.web;

import java.io.IOException;
import java.util.UUID;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * 추가 구현 — 요청 추적 ID (Step6 관측성: "한 요청을 처음부터 끝까지 따라갈 수 있어야 한다").
 *
 * <p>요청마다 짧은 traceId 를 발급해 MDC 에 넣는다. 컨트롤러 로그·RAG 검색 로그·도구 감사
 * 로그·Advisor 계측 로그가 전부 같은 traceId 로 남으므로, 로그를 traceId 로 grep 하면
 * 그 요청이 컨트롤러 → 안전 필터 → 메모리 → RAG → 도구 → 모델 순으로 어디를 거쳤는지
 * 한 줄씩 그대로 재구성된다. 응답 헤더 {@code X-Trace-Id} 로도 내려줘, 장애 문의 시
 * "안 돼요, traceId 이거예요" 한마디면 로그에서 바로 찾을 수 있다.
 */
@Component
public class TraceIdFilter extends OncePerRequestFilter {

    private static final String HEADER = "X-Trace-Id";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String traceId = UUID.randomUUID().toString().substring(0, 8);
        MDC.put("traceId", traceId);
        response.setHeader(HEADER, traceId);
        try {
            chain.doFilter(request, response);
        } finally {
            MDC.remove("traceId");
        }
    }
}
