package com.skala.lab3.tool;

import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import com.skala.lab3.domain.OrderRepository;
import com.skala.lab3.domain.OrderView;

/**
 * 주문 조회 도구 (요구사항 1 · 2).
 *
 * <p>사용자 ID 는 프롬프트가 아니라 {@link ToolContext} 로 들어온다 — 모델이 절대
 * 바꿔 부를 수 없는 통로다({@code ChatClient.prompt().toolContext(...)} 로 주입,
 * 실제 값은 인증된 {@code Authentication#getName()}). 주문 조회는 그 값과
 * {@code orderId} 를 함께 쿼리에 걸어 남의 주문이 결과 집합에 아예 나타나지 않게 한다.
 */
@Component
public class OrderTools {

    private final OrderRepository orders;

    public OrderTools(OrderRepository orders) {
        this.orders = orders;
    }

    @Tool(description = """
            주문번호로 배송 상태와 예상 도착일을 조회한다. 사용자 본인의 주문만 조회할 수 있다.
            예) "12345 어디쯤이야?", "내 주문 상태 알려줘"(주문번호가 없으면 되물어야 한다)""")
    public OrderView getOrder(
            @ToolParam(description = "조회할 주문번호(숫자 5자리, 예: 12345)") String orderId,
            ToolContext toolContext) {

        String userId = currentUser(toolContext);

        return orders.findByIdAndOwnerId(orderId, userId)   // 권한은 쿼리 안에
                .map(OrderView::from)
                .orElseThrow(() -> new IllegalArgumentException("주문을 찾을 수 없습니다."));
    }

    /** 사용자 ID 는 ToolContext 에서 꺼낸다 — 모델이 넘긴 값이 아니라 인증 주체에서 온 값이다. */
    private String currentUser(ToolContext toolContext) {
        Object userId = toolContext == null ? null : toolContext.getContext().get("userId");
        if (userId == null) {
            throw new IllegalStateException("toolContext 에 userId 가 없습니다 — 호출부 설정을 확인하세요.");
        }
        return userId.toString();
    }
}
