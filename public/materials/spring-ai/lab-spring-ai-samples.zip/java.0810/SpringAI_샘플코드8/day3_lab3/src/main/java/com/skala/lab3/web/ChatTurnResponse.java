package com.skala.lab3.web;

import java.util.List;

/**
 * {@code sources} 는 모델이 답변 문장 안에 적어 준 인용이 아니라, QuestionAnswerAdvisor 가
 * 실제로 검색해 컨텍스트에 남긴 문서 목록에서 뽑는다(요구사항 4). 모델의 서술을 믿는 대신
 * 검색 결과 자체를 근거로 삼아야 "출처가 붙는다"는 요구사항이 흔들리지 않는다.
 */
public record ChatTurnResponse(String answer, String sessionId, String traceId, List<String> sources) {
}
