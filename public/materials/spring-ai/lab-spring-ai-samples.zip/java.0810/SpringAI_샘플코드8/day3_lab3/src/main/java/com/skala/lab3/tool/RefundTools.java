package com.skala.lab3.tool;

import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import com.skala.lab3.audit.AuditLogService;
import com.skala.lab3.domain.OrderRepository;
import com.skala.lab3.domain.RefundTicket;
import com.skala.lab3.domain.TicketRepository;
import com.skala.lab3.domain.TicketView;

/**
 * 환불 접수 도구 — 승인 게이트(요구사항 3).
 *
 * <p>자율성의 크기는 되돌릴 수 있는 정도에 맞춘다. 조회는 도구가 자유롭게 하지만, 환불처럼
 * 되돌리기 어려운 쓰기 작업은 도구가 <b>접수만</b> 하고 상태를 {@code PENDING} 으로 남긴다.
 * 실제 승인·처리는 {@code POST /lab3/admin/tickets/{no}/approve}(사람 전용, ROLE_ADMIN)
 * 로만 가능하며, 이 경로는 모델에게 도구로 등록되지 않으므로 모델은 절대 승인 자체를
 * 실행할 수 없다.
 */
@Component
public class RefundTools {

    private final OrderRepository orders;
    private final TicketRepository tickets;
    private final AuditLogService audit;

    public RefundTools(OrderRepository orders, TicketRepository tickets, AuditLogService audit) {
        this.orders = orders;
        this.tickets = tickets;
        this.audit = audit;
    }

    @Tool(description = """
            환불을 접수한다. 실제 환불 처리가 아니라 접수만 하며, 담당자 승인 후 처리된다.
            사용자가 명시적으로 환불·반품을 요청했을 때만 부른다. 주문번호와 사유가 모두 있어야 하고,
            둘 중 하나라도 없으면 도구를 부르지 말고 되물어야 한다.""")
    public TicketView requestRefund(
            @ToolParam(description = "환불 대상 주문번호(숫자 5자리)") String orderId,
            @ToolParam(description = "환불 사유(사용자가 말한 그대로, 예: 단순 변심)") String reason,
            ToolContext toolContext) {

        String userId = currentUser(toolContext);

        orders.findByIdAndOwnerId(orderId, userId)          // 권한 먼저 — 남의 주문은 접수 자체가 안 된다
                .orElseThrow(() -> new IllegalArgumentException("주문을 찾을 수 없습니다."));

        RefundTicket ticket = tickets.create(orderId, userId, reason);   // 상태: PENDING
        audit.log("REFUND_REQUESTED", userId, orderId, ticket.no());

        return new TicketView(ticket.no(), ticket.status().name(),
                "접수되었습니다. 담당자 승인 후 처리됩니다.");
    }

    @Tool(description = "환불 접수 번호로 처리 상태를 조회한다. 접수 시 안내받은 번호(RF-로 시작)가 필요하다.")
    public TicketView refundStatus(@ToolParam(description = "환불 접수 번호(예: RF-1001)") String ticketNo,
                                    ToolContext toolContext) {

        String userId = currentUser(toolContext);

        return tickets.findByNo(ticketNo)
                .filter(t -> t.userId().equals(userId))      // 본인 접수 건만 — 접수 번호 추측 공격 방지
                .map(t -> new TicketView(t.no(), t.status().name(), "현재 상태: " + t.status()))
                .orElseThrow(() -> new IllegalArgumentException("해당 접수 번호를 찾을 수 없습니다."));
    }

    private String currentUser(ToolContext toolContext) {
        Object userId = toolContext == null ? null : toolContext.getContext().get("userId");
        if (userId == null) {
            throw new IllegalStateException("toolContext 에 userId 가 없습니다 — 호출부 설정을 확인하세요.");
        }
        return userId.toString();
    }
}
