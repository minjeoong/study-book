package com.skala.lab3.config;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import com.skala.lab3.service.DocIngestService;

/**
 * 기동 시 규정 문서를 자동으로 인제스트한다. 수동으로 {@code /lab3/ingest} 를 먼저
 * 호출해야 하는 번거로움을 없애, 앱을 띄우자마자 RAG 질문을 바로 던져 볼 수 있게 한다.
 */
@Component
public class DataInitializer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final DocIngestService ingestService;

    public DataInitializer(DocIngestService ingestService) {
        this.ingestService = ingestService;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        Resource[] docs = new PathMatchingResourcePatternResolver().getResources("classpath:/docs/*.md");
        Arrays.stream(docs).forEach(doc -> ingestService.ingest(doc, "policy"));
        log.info("규정 문서 {}건 자동 인제스트 완료", docs.length);
    }
}
