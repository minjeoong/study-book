package com.skala.lab3.domain;

import java.time.Instant;

/** 환불 접수 티켓. 도구는 이 레코드를 {@link TicketStatus#PENDING} 상태로만 만들 수 있다. */
public record RefundTicket(String no, String orderId, String userId, String reason,
                            Instant requestedAt, TicketStatus status) {

    public RefundTicket approve() {
        return new RefundTicket(no, orderId, userId, reason, requestedAt, TicketStatus.APPROVED);
    }
}
