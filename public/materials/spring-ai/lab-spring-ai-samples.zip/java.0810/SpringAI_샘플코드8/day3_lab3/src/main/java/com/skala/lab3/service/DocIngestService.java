package com.skala.lab3.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

/**
 * RAG 인제스트(Indexing) — 규정 문서를 읽어 VectorStore 에 넣는다(요구사항 4).
 *
 * <p>읽기(Tika) → 나누기(TokenTextSplitter) → 메타데이터 보강 → 저장(VectorStore).
 * 같은 문서를 다시 넣으면 청크가 중복 적재되므로 source 기준으로 먼저 지우고 다시 넣는다.
 */
@Service
public class DocIngestService {

    private static final Logger log = LoggerFactory.getLogger(DocIngestService.class);

    private final VectorStore vectorStore;

    public DocIngestService(VectorStore vectorStore) {
        this.vectorStore = vectorStore;
    }

    public record IngestResult(String source, int chunks) {
    }

    public IngestResult ingest(Resource file, String docType) {
        String source = file.getFilename() == null ? "unknown" : file.getFilename();
        deleteExisting(source);

        List<Document> raw = new TikaDocumentReader(file).get();

        // 청크를 200토큰 단위로 잘게 나눈다 — 규정 문서 하나를 통째로 1청크로 넣으면
        // "반품 가능 기간"과 "반품 배송비"가 한 벡터에 뭉개져 인접 주제(배송 규정의 배송비)에
        // 밀리는 경우가 실측됐다(교재 기본값 800 으로는 "왕복 배송비" 질의가 근거를 못 찾았다).
        List<Document> chunks = TokenTextSplitter.builder()
                .withChunkSize(200)
                .withMinChunkSizeChars(80)
                .withKeepSeparator(true)
                .build()
                .apply(raw);

        List<Document> enriched = chunks.stream()
                .map(chunk -> {
                    Map<String, Object> meta = new HashMap<>(chunk.getMetadata());
                    meta.put("source", source);
                    meta.put("docType", docType);
                    return new Document(chunk.getText(), meta);
                })
                .toList();

        vectorStore.add(enriched);
        log.info("인제스트 완료 source={} chunks={}", source, enriched.size());
        return new IngestResult(source, enriched.size());
    }

    private void deleteExisting(String source) {
        try {
            vectorStore.delete("source == '" + source + "'");
        } catch (Exception e) {
            log.debug("기존 청크 삭제를 건너뜁니다: {}", e.getMessage());
        }
    }
}
