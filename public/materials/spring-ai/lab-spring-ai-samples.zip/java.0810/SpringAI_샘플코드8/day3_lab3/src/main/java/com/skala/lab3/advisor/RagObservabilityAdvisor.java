package com.skala.lab3.advisor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ai.chat.client.ChatClientRequest;
import org.springframework.ai.chat.client.ChatClientResponse;
import org.springframework.ai.chat.client.advisor.api.AdvisorChain;
import org.springframework.ai.chat.client.advisor.api.BaseAdvisor;
import org.springframework.ai.chat.client.advisor.vectorstore.QuestionAnswerAdvisor;
import org.springframework.ai.document.Document;
import org.springframework.stereotype.Component;

/**
 * 추가 구현 ① — RAG 근거 검색 로그.
 *
 * <p>{@code QuestionAnswerAdvisor}(order 300) 바로 뒤(order 310)에 붙어, 그 순간 컨텍스트에
 * 쌓인 검색 결과 개수 · 유사도 점수를 traceId 와 함께 남긴다. Step6 관측성에서 요구하는
 * "검색 3건(0.72/0.68/0.51) → 도구 …" 형태의 end-to-end 로그를 실제로 만들어 준다.
 * 근거가 0건이면(=문서 밖 질문) 그 사실 자체도 로그로 남아, "모른다고 답했는지"를
 * 나중에 검증할 수 있다.
 */
@Component
public class RagObservabilityAdvisor implements BaseAdvisor {

    private static final Logger log = LoggerFactory.getLogger(RagObservabilityAdvisor.class);

    @Override
    public ChatClientRequest before(ChatClientRequest request, AdvisorChain chain) {
        Object raw = request.context().get(QuestionAnswerAdvisor.RETRIEVED_DOCUMENTS);
        if (raw instanceof List<?> docs && !docs.isEmpty()) {
            String scores = docs.stream()
                    .filter(Document.class::isInstance)
                    .map(Document.class::cast)
                    .map(d -> d.getScore() == null ? "?" : "%.2f".formatted(d.getScore()))
                    .reduce((a, b) -> a + "/" + b)
                    .orElse("?");
            log.info("[RAG] traceId={} 검색 {}건({})", MDC.get("traceId"), docs.size(), scores);
        } else {
            log.info("[RAG] traceId={} 근거 문서 없음", MDC.get("traceId"));
        }
        return request;
    }

    @Override
    public ChatClientResponse after(ChatClientResponse response, AdvisorChain chain) {
        return response;
    }

    @Override
    public String getName() {
        return "ragObservability";
    }

    @Override
    public int getOrder() {
        return 310;
    }
}
