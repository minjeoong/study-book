package com.skala.lab3.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

/**
 * 비즈니스 이벤트 감사 로그 — 환불 접수처럼 "누가·언제·무엇을" 남겨야 하는 이벤트 전용.
 *
 * <p>도구 호출 자체의 감사는 {@link ToolCallAuditAspect} 가 모든 {@code @Tool} 을 가로채
 * 자동으로 남기므로, 여기서는 그중에서도 되돌아볼 필요가 있는 <b>업무 이벤트</b>만 한 번 더
 * 구조화해 남긴다(예: REFUND_REQUESTED). 로그는 {@code AI_CHAT_AUDIT} 로거로 분리해
 * 운영에서 별도 파일 · 보존 기간을 적용하기 쉽게 한다.
 */
@Component
public class AuditLogService {

    private static final Logger audit = LoggerFactory.getLogger("AI_CHAT_AUDIT");

    public void log(String event, String userId, String targetId, String refNo) {
        audit.info("event={} user={} target={} ref={} traceId={}",
                event, userId, targetId, refNo, MDC.get("traceId"));
    }
}
