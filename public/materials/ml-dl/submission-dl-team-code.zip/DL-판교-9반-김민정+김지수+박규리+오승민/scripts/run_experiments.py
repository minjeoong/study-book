#!/usr/bin/env python

from __future__ import annotations

import argparse
import json
import pickle
import platform
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from wafercnn.config import CLASS_NAMES, MINORITY_CLASSES, ExperimentConfig, RESULTS_DIR
from wafercnn.data import duplicate_audit, load_splits, make_loaders, shape_audit
from wafercnn.engine import resolve_device
from wafercnn.losses import build_criterion, weight_table
from wafercnn.metrics import evaluate
from wafercnn.models import build_model, parameter_report
from wafercnn.runner import RunResult, run_experiment

# --- 공통 학습 조건 --------------------------------------------------------
# 실험마다 epoch 수가 달라 생기는 왜곡을 없애기 위해 Early Stopping 을 전
# 실험에 동일하게 건다. 감시 지표는 가이드 권고안인 valid loss 를 쓴다.
COMMON = dict(max_epochs=30, patience=5)

DROPOUT_P = 0.3
WEIGHT_DECAY = 1e-4


def experiment_configs(seeds: tuple[int, ...]) -> list[ExperimentConfig]:
    """8개 조합. Baseline 에서 바뀐 항목만 인자로 준다."""

    def cfg(name: str, changed: str, **changes) -> ExperimentConfig:
        return ExperimentConfig(
            name=name, changed=changed, parent="E1_base", seeds=seeds, **COMMON, **changes
        )

    return [
        cfg("E1_base", "(기준) 규제·가중치 없음"),
        cfg("E2_bn", "BatchNorm 추가", norm="batch"),
        cfg("E3_dropout", f"Dropout p={DROPOUT_P} 추가", dropout_p=DROPOUT_P),
        cfg("E4_cw", "손실: CE -> CE(역빈도 가중)", loss="ce_inverse"),
        cfg("E5_wd", f"Adam weight decay {WEIGHT_DECAY}", weight_decay=WEIGHT_DECAY),
        cfg("E6_dropout_bn", "Dropout + BatchNorm", dropout_p=DROPOUT_P, norm="batch"),
        cfg(
            "E7_dropout_bn_cw",
            "Dropout + BatchNorm + Class Weight",
            dropout_p=DROPOUT_P,
            norm="batch",
            loss="ce_inverse",
        ),
        cfg(
            "E8_dropout_bn_cw_wd",
            "Dropout + BatchNorm + Class Weight + Weight Decay",
            dropout_p=DROPOUT_P,
            norm="batch",
            loss="ce_inverse",
            weight_decay=WEIGHT_DECAY,
        ),
    ]


def _json_default(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    raise TypeError(type(obj))


def write_json(path: Path, payload) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=_json_default),
        encoding="utf-8",
    )


def diagnose(splits, device: torch.device) -> dict:
    """학습 전에 확인 가능한 사실만 모은다 (보고서 '진단' 장의 근거)."""
    unlabeled = splits.raw_total - splits.labeled_total
    none_pool = unlabeled + splits.true_none_total
    return {
        "raw_wafers": splits.raw_total,
        "labeled_wafers": splits.labeled_total,
        "unlabeled_wafers": unlabeled,
        "true_none_wafers": splits.true_none_total,
        "none_pool_used_by_baseline": none_pool,
        "true_none_share_in_none_pool(%)": round(
            100 * splits.true_none_total / none_pool, 2
        ),
        "split_sizes": {
            "train": int(len(splits.y_train)),
            "valid": int(len(splits.y_valid)),
            "test": int(len(splits.y_test)),
        },
        "class_distribution": splits.class_table().round(3).to_dict("records"),
        "minority_classes": list(MINORITY_CLASSES),
        "wafer_shape_audit": shape_audit(),
        "duplicate_audit(%)": {k: round(v, 3) for k, v in duplicate_audit(splits).items()},
        "class_weights": weight_table(splits.y_train),
        "baseline_parameters": parameter_report(build_model(ExperimentConfig(name="base"))),
        "batchnorm_parameters": parameter_report(
            build_model(ExperimentConfig(name="bn", norm="batch"))
        ),
        "environment": {
            "python": platform.python_version(),
            "torch": torch.__version__,
            "platform": platform.platform(),
            "device": str(device),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default=None, help="cpu / mps / cuda (기본: 자동)")
    parser.add_argument("--seeds", type=int, default=3, help="조합당 반복 seed 수")
    args = parser.parse_args()

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    device = torch.device(args.device) if args.device else resolve_device()
    splits = load_splits()
    write_json(RESULTS_DIR / "diagnosis.json", diagnose(splits, device))

    seeds = (42, 1, 7)[: args.seeds]
    configs = experiment_configs(seeds)

    # --- 8개 조합 학습 (seed 별 가중치는 Test 평가를 위해 보관) ---
    results: dict[str, RunResult] = {}
    for config in configs:
        runs = [
            run_experiment(config.replace(seeds=(s,)), splits, device, keep_state=True)
            for s in config.seeds
        ]
        merged = RunResult(
            config=config,
            runs=[r for part in runs for r in part.runs],
            params=runs[0].params,
        )
        results[config.name] = merged

    # --- 잡음 폭: 기준선(#1)의 seed 표준편차 ---
    # 같은 설정을 seed 만 바꿔 돌렸을 때의 흔들림이므로, 이보다 작은 차이는
    # 기법의 효과라고 말할 수 없다.
    baseline = results["E1_base"]
    noise = baseline.std("macro_f1")

    # --- 최종 선정 -----------------------------------------------------------
    # 주 지표는 소수 3클래스 Recall 이다. 미검출(FN) 비용이 오탐(FP) 비용보다
    # 훨씬 큰 문제이므로 "불량을 몇 건 잡았는가"를 최우선으로 둔다.
    # 게이트는 Macro-F1: Recall 만 좇다 보면 소수 클래스를 남발해 Precision 이
    # 무너지므로, 기준선 대비 하락폭이 MACRO_F1_DROP_GATE 를 넘으면 탈락시킨다.
    # 동점 처리는 잡음 폭 기준이다. 주 지표 차이가 seed 표준편차 이내면 개선으로
    # 보지 않고 더 단순한 구성을 남긴다.
    MACRO_F1_DROP_GATE = 0.05

    base_f1 = baseline.mean("macro_f1")
    base_minority = baseline.mean("minority_recall")
    passed = [
        r
        for r in results.values()
        if r.mean("macro_f1") >= base_f1 - MACRO_F1_DROP_GATE
        and r.mean("minority_recall") >= base_minority - 1e-9
    ] or [baseline]

    best = max(passed, key=lambda r: r.mean("minority_recall"))
    # 최고와 잡음 폭 이내인 후보 중 가장 단순한(=변경 항목이 적은) 것을 고른다.
    ties = [
        r
        for r in passed
        if best.mean("minority_recall") - r.mean("minority_recall") <= noise
    ]
    complexity = lambda r: (  # noqa: E731
        (r.config.norm != "none")
        + (r.config.dropout_p > 0)
        + (r.config.loss != "ce")
        + (r.config.weight_decay > 0)
    )
    champion = min(ties, key=lambda r: (complexity(r), -r.mean("macro_f1")))

    # --- Test 단일 평가 (선정 모델 + 기준선) ---
    def test_block(result: RunResult) -> dict:
        """저장된 seed 별 가중치로 Test 를 seed 당 1회 평가한다.

        '최고 seed'만 고르면 Test 점수에 선택 편의가 생기므로 전 seed 를
        평가해 평균과 표준편차를 함께 보고한다.
        """
        config = result.config
        criterion = build_criterion(config, splits.y_train).to(device)
        evals = []
        for run in result.runs:
            model = build_model(config)
            model.load_state_dict(run.state_dict)
            loaders = make_loaders(
                splits, batch_size=config.batch_size, seed=run.seed
            )
            evals.append(
                evaluate(
                    model.to(device),
                    loaders["test"],
                    criterion,
                    device,
                    keep_predictions=True,
                )
            )

        def agg(attr):
            vals = [getattr(e, attr) for e in evals]
            return round(float(np.mean(vals)), 4), round(float(np.std(vals)), 4)

        acc_mean, acc_std = agg("accuracy")
        f1_mean, f1_std = agg("macro_f1")
        min_mean, min_std = agg("minority_recall")
        return {
            "seeds": [r.seed for r in result.runs],
            "accuracy_mean(%)": round(acc_mean, 2),
            "accuracy_std(%)": round(acc_std, 2),
            "macro_f1_mean": f1_mean,
            "macro_f1_std": f1_std,
            "minority_recall_mean": min_mean,
            "minority_recall_std": min_std,
            "defect_recall_mean": agg("defect_recall")[0],
            "recall_per_class_mean": {
                name: round(float(np.mean([e.recall_per_class[name] for e in evals])), 4)
                for name in CLASS_NAMES
            },
            "confusion_matrix_seed0": evals[0].confusion().tolist(),
        }

    final_test = test_block(champion)
    baseline_test = test_block(baseline)

    write_json(
        RESULTS_DIR / "final.json",
        {
            "final_config": champion.config.as_dict(),
            "final_name": champion.config.name,
            "final_parameters": champion.params,
            "baseline_parameters": baseline.params,
            "selection_rule": {
                "primary_metric": "valid_minority_recall (Near-full/Donut/Random)",
                "gate": f"Macro-F1 >= 기준선 - {MACRO_F1_DROP_GATE} AND 소수 Recall >= 기준선",
                "gate_macro_f1_floor": round(float(base_f1 - MACRO_F1_DROP_GATE), 4),
                "gate_minority_floor": round(float(base_minority), 4),
                "noise_band": round(float(noise), 4),
                "passed": [r.config.name for r in passed],
                "best_by_primary": best.config.name,
                "tied_within_noise": [r.config.name for r in ties],
                "minority_classes": list(MINORITY_CLASSES),
            },
            "final_valid": {
                "macro_f1_mean": round(champion.mean("macro_f1"), 4),
                "macro_f1_std": round(champion.std("macro_f1"), 4),
                "accuracy_mean": round(champion.mean("accuracy"), 2),
                "minority_recall_mean": round(champion.mean("minority_recall"), 4),
                "gap_pp": round(champion.overfit_gap, 2),
                "per_seed": [
                    {
                        "seed": r.seed,
                        "macro_f1": round(r.valid.macro_f1, 4),
                        "accuracy": round(r.valid.accuracy, 2),
                        "best_epoch": r.history.best_epoch,
                        "epochs_run": r.history.epochs_run,
                    }
                    for r in champion.runs
                ],
            },
            "final_test": final_test,
            "baseline_test": baseline_test,
        },
    )

    # --- 표 저장 ---
    pd.DataFrame([r.row() for r in results.values()]).to_csv(
        RESULTS_DIR / "experiments.csv", index=False
    )

    # 클래스별 Recall 표. Recall 만 나열하면 "24장 중 24장"인지 "1,549장 중
    # 1,505장"인지 구분이 안 되므로 분할별 건수를 앞에 붙이고, 표본 수 합계
    # 행을 마지막에 둔다 (Recall 은 비율이라 세로 합계가 성립하지 않는다).
    counts = splits.class_table().set_index("class")[["train", "valid", "test"]]
    recall_table = counts.join(
        pd.DataFrame({name: r.recall_column() for name, r in results.items()})
    )
    recall_table.loc["합계"] = [
        counts["train"].sum(),
        counts["valid"].sum(),
        counts["test"].sum(),
        *([pd.NA] * (recall_table.shape[1] - 3)),
    ]
    recall_table.index.name = "class"
    recall_table.to_csv(RESULTS_DIR / "recall_by_class.csv")

    for result in results.values():
        for run in result.runs:
            run.state_dict = {}  # 그림 생성에는 불필요
    with open(RESULTS_DIR / "runs.pkl", "wb") as fh:
        pickle.dump(
            {
                "results": results,
                "final_test": final_test,
                "baseline_test": baseline_test,
                "noise": noise,
                "champion": champion.config.name,
            },
            fh,
        )


if __name__ == "__main__":
    main()
