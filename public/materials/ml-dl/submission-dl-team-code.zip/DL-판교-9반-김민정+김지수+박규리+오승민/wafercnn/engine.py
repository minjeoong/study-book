"""학습 루프, Early Stopping, 재현성 제어.

Early Stopping 은 가이드 권고안대로 valid loss 를 감시하며, 전 실험에
동일하게 적용한다. 실험마다 epoch 수가 달라 생기는 왜곡을 없애기 위해서다.
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass, field

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim


from wafercnn.config import ExperimentConfig
from wafercnn.data import WaferBatches
from wafercnn.metrics import EvalResult, evaluate

MIN_DELTA = 1e-4


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(False)


def resolve_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def build_optimizer(model: nn.Module, config: ExperimentConfig) -> optim.Optimizer:
    """Baseline 과 동일한 Adam.

    weight_decay 인자는 L2 항을 기울기에 더하는 방식(coupled)이라 Adam 의
    적응적 스텝 크기에 나눠지고, 그만큼 규제 강도가 파라미터마다 달라진다.
    실험 #5 의 결과 해석에 이 점이 그대로 걸린다 (보고서 6-2).
    """
    return optim.Adam(
        model.parameters(), lr=config.lr, weight_decay=config.weight_decay
    )


@dataclass
class TrainHistory:
    train_loss: list[float] = field(default_factory=list)
    valid_loss: list[float] = field(default_factory=list)
    train_accuracy: list[float] = field(default_factory=list)
    valid_accuracy: list[float] = field(default_factory=list)
    valid_macro_f1: list[float] = field(default_factory=list)
    best_epoch: int = 0
    epochs_run: int = 0
    seconds: float = 0.0


def train(
    model: nn.Module,
    loaders: dict[str, WaferBatches],
    criterion: nn.Module,
    config: ExperimentConfig,
    device: torch.device,
) -> tuple[nn.Module, TrainHistory]:
    """설정대로 학습하고, valid loss 가 가장 낮았던 시점의 가중치를 복원한다."""
    optimizer = build_optimizer(model, config)
    history = TrainHistory()
    best_value = -float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    stale = 0
    started = time.perf_counter()

    for epoch in range(1, config.max_epochs + 1):
        model.train()
        running, seen, correct = 0.0, 0, 0
        for images, labels in loaders["train"]:
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(images)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()

            running += float(loss.detach()) * labels.numel()
            seen += labels.numel()
            correct += int((logits.argmax(1) == labels).sum())

        valid = evaluate(model, loaders["valid"], criterion, device)
        history.train_loss.append(running / seen)
        history.train_accuracy.append(100.0 * correct / seen)
        history.valid_loss.append(valid.loss)
        history.valid_accuracy.append(valid.accuracy)
        history.valid_macro_f1.append(valid.macro_f1)
        history.epochs_run = epoch

        # '클수록 좋다'로 통일하기 위해 loss 에 음수를 붙인다.
        value = -valid.loss
        if value > best_value + MIN_DELTA:
            best_value, stale = value, 0
            history.best_epoch = epoch
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
            if stale >= config.patience:
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    history.seconds = time.perf_counter() - started
    return model, history
