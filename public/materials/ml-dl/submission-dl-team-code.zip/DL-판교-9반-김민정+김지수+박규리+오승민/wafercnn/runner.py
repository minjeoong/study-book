"""실험 1건 실행: 설정 -> 학습 -> Train/Valid 평가 -> 기록.

Test 셋은 여기서 건드리지 않는다. 모든 설계 판단은 Valid 로만 하고,
Test 는 최종 후보가 확정된 뒤 scripts/run_experiments.py 에서 한 번만 사용한다.
동일 설정을 여러 seed 로 돌려 평균과 표준편차를 남기므로, 실험 간 차이가
seed 잡음보다 큰지 판단할 수 있다.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import torch

from wafercnn.config import ExperimentConfig
from wafercnn.data import WaferSplits, make_loaders
from wafercnn.engine import TrainHistory, set_seed, train
from wafercnn.losses import build_criterion
from wafercnn.metrics import EvalResult, evaluate
from wafercnn.models import build_model, parameter_report


@dataclass
class SeedRun:
    seed: int
    train_eval: EvalResult
    valid: EvalResult
    history: TrainHistory
    state_dict: dict[str, torch.Tensor] = field(default_factory=dict)


@dataclass
class RunResult:
    config: ExperimentConfig
    runs: list[SeedRun]
    params: dict

    # ---- 집계 ----
    def _valid(self, attr: str) -> np.ndarray:
        return np.array([getattr(r.valid, attr) for r in self.runs], dtype=float)

    def _train(self, attr: str) -> np.ndarray:
        return np.array([getattr(r.train_eval, attr) for r in self.runs], dtype=float)

    def mean(self, attr: str, split: str = "valid") -> float:
        return float((self._valid if split == "valid" else self._train)(attr).mean())

    def std(self, attr: str, split: str = "valid") -> float:
        return float((self._valid if split == "valid" else self._train)(attr).std(ddof=0))

    @property
    def overfit_gap(self) -> float:
        """Train Accuracy - Valid Accuracy (%p). 과적합의 직접 측정치."""
        return self.mean("accuracy", "train") - self.mean("accuracy", "valid")

    def row(self) -> dict:
        """실험 결과 표 1행."""
        cfg = self.config
        return {
            "exp": cfg.name,
            "changed": cfg.changed,
            "parent": cfg.parent or "",
            "params": int(self.params["params_total"]),
            "head_share(%)": round(float(self.params["head_share(%)"]), 1),
            "epochs": int(np.mean([r.history.epochs_run for r in self.runs])),
            "best_epoch": int(np.mean([r.history.best_epoch for r in self.runs])),
            "train_acc(%)": round(self.mean("accuracy", "train"), 2),
            "valid_acc(%)": round(self.mean("accuracy", "valid"), 2),
            "gap(%p)": round(self.overfit_gap, 2),
            "valid_macro_f1": round(self.mean("macro_f1"), 4),
            "valid_macro_f1_std": round(self.std("macro_f1"), 4),
            "minority_recall": round(self.mean("minority_recall"), 4),
            "worst_recall": round(self.mean("worst_recall"), 4),
            "worst_class": self.runs[0].valid.worst_class,
            "defect_recall": round(self.mean("defect_recall"), 4),
            "seconds": round(float(np.sum([r.history.seconds for r in self.runs])), 1),
        }

    def recall_column(self) -> dict[str, float]:
        """클래스별 Valid Recall (seed 평균)."""
        keys = self.runs[0].valid.recall_per_class.keys()
        return {
            k: round(float(np.mean([r.valid.recall_per_class[k] for r in self.runs])), 4)
            for k in keys
        }


def run_experiment(
    config: ExperimentConfig,
    splits: WaferSplits,
    device: torch.device,
    keep_state: bool = False,
) -> RunResult:
    runs: list[SeedRun] = []
    params: dict = {}

    for seed in config.seeds:
        set_seed(seed)
        loaders = make_loaders(splits, batch_size=config.batch_size, seed=seed)
        model = build_model(config).to(device)
        params = parameter_report(model)
        criterion = build_criterion(config, splits.y_train).to(device)

        model, history = train(model, loaders, criterion, config, device)

        runs.append(
            SeedRun(
                seed=seed,
                train_eval=evaluate(model, loaders["train_eval"], criterion, device),
                valid=evaluate(
                    model, loaders["valid"], criterion, device, keep_predictions=True
                ),
                history=history,
                state_dict=(
                    {k: v.cpu() for k, v in model.state_dict().items()}
                    if keep_state
                    else {}
                ),
            )
        )
    return RunResult(config=config, runs=runs, params=params)
