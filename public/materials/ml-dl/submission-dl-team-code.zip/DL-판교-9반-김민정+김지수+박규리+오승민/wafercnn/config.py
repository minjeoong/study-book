"""실험 설정과 전역 상수.

한 번에 하나만 바꾸는 ablation을 하려면 "실험 = 설정 객체 1개"라는 규칙이
필요하다. 이 모듈의 ExperimentConfig 가 그 계약이며, 학습 스크립트는
설정 객체 외의 어떤 전역 상태도 참조하지 않는다.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Literal

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "working" / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
CACHE_DIR = RESULTS_DIR / "cache"
FIGURE_DIR = RESULTS_DIR / "figures"

# WM-811K 라벨 순서. Baseline 노트북의 mapping_type 과 동일하게 유지한다.
CLASS_NAMES: tuple[str, ...] = (
    "Center",
    "Donut",
    "Edge-Loc",
    "Edge-Ring",
    "Loc",
    "Near-full",
    "Random",
    "Scratch",
    "none",
)
CLASS_TO_INDEX: dict[str, int] = {name: i for i, name in enumerate(CLASS_NAMES)}

# 학습셋 기준 하위 3개 클래스. 실험 전에 고정해 두고 사후에 바꾸지 않는다.
MINORITY_CLASSES: tuple[str, ...] = ("Near-full", "Donut", "Random")
MINORITY_INDICES: tuple[int, ...] = tuple(CLASS_TO_INDEX[c] for c in MINORITY_CLASSES)
NONE_INDEX: int = CLASS_TO_INDEX["none"]

NormKind = Literal["none", "batch"]
LossKind = Literal["ce", "ce_inverse"]


@dataclass(frozen=True)
class ExperimentConfig:
    """실험 1건의 전체 명세.

    필드 기본값은 Baseline(90-wafer.ipynb)과 동일한 설정이다. 따라서 어떤
    실험이 무엇을 바꿨는지는 `ExperimentConfig()` 와의 차이만 보면 된다.
    """

    name: str
    changed: str = ""        # Baseline 대비 바뀐 항목 (표에 그대로 실린다)
    parent: str | None = None  # 비교 기준이 되는 실험 이름

    # --- 모델 구조 ---
    conv_channels: tuple[int, ...] = (32, 64)
    norm: NormKind = "none"        # "batch" 로 바꾸면 Conv 직후 BatchNorm
    head_hidden: int = 64
    dropout_p: float = 0.0         # > 0 이면 FC1 뒤에 Dropout

    # --- 최적화 (Adam 고정) ---
    lr: float = 1e-3
    weight_decay: float = 0.0
    batch_size: int = 64

    # --- 손실 / 불균형 ---
    loss: LossKind = "ce"          # "ce_inverse" 면 역빈도 클래스 가중

    # --- 학습 종료 조건 (감시 지표는 valid loss 고정) ---
    max_epochs: int = 30
    patience: int = 5

    seeds: tuple[int, ...] = (42,)

    def replace(self, **changes) -> "ExperimentConfig":
        from dataclasses import replace as _replace

        return _replace(self, **changes)

    def as_dict(self) -> dict:
        return asdict(self)
