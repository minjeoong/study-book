"""손실 함수와 클래스 불균형 가중치.

희소 클래스의 오분류에 더 큰 벌점을 주는 재가중(re-weighting)만 다룬다.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

from wafercnn.config import CLASS_NAMES, ExperimentConfig, LossKind
from wafercnn.models import NUM_CLASSES


def class_weights(y_train: np.ndarray, kind: LossKind) -> torch.Tensor | None:
    """학습셋 분포만으로 클래스 가중치를 계산한다 (검증/시험 정보 미사용).

    ce_inverse 는 w_c = N / (K * n_c) 로, 균형 재가중의 표준형이다.
    Near-full 같은 극소수 클래스에 20배 이상의 가중치가 걸려 결정경계가
    크게 밀린다. kind 가 "ce" 면 가중치를 걸지 않는다.
    """
    if kind != "ce_inverse":
        return None
    counts = np.bincount(y_train, minlength=NUM_CLASSES).astype(np.float64)
    counts = np.clip(counts, 1.0, None)
    return torch.tensor(
        len(y_train) / (NUM_CLASSES * counts), dtype=torch.float32
    )


def build_criterion(config: ExperimentConfig, y_train: np.ndarray) -> nn.Module:
    return nn.CrossEntropyLoss(weight=class_weights(y_train, config.loss))


def weight_table(y_train: np.ndarray) -> list[dict]:
    """보고서용: 클래스별 개수와 역빈도 가중치 값."""
    counts = np.bincount(y_train, minlength=NUM_CLASSES)
    inverse = class_weights(y_train, "ce_inverse")
    return [
        {
            "class": CLASS_NAMES[i],
            "train_count": int(counts[i]),
            "train_ratio(%)": round(100 * counts[i] / counts.sum(), 3),
            "w_inverse": round(float(inverse[i]), 3),
        }
        for i in range(NUM_CLASSES)
    ]
