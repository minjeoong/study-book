"""구성 가능한 웨이퍼맵 분류 CNN.

Baseline 과 최종 모델을 서로 다른 클래스로 두면 "무엇을 바꿨는지"가 코드에서
사라진다. 그래서 하나의 클래스가 설정에 따라 Baseline 을 그대로 재현하기도,
용량을 재배분한 최종 구조가 되기도 하도록 만들었다.

블록 규약(Baseline 과 동일):
    Conv3x3(padding=0) -> [BatchNorm] -> ReLU -> MaxPool2
    64 -> 62 -> 31 -> 29 -> 14
"""

from __future__ import annotations

import torch
import torch.nn as nn

from wafercnn.config import ExperimentConfig, NormKind

NUM_CLASSES = 9


def _conv_block(in_ch: int, out_ch: int, norm: NormKind) -> nn.Sequential:
    layers: list[nn.Module] = [nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=0)]
    if norm == "batch":
        # BN 은 Conv 직후, 활성 직전. 활성 입력 분포를 정규화하는 것이 목적이다.
        layers.append(nn.BatchNorm2d(out_ch))
    layers.append(nn.ReLU(inplace=True))
    layers.append(nn.MaxPool2d(kernel_size=2, stride=2))
    return nn.Sequential(*layers)


class WaferCNN(nn.Module):
    """설정 기반 CNN.

    분류 헤드는 Baseline 과 동일한 Flatten + Linear 다. 마지막 특징맵을
    평탄화해 Linear 로 보내므로 공간 위치가 그대로 파라미터에 대응하고,
    "몇 번 픽셀이 켜졌는가"를 외우기 쉽다 (보고서 3-2 진단).
    """

    def __init__(
        self,
        conv_channels: tuple[int, ...] = (32, 64),
        norm: NormKind = "none",
        head_hidden: int = 64,
        dropout_p: float = 0.0,
        image_size: int = 64,
        num_classes: int = NUM_CLASSES,
    ) -> None:
        super().__init__()

        blocks: list[nn.Module] = []
        prev_ch = 1
        size = image_size
        for out_ch in conv_channels:
            blocks.append(_conv_block(prev_ch, out_ch, norm))
            prev_ch = out_ch
            size = (size - 2) // 2
        self.features = nn.Sequential(*blocks)

        flat_dim = prev_ch * size * size
        classifier: list[nn.Module] = [
            nn.Flatten(),
            nn.Linear(flat_dim, head_hidden),
            nn.ReLU(inplace=True),
        ]
        if dropout_p > 0:
            classifier.append(nn.Dropout(dropout_p))
        classifier.append(nn.Linear(head_hidden, num_classes))
        # CrossEntropyLoss 가 log-softmax 를 포함하므로 Softmax 를 붙이지 않는다.
        self.classifier = nn.Sequential(*classifier)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.classifier(self.features(x))


def build_model(config: ExperimentConfig) -> WaferCNN:
    return WaferCNN(
        conv_channels=config.conv_channels,
        norm=config.norm,
        head_hidden=config.head_hidden,
        dropout_p=config.dropout_p,
    )


def layer_table(model: WaferCNN) -> list[dict]:
    """층별 파라미터 수와 비중.

    "어느 층이 용량을 다 가져갔는가"가 과적합 진단의 출발점이라, 합계가 아니라
    층 단위로 쪼개 놓는다 (보고서 3-2 표).
    """
    total = sum(p.numel() for p in model.parameters() if p.requires_grad)
    counters = {"Conv": 0, "FC": 0, "BN": 0}
    rows = []
    for module in model.modules():
        count = sum(
            p.numel() for p in module.parameters(recurse=False) if p.requires_grad
        )
        if not count:
            continue
        if isinstance(module, nn.Conv2d):
            kind, shape = "Conv", f"{module.in_channels} -> {module.out_channels}"
        elif isinstance(module, nn.Linear):
            kind, shape = "FC", f"{module.in_features} -> {module.out_features}"
        elif isinstance(module, nn.BatchNorm2d):
            kind, shape = "BN", f"{module.num_features}ch"
        else:
            kind, shape = "Other", type(module).__name__
        counters[kind] = counters.get(kind, 0) + 1
        rows.append(
            {
                "layer": f"{kind}{counters[kind]}",
                "shape": shape,
                "params": count,
                "share(%)": round(100.0 * count / total, 2),
            }
        )
    return rows


def parameter_report(model: WaferCNN) -> dict:
    """전체/특징추출부/분류헤드 파라미터 수, 헤드 비중, 층별 분해.

    과적합 진단의 핵심 근거이므로 수치를 코드로 뽑아 보고서에 그대로 쓴다.
    """
    total = sum(p.numel() for p in model.parameters() if p.requires_grad)
    head = sum(p.numel() for p in model.classifier.parameters() if p.requires_grad)
    features = total - head
    return {
        "params_total": total,
        "params_features": features,
        "params_head": head,
        "head_share(%)": 100.0 * head / total,
        "layers": layer_table(model),
    }
