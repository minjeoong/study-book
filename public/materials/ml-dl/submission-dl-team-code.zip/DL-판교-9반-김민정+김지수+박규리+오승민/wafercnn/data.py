"""데이터 로딩 / 전처리 / 3분할 / 배치 반복자.

Baseline(90-wafer.ipynb)과의 비교 가능성을 유지하기 위해 다음 세 가지는
고정한다.
  1) 다이어트 규칙: 불량 전량 + none 5,000장 (random_state=42)
  2) 리사이즈: 64x64, nearest(order=0), anti-aliasing 없음
  3) 분할: stratified 8:2 -> 학습분 내부에서 다시 8:2 (random_state=42)

따라서 실험 간 차이는 전부 모델/손실/최적화 설정에서만 나온다.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch
from skimage.transform import resize
from sklearn.model_selection import train_test_split

from wafercnn.config import CACHE_DIR, CLASS_NAMES, CLASS_TO_INDEX, DATA_DIR

IMAGE_SIZE = 64
NONE_SAMPLE_SIZE = 5_000
SPLIT_SEED = 42

# 원본 픽셀 코드: 0 = 다이 없음(웨이퍼 외곽), 1 = 정상 다이, 2 = 불량 다이
PIXEL_NO_DIE, PIXEL_PASS, PIXEL_FAIL = 0, 1, 2


def _pickle_path() -> str:
    """LSWMD.pkl(강의 배포명) 또는 WM811K.pkl(원본 배포명) 중 존재하는 쪽."""
    for name in ("LSWMD.pkl", "WM811K.pkl"):
        path = DATA_DIR / name
        if path.exists():
            return str(path)
    raise FileNotFoundError(
        f"{DATA_DIR} 에 LSWMD.pkl 또는 WM811K.pkl 이 필요합니다. "
        "MIR-WM811K.zip 의 Python/WM811K.pkl 을 해당 경로에 두세요."
    )


def _normalize_label(raw) -> tuple[str, bool]:
    """원본 failureType 을 (라벨명, 라벨_존재여부) 로 정규화한다.

    WM-811K 는 배포판마다 이 필드의 형태가 다르다.
      - LSWMD.pkl  : [['Center']] 형태의 중첩 배열, 미라벨은 길이 0
      - WM811K.pkl : 'Center' 문자열, 미라벨은 빈/더미 배열
    두 경우 모두 미라벨은 Baseline 과 동일하게 'none' 으로 취급하되,
    '진짜 none 라벨'과 '미라벨'을 구분하는 플래그를 함께 남긴다.
    """
    if isinstance(raw, str):
        return raw, True
    value = np.asarray(raw).ravel()
    if value.size == 0 or not isinstance(value[0], str):
        return "none", False
    return str(value[0]), True


def _resize_wafer(wafer_map: np.ndarray) -> np.ndarray:
    """0/1/2 라벨을 보존하도록 nearest 보간으로 64x64 리사이즈."""
    resized = resize(
        wafer_map,
        (IMAGE_SIZE, IMAGE_SIZE),
        order=0,
        preserve_range=True,
        anti_aliasing=False,
    )
    return resized.astype(np.uint8)


def build_cache(force: bool = False) -> str:
    """원본 pickle -> (N, 64, 64) uint8 배열 캐시.

    2GB pickle 로딩과 3만 장 리사이즈를 실험마다 반복하지 않기 위해 한 번만
    수행하고 npz 로 저장한다. uint8 로 저장하므로 119MB 로 끝난다.
    """
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_path = CACHE_DIR / f"wafer_{IMAGE_SIZE}.npz"
    if cache_path.exists() and not force:
        return str(cache_path)

    df = pd.read_pickle(_pickle_path())
    raw_total = len(df)

    normalized = [_normalize_label(v) for v in df["failureType"].to_numpy()]
    label_names = np.array([n for n, _ in normalized])
    has_label = np.array([flag for _, flag in normalized])

    # Baseline 다이어트 규칙: 불량은 전량 유지, none 은 5,000장만 샘플링.
    # 순서(불량 -> none)와 시드를 Baseline 과 동일하게 맞춘다.
    is_failure = label_names != "none"
    failure_idx = np.flatnonzero(is_failure)
    none_idx = (
        pd.Series(np.flatnonzero(~is_failure))
        .sample(n=NONE_SAMPLE_SIZE, random_state=SPLIT_SEED)
        .to_numpy()
    )
    keep = np.concatenate([failure_idx, none_idx])

    x = np.stack([_resize_wafer(w) for w in df["waferMap"].to_numpy()[keep]])
    y = np.array([CLASS_TO_INDEX[n] for n in label_names[keep]], dtype=np.int64)

    # 리사이즈 전 원본 크기 통계 (보고서 3-1). shape_audit() 이 이 키들을 읽으므로
    # 여기서 반드시 함께 저장해야 한다.
    labeled_shapes = np.array(
        [w.shape for w in df["waferMap"].to_numpy()[has_label]], dtype=np.int64
    )

    np.savez_compressed(
        cache_path,
        x=x.astype(np.uint8),
        y=y,
        raw_total=raw_total,
        labeled_total=int(has_label.sum()),
        true_none_total=int((has_label & ~is_failure).sum()),
        shape_kinds=len(np.unique(labeled_shapes, axis=0)),
        height_min=labeled_shapes[:, 0].min(),
        height_max=labeled_shapes[:, 0].max(),
        width_min=labeled_shapes[:, 1].min(),
        width_max=labeled_shapes[:, 1].max(),
    )
    return str(cache_path)


def shape_audit() -> dict[str, int]:
    """라벨이 있는 웨이퍼맵의 원본 크기 분포 (서로 다른 shape 수, 세로/가로 범위)."""
    with np.load(build_cache()) as bundle:
        return {
            "distinct_shapes": int(bundle["shape_kinds"]),
            "height_min": int(bundle["height_min"]),
            "height_max": int(bundle["height_max"]),
            "width_min": int(bundle["width_min"]),
            "width_max": int(bundle["width_max"]),
            "resized_to": f"{IMAGE_SIZE}x{IMAGE_SIZE}",
        }


@dataclass(frozen=True)
class WaferSplits:
    """3분할된 배열 묶음."""

    x_train: np.ndarray
    y_train: np.ndarray
    x_valid: np.ndarray
    y_valid: np.ndarray
    x_test: np.ndarray
    y_test: np.ndarray
    raw_total: int
    labeled_total: int
    true_none_total: int

    def class_table(self) -> pd.DataFrame:
        """분할별 클래스 분포 표 (보고서 3장 데이터 진단용)."""
        rows = []
        for i, name in enumerate(CLASS_NAMES):
            rows.append(
                {
                    "class": name,
                    "train": int((self.y_train == i).sum()),
                    "valid": int((self.y_valid == i).sum()),
                    "test": int((self.y_test == i).sum()),
                }
            )
        table = pd.DataFrame(rows)
        table["total"] = table[["train", "valid", "test"]].sum(axis=1)
        table["train_ratio(%)"] = 100 * table["train"] / table["train"].sum()
        return table


def load_splits(force_cache: bool = False) -> WaferSplits:
    """캐시를 읽어 stratified 3분할을 만든다 (Baseline과 동일한 시드/비율)."""
    cache_path = build_cache(force=force_cache)
    with np.load(cache_path) as bundle:
        x, y = bundle["x"], bundle["y"]
        raw_total = int(bundle["raw_total"])
        labeled_total = int(bundle["labeled_total"])
        true_none_total = int(bundle["true_none_total"])

    x_train_full, x_test, y_train_full, y_test = train_test_split(
        x, y, test_size=0.2, random_state=SPLIT_SEED, stratify=y
    )
    x_train, x_valid, y_train, y_valid = train_test_split(
        x_train_full,
        y_train_full,
        test_size=0.2,
        random_state=SPLIT_SEED,
        stratify=y_train_full,
    )
    return WaferSplits(
        x_train=x_train,
        y_train=y_train,
        x_valid=x_valid,
        y_valid=y_valid,
        x_test=x_test,
        y_test=y_test,
        raw_total=raw_total,
        labeled_total=labeled_total,
        true_none_total=true_none_total,
    )


def duplicate_audit(splits: WaferSplits) -> dict[str, float]:
    """리사이즈 후 완전 동일한 이미지가 분할을 넘나드는 비율을 센다.

    WM-811K 는 같은 로트에서 나온 유사 웨이퍼가 많아, 무작위 분할 시
    Train 과 Test 에 동일 이미지가 함께 들어갈 수 있다. Test 점수를 해석할 때
    낙관 편향의 크기를 가늠하기 위한 감사 지표다.
    """

    def digests(arr: np.ndarray) -> list[str]:
        return [hashlib.blake2b(a.tobytes(), digest_size=16).hexdigest() for a in arr]

    train_d = set(digests(splits.x_train))
    valid_d = digests(splits.x_valid)
    test_d = digests(splits.x_test)
    return {
        "train_unique_ratio(%)": 100 * len(train_d) / len(splits.x_train),
        "valid_seen_in_train(%)": 100 * np.mean([d in train_d for d in valid_d]),
        "test_seen_in_train(%)": 100 * np.mean([d in train_d for d in test_d]),
    }


def encode(x: "np.ndarray | torch.Tensor") -> torch.Tensor:
    """(..., 64, 64) uint8 -> (..., 1, 64, 64) float32.

    Baseline 과 동일하게 0/1/2 픽셀 코드를 1채널 실수값으로 그대로 넣는다.
    """
    tensor = (
        x if isinstance(x, torch.Tensor) else torch.from_numpy(np.ascontiguousarray(x))
    )
    return tensor.unsqueeze(-3).float()


class WaferBatches:
    """uint8 원본을 들고 있다가 배치 단위로 인코딩하는 미니배치 반복자.

    데이터가 전부 메모리에 있으므로 DataLoader 의 샘플 단위 __getitem__ +
    collate 경로는 순수 오버헤드다. 배치 인덱스로 한 번에 슬라이스해서
    인코딩하면 같은 결과를 내면서 에폭 시간이 크게 줄어든다.
    """

    def __init__(
        self,
        x: np.ndarray,
        y: np.ndarray,
        batch_size: int,
        shuffle: bool = False,
        seed: int = 0,
    ) -> None:
        self.raw = torch.from_numpy(np.ascontiguousarray(x))
        self.labels = torch.from_numpy(np.ascontiguousarray(y)).long()
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.generator = torch.Generator().manual_seed(seed)

    def __len__(self) -> int:
        return (self.labels.numel() + self.batch_size - 1) // self.batch_size

    def __iter__(self):
        n = self.labels.numel()
        order = (
            torch.randperm(n, generator=self.generator)
            if self.shuffle
            else torch.arange(n)
        )
        for start in range(0, n, self.batch_size):
            idx = order[start : start + self.batch_size]
            yield encode(self.raw[idx]), self.labels[idx]


def make_loaders(
    splits: WaferSplits,
    batch_size: int,
    seed: int,
    eval_batch_size: int = 512,
) -> dict[str, WaferBatches]:
    """학습/검증/시험 반복자. 셔플은 학습용에만 적용한다."""
    return {
        "train": WaferBatches(
            splits.x_train, splits.y_train, batch_size, shuffle=True, seed=seed
        ),
        # 학습 성능은 셔플 없이 평가해야 Train-Valid 격차가 왜곡되지 않는다.
        "train_eval": WaferBatches(splits.x_train, splits.y_train, eval_batch_size),
        "valid": WaferBatches(splits.x_valid, splits.y_valid, eval_batch_size),
        "test": WaferBatches(splits.x_test, splits.y_test, eval_batch_size),
    }
