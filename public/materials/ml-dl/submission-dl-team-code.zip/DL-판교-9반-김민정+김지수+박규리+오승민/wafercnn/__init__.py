"""WM-811K 웨이퍼맵 불량 분류 CNN 최적화 실험 패키지.

모듈 구성
---------
config  : 실험 1건을 완전히 기술하는 ExperimentConfig
data    : LSWMD/WM811K 로딩, 다이어트 샘플링, 리사이즈 캐시, 3분할, 배치 반복자
models  : 구성 가능한 WaferCNN (Conv 블록 / BatchNorm / Dropout)
losses  : CrossEntropy + 역빈도 클래스 가중치
metrics : Accuracy / Macro-F1 / 클래스별 Recall / 혼동행렬 / 미탐 지표
engine  : Early Stopping 학습 루프 (valid loss 감시)
runner  : 설정 1건을 seed 별로 학습하고 결과를 모으는 실행기
plots   : 그림 생성 (노트북에서 인라인으로 표시)

실행은 scripts/run_experiments.py 하나면 된다.
"""

from wafercnn.config import CLASS_NAMES, ExperimentConfig, MINORITY_CLASSES

__all__ = ["CLASS_NAMES", "MINORITY_CLASSES", "ExperimentConfig"]
