"""보고서용 그림 생성 (전부 무채색).

색을 쓰지 않고 명도 / 선 종류 / 해칭만으로 계열을 구분한다. 흑백 인쇄에서도
동일하게 읽히고, 보고서 톤도 통일된다.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib as mpl

# 그림은 항상 파일로 저장한다. GUI 백엔드는 헤드리스 실행에서 프로세스를
# 중단시키므로 pyplot 을 불러오기 전에 Agg 로 고정한다.
mpl.use("Agg")

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

from wafercnn.config import CLASS_NAMES, FIGURE_DIR, MINORITY_CLASSES

INK = "#111111"
MID = "#7a7a7a"
LIGHT = "#c8c8c8"


def apply_style() -> None:
    for family in ("Apple SD Gothic Neo", "AppleGothic", "Nanum Gothic"):
        if any(f.name == family for f in mpl.font_manager.fontManager.ttflist):
            mpl.rcParams["font.family"] = family
            break
    mpl.rcParams.update(
        {
            "axes.unicode_minus": False,
            "figure.dpi": 140,
            "savefig.dpi": 140,
            "savefig.bbox": "tight",
            "axes.edgecolor": INK,
            "axes.labelcolor": INK,
            "axes.titlesize": 11,
            "axes.titleweight": "bold",
            "axes.grid": True,
            "grid.color": LIGHT,
            "grid.linewidth": 0.6,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "text.color": INK,
            "xtick.color": INK,
            "ytick.color": INK,
            "font.size": 9,
            "legend.frameon": False,
        }
    )


def _save(fig, name: str) -> Path:
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    path = FIGURE_DIR / f"{name}.png"
    fig.savefig(path)
    plt.close(fig)
    return path


def fig_class_distribution(class_rows: list[dict]) -> Path:
    """학습셋 클래스 분포. 소수 3클래스는 해칭으로 구분한다."""
    names = [r["class"] for r in class_rows]
    counts = [r["train"] for r in class_rows]
    order = np.argsort(counts)

    fig, ax = plt.subplots(figsize=(6.2, 3.2))
    for rank, i in enumerate(order):
        minority = names[i] in MINORITY_CLASSES
        ax.barh(
            rank,
            counts[i],
            color="white" if minority else MID,
            edgecolor=INK,
            hatch="///" if minority else None,
            height=0.68,
            linewidth=0.8,
        )
        ax.text(
            counts[i] * 1.12,
            rank,
            f"{counts[i]:,} ({100 * counts[i] / sum(counts):.1f}%)",
            va="center",
            fontsize=8,
        )
    ax.set_yticks(range(len(order)), [names[i] for i in order])
    ax.set_xscale("log")
    ax.set_xlim(50, max(counts) * 6)
    ax.set_xlabel("학습셋 표본 수 (로그 축)")
    ax.set_title("학습셋 클래스 분포 — 해칭은 사전 지정한 소수 3클래스")
    ax.grid(axis="y", visible=False)
    return _save(fig, "fig1_class_distribution")


def fig_overfitting(baseline_run, champion_run) -> Path:
    """왼쪽: Baseline 의 Train/Valid 정확도 벌어짐. 오른쪽: 감시 지표 불일치."""
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.3))

    hist = baseline_run.history
    epochs = np.arange(1, len(hist.train_accuracy) + 1)
    axes[0].plot(epochs, hist.train_accuracy, color=INK, marker="o", ms=3, label="Train")
    axes[0].plot(
        epochs,
        hist.valid_accuracy,
        color=MID,
        marker="s",
        ms=3,
        ls="--",
        label="Valid",
    )
    axes[0].fill_between(
        epochs, hist.train_accuracy, hist.valid_accuracy, color=LIGHT, alpha=0.5
    )
    gap = hist.train_accuracy[-1] - hist.valid_accuracy[-1]
    axes[0].annotate(
        f"최종 격차 {gap:.1f}%p",
        xy=(epochs[-1], (hist.train_accuracy[-1] + hist.valid_accuracy[-1]) / 2),
        xytext=(-8, 0),
        textcoords="offset points",
        ha="right",
        fontsize=8,
    )
    axes[0].set_xlabel("epoch")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].set_title("Baseline: 학습은 계속 오르고 검증은 멈춘다")
    axes[0].legend(loc="lower right")

    ch = champion_run.history
    epochs = np.arange(1, len(ch.valid_loss) + 1)
    ax_loss = axes[1]
    ax_loss.plot(epochs, ch.valid_loss, color=INK, marker="o", ms=3, label="Valid Loss")
    ax_loss.set_xlabel("epoch")
    ax_loss.set_ylabel("Valid Loss")
    ax_f1 = ax_loss.twinx()
    ax_f1.plot(
        epochs,
        ch.valid_macro_f1,
        color=MID,
        marker="s",
        ms=3,
        ls="--",
        label="Valid Macro-F1",
    )
    ax_f1.set_ylabel("Valid Macro-F1")
    ax_f1.grid(False)

    loss_best = int(np.argmin(ch.valid_loss)) + 1
    f1_best = int(np.argmax(ch.valid_macro_f1)) + 1
    ax_loss.axvline(loss_best, color=INK, ls=":", lw=1)
    ax_loss.axvline(f1_best, color=MID, ls=":", lw=1)
    ax_loss.set_title(
        f"감시 지표 불일치: Loss 최소 {loss_best}ep vs Macro-F1 최대 {f1_best}ep"
    )
    handles = ax_loss.get_legend_handles_labels()[0] + ax_f1.get_legend_handles_labels()[0]
    labels = ax_loss.get_legend_handles_labels()[1] + ax_f1.get_legend_handles_labels()[1]
    ax_loss.legend(handles, labels, loc="center right")
    return _save(fig, "fig2_overfitting_and_monitor")


def fig_selection_gates(rows: list[dict], baseline: dict, noise: float) -> Path:
    """선정 규칙을 그림 하나로: 두 게이트를 통과한 실험만 후보가 된다.

    x = Macro-F1(게이트), y = 소수 3클래스 Recall(주 지표). 오른쪽 위 사분면이
    통과 영역이고, 그 안에서 가장 위에 있는 점이 최종안이다.
    """
    fig, ax = plt.subplots(figsize=(6.4, 4.6))

    f1_floor = baseline["valid_macro_f1"] - 0.05
    minority_floor = baseline["minority_recall"]

    ax.axvspan(f1_floor, 1.0, ymin=0, ymax=1, color=LIGHT, alpha=0.35)
    ax.axvline(f1_floor, color=MID, ls="--", lw=1)
    ax.axhline(minority_floor, color=MID, ls="--", lw=1)

    # 점이 겹칠 때 이름표가 포개지지 않도록 위/아래로 번갈아 놓는다.
    order = sorted(range(len(rows)), key=lambda i: rows[i]["valid_macro_f1"])
    offset_y = {i: (-3 if rank % 2 == 0 else 7) for rank, i in enumerate(order)}

    for index, row in enumerate(rows):
        passed = (
            row["valid_macro_f1"] >= f1_floor
            and row["minority_recall"] >= minority_floor
        )
        ax.plot(
            row["valid_macro_f1"],
            row["minority_recall"],
            marker="o" if passed else "x",
            ms=8 if passed else 6,
            mfc=INK if passed else "none",
            mec=INK if passed else MID,
            mew=1.2,
            ls="none",
        )
        ax.annotate(
            row["exp"].split("_", 1)[0],
            (row["valid_macro_f1"], row["minority_recall"]),
            xytext=(6, offset_y[index]),
            textcoords="offset points",
            fontsize=8,
            fontweight="bold" if passed else "normal",
            color=INK if passed else MID,
        )

    # 축 범위를 데이터에 맞춰 좁힌 뒤에 하한선 라벨을 붙인다. 자동 스케일이
    # 끝나기 전에 붙이면 라벨이 그림 밖으로 밀려난다.
    xs = [r["valid_macro_f1"] for r in rows] + [f1_floor]
    ys = [r["minority_recall"] for r in rows] + [minority_floor]
    xpad = 0.06 * (max(xs) - min(xs))
    ypad = 0.08 * (max(ys) - min(ys))
    ax.set_xlim(min(xs) - xpad, max(xs) + 2.6 * xpad)
    ax.set_ylim(min(ys) - ypad, max(ys) + ypad)

    ax.annotate(
        f"Macro-F1 하한 {f1_floor:.4f}",
        xy=(f1_floor, ax.get_ylim()[0]),
        xytext=(4, 6),
        textcoords="offset points",
        fontsize=7,
        color=MID,
        rotation=90,
        va="bottom",
    )
    ax.annotate(
        f"소수 Recall 하한 {minority_floor:.4f}",
        xy=(ax.get_xlim()[0], minority_floor),
        xytext=(4, 4),
        textcoords="offset points",
        fontsize=7,
        color=MID,
    )

    ax.set_xlabel("Valid Macro-F1  (게이트)")
    ax.set_ylabel("소수 3클래스 Recall  (주 지표)")
    ax.set_title(f"선정 규칙: 두 게이트 통과 후 주 지표 최대 (잡음 폭 {noise:.4f})")
    return _save(fig, "fig3_selection_gates")


def fig_metric_disagreement(rows: list[dict]) -> Path:
    """Accuracy 로 줄을 세우는 것과 Macro-F1 로 줄을 세우는 것이 다르다."""
    fig, ax = plt.subplots(figsize=(5.6, 4.4))
    for row in rows:
        ax.plot(
            row["valid_acc(%)"],
            row["valid_macro_f1"],
            marker="o",
            ms=6,
            mfc="white",
            mec=INK,
            ls="none",
        )
        ax.annotate(
            row["exp"].split("_", 1)[0],
            (row["valid_acc(%)"], row["valid_macro_f1"]),
            xytext=(6, -3),
            textcoords="offset points",
            fontsize=8,
        )
    ax.set_xlabel("Valid Accuracy (%)")
    ax.set_ylabel("Valid Macro-F1")
    ax.set_title("Accuracy 가 같아도 Macro-F1 은 다르다")
    return _save(fig, "fig4_metric_disagreement")


def fig_confusion(baseline_cm: np.ndarray, final_cm: np.ndarray) -> Path:
    """행 정규화 혼동행렬. 회색 농도가 그 행에서 차지하는 비율이다."""
    fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.6))
    for panel, (ax, cm, title) in enumerate(
        zip(axes, [np.array(baseline_cm), np.array(final_cm)], ["Baseline", "최종 모델"])
    ):
        norm = cm / np.clip(cm.sum(axis=1, keepdims=True), 1, None)
        ax.imshow(norm, cmap="Greys", vmin=0, vmax=1)
        for i in range(len(CLASS_NAMES)):
            for j in range(len(CLASS_NAMES)):
                if norm[i, j] < 0.005:
                    continue
                ax.text(
                    j,
                    i,
                    f"{norm[i, j]:.2f}".lstrip("0"),
                    ha="center",
                    va="center",
                    fontsize=7,
                    color="white" if norm[i, j] > 0.55 else INK,
                )
        ax.set_xticks(range(len(CLASS_NAMES)), CLASS_NAMES, rotation=45, ha="right")
        ax.set_yticks(range(len(CLASS_NAMES)), CLASS_NAMES)
        ax.set_xlabel("예측")
        if panel == 0:
            ax.set_ylabel("실제")
        ax.set_title(f"{title} — Test 혼동행렬 (행 정규화)")
        ax.grid(False)
    return _save(fig, "fig5_confusion")


def fig_recall_by_class(baseline_recall: dict, final_recall: dict) -> Path:
    """클래스별 Test Recall 비교. 소수 클래스 라벨에 * 표시."""
    names = list(CLASS_NAMES)
    x = np.arange(len(names))
    fig, ax = plt.subplots(figsize=(8.0, 3.4))
    ax.bar(
        x - 0.2,
        [baseline_recall[n] for n in names],
        width=0.38,
        color="white",
        edgecolor=INK,
        hatch="///",
        linewidth=0.8,
        label="Baseline",
    )
    ax.bar(
        x + 0.2,
        [final_recall[n] for n in names],
        width=0.38,
        color=MID,
        edgecolor=INK,
        linewidth=0.8,
        label="최종 모델",
    )
    for xi, n in zip(x, names):
        delta = final_recall[n] - baseline_recall[n]
        ax.annotate(
            f"{delta:+.2f}",
            (xi, max(baseline_recall[n], final_recall[n]) + 0.03),
            ha="center",
            fontsize=7.5,
        )
    ax.set_xticks(
        x, [f"{n}*" if n in MINORITY_CLASSES else n for n in names], rotation=30, ha="right"
    )
    ax.set_ylim(0, 1.15)
    ax.set_ylabel("Test Recall")
    ax.set_title("클래스별 Test Recall — * 는 사전 지정 소수 클래스")
    ax.legend(loc="lower right", ncol=2)
    return _save(fig, "fig6_recall_by_class")


def fig_wafer_samples(x: np.ndarray, y: np.ndarray, per_class: int = 3) -> Path:
    """클래스별 웨이퍼맵 예시 (무채색). 0=다이 없음, 1=정상, 2=불량."""
    fig, axes = plt.subplots(
        per_class, len(CLASS_NAMES), figsize=(1.05 * len(CLASS_NAMES), 1.15 * per_class)
    )
    rng = np.random.default_rng(0)
    for col, name in enumerate(CLASS_NAMES):
        idx = np.flatnonzero(y == col)
        picks = rng.choice(idx, size=min(per_class, len(idx)), replace=False)
        for row in range(per_class):
            ax = axes[row, col]
            ax.axis("off")
            if row < len(picks):
                ax.imshow(x[picks[row]], cmap="Greys", vmin=0, vmax=2, interpolation="nearest")
            if row == 0:
                ax.set_title(name, fontsize=8)
    fig.suptitle("웨이퍼맵 예시 (밝음=다이 없음, 중간=정상 다이, 어두움=불량 다이)", fontsize=9)
    return _save(fig, "fig7_wafer_samples")
