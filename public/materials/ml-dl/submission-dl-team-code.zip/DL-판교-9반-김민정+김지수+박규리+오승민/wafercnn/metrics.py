"""평가 지표.

Accuracy 하나로는 이 문제를 볼 수 없다. 학습셋에서 Near-full 은 0.5% 미만이라
그 클래스를 전부 틀려도 Accuracy 는 거의 움직이지 않는다. 그래서 매 평가마다
아래를 함께 계산한다.

  accuracy       : 전체 정답률 (Baseline 비교용)
  macro_f1       : 클래스 크기와 무관하게 9개를 동등 취급 -> 주 지표
  recall_per_class: 유형별 미탐 정도
  minority_recall : 고정된 하위 3개 클래스(Near-full/Donut/Random) Recall 평균
  worst_recall    : 9개 클래스 중 최악 Recall (최약 고리)
  defect_recall   : 불량을 불량(none 이외)으로 잡아낸 비율 = 1 - 미탐률
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import confusion_matrix, f1_score, recall_score

from wafercnn.data import WaferBatches

from wafercnn.config import CLASS_NAMES, MINORITY_INDICES, NONE_INDEX
from wafercnn.models import NUM_CLASSES

ALL_LABELS = list(range(NUM_CLASSES))


@dataclass
class EvalResult:
    loss: float
    accuracy: float
    macro_f1: float
    minority_recall: float
    worst_recall: float
    worst_class: str
    defect_recall: float
    recall_per_class: dict[str, float] = field(default_factory=dict)
    y_true: np.ndarray | None = None
    y_pred: np.ndarray | None = None

    def confusion(self) -> np.ndarray:
        return confusion_matrix(self.y_true, self.y_pred, labels=ALL_LABELS)


@torch.no_grad()
def evaluate(
    model: nn.Module,
    loader: WaferBatches,
    criterion: nn.Module | None = None,
    device: torch.device | str = "cpu",
    keep_predictions: bool = False,
) -> EvalResult:
    model.eval()
    losses: list[float] = []
    counts: list[int] = []
    preds: list[np.ndarray] = []
    trues: list[np.ndarray] = []

    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        logits = model(images)
        if criterion is not None:
            losses.append(float(criterion(logits, labels)) * labels.numel())
            counts.append(labels.numel())
        preds.append(logits.argmax(dim=1).cpu().numpy())
        trues.append(labels.cpu().numpy())

    y_pred = np.concatenate(preds)
    y_true = np.concatenate(trues)
    loss = float(np.sum(losses) / np.sum(counts)) if losses else float("nan")

    recalls = recall_score(
        y_true, y_pred, labels=ALL_LABELS, average=None, zero_division=0
    )
    f1s = f1_score(y_true, y_pred, labels=ALL_LABELS, average=None, zero_division=0)
    worst_idx = int(np.argmin(recalls))

    is_defect = y_true != NONE_INDEX
    defect_recall = (
        float(np.mean(y_pred[is_defect] != NONE_INDEX)) if is_defect.any() else float("nan")
    )

    return EvalResult(
        loss=loss,
        accuracy=100.0 * float(np.mean(y_pred == y_true)),
        macro_f1=float(np.mean(f1s)),
        minority_recall=float(np.mean([recalls[i] for i in MINORITY_INDICES])),
        worst_recall=float(recalls[worst_idx]),
        worst_class=CLASS_NAMES[worst_idx],
        defect_recall=defect_recall,
        recall_per_class={CLASS_NAMES[i]: float(recalls[i]) for i in ALL_LABELS},
        y_true=y_true if keep_predictions else None,
        y_pred=y_pred if keep_predictions else None,
    )
