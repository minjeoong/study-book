# 웨이퍼맵 불량 분류 CNN 최적화 (WM-811K)

반도체 웨이퍼맵 이미지로 불량 유형 9종을 분류하는 Baseline CNN 을 진단하고,
**규제**와 **클래스 불균형 보정** 두 축으로 8개 조합을 비교한 코드다.
Baseline 구조(Conv 32-64 + Flatten 헤드, ReLU, Adam)는 전 실험에서 고정한다.

## 실험 구성

| # | 실험 | 바꾼 항목 |
| --- | --- | --- |
| 1 | Base 모델 | — (Early Stopping 만) |
| 2 | BatchNorm | Conv 직후 BN |
| 3 | Dropout | p=0.3 (FC1 뒤) |
| 4 | Class Weight | CE 역빈도 가중 |
| 5 | Weight Decay | Adam wd=1e-4 |
| 6 | Dropout + BN | 3 + 2 |
| 7 | Dropout + BN + CW | 6 + 4 |
| 8 | Dropout + BN + CW + WD | 7 + 5 |

Early Stopping(valid loss, patience=5)은 전 실험에 공통 적용한다.
실험마다 epoch 수가 달라 생기는 왜곡을 없애기 위해서다.

## 선정 규칙 (사전 정의)

| 항목 | 내용 |
| --- | --- |
| 주 지표 | 소수 3클래스(Near-full, Donut, Random) Recall 평균 — 미검출(FN) 비용이 오탐(FP)보다 크다는 전제 |
| 게이트 | Macro-F1 ≥ 기준선 − 0.05 **그리고** 소수 Recall ≥ 기준선 |
| 동등 판정 | 주 지표 차이가 기준선 3-seed Macro-F1 표준편차(잡음 폭) 이내면 개선으로 보지 않고 더 단순한 구성 유지 |

판정 규칙은 `scripts/run_experiments.py` 의 "최종 선정" 블록 한 곳에만 있다.
결과를 본 뒤 기준을 바꾸는 일을 구조적으로 막기 위한 배치다.

## 준비

```bash
pip install torch numpy pandas scikit-learn scikit-image matplotlib
```

원본 데이터를 `working/data/` 에 둔다. 아래 둘 중 어느 파일이든 자동으로 인식한다.

- `LSWMD.pkl` (강의 배포본)
- `WM811K.pkl` (MIR-WM811K 배포본 `MIR-WM811K.zip` 의 `Python/WM811K.pkl`)

## 실행

```bash
python scripts/run_experiments.py --device mps --seeds 3   # 전체 실험 (약 24분)
```

`--device` 는 `cpu` / `mps` / `cuda` 중 선택하며, 생략하면 사용 가능한 가속기를
자동으로 고른다. 첫 실행에서 원본 pickle 을 읽어 64x64 uint8
캐시(`results/cache/wafer_64.npz`)를 만들고, 이후 실험은 캐시만 사용한다.

## 구조

```
wafercnn/
  config.py    ExperimentConfig — 실험 1건을 완전히 기술하는 설정 객체
  data.py      로딩 / 다이어트 샘플링 / 리사이즈 캐시 / 3분할 / 배치 반복자
  models.py    WaferCNN — Conv 블록, BatchNorm, Dropout 을 설정으로 조립
  losses.py    CrossEntropy + 역빈도 클래스 가중치
  metrics.py   Accuracy / Macro-F1 / 클래스별 Recall / 소수 Recall / 불량 검출률
  engine.py    Early Stopping 학습 루프 (valid loss 감시), 시드 고정
  runner.py    설정 -> 학습 -> Train/Valid 평가 -> 기록 (Test 는 건드리지 않음)
  plots.py     무채색 그림 (노트북 인라인 표시용)
scripts/
  run_experiments.py     8개 조합 실행 + 최종 선정 + Test 평가 -> results/
report/
  노션-형식.md            최종 보고서
working/
  90-wafer.ipynb         제공된 Baseline (수정하지 않음)
```

## 산출물

| 파일 | 내용 |
| --- | --- |
| `results/diagnosis.json` | 데이터 / 구조 진단 수치, 클래스 가중치, 실행 환경 |
| `results/experiments.csv` | 8개 조합 결과 표 |
| `results/recall_by_class.csv` | 클래스별 Recall (건수 + 합계 포함) |
| `results/final.json` | 선정 규칙, 최종 구성, Valid 결과, Test 평가, 혼동행렬 |

## 재현성

- 데이터 분할, 다이어트 샘플링, 모델 초기화, 배치 셔플 난수를 모두 시드로 고정한다.
- 모든 조합을 seed 42 / 1 / 7 로 3회씩 돌려 평균과 표준편차를 낸다.
  Valid 의 Near-full 은 24장이라 1 seed 만 쓰면 몇 장 차이로 순위가 뒤집힌다.
- 모든 설계 판단은 Valid 로만 하고, Test 는 최종 구성이 확정된 뒤 한 번만 평가한다.
- 실행 환경(Python / PyTorch 버전, 장치)은 `results/diagnosis.json` 에 함께 기록된다.
