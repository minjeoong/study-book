import logging

from modules.download_adult import download_adult_data
from modules.load_Pandas import load_pandas
from modules.stats_analysis import run_statistical_analysis
from modules.visualize import run_visualization
from modules.loadPolars import load_polars
from modules.clean import preprocess_pipeline
from modules.optimized_features import run_feature_optimization
from modules.model import evaluate_and_select_best_model
from modules.report import build_report_context, render_report


# main.py 전반에서 logger.info로 진행 상황을 남기므로 여기서 한 번만 설정합니다.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger(__name__)

def main():
    print("=======================================================")
    print("📥 1. 데이터 다운로드 및 준비 시작...")
    download_adult_data()
    
    # 1-1) Pandas 로딩
    #  요구사항
    #   - header 없는 CSV에 컬럼명 부여, " ?"를 결측치로 인식, 값 앞 공백 제거
    #  예외 처리
    #   - 파일 없음/파싱 실패를 각각 명확한 예외로 재발생
    # ---------------------------------------------------------------------------
    df_pandas, elapsed_pandas=load_pandas()

    # ---------------------------------------------------------------------------
    # 1-2) Polars 로딩
    #  요구사항
    #   - pandas 로딩과 동일한 정제 결과(공백 제거, "?" -> null)를 맞춰야 두 결과의
    #     shape 비교가 의미 있음. polars는 skipinitialspace/na_values 옵션이
    #     pandas만큼 유연하지 않아, 문자열 컬럼을 strip한 뒤 "?"를 null로 치환하는
    #     후처리 단계를 별도로 둔다.
    #  예외 처리
    #   - 파일 없음/파싱 실패를 각각 명확한 예외로 재발생
    # ---------------------------------------------------------------------------
    # ---------------------------------------------------------------------------
    df_polars, elapsed_polars=load_polars()
    # 1-3) Pandas vs Polars 비교
    #  요구사항
    #   - 선택한 데이터셋을 Pandas와 Polars 양쪽으로 로딩하여 결과를 비교
    #  출력
    #   - shape, 컬럼별 dtype 일치 여부, 로딩 소요 시간
    # ---------------------------------------------------------------------------

    print("\n=======================================================")
    print("📊 Pandas vs Polars 로딩 결과 비교")
    print("=======================================================")

    # shape 비교
    print("\n[Shape]")
    print(f"Pandas : {df_pandas.shape}")
    print(f"Polars : {df_polars.shape}")
    print(f"Shape 일치 여부: {df_pandas.shape == df_polars.shape}")

    # dtype 비교
    print("\n[Dtype]")
    print("Pandas:")
    print(df_pandas.dtypes)

    print("\nPolars:")
    print(df_polars.schema)

    # 로딩 시간 비교
    print("\n[Loading Time]")
    print(f"Pandas : {elapsed_pandas:.6f}초")
    print(f"Polars : {elapsed_polars:.6f}초")

    if elapsed_pandas < elapsed_polars:
        print("→ Pandas가 더 빠름")
    elif elapsed_polars < elapsed_pandas:
        print("→ Polars가 더 빠름")
    else:
        print("→ 두 도구의 실행 시간이 동일함")


    # 결측치, 중복 처리
    df_clean=preprocess_pipeline(df_polars)

    # 피쳐 옵티마이제이션
    df_optimized=run_feature_optimization(df_clean)

    # ---------------------------------------------------------------------------
    # 2-1) Seaborn 정적 차트 4종 (2x2)
    #  요구사항
    #   - Seaborn으로 정적 차트 1개 이상 (분포/상관관계/그룹비교 중 택1)
    #   - 아래 4개 서브플롯으로 세 유형을 모두 다룸
    # ---------------------------------------------------------------------------
    # ---------------------------------------------------------------------------
    # 2-2) Plotly 인터랙티브 차트
    #  요구사항
    #   - Plotly로 인터랙티브 차트 1개 이상 (분포/상관관계/그룹비교 중 택1)
    #   - 학력별 고소득 비율을 그룹 비교 막대 차트로 표현, hover로 표본 수까지 노출
    #  구현: modules/visualize.py (plot_seaborn, plot_plotly, run_visualization)
    # ---------------------------------------------------------------------------
    logger.info("[2/5] 시각화: Seaborn 정적 4종 + Plotly 인터랙티브 1종")

    run_visualization(df_pandas)
    # ---------------------------------------------------------------------------






    # ---------------------------------------------------------------------------
    # 3) 기술통계 · 상관계수 · t-test
    #  요구사항
    #   - 평균·표준편차·분위수, 변수 간 상관계수, scipy.stats.ttest_ind 기반
    #     소득 그룹 간 평균 주당 근무시간 차이 검정 및 p-value 해석
    #  구현: modules/stats_analysis.py (descriptive_stats, correlation_matrix,
    #        interpret_p_value, run_income_hours_ttest, run_statistical_analysis)
    # ---------------------------------------------------------------------------
    logger.info("[3/5] 통계 분석: 기술통계 + 상관계수 + t-test")

    stats_result = run_statistical_analysis(df_pandas)






    # ---------------------------------------------------------------------------
    # 4-1) 전처리 + 모델 Pipeline 구성
    # 4-2) 여러 모델 비교 (Linear vs Ridge vs Lasso) -> 최고 성능 모델 선택
    # 4-3) joblib 저장/로딩 + 예외 처리
    #  [EDA 인사이트 - 타겟 불균형 및 모델링/피처 엔지니어링 넥스트 스텝]
    #  1. 타겟 변수 (Income) 불균형:
    #     - 전체 데이터 중 <=50K(저소득) 약 76%, >50K(고소득) 약 24%로 타겟 데이터가 불균형함.
    #     - Accuracy(정확도)만 보면 꼼수가 생길 수 있으므로 F1-Score 및 ROC-AUC를 핵심 평가지표로 활용함.
    #  2. 모델 예측률을 높이기 위한 "넥스트 스텝(Feature Engineering)" 제안:
    #     - 나이(Age) Binning: 연령대 범주형 변수(10대, 20대, 30대...)로 묶어 비선형 패턴 학습 보조.
    #     - 자본 수익(Capital) 단순화: capital-gain과 capital-loss 데이터를 투자 수익/손실 발생 여부(0 또는 1) 이진 변수로 치환.
    # ---------------------------------------------------------------------------
    logger.info("[4/5] 모델 비교: Linear vs Ridge vs Lasso + joblib 저장")

    model_result = evaluate_and_select_best_model(df_optimized)
    best_name = model_result["best_model_name"]
    best_auc = model_result["best_auc"]
    res_df = model_result["metrics_df"]


    # ---------------------------------------------------------------------------
    # 5) Jinja2로 report.md 렌더링
    #  요구사항
    #   - 분석 결과를 report.md로 자동 생성
    # ---------------------------------------------------------------------------
    logger.info("[5/5] report.md 자동 생성")

    context = build_report_context(
        pandas_df=df_pandas,
        polars_df=df_polars,
        pandas_seconds=elapsed_pandas,
        polars_seconds=elapsed_polars,
        missing_before=df_pandas.isnull().sum(),
        dedup_before=df_polars.height,
        dedup_after=df_clean.height,
        cleaned=df_clean.to_pandas(),
        desc_stats=stats_result["descriptive"],
        corr=stats_result["correlation"],
        ttest_result=stats_result["ttest"],
        scores=res_df.to_dict(orient="records"),
        best_name=best_name,
        best_auc=best_auc,
    )

    render_report(context)


if __name__ == "__main__":
    main()
