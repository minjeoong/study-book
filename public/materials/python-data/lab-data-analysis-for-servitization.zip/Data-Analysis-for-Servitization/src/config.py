from pathlib import Path

# python main.py 를 src/ 에서 실행하는 것을 기준으로 경로를 잡습니다.
SRC_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SRC_DIR.parent

TEMPLATES_DIR = PROJECT_ROOT / "templates"

OUTPUT_DIR = SRC_DIR / "outputs"
FIGURES_DIR = OUTPUT_DIR / "figures"
MODELS_DIR = OUTPUT_DIR / "models"
LOGS_DIR = OUTPUT_DIR / "logs"

REPORT_PATH = OUTPUT_DIR / "report.md"
MODEL_PATH = MODELS_DIR / "best_model.joblib"
EDA_STATIC_CHART_PATH = FIGURES_DIR / "seaborn_4charts.png"
INCOME_PLOTLY_CHART_PATH = FIGURES_DIR / "income_by_education.html"

DATASET_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data"
DATA_RAW_DIR = SRC_DIR / "data" / "raw"
DATA_RAW_PATH = DATA_RAW_DIR / "adult.data"
ALPHA = 0.05
TARGET_COL = "income"
BASE_DIR = SRC_DIR
