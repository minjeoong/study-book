"""
src package initialization
"""
