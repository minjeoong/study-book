# Adult Census Income - End2End 분석 리포트

생성 시각: 2026-08-07 20:24:38

## 1. 데이터 준비

- 원본 데이터: Adult Census Income (https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data)
- Pandas 로딩: shape=(32561, 15), 소요시간=77.5ms
- Polars 로딩: shape=(32561, 15), 소요시간=37.4ms
- 중복 제거: 32561행 -> 32537행 (24건 제거)

### 결측치 현황

| 컬럼 | 결측 건수 | 비율 |
|---|---:|---:|
| occupation | 1843 | 5.7% |
| workclass | 1836 | 5.6% |
| native-country | 583 | 1.8% |


## 2. 시각화

- Seaborn 정적 차트(분포·상관관계·그룹비교 4종): [figures/seaborn_4charts.png](figures/seaborn_4charts.png)
- Plotly 인터랙티브 차트(학력별 고소득 비율): [figures/income_by_education.html](figures/income_by_education.html)

## 3. 통계 분석

### 기술통계 (수치형 변수)

|                |   count |      평균 |    표준편차 |   min |   25%분위 |   중앙값 |   75%분위 |   max |
|:---------------|--------:|--------:|--------:|------:|--------:|------:|--------:|------:|
| age            |   32561 |   38.58 |   13.64 |    17 |      28 |    37 |      48 |    90 |
| education-num  |   32561 |   10.08 |    2.57 |     1 |       9 |    10 |      12 |    16 |
| capital-gain   |   32561 | 1077.65 | 7385.29 |     0 |       0 |     0 |       0 | 99999 |
| capital-loss   |   32561 |   87.3  |  402.96 |     0 |       0 |     0 |       0 |  4356 |
| hours-per-week |   32561 |   40.44 |   12.35 |     1 |      40 |    40 |      45 |    99 |

### 상관계수

|                |   age |   education-num |   capital-gain |   capital-loss |   hours-per-week |
|:---------------|------:|----------------:|---------------:|---------------:|-----------------:|
| age            | 1     |           0.037 |          0.078 |          0.058 |            0.069 |
| education-num  | 0.037 |           1     |          0.123 |          0.08  |            0.148 |
| capital-gain   | 0.078 |           0.123 |          1     |         -0.032 |            0.078 |
| capital-loss   | 0.058 |           0.08  |         -0.032 |          1     |            0.054 |
| hours-per-week | 0.069 |           0.148 |          0.078 |          0.054 |            1     |

### t-test: 소득 그룹 간 평균 주당 근무시간 비교

- 귀무가설(H0): 소득 그룹(<=50K vs >50K)에 따라 평균 주당 근무시간에 차이가 없다.
- 대립가설(H1): 두 소득 그룹의 평균 주당 근무시간에는 차이가 있다.
- <=50K: n=24720, 평균=38.84시간
- \>50K: n=7841, 평균=45.47시간
- t-statistic=-45.1231, p-value=0.000000
- 해석: p < 0.05 -> 귀무가설 기각, 통계적으로 유의미한 차이가 있음

## 4. ML Pipeline

- 타깃: income (`<=50K`=0 / `>50K`=1), 클래스 비율 >50K=24.1%
- 후보 모델을 동일 train/test로 공정 비교하고 ROC-AUC 기준 최고 모델을 저장했다 (accuracy는 클래스 불균형 때문에 참고용).

| 모델 | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Linear (Logistic Regression) **(선택됨)** | 0.8536 | 0.7431 | 0.5995 | 0.6636 | 0.9043 |
| Ridge Classification (릿지) | 0.8425 | 0.7554 | 0.5121 | 0.6104 | 0.8920 |
| Lasso Classification (라쏘) | 0.8537 | 0.7433 | 0.6001 | 0.6641 | 0.9043 |


- 최종 선택 모델: **Linear (Logistic Regression)**
- 저장 경로: `outputs/models/best_model.joblib`
- 재로딩 검증: 저장 전/후 ROC-AUC 동일 확인 완료

## 5. 요약

- 가장 강한 상관관계: `education-num` <-> `hours-per-week` (0.148)
- 소득 그룹 간 근무시간 차이는 통계적으로 유의미하다(유의함, alpha=0.05).
- Linear (Logistic Regression)이 ROC-AUC 0.9043로 가장 우수한 income 예측 성능을 보였다.

---
*이 리포트는 `run_pipeline.py` 실행 시 Jinja2 템플릿(`templates/report.md.j2`)으로 자동 생성됩니다.*