import time
import polars as pl

from config import DATA_RAW_PATH

COLUMNS = [
    "age",
    "workclass",
    "fnlwgt",
    "education",
    "education-num",
    "marital-status",
    "occupation",
    "relationship",
    "race",
    "sex",
    "capital-gain",
    "capital-loss",
    "hours-per-week",
    "native-country",
    "income"
]


def load_polars(path=DATA_RAW_PATH):
    start = time.perf_counter()

    try:
        df = pl.read_csv(
            path,
            has_header=False,
            new_columns=COLUMNS,
            separator=","
        )
    except FileNotFoundError as e:
        raise FileNotFoundError(f"[Polars] 데이터 파일을 찾을 수 없습니다: {path}") from e
    except pl.exceptions.ComputeError as e:
        raise ValueError(f"[Polars] CSV 파싱 실패: {path} ({e})") from e

    # 원본 CSV는 ", " 로 구분되어 있어 age를 제외한 모든 컬럼 값 앞에 공백이 남는다.
    # Polars에는 pandas의 skipinitialspace 옵션이 없으므로 문자열 컬럼을 직접 strip하고,
    # 공백 제거 후 "?"가 된 값을 null로 치환해 pandas(na_values="?")와 동일하게 맞춘다.
    string_cols = [col for col, dtype in df.schema.items() if dtype == pl.String]
    if string_cols:
        df = df.with_columns([
            pl.col(col).str.strip_chars().replace("?", None).alias(col)
            for col in string_cols
        ])

    # CSV 끝의 빈 줄이 완전 결측 행으로 읽히는 것을 제거한다(pandas는 기본적으로 빈 줄을 건너뜀).
    df = df.filter(~pl.all_horizontal(pl.all().is_null()))

    elapsed = time.perf_counter() - start

    print(f"[Polars] 데이터 크기: {df.shape}")
    print(f"[Polars] 로딩 시간: {elapsed:.6f}초")

    return df, elapsed