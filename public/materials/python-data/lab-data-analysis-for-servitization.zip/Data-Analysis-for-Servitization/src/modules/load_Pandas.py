import time
import pandas as pd

from config import DATA_RAW_PATH

COLUMNS = [
    "age",
    "workclass",
    "fnlwgt",
    "education",
    "education-num",
    "marital-status",
    "occupation",
    "relationship",
    "race",
    "sex",
    "capital-gain",
    "capital-loss",
    "hours-per-week",
    "native-country",
    "income"
]


def load_pandas(path=DATA_RAW_PATH):
    start = time.perf_counter()

    try:
        df = pd.read_csv(
            path,
            header=None,
            names=COLUMNS,
            na_values="?",
            skipinitialspace=True
        )
    except FileNotFoundError as e:
        raise FileNotFoundError(f"[Pandas] 데이터 파일을 찾을 수 없습니다: {path}") from e
    except pd.errors.ParserError as e:
        raise ValueError(f"[Pandas] CSV 파싱 실패: {path} ({e})") from e

    elapsed = time.perf_counter() - start

    print(f"[Pandas] 데이터 크기: {df.shape}")
    print(f"[Pandas] 로딩 시간: {elapsed:.6f}초")

    return df, elapsed