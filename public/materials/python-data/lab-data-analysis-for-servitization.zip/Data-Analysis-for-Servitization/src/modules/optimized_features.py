import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.feature_selection import RFECV
from sklearn.ensemble import RandomForestClassifier


def run_feature_optimization(df):
    """
    전처리 완료 DataFrame을 입력받아
    One-Hot Encoding 후 RFECV로 중요 피처를 선택한다.

    입력:
        df : Polars DataFrame 또는 Pandas DataFrame

    반환:
        df_optimized : 선택된 피처 + income 타겟을 포함한 Pandas DataFrame
    """

    print("\n=======================================================")
    print("🔎 3. Feature Optimization 시작")
    print("=======================================================")

    # ------------------------------------------------------
    # 1. Polars -> Pandas 변환
    # sklearn / get_dummies 사용을 위해 Pandas로 변환
    # ------------------------------------------------------
    if hasattr(df, "to_pandas"):
        df = df.to_pandas()

    # ------------------------------------------------------
    # 2. 범주형 변수 One-Hot Encoding
    # ------------------------------------------------------
    print("✅ [1/3] One-Hot Encoding 진행 중...")

    cat_cols = df.select_dtypes(
        include=["object", "category"]
    ).columns.tolist()

    df_encoded = pd.get_dummies(
        df,
        columns=cat_cols,
        drop_first=True
    )

    # bool -> int 변환
    bool_cols = df_encoded.select_dtypes(
        include="bool"
    ).columns

    df_encoded[bool_cols] = df_encoded[bool_cols].astype(int)

    # ------------------------------------------------------
    # 3. Feature / Target 분리
    # ------------------------------------------------------
    X = df_encoded.drop(columns=["income"])
    y = df_encoded["income"]

    print(f"   → 초기 피처 개수: {X.shape[1]}")

    # ------------------------------------------------------
    # 4. RFECV 기반 피처 선택
    # ------------------------------------------------------
    print("✅ [2/3] RFECV 기반 피처 최적화 진행 중...")

    rf_model = RandomForestClassifier(
        n_estimators=30,
        max_depth=7,
        random_state=42,
        n_jobs=-1
    )

    cv = StratifiedKFold(
        n_splits=3,
        shuffle=True,
        random_state=42
    )

    rfecv = RFECV(
        estimator=rf_model,
        step=1,
        cv=cv,
        scoring="accuracy",
        min_features_to_select=10,
        n_jobs=-1
    )

    rfecv.fit(X, y)

    # ------------------------------------------------------
    # 5. 선택된 피처만 추출
    # ------------------------------------------------------
    selected_cols = X.columns[rfecv.support_]
    dropped_cols = X.columns[~rfecv.support_]

    X_optimized = X.loc[:, selected_cols]

    df_optimized = pd.concat(
        [X_optimized, y],
        axis=1
    )

    print("✅ [3/3] 피처 최적화 완료")
    print(f"   → 제거된 피처: {len(dropped_cols)}개")
    print(f"   → 선택된 피처: {len(selected_cols)}개")
    print(f"   → 최종 데이터 크기: {df_optimized.shape}")

    return df_optimized