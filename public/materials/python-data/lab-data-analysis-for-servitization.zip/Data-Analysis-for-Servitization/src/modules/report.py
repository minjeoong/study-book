"""
Jinja2로 templates/report.md.j2를 렌더링해 분석 결과를 output/report.md로
자동 생성한다.

- render_report : context 딕셔너리를 템플릿에 주입해 report.md 파일로 저장

예외 처리
- 템플릿 파일이 없으면 FileNotFoundError
- 렌더링 중 컨텍스트 키 누락 등은 jinja2.UndefinedError를 ValueError로 통일해 재발생
- 파일 저장 실패는 OSError로 원인을 보존해 재발생
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
from jinja2 import Environment, FileSystemLoader, StrictUndefined, TemplateNotFound, UndefinedError

from config import (
    ALPHA,
    BASE_DIR,
    DATASET_URL,
    EDA_STATIC_CHART_PATH,
    INCOME_PLOTLY_CHART_PATH,
    MODEL_PATH,
    REPORT_PATH,
    TARGET_COL,
    TEMPLATES_DIR,
)


# ---------------------------------------------------------------------------
# Jinja2로 report.md 렌더링
#  요구사항
#   - 분석 결과를 report.md로 자동 생성
# ---------------------------------------------------------------------------
def render_report(
    context: dict[str, Any],
    template_name: str = "report.md.j2",
    out_path: Path = REPORT_PATH,
) -> Path:
    env = Environment(loader=FileSystemLoader(TEMPLATES_DIR), undefined=StrictUndefined)

    try:
        template = env.get_template(template_name)
    except TemplateNotFound as e:
        raise FileNotFoundError(f"리포트 템플릿을 찾을 수 없습니다: {TEMPLATES_DIR / template_name}") from e

    try:
        rendered = template.render(**context)
    except UndefinedError as e:
        raise ValueError(f"리포트 렌더링 실패(컨텍스트 값 누락): {e}") from e

    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        out_path.write_text(rendered, encoding="utf-8")
    except OSError as e:
        raise OSError(f"리포트 저장 실패: {out_path} ({e})") from e

    print(f"  report.md 생성 완료: {out_path}")
    return out_path


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")



def build_report_context(
    *,
    pandas_df: pd.DataFrame,
    polars_df,
    pandas_seconds: float,
    polars_seconds: float,
    missing_before: pd.Series,
    dedup_before: int,
    dedup_after: int,
    cleaned: pd.DataFrame,
    desc_stats: pd.DataFrame,
    corr: pd.DataFrame,
    ttest_result: dict,
    scores: list[dict] | dict,
    best_name: str,
    best_auc: float,
) -> dict:
    missing_summary = [
        {"column": col, "count": int(cnt), "pct": cnt / len(pandas_df) * 100}
        for col, cnt in missing_before.sort_values(ascending=False).items()
        if cnt > 0
    ]

    if isinstance(scores, list):
        model_scores = [
            {
                "name": row["Model"],
                "accuracy": row["Accuracy"],
                "precision": row.get("Precision", row["F1-Score"]),
                "recall": row.get("Recall", row["F1-Score"]),
                "f1": row["F1-Score"],
                "roc_auc": row["ROC-AUC"],
            }
            for row in scores
        ]
    else:
        model_scores = [{"name": name, **metrics} for name, metrics in scores.items()]

    target_col = cleaned[TARGET_COL]
    if target_col.dtype == object:
        target_positive_rate = (target_col == ">50K").mean()
    else:
        target_positive_rate = target_col.mean()

    return {
        "title": "Adult Census Income - End2End 분석 리포트",
        "generated": now_str(),
        "dataset_url": DATASET_URL,
        "pandas_shape": pandas_df.shape,
        "polars_shape": polars_df.shape,
        "pandas_seconds": pandas_seconds,
        "polars_seconds": polars_seconds,
        "dedup_before": dedup_before,
        "dedup_after": dedup_after,
        "dedup_removed": dedup_before - dedup_after,
        "missing_summary": missing_summary,
        "static_chart_path": f"figures/{EDA_STATIC_CHART_PATH.name}",
        "plotly_chart_path": f"figures/{INCOME_PLOTLY_CHART_PATH.name}",
        "desc_stats_md": desc_stats.round(2).to_markdown(),
        "corr_md": corr.round(3).to_markdown(),
        "corr_table": corr.to_dict(),
        "ttest": ttest_result,
        "alpha": ALPHA,
        "target_positive_rate": target_positive_rate,
        "model_scores": model_scores,
        "best_model_name": best_name,
        "best_roc_auc": best_auc,
        "model_path": MODEL_PATH.relative_to(BASE_DIR),
    }

