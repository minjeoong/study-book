import polars as pl


# ==========================================================
# Adult Dataset 전처리 모듈
# 입력: load_polars()에서 반환된 Polars DataFrame
# 출력: 전처리가 완료된 Polars DataFrame
# ==========================================================


def cast_numeric_columns(df):
    """
    숫자형 컬럼을 Int64 타입으로 변환한다.
    숫자로 변환할 수 없는 값은 null로 처리한다.
    """
    numeric_cols = [
        "age",
        "fnlwgt",
        "education-num",
        "capital-gain",
        "capital-loss",
        "hours-per-week"
    ]

    existing_cols = [
        col for col in numeric_cols
        if col in df.columns
    ]

    if existing_cols:
        df = df.with_columns([
            pl.col(col)
            .cast(pl.Int64, strict=False)
            .alias(col)
            for col in existing_cols
        ])

    return df


def handle_missing_values(df):
    """
    문자열 컬럼의 결측치를 'Unknown'으로 치환한다.
    """
    string_cols = [
        col
        for col, dtype in df.schema.items()
        if dtype == pl.String
    ]

    if string_cols:
        df = df.with_columns(
            pl.col(string_cols).fill_null("Unknown")
        )

    return df


def drop_duplicates(df):
    """
    완전히 동일한 중복 행을 제거한다.
    기존 데이터 순서는 유지한다.
    """
    return df.unique(maintain_order=True)


def drop_unnecessary_cols(df):
    """
    모델 예측에 사용하지 않을 fnlwgt 컬럼을 제거한다.
    """
    if "fnlwgt" in df.columns:
        df = df.drop("fnlwgt")

    return df


def create_derived_features(df):
    """
    파생 변수를 생성한다.

    1. age_group
       나이를 연령대로 그룹화한다.

    2. has_capital_gain
       capital-gain이 0보다 크면 1, 아니면 0

    3. has_capital_loss
       capital-loss가 0보다 크면 1, 아니면 0
    """

    expressions = []

    # ------------------------------------------------------
    # 1. 나이 그룹화
    # ------------------------------------------------------
    if "age" in df.columns:
        age_group = (
            pl.when(pl.col("age") <= 19)
            .then(pl.lit("10s"))
            .when(pl.col("age") <= 29)
            .then(pl.lit("20s"))
            .when(pl.col("age") <= 39)
            .then(pl.lit("30s"))
            .when(pl.col("age") <= 49)
            .then(pl.lit("40s"))
            .when(pl.col("age") <= 59)
            .then(pl.lit("50s"))
            .when(pl.col("age") <= 69)
            .then(pl.lit("60s"))
            .otherwise(pl.lit("70+"))
            .alias("age_group")
        )

        expressions.append(age_group)

    # ------------------------------------------------------
    # 2. Capital Gain 이진화
    # ------------------------------------------------------
    if "capital-gain" in df.columns:
        has_capital_gain = (
            (pl.col("capital-gain") > 0)
            .cast(pl.Int8)
            .alias("has_capital_gain")
        )

        expressions.append(has_capital_gain)

    # ------------------------------------------------------
    # 3. Capital Loss 이진화
    # ------------------------------------------------------
    if "capital-loss" in df.columns:
        has_capital_loss = (
            (pl.col("capital-loss") > 0)
            .cast(pl.Int8)
            .alias("has_capital_loss")
        )

        expressions.append(has_capital_loss)

    if expressions:
        df = df.with_columns(expressions)

    return df


def encode_target(df):
    """
    income 컬럼을 이진 분류 타겟으로 변환한다.

    <=50K -> 0
    >50K  -> 1
    """
    if "income" in df.columns:
        df = df.with_columns(
            pl.col("income")
            .str.contains(">50K")
            .fill_null(False)
            .cast(pl.Int8)
            .alias("income")
        )

    return df


def preprocess_pipeline(df):
    """
    전체 전처리 과정을 순서대로 실행한다.

    1. 숫자형 타입 변환
    2. 결측치 처리
    3. 중복 제거
    4. 불필요한 컬럼 제거
    5. 파생 변수 생성
    6. 타겟 인코딩
    """

    print("\n=======================================================")
    print("🧹 2. 데이터 전처리 시작")
    print("=======================================================")

    # ------------------------------------------------------
    # 1. 숫자형 타입 변환
    # ------------------------------------------------------
    print("✅ [1/6] 숫자형 컬럼 타입 변환 중...")
    df = cast_numeric_columns(df)

    # ------------------------------------------------------
    # 2. 결측치 처리
    # ------------------------------------------------------
    print("✅ [2/6] 결측치를 'Unknown'으로 처리 중...")
    df = handle_missing_values(df)

    # ------------------------------------------------------
    # 3. 중복 제거
    # ------------------------------------------------------
    print("✅ [3/6] 중복 데이터 제거 중...")

    rows_before_dedup = df.height

    df = drop_duplicates(df)

    rows_after_dedup = df.height
    removed = rows_before_dedup - rows_after_dedup

    print(f"   → 중복 {removed}건 제거")

    # ------------------------------------------------------
    # 4. 불필요한 컬럼 제거
    # ------------------------------------------------------
    print("✅ [4/6] 불필요한 컬럼(fnlwgt) 삭제 중...")
    df = drop_unnecessary_cols(df)

    # ------------------------------------------------------
    # 5. 파생 변수 생성
    # ------------------------------------------------------
    print("✅ [5/6] 파생 변수 생성 중...")
    df = create_derived_features(df)

    # ------------------------------------------------------
    # 6. 타겟 인코딩
    # ------------------------------------------------------
    print("✅ [6/6] 타겟 변수(income) 이진 인코딩 중...")
    df = encode_target(df)

    # ------------------------------------------------------
    # 결과 출력
    # ------------------------------------------------------
    print("\n🎉 전처리 파이프라인 완료!")
    print(f"   → 최종 데이터 크기: {df.shape}")

    print("\n[최종 Schema]")
    print(df.schema)

    return df