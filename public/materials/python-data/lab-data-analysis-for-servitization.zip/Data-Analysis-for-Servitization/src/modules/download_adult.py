import ssl
from urllib.request import urlretrieve

from config import DATASET_URL, DATA_RAW_PATH

ssl._create_default_https_context = ssl._create_unverified_context


def download_adult_data():
    """UCI Adult 데이터셋을 data/raw/adult.data에 저장한다."""
    DATA_RAW_PATH.parent.mkdir(parents=True, exist_ok=True)

    try:
        if not DATA_RAW_PATH.exists():
            urlretrieve(DATASET_URL, DATA_RAW_PATH)
            print(f"다운로드 완료: {DATA_RAW_PATH}")
        else:
            print(f"이미 파일이 존재합니다: {DATA_RAW_PATH}")
    except Exception as e:
        raise RuntimeError(f"Adult 데이터셋 다운로드 실패: {e}") from e


if __name__ == "__main__":
    download_adult_data()

