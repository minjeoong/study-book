"""
2) 시각화 모듈 — Seaborn 정적 차트 4종(2x2)과 Plotly 인터랙티브 차트 1종을 만듭니다.

load_Pandas.py / loadPolars.py와 같은 방식으로, main.py에서 호출해 쓰는 함수만 둡니다.
모든 차트에는 제목·x축 레이블·y축 레이블을 반드시 넣습니다(과제 필수 요구사항).
"""

import matplotlib.pyplot as plt
import plotly.express as px
import seaborn as sns
from matplotlib import font_manager

from config import EDA_STATIC_CHART_PATH, INCOME_PLOTLY_CHART_PATH

# 소득 두 계층에 색을 고정 배정합니다(정렬이 바뀌어도 색이 따라 움직이지 않게).
COLOR_LOW = "#2a78d6"
COLOR_HIGH = "#eb6834"
INCOME_ORDER = ["<=50K", ">50K"]
INCOME_PALETTE = {"<=50K": COLOR_LOW, ">50K": COLOR_HIGH}

NUMERIC_COLUMNS = [
    "age",
    "education-num",
    "capital-gain",
    "capital-loss",
    "hours-per-week"
]


def setup_korean_font():
    """설치된 한글 폰트를 찾아 적용합니다(없으면 그래프의 한글이 네모로 깨집니다)."""
    installed_fonts = {font.name for font in font_manager.fontManager.ttflist}

    for font_name in ("AppleGothic", "Malgun Gothic", "NanumGothic"):
        if font_name in installed_fonts:
            plt.rcParams["font.family"] = font_name
            break

    # 한글 폰트를 쓰면 마이너스 기호가 깨지므로 유니코드 마이너스를 끕니다.
    plt.rcParams["axes.unicode_minus"] = False


def prepare_income(df):
    """
    income 표기를 통일합니다.

    원본에는 값 앞 공백이나 마침표('<=50K.')가 섞여 있어, 그대로 두면 같은 클래스가
    두 개로 나뉘어 그래프가 어긋납니다.
    """
    df_plot = df.copy()
    df_plot["income"] = df_plot["income"].str.strip().str.rstrip(".")

    return df_plot


def plot_seaborn(df, path=EDA_STATIC_CHART_PATH):
    """
    2-1) Seaborn 정적 차트 4종을 2x2 서브플롯 한 장으로 저장합니다.

    분포 / 상관관계 / 그룹비교 세 유형을 모두 담습니다.
      ① 소득 클래스 분포     (분포)
      ② 소득별 나이 분포     (분포 + 그룹비교)
      ③ 소득별 주당 근로시간 (그룹비교)
      ④ 수치형 변수 상관계수 (상관관계)
    """
    print("[Seaborn] 정적 차트 4종 생성 중...")

    # set_theme()이 폰트 설정을 덮어쓰므로, 테마를 먼저 적용한 뒤 한글 폰트를 지정합니다.
    sns.set_theme(style="whitegrid")
    setup_korean_font()
    path.parent.mkdir(parents=True, exist_ok=True)

    df_plot = prepare_income(df)
    fig, axes = plt.subplots(2, 2, figsize=(16, 11))
    ax_count, ax_age, ax_hours, ax_corr = axes.flatten()

    # ① 소득 클래스 분포 (분포)
    sns.countplot(
        data=df_plot,
        x="income",
        order=INCOME_ORDER,
        hue="income",
        palette=INCOME_PALETTE,
        legend=False,
        width=0.55,
        ax=ax_count
    )
    # 막대 위에 건수와 비율을 적어 클래스 불균형 정도가 바로 읽히게 합니다.
    total_rows = len(df_plot)
    for patch in ax_count.patches:
        count = int(patch.get_height())
        ax_count.annotate(
            f"{count:,}명 ({count / total_rows:.1%})",
            xy=(patch.get_x() + patch.get_width() / 2, count),
            xytext=(0, 6),
            textcoords="offset points",
            ha="center",
            fontsize=11
        )
    ax_count.margins(y=0.15)
    ax_count.set_title("① 소득 클래스 분포 — 저소득이 약 3배 많은 불균형 데이터", loc="left")
    ax_count.set_xlabel("연간 소득 구간 (income)")
    ax_count.set_ylabel("응답자 수 (명)")

    # ② 소득별 나이 분포 (분포 + 그룹비교)
    # 두 집단의 표본 수 차이가 크므로 density로 정규화해야 분포 '모양'을 비교할 수 있습니다.
    sns.histplot(
        data=df_plot,
        x="age",
        hue="income",
        hue_order=INCOME_ORDER,
        palette=INCOME_PALETTE,
        bins=40,
        element="step",
        stat="density",
        common_norm=False,
        alpha=0.35,
        ax=ax_age
    )
    ax_age.set_title("② 소득별 나이 분포 — 고소득은 중년층에 집중", loc="left")
    ax_age.set_xlabel("나이 (세)")
    ax_age.set_ylabel("상대 밀도 (집단별 정규화)")
    if ax_age.get_legend() is not None:
        ax_age.get_legend().set_title("소득 구간")

    # ③ 소득별 주당 근로시간 (그룹비교) — 3-4 t-test와 같은 변수를 눈으로 먼저 확인합니다.
    sns.boxplot(
        data=df_plot,
        x="income",
        y="hours-per-week",
        order=INCOME_ORDER,
        hue="income",
        palette=INCOME_PALETTE,
        legend=False,
        width=0.5,
        showmeans=True,
        meanprops={
            "marker": "D",
            "markerfacecolor": "white",
            "markeredgecolor": "black"
        },
        ax=ax_hours
    )
    ax_hours.set_title("③ 소득별 주당 근로시간 — t-test 대상 (◆ 평균)", loc="left")
    ax_hours.set_xlabel("연간 소득 구간 (income)")
    ax_hours.set_ylabel("주당 근로시간 (시간)")

    # ④ 수치형 변수 상관계수 (상관관계)
    df_corr = df_plot[NUMERIC_COLUMNS].copy()
    # 목표 변수와의 관계도 함께 보기 위해 income을 0/1로 바꿔 넣습니다.
    df_corr["고소득여부"] = (df_plot["income"] == ">50K").astype(int)
    sns.heatmap(
        df_corr.corr(),
        annot=True,
        fmt=".2f",
        cmap="coolwarm",
        vmin=-1,
        vmax=1,
        center=0,  # 무상관(0)을 중립색에 고정합니다.
        linewidths=1,
        ax=ax_corr
    )
    ax_corr.set_title("④ 수치형 변수 상관계수 — 교육 연수가 소득과 가장 높음", loc="left")
    ax_corr.set_xlabel("변수")
    ax_corr.set_ylabel("변수")
    ax_corr.tick_params(axis="x", rotation=30)
    ax_corr.tick_params(axis="y", rotation=0)

    fig.suptitle("Adult Census Income — Seaborn 정적 차트 4종", fontsize=18, x=0.02, ha="left")
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    fig.savefig(path, dpi=150)
    plt.close(fig)

    print(f"[Seaborn] 저장 완료: {path}")

    return path


def plot_plotly(df, path=INCOME_PLOTLY_CHART_PATH):
    """
    2-2) Plotly 인터랙티브 차트 — 학력별 고소득 비율을 막대로 비교합니다.

    막대에 마우스를 올리면 표본 수가 함께 표시됩니다. 표본이 적은 학력(Doctorate는
    400명대)은 비율이 크게 흔들리므로, 비율만 보고 판단하지 않도록 넣었습니다.
    """
    print("[Plotly] 인터랙티브 차트 생성 중...")

    path.parent.mkdir(parents=True, exist_ok=True)

    df_plot = prepare_income(df)
    df_plot["고소득"] = (df_plot["income"] == ">50K").astype(int)

    # education-num이 곧 학력 서열이므로 그 순서대로 x축을 세웁니다.
    df_education = (
        df_plot.groupby(["education-num", "education"], as_index=False)
        .agg(고소득비율=("고소득", "mean"), 표본수=("고소득", "size"))
        .sort_values("education-num")
    )
    df_education["고소득비율(%)"] = df_education["고소득비율"] * 100

    fig = px.bar(
        df_education,
        x="education",
        y="고소득비율(%)",
        color="고소득비율(%)",
        color_continuous_scale=["#c9dcf5", COLOR_HIGH],
        custom_data=["education-num", "표본수"],
        template="plotly_white"
    )
    fig.update_traces(
        hovertemplate=(
            "<b>%{x}</b> (education-num %{customdata[0]})<br>"
            "고소득 비율 %{y:.1f}%<br>표본 %{customdata[1]:,}명<extra></extra>"
        )
    )
    fig.update_layout(
        title="학력별 고소득(&gt;50K) 비율 — 막대에 마우스를 올리면 표본 수 표시",
        xaxis_title="학력 (education, 낮은 학력 → 높은 학력 순)",
        yaxis_title="고소득(>50K) 비율 (%)",
        xaxis={
            "categoryorder": "array",
            "categoryarray": df_education["education"].tolist()
        },
        coloraxis_showscale=False,
        height=600
    )

    # fig.show()가 아니라 write_html로 저장해야 산출물이 파일로 남습니다.
    # include_plotlyjs="cdn": plotly.js를 파일에 넣지 않아 4.6MB -> 10KB가 됩니다.
    fig.write_html(str(path), include_plotlyjs="cdn")

    print(f"[Plotly] 저장 완료: {path}")

    return path


def run_visualization(df):
    """2-1)과 2-2)를 한 번에 실행합니다. main.py에서는 이 함수만 호출하면 됩니다."""
    seaborn_path = plot_seaborn(df)
    plotly_path = plot_plotly(df)
    return seaborn_path, plotly_path
