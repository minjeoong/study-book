import os
import joblib
import datetime
import warnings
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from pathlib import Path
from sklearn.model_selection import train_test_split, learning_curve
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score

from config import FIGURES_DIR, LOGS_DIR, MODELS_DIR, TARGET_COL

warnings.filterwarnings('ignore')
plt.rc('font', family='AppleGothic')
plt.rcParams['axes.unicode_minus'] = False


# ---------------------------------------------------------------------------
# 4-1) 전처리 + 모델 Pipeline 구성
# 4-2) 여러 모델 비교 (Linear vs Ridge vs Lasso) -> 최고 성능 모델 선택
# 4-3) joblib 저장/로딩 + 예외 처리
#  [EDA 인사이트 - 타겟 불균형 및 모델링/피처 엔지니어링 넥스트 스텝]
#  1. 타겟 변수 (Income) 불균형:
#     - 전체 데이터 중 <=50K(저소득) 약 76%, >50K(고소득) 약 24%로 타겟 데이터가 불균형함.
#     - Accuracy(정확도)만 보면 꼼수가 생길 수 있으므로 F1-Score 및 ROC-AUC를 핵심 평가지표로 활용함.
#  2. 모델 예측률을 높이기 위한 "넥스트 스텝(Feature Engineering)" 제안:
#     - 나이(Age) Binning: 연령대 범주형 변수(10대, 20대, 30대...)로 묶어 비선형 패턴 학습 보조.
#     - 자본 수익(Capital) 단순화: capital-gain과 capital-loss 데이터를 투자 수익/손실 발생 여부(0 또는 1) 이진 변수로 치환.
# ---------------------------------------------------------------------------

def plot_and_save_learning_curve(pipeline, X, y, figure_path):
    """
    최고 성능 모델의 학습 곡선(Learning Curve)을 생성하고 이미지 파일로 저장한다.
    """
    plt.figure(figsize=(10, 6))
    train_sizes, train_scores, val_scores = learning_curve(
        pipeline, X, y, cv=5, scoring='roc_auc',
        train_sizes=np.linspace(0.1, 1.0, 5), n_jobs=-1, random_state=42
    )

    train_mean = np.mean(train_scores, axis=1)
    train_std = np.std(train_scores, axis=1)
    val_mean = np.mean(val_scores, axis=1)
    val_std = np.std(val_scores, axis=1)

    plt.plot(train_sizes, train_mean, 'o-', color='#1f77b4', label='Training ROC-AUC Score')
    plt.plot(train_sizes, val_mean, 'o-', color='#ff7f0e', label='Cross-Validation ROC-AUC Score')

    plt.fill_between(train_sizes, train_mean - train_std, train_mean + train_std, alpha=0.15, color='#1f77b4')
    plt.fill_between(train_sizes, val_mean - val_std, val_mean + val_std, alpha=0.15, color='#ff7f0e')

    plt.title('Best Model Learning Curve (Train vs Validation ROC-AUC)', fontsize=14, fontweight='bold')
    plt.xlabel('Training Samples (표본 수)', fontsize=12)
    plt.ylabel('ROC-AUC Score', fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(loc='lower right', fontsize=11)
    plt.tight_layout()

    os.makedirs(os.path.dirname(figure_path), exist_ok=True)
    plt.savefig(figure_path, dpi=300)
    plt.close()
    print(f"📊 [학습 곡선 저장] {figure_path}")


def evaluate_and_select_best_model(df, log_dir=LOGS_DIR, fig_dir=FIGURES_DIR, model_dir=MODELS_DIR):
    """
    메인(main.py)으로부터 전달받은 데이터(df)를 바탕으로
    Linear, Ridge, Lasso 후보 모델을 자동 평가 및 비교하고,
    학습 곡선 그래프, 결과 로그, 최적 joblib 모델을 저장한 후 결과를 리턴합니다.
    """
    warnings.filterwarnings('ignore')
    log_dir = Path(log_dir)
    fig_dir = Path(fig_dir)
    model_dir = Path(model_dir)

    log_dir.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)
    model_dir.mkdir(parents=True, exist_ok=True)

    X = df.drop(TARGET_COL, axis=1)
    y = df[TARGET_COL]

    # Train / Test 분할 (80:20)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    num_cols = X_train.select_dtypes(include=['int64', 'float64']).columns.tolist()
    cat_cols = X_train.select_dtypes(include=['object', 'category', 'string']).columns.tolist()

    # 4-1) 전처리 Pipeline 구성
    preprocessor = ColumnTransformer(transformers=[
        ('num', Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ]), num_cols),
        ('cat', Pipeline([
            ('imputer', SimpleImputer(strategy='constant', fill_value='Unknown')),
            ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
        ]), cat_cols)
    ])

    # 4-2) 후보 모델 비교
    CANDIDATE_MODELS = {
        'Linear (Logistic Regression)': LogisticRegression(C=1.0, max_iter=1000, random_state=42),
        'Ridge Classification (릿지)': RidgeClassifier(alpha=1.0, random_state=42),
        'Lasso Classification (라쏘)': LogisticRegression(penalty='l1', solver='liblinear', C=1.0, max_iter=1000, random_state=42)
    }

    results = []
    best_model_name = None
    best_auc = -1.0
    best_pipeline = None

    print("\n=======================================================")
    print("🤖 4-2) 후보 모델 공정 비교 평가 (Linear vs Ridge vs Lasso)")
    print("=======================================================")

    for name, clf in CANDIDATE_MODELS.items():
        pipe = Pipeline([
            ('preprocessor', preprocessor),
            ('classifier', clf)
        ])
        
        pipe.fit(X_train, y_train)
        y_pred = pipe.predict(X_test)
        
        if hasattr(pipe, 'predict_proba'):
            y_scores = pipe.predict_proba(X_test)[:, 1]
        else:
            y_scores = pipe.decision_function(X_test)
            
        acc = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, zero_division=0)
        recall = recall_score(y_test, y_pred, zero_division=0)
        f1 = f1_score(y_test, y_pred)
        auc = roc_auc_score(y_test, y_scores)

        results.append({
            'Model': name,
            'Accuracy': round(acc, 4),
            'Precision': round(precision, 4),
            'Recall': round(recall, 4),
            'F1-Score': round(f1, 4),
            'ROC-AUC': round(auc, 4)
        })
        
        if auc > best_auc:
            best_auc = auc
            best_model_name = name
            best_pipeline = pipe

    res_df = pd.DataFrame(results)
    print("\n[📊 모델 성능 비교 결과표]")
    print(res_df.to_string(index=False))
    print(f"\n🏆 최적 선택 모델: {best_model_name} (ROC-AUC: {best_auc:.4f})")

    # 1. 학습 곡선 그래프 저장
    learning_curve_file = fig_dir / "learning_curve.png"
    plot_and_save_learning_curve(best_pipeline, X_train, y_train, str(learning_curve_file))

    # 2. 결과 로그 파일 저장
    log_file = log_dir / "model_evaluation.log"
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(log_file, "w", encoding="utf-8") as f:
        f.write(f"=== Adult Income Model Evaluation Log ({timestamp}) ===\n\n")
        f.write("[모델 비교 성능표]\n")
        f.write(res_df.to_string(index=False) + "\n\n")
        f.write(f"🏆 선택된 최적 모델: {best_model_name}\n")
        f.write(f"📈 최고 ROC-AUC 점수: {best_auc:.4f}\n")
        f.write(f"📊 학습 곡선 파일: {learning_curve_file.name}\n")
    print(f"📝 [평가 로그 저장] {log_file}")

    # 3. 4-3) joblib 모델 저장 및 재로딩 검증
    saved_model_file = model_dir / "best_model.joblib"
    reloaded_pred = None
    try:
        joblib.dump(best_pipeline, saved_model_file)
        print(f"💾 [모델 파일 저장] {saved_model_file}")
        
        loaded_model = joblib.load(saved_model_file)
        reloaded_pred = loaded_model.predict(X_test.iloc[:1])[0]
        print(f"✅ [재로딩 검증 성공] 샘플 1건 예측값: {reloaded_pred}")
    except Exception as e:
        print(f"❌ [모델 저장/로딩 예외] {e}")

    # 메인(main.py)으로 반환되는 리턴 구조체
    return {
        'status': 'SUCCESS',
        'timestamp': timestamp,
        'best_model_name': best_model_name,
        'best_auc': best_auc,
        'metrics_df': res_df,
        'model_path': str(saved_model_file),
        'figure_path': str(learning_curve_file),
        'log_path': str(log_file),
        'sample_prediction': int(reloaded_pred) if reloaded_pred is not None else None
    }
