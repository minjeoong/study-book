import pandas as pd
from scipy import stats

# ---------------------------------------------------------------------------
# 3) 기술통계, 상관계수, 가설검정
#  가설: 소득 그룹(income)에 따라 평균 주당 근무시간(hours-per-week)에
#        통계적으로 유의미한 차이가 있다.
#  위치: 2번(시각화) 다음, 4번(모델 파이프라인) 이전 단계.
#        run_statistical_analysis()가 진입점이며, main.py에서 2번 단계까지
#        정제된 df를 받아 3번 전체를 수행한 뒤 4번 파이프라인으로 이어준다.
# ---------------------------------------------------------------------------

TARGET_COL = "income"
NUMERIC_FEATURES = ["age", "education-num", "capital-gain", "capital-loss", "hours-per-week"]
ALPHA = 0.05


# ---------------------------------------------------------------------------
# 3-1) 기술통계
#  요구사항
#   - 평균, 표준편차, 분위수 산출
# ---------------------------------------------------------------------------
def descriptive_stats(df: pd.DataFrame) -> pd.DataFrame:
    desc = df[NUMERIC_FEATURES].describe().T
    desc = desc.rename(
        columns={"mean": "평균", "std": "표준편차", "25%": "25%분위", "50%": "중앙값", "75%": "75%분위"}
    )
    print(desc.round(2).to_string())
    return desc


# ---------------------------------------------------------------------------
# 3-2) 상관계수
#  요구사항
#   - 변수 간 상관계수 계산
# ---------------------------------------------------------------------------
def correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    corr = df[NUMERIC_FEATURES].corr()
    print(corr.round(3).to_string())
    return corr


# ---------------------------------------------------------------------------
# 3-3) p-value 해석 (공용)
# ---------------------------------------------------------------------------
def interpret_p_value(p_value: float, alpha: float = ALPHA) -> str:
    return (
        f"p < {alpha} -> 귀무가설 기각, 통계적으로 유의미한 차이가 있음"
        if p_value < alpha
        else f"p >= {alpha} -> 귀무가설 기각 실패, 유의미한 차이가 있다고 보기 어려움"
    )


# ---------------------------------------------------------------------------
# 3-4) t-test
#  요구사항
#   - scipy.stats.ttest_ind로 t-test 수행 및 p-value 해석
#  가설: 모듈 docstring 참고 (소득 그룹 간 평균 주당 근무시간 차이)
#  예외 처리
#   - 비교할 두 그룹의 표본이 t-test를 수행하기에 부족하면 ValueError
# ---------------------------------------------------------------------------
def run_income_hours_ttest(df: pd.DataFrame, alpha: float = ALPHA) -> dict:
    low = df.loc[df[TARGET_COL] == "<=50K", "hours-per-week"].dropna()
    high = df.loc[df[TARGET_COL] == ">50K", "hours-per-week"].dropna()

    if len(low) < 2 or len(high) < 2:
        raise ValueError(f"t-test 표본 부족: <=50K({len(low)}건) vs >50K({len(high)}건)")

    # Welch's t-test (등분산 가정하지 않음)
    t_stat, p_value = stats.ttest_ind(low, high, equal_var=False)

    print(
        f"[t-test] <=50K(n={len(low)}, mean={low.mean():.2f}h) "
        f"vs >50K(n={len(high)}, mean={high.mean():.2f}h)"
    )
    print(f"  t-statistic={t_stat:.4f}, p-value={p_value:.6f}")
    print(f"  해석: {interpret_p_value(p_value, alpha)}")

    return {
        "n_low": len(low),
        "mean_low": low.mean(),
        "n_high": len(high),
        "mean_high": high.mean(),
        "t_stat": t_stat,
        "p_value": p_value,
        "interpretation": interpret_p_value(p_value, alpha),
    }


def run_statistical_analysis(df: pd.DataFrame, alpha: float = ALPHA) -> dict:
    """3번(기술통계·상관계수·t-test) 전체를 순서대로 실행한다.

    2번 단계에서 넘어온 정제 df를 받아 결과를 모아 반환하고,
    이어서 4번(모델 파이프라인) 단계가 이 반환값을 참고할 수 있게 한다.
    """
    print("✅ [3-1] 기술통계 산출 중...")
    desc = descriptive_stats(df)

    print("✅ [3-2] 상관계수 산출 중...")
    corr = correlation_matrix(df)

    print("✅ [3-4] 소득 그룹 간 주당 근무시간 t-test 수행 중...")
    ttest_result = run_income_hours_ttest(df, alpha=alpha)

    return {"descriptive": desc, "correlation": corr, "ttest": ttest_result}
