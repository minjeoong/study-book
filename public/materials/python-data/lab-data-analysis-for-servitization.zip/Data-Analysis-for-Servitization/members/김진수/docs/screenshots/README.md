# PDF 제출용 화면 캡처 가이드

`python src/main.py`를 한 번 실행하면 터미널에 1~11번 단계가 순서대로 출력됩니다.
아래 순서대로 캡처해 `docs/screenshots/`에 같은 파일명으로 저장한 뒤 PDF에 넣으세요.

캡처 팁
- 터미널 글자 크기를 키우고, 구분선(`====`)과 단계 제목이 함께 보이도록 자릅니다.
- 숫자가 잘리지 않도록 창 너비를 충분히 넓힙니다.
- 각 캡처 아래에 **개인 의견**을 반드시 함께 적습니다(관찰 → 해석 → 한계 → 개선).

| 순서 | 파일명 | 캡처할 화면 | 반드시 보여야 할 것 |
|---|---|---|---|
| 1 | `01_pandas_polars.png` | 터미널 "1. 데이터 로딩 — Pandas vs Polars 비교" | Pandas shape, Polars shape, 두 라이브러리 loading time, 메모리 사용량, shape/결측치 일치 여부 |
| 2 | `02_missing_duplicates.png` | 터미널 "2. 결측치 / 중복 데이터 확인 및 처리" | 컬럼별 결측치 수, 중복 행 개수, 원본 행 수 → 처리 후 행 수 |
| 3 | `03_eda.png` | 터미널 "3. 기본 EDA" | income 분포(건수·비율), 클래스 불균형 비율, education·occupation 빈도 |
| 4 | `04_statistics.png` | 터미널 "4. 기술통계" | mean, std, 25%, 50%, 75% 가 모두 보이는 describe 표 |
| 5 | `05_correlation.png` | 터미널 "5. 상관분석" | 수치형 변수 상관계수 행렬, 고소득 여부와의 상관계수 |
| 6 | `06_ttest.png` | 터미널 "6. t-test" | H0, H1, 두 집단 평균·표본 수, t-statistic, p-value, 해석 문장 |
| 7 | `07_seaborn.png` | `outputs/figures/01_income_distribution.png` 와 `02_age_by_income.png` | 제목, x축 레이블, y축 레이블 (두 그림을 나란히 배치해도 됩니다) |
| 8 | `08_plotly.png` | 브라우저에서 연 `outputs/figures/04_income_by_education.html` | 제목, x축/y축 레이블, **hover tooltip이 떠 있는 순간** |
| 9 | `09_ml_metrics.png` | 터미널 "9. Machine Learning Pipeline" | Accuracy, F1, Precision, Recall, ROC-AUC, Classification Report, Confusion Matrix |
| 10 | `10_report_generated.png` | 터미널 "10~11" 또는 파일 탐색기 | `adult_income_pipeline.joblib`, `report.md`, `logs/run.log` 가 실제로 생성된 모습 |

Plotly HTML은 아래 명령으로 브라우저에서 열 수 있습니다.

```bash
open outputs/figures/04_income_by_education.html
```

파일 생성 확인은 아래 명령의 출력을 캡처해도 됩니다.

```bash
ls -lh outputs/model outputs/figures outputs/logs outputs/report.md
```

## PDF 목차 (권장)

1. 프로젝트 개요
2. 데이터셋 소개
3. Pandas / Polars 로딩 및 비교 — 캡처 1
4. 결측치 / 중복 데이터 처리 — 캡처 2
5. 기본 EDA — 캡처 3
6. Seaborn 시각화 — 캡처 7
7. Plotly 시각화 — 캡처 8
8. 기술통계 — 캡처 4
9. 상관분석 — 캡처 5
10. t-test 및 p-value 해석 — 캡처 6
11. Machine Learning Pipeline
12. 모델 평가 결과 — 캡처 9
13. 모델 저장 및 report.md 자동 생성 — 캡처 10
14. 분석 의견 (`outputs/report.md` 11절을 본인 표현으로 정리)
15. 개선 사항 및 결론 (`outputs/report.md` 8절 심화 분석 · 12절 결론 참고)
