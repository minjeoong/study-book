"""
제출자 : 판교_9반_김진수
과제   : [종합 실습 2] Adult Census Income End-to-End 데이터 분석

프로그램 설명
1. UCI Adult Census Income 원본 데이터를 data/raw/adult.data에서 읽고(없으면 자동 다운로드),
   같은 파일을 Pandas와 Polars로 각각 로딩하여 shape·로딩 시간·메모리 사용량을 비교합니다.
   (URL을 두 번 호출하면 네트워크 상태 차이가 로딩 시간에 섞이므로 동일 로컬 파일을 사용합니다.)
2. 문자열 앞뒤 공백과 '?' 결측 표기를 정리하고, 컬럼별 결측치와 중복 행을 확인·처리합니다.
3. 기본 EDA(소득 분포, 주요 범주형 변수 빈도, 수치형 요약)를 출력합니다.
4. Seaborn 정적 차트 3종과 Plotly 인터랙티브 차트 1종을 제목·축 레이블과 함께 저장합니다.
5. 기술통계(평균·표준편차·분위수)와 수치형 변수 상관계수를 출력합니다.
6. 두 소득 집단의 주당 근로시간 평균 차이를 scipy.stats.ttest_ind(Welch)로 검정하고
   H0/H1/t통계량/p-value와 그 해석을 함께 출력합니다.
7. ColumnTransformer + Pipeline으로 전처리와 LogisticRegression을 하나의 객체로 묶어
   학습·평가(Accuracy, Precision, Recall, F1, ROC-AUC)하고, 5-겹 교차검증으로 결과가
   특정 분할에 의존하지 않는지 확인한 뒤 joblib으로 저장합니다.
8. 위 모든 실행 결과를 그대로 사용하여 outputs/report.md를 자동 생성합니다.
"""

from __future__ import annotations

import logging
import platform
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any, Final

REQUIRED_PACKAGES: Final[str] = (
    "pandas polars numpy matplotlib seaborn scipy scikit-learn joblib plotly"
)

try:
    import joblib
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd
    import plotly.express as px
    import polars as pl
    import seaborn as sns
    from matplotlib import __version__ as matplotlib_version
    from matplotlib import font_manager
    from plotly import __version__ as plotly_version
    from scipy import __version__ as scipy_version
    from sklearn import __version__ as sklearn_version
    from matplotlib.colors import LinearSegmentedColormap
    from scipy.stats import ttest_ind
    from sklearn.compose import ColumnTransformer
    from sklearn.impute import SimpleImputer
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import (
        accuracy_score,
        classification_report,
        confusion_matrix,
        f1_score,
        precision_score,
        recall_score,
        roc_auc_score,
        roc_curve,
    )
    from sklearn.model_selection import StratifiedKFold, cross_validate, train_test_split
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder, StandardScaler
except ImportError as error:
    raise SystemExit(
        f"[환경 오류] '{getattr(error, 'name', '필수 패키지')}' 패키지를 불러올 수 없습니다.\n"
        "지금 실행 중인 Python에 그대로 설치하려면 아래 명령을 사용하세요.\n"
        f"  {sys.executable} -m pip install {REQUIRED_PACKAGES}\n"
        f"(현재 실행 중인 Python: {sys.executable})"
    ) from error


# ---------------------------------------------------------------------------
# 환경 설정 — 경로와 컬럼 목록은 한 곳에서만 정의하고 이후 단계가 재사용합니다.
# ---------------------------------------------------------------------------

BASE_DIR: Final[Path] = Path(__file__).resolve().parent.parent
# 팀 저장소 규칙: 원본 데이터는 data/raw에 두고 수정하지 않습니다.
DATA_DIR: Final[Path] = BASE_DIR / "data" / "raw"
OUTPUT_DIR: Final[Path] = BASE_DIR / "outputs"
FIGURE_DIR: Final[Path] = OUTPUT_DIR / "figures"
MODEL_DIR: Final[Path] = OUTPUT_DIR / "model"
LOG_DIR: Final[Path] = OUTPUT_DIR / "logs"
LOG_PATH: Final[Path] = LOG_DIR / "run.log"

DATA_URL: Final[str] = (
    "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data"
)
RAW_DATA_PATH: Final[Path] = DATA_DIR / "adult.data"

MODEL_PATH: Final[Path] = MODEL_DIR / "adult_income_pipeline.joblib"
REPORT_PATH: Final[Path] = OUTPUT_DIR / "report.md"

# 그림 파일 이름 앞에 번호를 붙여 둔다.
# 파일 탐색기에서 정렬하면 보고서에 실린 순서와 같아져서, 캡처를 뜰 때 헷갈리지 않는다.
INCOME_PNG: Final[Path] = FIGURE_DIR / "01_income_distribution.png"
AGE_PNG: Final[Path] = FIGURE_DIR / "02_age_by_income.png"
CORRELATION_PNG: Final[Path] = FIGURE_DIR / "03_correlation_heatmap.png"
EDUCATION_HTML: Final[Path] = FIGURE_DIR / "04_income_by_education.html"
EVALUATION_PNG: Final[Path] = FIGURE_DIR / "05_model_evaluation.png"
THRESHOLD_PNG: Final[Path] = FIGURE_DIR / "06_threshold_tradeoff.png"

# 원본 파일에는 헤더가 없으므로 과제에서 지정한 컬럼명을 직접 부여합니다.
COLUMNS: Final[list[str]] = [
    "age", "workclass", "fnlwgt", "education", "education-num",
    "marital-status", "occupation", "relationship", "race", "sex",
    "capital-gain", "capital-loss", "hours-per-week", "native-country", "income",
]
# Polars는 dtype을 자동 추론하지 않고 읽기 때문에, Pandas와 같은 정수형이 되도록 직접 캐스팅합니다.
POLARS_NUMERIC_COLUMNS: Final[list[str]] = [
    "age", "fnlwgt", "education-num", "capital-gain", "capital-loss", "hours-per-week",
]
TARGET_COLUMN: Final[str] = "income"
POSITIVE_LABEL: Final[str] = ">50K"

# 차트 표시용 이름.
# 한글 폰트(AppleGothic 등)에는 '<'와 '>' 글리프가 없어 '〈=50K'처럼 전각 괄호로 대체되어
# 깨져 보입니다. 데이터 값은 원본('<=50K')을 그대로 두고, 그림에 그릴 때만 아래 이름을 씁니다.
DISPLAY_LABELS: Final[dict[str, str]] = {
    "<=50K": "50K 이하",
    ">50K": "50K 초과",
}

# 모델 입력 변수.
# fnlwgt는 인구 추정 가중치(표본 설계 값)이지 개인의 특성이 아니므로 특징에서 제외합니다.
NUMERIC_FEATURES: Final[list[str]] = [
    "age", "education-num", "capital-gain", "capital-loss", "hours-per-week",
]
CATEGORICAL_FEATURES: Final[list[str]] = [
    "workclass", "education", "marital-status", "occupation",
    "relationship", "race", "sex", "native-country",
]
FEATURE_COLUMNS: Final[list[str]] = NUMERIC_FEATURES + CATEGORICAL_FEATURES

ALPHA: Final[float] = 0.05
RANDOM_STATE: Final[int] = 42
TEST_SIZE: Final[float] = 0.20

# 색맹 안전성이 확인된 팔레트에서 소득 두 계층에 고정 배정합니다(순위가 바뀌어도 색은 유지).
COLOR_LOW: Final[str] = "#2a78d6"
COLOR_HIGH: Final[str] = "#eb6834"
INK: Final[str] = "#0b0b0b"
INK_SOFT: Final[str] = "#52514e"
INK_MUTED: Final[str] = "#898781"
SURFACE: Final[str] = "#fcfcfb"
GRID: Final[str] = "#e1e0d9"

# 상관계수는 부호가 있는 값이므로 파랑↔빨강 발산형 + 중립점 회색을 사용합니다(무지개 금지).
DIVERGING_CMAP: Final = LinearSegmentedColormap.from_list(
    "blue_gray_red",
    ["#0d366b", "#256abf", "#86b6ef", "#f0efec", "#ea7170", "#d03b3b", "#7d1817"],
)

CV_FOLDS: Final[int] = 5

# 이보다 학습 표본이 적은 범주의 계수는 몇 건의 우연으로도 크게 흔들리므로 해석하지 않습니다.
MIN_SAMPLES_FOR_COEFFICIENT: Final[int] = 100

# 나이는 소득과 단조 증가가 아니라 중년에서 정점을 찍는 곡선 관계이므로,
# 선형 모델이 그 패턴을 잡을 수 있도록 연령대 구간으로 묶은 파생 변수를 만듭니다.
AGE_BIN_EDGES: Final[list[int]] = [16, 25, 35, 45, 55, 65, 100]
AGE_BIN_LABELS: Final[list[str]] = [
    "17-25세", "26-35세", "36-45세", "46-55세", "56-65세", "66세 이상",
]

# 결측을 최빈값으로 덮으면 '응답하지 않았다'는 정보 자체가 사라지므로,
# 개선 모델에서는 별도 범주(Unknown)로 남겨 모델이 직접 판단하게 합니다.
UNKNOWN_CATEGORY: Final[str] = "Unknown"

ENGINEERED_NUMERIC_FEATURES: Final[list[str]] = NUMERIC_FEATURES + [
    "has-capital-gain", "has-capital-loss",
]
ENGINEERED_CATEGORICAL_FEATURES: Final[list[str]] = CATEGORICAL_FEATURES + ["age-band"]


logger: Final[logging.Logger] = logging.getLogger("adult_analysis")


def configure_logging() -> None:
    """
    화면과 로그 파일에 동시에 기록하도록 로거를 설정한다.

    핸들러를 둘로 나눈 이유가 있다.
    - 화면(stdout)에는 메시지만 그대로 찍는다. 앞에 시각·레벨이 붙으면 표나 구분선이
      밀려서 캡처가 지저분해지기 때문이다.
    - 파일(outputs/logs/run.log)에는 시각과 레벨을 함께 남긴다. 나중에 "이 숫자가
      언제 나온 값이냐"를 되짚을 때 필요하다.

    로그 파일을 남기면 실행 결과가 사라지지 않아서, 캡처를 다시 뜨거나 이전 실행과
    수치를 비교할 때 근거가 된다.
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logger.setLevel(logging.DEBUG)
    # 같은 프로세스에서 두 번 호출되어도 핸들러가 중복으로 붙지 않게 비우고 시작한다.
    logger.handlers.clear()
    # 루트 로거로 올려보내지 않는다. 안 그러면 같은 줄이 두 번 찍힌다.
    logger.propagate = False

    console = logging.StreamHandler(stream=sys.stdout)
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter("%(message)s"))

    logfile = logging.FileHandler(LOG_PATH, mode="w", encoding="utf-8")
    logfile.setLevel(logging.DEBUG)
    logfile.setFormatter(
        logging.Formatter("%(asctime)s [%(levelname)-7s] %(message)s", "%Y-%m-%d %H:%M:%S")
    )

    logger.addHandler(console)
    logger.addHandler(logfile)


def log_environment() -> dict[str, str]:
    """
    실행 환경을 로그와 보고서에 남긴다.

    같은 코드라도 라이브러리 버전이 다르면 수치가 조금씩 달라질 수 있다.
    나중에 "왜 값이 다르지"를 따질 때 기준이 되므로 버전을 먼저 기록해 둔다.
    """
    versions = {
        "Python": platform.python_version(),
        "OS": f"{platform.system()} {platform.release()}",
        "pandas": pd.__version__,
        "polars": pl.__version__,
        "numpy": np.__version__,
        "scikit-learn": sklearn_version,
        "scipy": scipy_version,
        "matplotlib": matplotlib_version,
        "seaborn": sns.__version__,
        "plotly": plotly_version,
        "joblib": joblib.__version__,
    }

    log_section("0. 실행 환경")
    for name, version in versions.items():
        logger.info(f"{name:<14}: {version}")
    logger.debug(f"실행 파일 경로 : {Path(__file__).resolve()}")
    logger.debug(f"작업 기준 경로 : {BASE_DIR}")

    return versions


def log_section(title: str) -> None:
    """각 실행 단계를 구분선과 함께 찍는다. 캡처할 때 단계 경계가 분명해진다."""
    logger.info("\n" + "=" * 78)
    logger.info(title)
    logger.info("=" * 78)


def format_p_value(p_value: float) -> str:
    """
    p-value를 사람이 읽을 수 있게 표기합니다.

    표본이 크면 p-value가 double의 표현 한계(약 1e-308) 아래로 내려가 0.0으로 반환됩니다.
    이때 '0'이라고 적으면 오해를 주므로 '표현 한계 미만'임을 명시합니다.
    """
    if p_value == 0.0:
        return "1e-308 미만 (부동소수점 표현 한계로 0.0으로 반환됨)"
    return f"{p_value:.6g}"


def configure_chart_theme() -> None:
    """차트 배경·격자·글자색을 한 번에 지정합니다(차트마다 반복 설정하지 않기 위함)."""
    sns.set_theme(style="white")
    plt.rcParams.update({
        "axes.unicode_minus": False,
        "figure.facecolor": SURFACE,
        "axes.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "axes.grid": True,
        "axes.grid.axis": "y",
        "grid.color": GRID,
        "grid.linewidth": 0.8,
        "axes.axisbelow": True,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.edgecolor": "#c3c2b7",
        "axes.labelcolor": INK_SOFT,
        "text.color": INK,
        "xtick.color": INK_MUTED,
        "ytick.color": INK_MUTED,
        "axes.titlesize": 15,
        "axes.labelsize": 12,
        "legend.frameon": False,
    })


def configure_korean_font() -> None:
    """
    운영체제에 깔린 한글 폰트를 찾아 Matplotlib에 적용한다.

    폰트를 못 찾아도 실행을 멈추지는 않는다. 차트의 한글이 네모로 깨질 뿐 수치와
    분석 결과는 그대로 나오기 때문이다. 대신 경고를 남겨서 캡처를 뜨기 전에
    알아챌 수 있게 한다.
    """
    installed = {font.name for font in font_manager.fontManager.ttflist}

    for font_name in ("AppleGothic", "Malgun Gothic", "NanumGothic"):
        if font_name in installed:
            plt.rcParams["font.family"] = font_name
            logger.debug(f"한글 폰트 적용: {font_name}")
            return

    logger.warning(
        "[경고] 한글 폰트를 찾지 못했습니다. 차트의 한글이 깨져 보이면 "
        "AppleGothic·맑은 고딕·나눔고딕 중 하나를 설치한 뒤 다시 실행하세요."
    )


# ---------------------------------------------------------------------------
# 1. 데이터 준비 — 원본 캐시 후 Pandas / Polars 로딩 및 비교
# ---------------------------------------------------------------------------

def download_dataset(url: str, destination: Path) -> Path:
    """
    원본 데이터를 한 번만 내려받아 로컬에 캐시합니다.

    Pandas와 Polars가 각각 URL을 호출하면 네트워크 상태 차이가 로딩 시간에 섞여
    라이브러리 비교가 공정하지 않습니다. 또한 Polars의 read_csv는 로컬 경로 입력이
    가장 안정적이므로, 동일한 로컬 파일을 두 라이브러리에 똑같이 입력합니다.
    """
    destination.parent.mkdir(parents=True, exist_ok=True)

    if destination.exists() and destination.stat().st_size > 0:
        logger.info(f"[캐시 사용] 이미 내려받은 원본을 사용합니다: {destination}")
        return destination

    logger.info(f"[다운로드] {url}")
    try:
        urllib.request.urlretrieve(url, destination)
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as error:
        raise SystemExit(
            f"[네트워크 오류] 원본 데이터를 내려받지 못했습니다: {error}\n"
            f"브라우저로 {url} 를 저장한 뒤 {destination} 경로에 두고 다시 실행하세요."
        ) from error

    if destination.stat().st_size == 0:
        raise ValueError(f"내려받은 파일이 비어 있습니다: {destination}")

    logger.info(f"[다운로드 완료] {destination} ({destination.stat().st_size:,} bytes)")
    return destination


def load_with_pandas(path: Path) -> tuple[pd.DataFrame, float]:
    """Pandas로 데이터를 로딩하고 소요 시간을 함께 반환합니다."""
    start = time.perf_counter()
    # header=None: 원본에 컬럼명이 없습니다.
    # skipinitialspace=True: 값이 ", State-gov"처럼 콤마 뒤 공백을 포함합니다.
    # na_values="?": Adult 데이터는 결측을 '?' 문자열로 표기합니다.
    dataframe = pd.read_csv(
        path,
        header=None,
        names=COLUMNS,
        skipinitialspace=True,
        na_values="?",
        skip_blank_lines=True,
    )
    elapsed = time.perf_counter() - start
    return dataframe, elapsed


def load_with_polars(path: Path) -> tuple[pl.DataFrame, float]:
    """Polars로 동일한 데이터를 로딩하고 소요 시간을 함께 반환합니다."""
    start = time.perf_counter()
    # Polars에는 skipinitialspace 옵션이 없어 값이 " State-gov"처럼 앞 공백을 포함합니다.
    # 그래서 (1) 문자열 공백 제거 → (2) '?'를 null 처리 → (3) 숫자 컬럼 캐스팅 →
    # (4) 파일 끝 빈 줄이 만든 전부 null인 행 제거 순으로, Pandas 로딩 결과와 맞춥니다.
    frame = (
        pl.read_csv(
            path,
            has_header=False,
            new_columns=COLUMNS,
            infer_schema_length=0,  # 앞 공백 때문에 숫자 컬럼이 잘못 추론되므로 모두 문자열로 읽습니다.
            truncate_ragged_lines=True,
        )
        .with_columns(pl.col(pl.String).str.strip_chars())
        .with_columns(
            pl.when(pl.col(pl.String) == "?")
            .then(None)
            .otherwise(pl.col(pl.String))
            .name.keep()
        )
        .with_columns(pl.col(POLARS_NUMERIC_COLUMNS).cast(pl.Int64, strict=False))
        .filter(~pl.all_horizontal(pl.all().is_null()))
    )
    elapsed = time.perf_counter() - start
    return frame, elapsed


def compare_pandas_polars(
    pandas_df: pd.DataFrame,
    pandas_seconds: float,
    polars_df: pl.DataFrame,
    polars_seconds: float,
) -> dict[str, Any]:
    """두 라이브러리의 shape·로딩 시간·메모리 사용량·결측 수를 비교 출력합니다."""
    log_section("1. 데이터 로딩: Pandas vs Polars 비교")

    # deep=True라야 object(문자열) 컬럼의 실제 문자열 메모리까지 합산됩니다.
    pandas_mb = pandas_df.memory_usage(deep=True).sum() / 1024 ** 2
    polars_mb = polars_df.estimated_size("mb")

    pandas_nulls = int(pandas_df.isna().sum().sum())
    polars_nulls = int(polars_df.null_count().sum_horizontal().item())

    logger.info(f"Pandas shape        : {pandas_df.shape}")
    logger.info(f"Polars shape        : {polars_df.shape}")
    logger.info(f"Pandas loading time : {pandas_seconds:.4f} 초")
    logger.info(f"Polars loading time : {polars_seconds:.4f} 초")
    logger.info(f"Pandas 메모리 사용량 : {pandas_mb:,.2f} MB")
    logger.info(f"Polars 메모리 사용량 : {polars_mb:,.2f} MB")
    logger.info(f"Pandas 전체 결측치 수 : {pandas_nulls:,}")
    logger.info(f"Polars 전체 결측치 수 : {polars_nulls:,}")

    shape_match = pandas_df.shape == polars_df.shape
    null_match = pandas_nulls == polars_nulls
    logger.info(f"\nshape 일치 여부      : {'일치' if shape_match else '불일치'}")
    logger.info(f"결측치 수 일치 여부  : {'일치' if null_match else '불일치'}")

    logger.info("\n[Pandas head(3)]")
    logger.info(pandas_df.head(3).to_string())
    logger.info("\n[Polars head(3)]")
    logger.info(polars_df.head(3))

    return {
        "pandas_shape": pandas_df.shape,
        "polars_shape": polars_df.shape,
        "pandas_seconds": pandas_seconds,
        "polars_seconds": polars_seconds,
        "pandas_mb": pandas_mb,
        "polars_mb": polars_mb,
        "pandas_nulls": pandas_nulls,
        "polars_nulls": polars_nulls,
        "shape_match": shape_match,
        "null_match": null_match,
    }


# ---------------------------------------------------------------------------
# 2. 결측치 · 중복 처리
# ---------------------------------------------------------------------------

def clean_data(dataframe: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    """
    결측치와 중복을 확인하고 처리합니다.

    처리 방침:
    - 중복 행은 같은 응답이 두 번 집계되어 분포와 검정 결과를 왜곡하므로 제거합니다.
    - 결측치가 있는 세 컬럼(workclass, occupation, native-country)은 모두 범주형이며
      전체의 일부에 불과합니다. EDA에서는 결측을 제거하지 않고 '결측 제외' 상태로
      집계하여 원본 분포를 보존하고, ML에서는 행을 버리지 않고 Pipeline의
      SimpleImputer(최빈값)로 대치합니다. 목표 변수 income에 결측이 있으면
      정답이 없는 행이므로 그 행만 제거합니다.
    """
    log_section("2. 결측치 / 중복 데이터 확인 및 처리")

    missing_by_column = dataframe.isna().sum()
    duplicate_count = int(dataframe.duplicated().sum())

    logger.info("[컬럼별 결측치 수]")
    logger.info(missing_by_column.to_string())
    logger.info(f"\n결측치가 있는 컬럼 수 : {int((missing_by_column > 0).sum())}")
    logger.info(f"전체 결측치 수        : {int(missing_by_column.sum()):,}")
    logger.info(f"중복 행 개수          : {duplicate_count:,}")

    before_rows = len(dataframe)
    cleaned = dataframe.drop_duplicates().copy()
    after_duplicates = len(cleaned)

    # income 문자열에 공백이나 마침표('<=50K.')가 섞이면 클래스가 4개로 갈라집니다.
    cleaned[TARGET_COLUMN] = cleaned[TARGET_COLUMN].str.strip().str.rstrip(".")
    cleaned = cleaned[cleaned[TARGET_COLUMN].notna()]
    after_target = len(cleaned)

    if cleaned.empty:
        raise ValueError("중복·결측 처리 후 분석할 데이터가 없습니다.")

    logger.info(f"\n원본 행 수                    : {before_rows:,}")
    logger.info(f"중복 제거 후 행 수            : {after_duplicates:,} (제거 {before_rows - after_duplicates:,}행)")
    logger.info(f"목표 변수 결측 제거 후 행 수  : {after_target:,} (제거 {after_duplicates - after_target:,}행)")
    logger.info(f"처리 후 남은 결측치 수        : {int(cleaned.isna().sum().sum()):,} "
          f"(범주형 3개 컬럼 — ML Pipeline에서 최빈값으로 대치)")
    logger.info(f"income 클래스 목록            : {sorted(cleaned[TARGET_COLUMN].unique())}")

    summary = {
        "missing_by_column": missing_by_column[missing_by_column > 0].to_dict(),
        "missing_total": int(missing_by_column.sum()),
        "duplicate_count": duplicate_count,
        "rows_before": before_rows,
        "rows_after": after_target,
        "missing_after": int(cleaned.isna().sum().sum()),
        "classes": sorted(cleaned[TARGET_COLUMN].unique()),
    }
    return cleaned, summary


# ---------------------------------------------------------------------------
# 3. 기본 EDA
# ---------------------------------------------------------------------------

def perform_eda(dataframe: pd.DataFrame) -> dict[str, Any]:
    """소득 분포와 주요 범주형 변수 빈도를 출력하여 데이터의 전반적 구조를 확인합니다."""
    log_section("3. 기본 EDA")

    logger.info("[데이터 구조]")
    logger.info(f"행 수 : {len(dataframe):,} / 열 수 : {len(dataframe.columns)}")
    logger.info("\n[dtypes]")
    logger.info(dataframe.dtypes.to_string())

    income_counts = dataframe[TARGET_COLUMN].value_counts()
    income_ratio = dataframe[TARGET_COLUMN].value_counts(normalize=True)

    logger.info("\n[income 분포]")
    for label in income_counts.index:
        logger.info(f"{label:>6} : {income_counts[label]:>7,}건 ({income_ratio[label]:.2%})")
    # 클래스 불균형은 Accuracy만 보면 안 되는 이유가 되므로 비율을 명시적으로 남깁니다.
    logger.info(f"클래스 불균형 비율(다수/소수) : {income_counts.max() / income_counts.min():.2f} : 1")

    logger.info("\n[education 빈도 상위 5개]")
    logger.info(dataframe["education"].value_counts().head(5).to_string())
    logger.info("\n[occupation 빈도 상위 5개, 결측 제외]")
    logger.info(dataframe["occupation"].value_counts().head(5).to_string())
    logger.info("\n[sex 빈도]")
    logger.info(dataframe["sex"].value_counts().to_string())

    return {
        "income_counts": income_counts.to_dict(),
        "income_ratio": {k: float(v) for k, v in income_ratio.items()},
        "imbalance_ratio": float(income_counts.max() / income_counts.min()),
        "top_education": dataframe["education"].value_counts().head(5).to_dict(),
        "top_occupation": dataframe["occupation"].value_counts().head(5).to_dict(),
    }


# ---------------------------------------------------------------------------
# 4. 기술통계 · 상관분석
# ---------------------------------------------------------------------------

def descriptive_statistics(dataframe: pd.DataFrame) -> pd.DataFrame:
    """수치형 변수의 평균·표준편차·분위수를 출력합니다."""
    log_section("4. 기술통계: 평균 / 표준편차 / 분위수")

    description = dataframe[NUMERIC_FEATURES].describe().T
    logger.info(description.to_string(float_format=lambda value: f"{value:,.2f}"))

    logger.info("\n[소득 집단별 주요 지표 평균]")
    grouped = dataframe.groupby(TARGET_COLUMN)[
        ["age", "education-num", "hours-per-week"]
    ].mean()
    logger.info(grouped.to_string(float_format=lambda value: f"{value:,.2f}"))

    return description


def correlation_analysis(dataframe: pd.DataFrame) -> pd.DataFrame:
    """수치형 변수 간 상관계수 행렬을 출력합니다."""
    log_section("5. 상관분석: 수치형 변수 상관계수")

    # 목표 변수와의 관계를 함께 보기 위해 income을 0/1로 바꾼 파생 컬럼을 추가합니다.
    numeric_frame = dataframe[NUMERIC_FEATURES].copy()
    numeric_frame["income_binary"] = (dataframe[TARGET_COLUMN] == POSITIVE_LABEL).astype(int)

    correlation = numeric_frame.corr()
    logger.info(correlation.to_string(float_format=lambda value: f"{value: .4f}"))

    target_correlation = (
        correlation["income_binary"].drop("income_binary").sort_values(ascending=False)
    )
    logger.info("\n[고소득 여부(income_binary)와의 상관계수, 절댓값 큰 순]")
    logger.info(target_correlation.to_string(float_format=lambda value: f"{value: .4f}"))

    save_correlation_heatmap(correlation)
    return correlation


def save_correlation_heatmap(correlation: pd.DataFrame) -> None:
    """상관계수 행렬을 Seaborn 히트맵으로 저장합니다(숫자 표만으로는 크기 비교가 어렵기 때문)."""
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    korean_labels = {
        "age": "나이",
        "education-num": "교육 연수",
        "capital-gain": "자본 이득",
        "capital-loss": "자본 손실",
        "hours-per-week": "주당 근로시간",
        "income_binary": "고소득 여부",
    }
    labeled = correlation.rename(index=korean_labels, columns=korean_labels)

    # 대칭 행렬이라 위쪽 절반은 같은 정보의 반복입니다.
    # 아래 삼각형만 남기고, 전부 가려지는 첫 행·마지막 열은 잘라 빈 칸을 없앱니다.
    lower_triangle = labeled.iloc[1:, :-1]
    upper_mask = np.triu(np.ones_like(lower_triangle, dtype=bool), k=1)

    fig, ax = plt.subplots(figsize=(8.5, 6.5))
    sns.heatmap(
        lower_triangle, mask=upper_mask, annot=True, fmt=".3f",
        cmap=DIVERGING_CMAP, vmin=-1, vmax=1, center=0,  # 무상관(0)을 중립색에 고정합니다.
        linewidths=2, linecolor=SURFACE, annot_kws={"fontsize": 11},
        cbar_kws={"shrink": 0.7, "ticks": [-1, -0.5, 0, 0.5, 1]}, ax=ax,
    )
    ax.set_title(
        "수치형 변수 상관계수 (고소득 여부와 가장 관련이 큰 변수는 교육 연수)",
        loc="left", color=INK,
    )
    ax.set_xlabel("변수")
    ax.set_ylabel("변수")
    ax.tick_params(axis="both", rotation=0, length=0)
    ax.grid(False)
    # 세로로 세운 y축 이름('변수')이 그림 왼쪽 끝에서 잘리므로,
    # bbox_inches="tight"로 실제 그려진 요소를 모두 포함하도록 여백을 다시 계산합니다.
    fig.tight_layout(pad=1.5)
    fig.savefig(CORRELATION_PNG, dpi=200, facecolor=SURFACE, bbox_inches="tight")
    plt.close(fig)

    logger.info(f"\n[저장 완료] {CORRELATION_PNG}")


# ---------------------------------------------------------------------------
# 5. t-test
# ---------------------------------------------------------------------------

def perform_t_test(dataframe: pd.DataFrame) -> dict[str, Any]:
    """
    두 소득 집단의 주당 근로시간 평균 차이를 독립표본 t-test로 검정합니다.

    H0: 두 소득 집단의 평균 주당 근로시간은 같다.
    H1: 두 소득 집단의 평균 주당 근로시간은 다르다.
    """
    log_section("6. t-test: 소득 집단별 주당 근로시간 평균 비교")

    low_group = dataframe.loc[dataframe[TARGET_COLUMN] == "<=50K", "hours-per-week"].dropna()
    high_group = dataframe.loc[dataframe[TARGET_COLUMN] == POSITIVE_LABEL, "hours-per-week"].dropna()

    for name, values in (("<=50K", low_group), (">50K", high_group)):
        if len(values) < 2:
            raise ValueError(f"t-test를 하려면 '{name}' 집단 데이터가 2개 이상 필요합니다.")

    logger.info("H0 : 두 소득 집단의 평균 주당 근로시간은 같다.")
    logger.info("H1 : 두 소득 집단의 평균 주당 근로시간은 다르다.")
    logger.info(f"\n<=50K 집단 : n = {len(low_group):,} / 평균 = {low_group.mean():.4f} / 표준편차 = {low_group.std():.4f}")
    logger.info(f" >50K 집단 : n = {len(high_group):,} / 평균 = {high_group.mean():.4f} / 표준편차 = {high_group.std():.4f}")

    # 두 집단은 표본 수와 분산이 서로 다르므로 등분산을 강하게 가정하지 않는
    # Welch's t-test(equal_var=False)를 사용합니다.
    t_stat, p_value = ttest_ind(high_group, low_group, equal_var=False)

    if not (np.isfinite(t_stat) and np.isfinite(p_value)):
        raise ValueError("t-test 결과가 유효하지 않습니다(집단 분산이 0인지 확인하세요).")

    # 표본이 3만 건이 넘으면 아주 작은 차이도 p-value가 작게 나옵니다.
    # p-value는 '차이가 있는지'만 알려주므로, '차이가 얼마나 큰지'는 효과크기로 따로 봅니다.
    mean_difference = float(high_group.mean() - low_group.mean())
    cohens_d = compute_cohens_d(high_group, low_group)
    effect_label = interpret_effect_size(cohens_d)

    logger.info(f"\nt-statistic : {t_stat:.6f}")
    logger.info(f"p-value     : {format_p_value(p_value)}")
    logger.info(f"평균 차이   : {mean_difference:.4f} 시간/주")
    logger.info(f"Cohen's d   : {cohens_d:.4f} ({effect_label})")

    if p_value < ALPHA:
        interpretation = (
            f"p-value가 유의수준 {ALPHA:.2f}보다 작으므로 귀무가설(H0)을 기각합니다. "
            "즉 두 소득 집단의 평균 주당 근로시간에는 통계적으로 유의한 차이가 있습니다. "
            f"다만 표본이 {len(low_group) + len(high_group):,}건으로 매우 크면 작은 차이도 유의하게 나오므로, "
            f"차이의 크기까지 함께 보아야 합니다. 실제 차이는 {mean_difference:.2f}시간/주이고 "
            f"Cohen's d는 {cohens_d:.3f}({effect_label})입니다. "
            "또한 이는 '차이가 있다'는 의미일 뿐, 근로시간이 고소득의 원인이라는 뜻은 아닙니다."
        )
    else:
        interpretation = (
            f"p-value가 유의수준 {ALPHA:.2f} 이상이므로 귀무가설(H0)을 기각할 근거가 부족합니다. "
            "즉 두 집단의 평균 근로시간 차이를 통계적으로 확인하지 못했습니다."
        )

    logger.info(f"해석        : {interpretation}")

    return {
        "low_n": len(low_group),
        "high_n": len(high_group),
        "low_mean": float(low_group.mean()),
        "high_mean": float(high_group.mean()),
        "low_std": float(low_group.std()),
        "high_std": float(high_group.std()),
        "t_stat": float(t_stat),
        "p_value": float(p_value),
        "mean_difference": mean_difference,
        "cohens_d": cohens_d,
        "effect_label": effect_label,
        "interpretation": interpretation,
    }


def compute_cohens_d(group_a: pd.Series, group_b: pd.Series) -> float:
    """
    두 집단 평균 차이의 효과크기(Cohen's d)를 계산합니다.

    합동 표준편차(pooled SD)로 평균 차이를 나눈 값이라, 표본 크기가 커져도 값이 커지지
    않습니다. p-value가 '차이의 존재'를 말한다면 d는 '차이의 크기'를 말합니다.
    """
    n_a, n_b = len(group_a), len(group_b)
    variance_a, variance_b = group_a.var(ddof=1), group_b.var(ddof=1)
    pooled_std = np.sqrt(((n_a - 1) * variance_a + (n_b - 1) * variance_b) / (n_a + n_b - 2))

    if pooled_std == 0:
        raise ValueError("두 집단의 분산이 모두 0이라 효과크기를 계산할 수 없습니다.")

    return float((group_a.mean() - group_b.mean()) / pooled_std)


def interpret_effect_size(cohens_d: float) -> str:
    """Cohen(1988)의 관례적 기준으로 효과크기를 해석합니다."""
    magnitude = abs(cohens_d)

    if magnitude < 0.2:
        return "매우 작음"
    if magnitude < 0.5:
        return "작음"
    if magnitude < 0.8:
        return "중간"
    return "큼"


# ---------------------------------------------------------------------------
# 6. 시각화 — Seaborn 2종 + Plotly 1종 (모두 제목·x축·y축 레이블 포함)
# ---------------------------------------------------------------------------

def create_seaborn_plots(dataframe: pd.DataFrame) -> None:
    """소득 클래스 분포와 소득별 나이 분포를 Seaborn 정적 차트로 저장합니다."""
    log_section("7. Seaborn 정적 차트 생성")

    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    palette = {"<=50K": COLOR_LOW, ">50K": COLOR_HIGH}
    order = ["<=50K", POSITIVE_LABEL]

    # ── Seaborn 1: 소득 클래스 분포 ────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(8, 5.5))
    sns.countplot(
        data=dataframe, x=TARGET_COLUMN, order=order,
        hue=TARGET_COLUMN, palette=palette, legend=False, width=0.55, ax=ax,
    )
    total = len(dataframe)
    # 막대 위에 건수와 비율을 함께 적어 클래스 불균형 정도가 바로 읽히게 합니다.
    for patch, label in zip(ax.patches, order):
        count = int(patch.get_height())
        ax.annotate(
            f"{count:,}건 ({count / total:.1%})",
            xy=(patch.get_x() + patch.get_width() / 2, count),
            xytext=(0, 6), textcoords="offset points",
            ha="center", color=INK, fontsize=12,
        )
    ax.margins(y=0.15)
    ax.set_title("소득 클래스 분포 (저소득 집단이 약 3배 많음)", loc="left", color=INK)
    ax.set_xlabel("연간 소득 구간 (income)")
    ax.set_ylabel("응답자 수 (명)")
    # 한글 폰트에 '<'·'>' 글리프가 없어 깨지므로 눈금 이름만 한글 표기로 바꿉니다.
    ax.set_xticks(range(len(order)))
    ax.set_xticklabels([DISPLAY_LABELS[label] for label in order])
    fig.tight_layout()
    fig.savefig(INCOME_PNG, dpi=200, facecolor=SURFACE)
    plt.close(fig)
    logger.info(f"[저장 완료] {INCOME_PNG}")

    # ── Seaborn 2: 소득별 나이 분포 ───────────────────────────────────────
    fig, ax = plt.subplots(figsize=(9, 5.5))
    sns.histplot(
        data=dataframe, x="age", hue=TARGET_COLUMN, hue_order=order,
        palette=palette, bins=40, element="step",
        # 두 집단의 표본 수 차이가 크므로 stat="density"로 각 분포의 모양을 비교합니다.
        stat="density", common_norm=False, alpha=0.35, ax=ax,
    )
    # 평균선 주석이 히스토그램 마루와 겹치지 않도록, y축 위쪽에 여백을 먼저 확보합니다.
    ax.margins(y=0.18)
    for label, color in palette.items():
        mean_age = dataframe.loc[dataframe[TARGET_COLUMN] == label, "age"].mean()
        ax.axvline(mean_age, color=color, linewidth=1.4, linestyle="--")
        ax.annotate(
            f"{DISPLAY_LABELS[label]} 평균 {mean_age:.1f}세",
            xy=(mean_age, ax.get_ylim()[1]),
            xytext=(6, -16 if label == "<=50K" else -34),
            textcoords="offset points", color=color, fontsize=11,
            bbox={"facecolor": SURFACE, "edgecolor": "none", "pad": 1.5},
        )
    ax.set_title("소득 집단별 나이 분포 (고소득 집단은 중년층에 몰려 있음)", loc="left", color=INK)
    ax.set_xlabel("나이 (세)")
    ax.set_ylabel("상대 밀도 (집단별 정규화)")
    legend = ax.get_legend()
    if legend is not None:
        legend.set_title("소득 구간")
        for text, label in zip(legend.get_texts(), order):
            text.set_text(DISPLAY_LABELS[label])
    fig.tight_layout()
    fig.savefig(AGE_PNG, dpi=200, facecolor=SURFACE)
    plt.close(fig)
    logger.info(f"[저장 완료] {AGE_PNG}")


def create_plotly_chart(dataframe: pd.DataFrame) -> None:
    """교육 수준별 고소득(>50K) 비율을 Plotly 인터랙티브 막대 차트로 저장합니다."""
    log_section("8. Plotly 인터랙티브 차트 생성")

    FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    # 교육 수준은 education-num이 곧 서열이므로 그 순서대로 x축을 세웁니다.
    summary = (
        dataframe.assign(is_high=(dataframe[TARGET_COLUMN] == POSITIVE_LABEL).astype(int))
        .groupby(["education-num", "education"], as_index=False)
        .agg(고소득비율=("is_high", "mean"), 인원수=("is_high", "size"))
        .sort_values("education-num")
    )
    summary["고소득비율(%)"] = summary["고소득비율"] * 100

    figure = px.bar(
        summary,
        x="education", y="고소득비율(%)",
        color="고소득비율(%)",
        color_continuous_scale=["#c9dcf5", COLOR_HIGH],
        custom_data=["education-num", "인원수"],
        template="plotly_white",
    )
    figure.update_traces(
        hovertemplate=(
            "<b>%{x}</b> (education-num %{customdata[0]})<br>"
            "고소득 비율 %{y:.1f}%<br>표본 %{customdata[1]:,}명<extra></extra>"
        )
    )
    figure.update_layout(
        title={
            "text": (
                "교육 수준별 고소득(&gt;50K) 비율"
                f"<br><sup style='color:{INK_SOFT}'>UCI Adult Census Income · "
                f"정제 후 {len(dataframe):,}건 · 막대에 마우스를 올리면 표본 수가 표시됩니다</sup>"
            ),
            "x": 0.02, "font": {"size": 20, "color": INK},
        },
        xaxis={"title": "교육 수준 (education, 낮은 학력 → 높은 학력 순)", "categoryorder": "array",
               "categoryarray": summary["education"].tolist()},
        yaxis={"title": "고소득(>50K) 비율 (%)", "gridcolor": GRID},
        font={"family": "AppleGothic, Malgun Gothic, NanumGothic, sans-serif",
              "size": 13, "color": INK_SOFT},
        coloraxis_showscale=False,
        paper_bgcolor=SURFACE, plot_bgcolor=SURFACE,
        margin={"l": 70, "r": 40, "t": 110, "b": 120}, height=620,
    )

    # fig.show()가 아니라 write_html로 저장해야 제출용 산출물이 파일로 남습니다.
    figure.write_html(
        EDUCATION_HTML, include_plotlyjs=True, full_html=True,
        config={"responsive": True, "displaylogo": False},
    )

    if not EDUCATION_HTML.exists() or EDUCATION_HTML.stat().st_size == 0:
        raise OSError(f"Plotly HTML 저장에 실패했습니다: {EDUCATION_HTML}")

    logger.info(f"[저장 완료] {EDUCATION_HTML}")
    logger.info("브라우저에서 열어 hover tooltip이 보이는 화면을 캡처하세요.")


# ---------------------------------------------------------------------------
# 7. 머신러닝 Pipeline — 전처리 + 모델을 한 객체로 구성
# ---------------------------------------------------------------------------

def build_pipeline() -> Pipeline:
    """ColumnTransformer로 수치형·범주형 전처리를 나누고 LogisticRegression과 묶습니다."""
    numeric_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        # 로지스틱 회귀는 변수 스케일에 민감하고 수렴 속도에도 영향을 받으므로 표준화합니다.
        ("scaler", StandardScaler()),
    ])
    categorical_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        # handle_unknown="ignore": 학습에 없던 범주(예: 새로운 native-country)가 들어와도
        # 예측이 실패하지 않고 0 벡터로 처리됩니다.
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, NUMERIC_FEATURES),
            ("categorical", categorical_pipeline, CATEGORICAL_FEATURES),
        ],
        remainder="drop",
    )

    return Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("model", LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)),
    ])


def train_machine_learning_pipeline(dataframe: pd.DataFrame) -> dict[str, Any]:
    """Pipeline을 학습·평가하고 전처리를 포함한 전체 객체를 joblib으로 저장합니다."""
    log_section("9. Machine Learning Pipeline: 학습 · 평가 · 저장")

    features = dataframe[FEATURE_COLUMNS]
    target = (dataframe[TARGET_COLUMN] == POSITIVE_LABEL).astype(int)

    if target.isna().any():
        raise ValueError("목표 변수에 결측이 남아 있습니다.")

    # stratify=target: 클래스 비율이 약 3:1이므로 학습·평가 세트의 비율을 동일하게 유지합니다.
    X_train, X_test, y_train, y_test = train_test_split(
        features, target, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=target
    )

    pipeline = build_pipeline()
    pipeline.fit(X_train, y_train)

    predictions = pipeline.predict(X_test)
    probabilities = pipeline.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": accuracy_score(y_test, predictions),
        "precision": precision_score(y_test, predictions),
        "recall": recall_score(y_test, predictions),
        "f1": f1_score(y_test, predictions),
        "roc_auc": roc_auc_score(y_test, probabilities),
    }
    matrix = confusion_matrix(y_test, predictions)
    report_text = classification_report(
        y_test, predictions, target_names=["<=50K", ">50K"], digits=4
    )

    logger.info(f"학습 데이터 수 : {len(X_train):,} / 평가 데이터 수 : {len(X_test):,}")
    logger.info(f"\nAccuracy  : {metrics['accuracy']:.4f}")
    logger.info(f"F1 Score  : {metrics['f1']:.4f}")
    logger.info(f"Precision : {metrics['precision']:.4f}")
    logger.info(f"Recall    : {metrics['recall']:.4f}")
    logger.info(f"ROC-AUC   : {metrics['roc_auc']:.4f}")
    logger.info("\n[Classification Report]")
    logger.info(report_text)
    logger.info("[Confusion Matrix]  행=실제, 열=예측")
    logger.info(pd.DataFrame(
        matrix, index=["실제 <=50K", "실제 >50K"], columns=["예측 <=50K", "예측 >50K"]
    ).to_string())

    # 한 번의 분할 결과가 우연인지 확인하기 위해 층화 5-겹 교차검증을 함께 수행합니다.
    cv_scores = cross_validate(
        build_pipeline(),
        features, target,
        cv=StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE),
        scoring=("accuracy", "f1", "roc_auc"),
        n_jobs=-1,
    )
    cv_summary = {
        name: (float(cv_scores[f"test_{name}"].mean()), float(cv_scores[f"test_{name}"].std()))
        for name in ("accuracy", "f1", "roc_auc")
    }
    logger.info(f"\n[{CV_FOLDS}-겹 교차검증: 평균 ± 표준편차]")
    for name, (mean_score, std_score) in cv_summary.items():
        logger.info(f"{name:<9}: {mean_score:.4f} ± {std_score:.4f}")

    top_coefficients = summarize_coefficients(pipeline, X_train)
    save_evaluation_figure(matrix, y_test, probabilities, metrics["roc_auc"])

    # 전처리 + 모델 전체 Pipeline을 저장해야 예측 시 같은 전처리가 그대로 재현됩니다.
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, MODEL_PATH)

    if not MODEL_PATH.exists() or MODEL_PATH.stat().st_size == 0:
        raise OSError(f"모델 저장에 실패했습니다: {MODEL_PATH}")

    logger.info(f"\n[저장 완료] {MODEL_PATH} ({MODEL_PATH.stat().st_size:,} bytes)")

    # 재로딩 후 예측이 같아야 전처리까지 온전히 직렬화된 것입니다.
    loaded = joblib.load(MODEL_PATH)
    if not np.array_equal(predictions, loaded.predict(X_test)):
        raise AssertionError("저장 전과 재로딩 후 예측 결과가 일치하지 않습니다.")
    logger.info("[재로딩 검증 완료] 저장 전과 재로딩 후 예측 결과가 일치합니다.")

    return {
        **metrics,
        "train_rows": len(X_train),
        "test_rows": len(X_test),
        "confusion_matrix": matrix.tolist(),
        "classification_report": report_text,
        "cv_summary": cv_summary,
        "top_coefficients": top_coefficients,
        "model_path": MODEL_PATH,
    }


def count_training_samples(feature_name: str, X_train: pd.DataFrame) -> int:
    """
    원-핫 특성 이름(`categorical__native-country_Cambodia`)에 해당하는 학습 표본 수를 셉니다.

    범주 안에 밑줄이 들어간 값(`Married-civ-spouse`는 없지만 `native-country`처럼 컬럼명에
    하이픈·밑줄이 섞일 수 있음)이 있어도 맞게 나누기 위해, 컬럼 이름을 먼저 맞춰 봅니다.
    """
    if not feature_name.startswith("categorical__"):
        return len(X_train)  # 수치형은 모든 행이 값을 가지므로 전체 표본 수입니다.

    body = feature_name.removeprefix("categorical__")

    for column in CATEGORICAL_FEATURES:
        if body.startswith(f"{column}_"):
            category = body.removeprefix(f"{column}_")
            return int((X_train[column] == category).sum())

    return 0


def summarize_coefficients(
    pipeline: Pipeline,
    X_train: pd.DataFrame,
) -> dict[str, list[tuple[str, float, int]]]:
    """
    학습된 로지스틱 회귀의 계수를 표본 수와 함께 정리합니다.

    수치형은 표준화, 범주형은 원-핫 인코딩되어 있으므로 계수의 부호와 크기를 '고소득 확률을
    높이는/낮추는 방향'으로 읽을 수 있습니다. 다만 표본이 적은 범주는 몇 건의 우연으로도
    계수가 크게 흔들리므로(희소 범주 과적합), 학습 표본이 MIN_SAMPLES_FOR_COEFFICIENT건
    미만인 범주는 신뢰할 수 있는 순위에서 제외하고 따로 보여 줍니다.
    """
    feature_names = pipeline.named_steps["preprocessor"].get_feature_names_out()
    coefficients = pipeline.named_steps["model"].coef_[0]

    entries = [
        (name, float(value), count_training_samples(name, X_train))
        for name, value in zip(feature_names, coefficients)
    ]
    reliable = sorted(
        (entry for entry in entries if entry[2] >= MIN_SAMPLES_FOR_COEFFICIENT),
        key=lambda entry: entry[1],
        reverse=True,
    )
    # 표본이 적은데도 계수 절댓값이 큰 항목 — '해석하면 안 되는 계수'의 예시로 보여 줍니다.
    unstable = sorted(
        (entry for entry in entries if entry[2] < MIN_SAMPLES_FOR_COEFFICIENT),
        key=lambda entry: abs(entry[1]),
        reverse=True,
    )[:5]

    top_positive = reliable[:5]
    top_negative = reliable[-5:]

    logger.info(f"\n[고소득 확률을 높이는 방향 상위 5개 — 학습 표본 {MIN_SAMPLES_FOR_COEFFICIENT}건 이상만]")
    for name, value, count in top_positive:
        logger.info(f"  {value:+.4f}  (n={count:,})  {name}")
    logger.info(f"[고소득 확률을 낮추는 방향 상위 5개 — 학습 표본 {MIN_SAMPLES_FOR_COEFFICIENT}건 이상만]")
    for name, value, count in reversed(top_negative):
        logger.info(f"  {value:+.4f}  (n={count:,})  {name}")

    logger.info(f"\n[참고: 표본이 적어 계수가 불안정한 항목 — 해석에서 제외]")
    for name, value, count in unstable:
        logger.info(f"  {value:+.4f}  (n={count:,})  {name}")

    return {"positive": top_positive, "negative": top_negative, "unstable": unstable}


def save_evaluation_figure(
    matrix: np.ndarray,
    y_test: pd.Series,
    probabilities: np.ndarray,
    roc_auc: float,
) -> None:
    """Confusion Matrix와 ROC 곡선을 한 Figure에 저장합니다(PDF 캡처용 평가 근거)."""
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    fig, (ax_matrix, ax_roc) = plt.subplots(1, 2, figsize=(14, 5.8))

    # ── Confusion Matrix ─────────────────────────────────────────────────
    labels = [DISPLAY_LABELS["<=50K"], DISPLAY_LABELS[">50K"]]
    sns.heatmap(
        matrix, annot=True, fmt=",d", cmap="Blues", cbar=False,
        xticklabels=[f"예측 {label}" for label in labels],
        yticklabels=[f"실제 {label}" for label in labels],
        linewidths=2, linecolor=SURFACE, annot_kws={"fontsize": 14}, ax=ax_matrix,
    )
    ax_matrix.set_title(
        "Confusion Matrix (고소득자를 놓친 경우가 왼쪽 아래에 몰려 있음)", loc="left", color=INK
    )
    ax_matrix.set_xlabel("예측 클래스")
    ax_matrix.set_ylabel("실제 클래스")
    ax_matrix.tick_params(axis="both", rotation=0, length=0)
    ax_matrix.grid(False)

    # ── ROC 곡선 ─────────────────────────────────────────────────────────
    false_positive_rate, true_positive_rate, _ = roc_curve(y_test, probabilities)
    ax_roc.plot(
        false_positive_rate, true_positive_rate,
        color=COLOR_HIGH, linewidth=2, label=f"ROC 곡선 (AUC = {roc_auc:.4f})",
    )
    # 무작위 분류기(AUC 0.5) 기준선을 함께 그려야 곡선의 개선 정도가 읽힙니다.
    ax_roc.plot([0, 1], [0, 1], color=INK_MUTED, linewidth=1, linestyle="--", label="무작위 분류 (AUC = 0.5)")
    ax_roc.set_xlim(0, 1)
    ax_roc.set_ylim(0, 1.02)
    ax_roc.set_title("ROC 곡선 (임계값을 바꿔 가며 본 분류 성능)", loc="left", color=INK)
    ax_roc.set_xlabel("거짓 양성 비율 (False Positive Rate)")
    ax_roc.set_ylabel("참 양성 비율 (True Positive Rate)")
    ax_roc.legend(loc="lower right", fontsize=11)

    # pad를 두지 않으면 세로로 세운 y축 이름이 그림 왼쪽 끝에서 잘립니다.
    fig.tight_layout(pad=1.8)
    fig.savefig(EVALUATION_PNG, dpi=200, facecolor=SURFACE)
    plt.close(fig)

    logger.info(f"\n[저장 완료] {EVALUATION_PNG}")


# ---------------------------------------------------------------------------
# 8. 심화 분석 — 파생변수 · 모델 비교 · 임계값 조정
#    (기본 요구사항을 만족한 뒤, Recall 0.62라는 약점을 실제로 개선해 봅니다)
# ---------------------------------------------------------------------------

def engineer_features(dataframe: pd.DataFrame) -> pd.DataFrame:
    """
    EDA에서 확인한 세 가지 패턴을 모델이 쓸 수 있는 형태로 바꿉니다.

    1) 나이 → 연령대 구간: 소득은 46~55세에서 정점을 찍고 다시 낮아지는 곡선 관계라,
       선형 계수 하나로는 표현되지 않습니다. 구간으로 묶으면 각 구간이 독립된 가중치를 갖습니다.
    2) 자본 이득·손실 → 발생 여부(0/1): 전체의 91.7%가 0원인 희소 변수라 금액 자체보다
       '있었는가'가 더 안정적인 신호입니다. 원래 금액 컬럼도 함께 남겨 둡니다.
    3) 범주형 결측 → 'Unknown' 범주: 최빈값으로 덮으면 '응답하지 않았다'는 정보가 사라집니다.
    """
    engineered = dataframe.copy()

    # 원본 나이 컬럼도 그대로 두어, 구간 정보와 연속 정보를 모두 사용할 수 있게 합니다.
    engineered["age-band"] = pd.cut(
        engineered["age"], bins=AGE_BIN_EDGES, labels=AGE_BIN_LABELS
    ).astype(str)
    engineered["has-capital-gain"] = (engineered["capital-gain"] > 0).astype(int)
    engineered["has-capital-loss"] = (engineered["capital-loss"] > 0).astype(int)

    return engineered


def build_engineered_pipeline(model: Any) -> Pipeline:
    """파생 변수를 쓰고 결측을 'Unknown' 범주로 남기는 Pipeline을 만듭니다."""
    numeric_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipeline = Pipeline(steps=[
        # strategy="constant": 결측을 최빈값으로 덮지 않고 별도 범주로 남깁니다.
        ("imputer", SimpleImputer(strategy="constant", fill_value=UNKNOWN_CATEGORY)),
        # sparse_output=False: 트리 모델(HistGradientBoosting)이 희소 행렬을 받지 못합니다.
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, ENGINEERED_NUMERIC_FEATURES),
            ("categorical", categorical_pipeline, ENGINEERED_CATEGORICAL_FEATURES),
        ],
        remainder="drop",
    )

    return Pipeline(steps=[("preprocessor", preprocessor), ("model", model)])


def evaluate_pipeline(
    pipeline: Pipeline,
    X_train: pd.DataFrame,
    X_test: pd.DataFrame,
    y_train: pd.Series,
    y_test: pd.Series,
) -> dict[str, float]:
    """Pipeline을 학습하고 동일한 평가 지표 묶음을 계산합니다(모델 간 비교용)."""
    pipeline.fit(X_train, y_train)
    predictions = pipeline.predict(X_test)
    probabilities = pipeline.predict_proba(X_test)[:, 1]

    return {
        "accuracy": accuracy_score(y_test, predictions),
        "precision": precision_score(y_test, predictions),
        "recall": recall_score(y_test, predictions),
        "f1": f1_score(y_test, predictions),
        "roc_auc": roc_auc_score(y_test, probabilities),
    }


def run_advanced_analysis(dataframe: pd.DataFrame) -> dict[str, Any]:
    """
    기본 모델의 약점(고소득층 Recall 0.62)을 세 방향으로 개선해 보고 결과를 비교합니다.

    ① 파생 변수 추가 + 결측을 Unknown 범주로
    ② 클래스 가중치 부여(class_weight="balanced")
    ③ 트리 기반 모델(HistGradientBoosting) — 원-핫으로 차원이 커진 범주형 데이터에 유리
    마지막으로 기본 모델의 판정 임계값을 조정했을 때 Recall이 얼마나 회복되는지 확인합니다.
    """
    log_section("10. 심화 분석: 파생변수 · 모델 비교 · 임계값 조정")

    engineered = engineer_features(dataframe)
    target = (engineered[TARGET_COLUMN] == POSITIVE_LABEL).astype(int)

    # 기본 모델과 같은 random_state·stratify를 써야 모델 간 비교가 공정합니다.
    train_index, test_index = train_test_split(
        engineered.index, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=target
    )
    y_train, y_test = target.loc[train_index], target.loc[test_index]

    base_train = engineered.loc[train_index, FEATURE_COLUMNS]
    base_test = engineered.loc[test_index, FEATURE_COLUMNS]
    engineered_columns = ENGINEERED_NUMERIC_FEATURES + ENGINEERED_CATEGORICAL_FEATURES
    engineered_train = engineered.loc[train_index, engineered_columns]
    engineered_test = engineered.loc[test_index, engineered_columns]

    candidates = {
        "① 기본 (로지스틱 회귀)": (
            build_pipeline(), base_train, base_test,
        ),
        "② + 파생변수 · Unknown 범주": (
            build_engineered_pipeline(
                LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)
            ),
            engineered_train, engineered_test,
        ),
        "③ + class_weight=balanced": (
            build_engineered_pipeline(
                LogisticRegression(
                    max_iter=1000, random_state=RANDOM_STATE, class_weight="balanced"
                )
            ),
            engineered_train, engineered_test,
        ),
        "④ 트리 기반 (HistGradientBoosting)": (
            build_engineered_pipeline(
                HistGradientBoostingClassifier(random_state=RANDOM_STATE)
            ),
            engineered_train, engineered_test,
        ),
    }

    comparison: dict[str, dict[str, float]] = {}
    for name, (pipeline, X_train, X_test) in candidates.items():
        comparison[name] = evaluate_pipeline(pipeline, X_train, X_test, y_train, y_test)
        logger.info(f"[학습 완료] {name}")

    comparison_frame = pd.DataFrame(comparison).T
    logger.info("\n[모델 비교: 동일한 학습·평가 분할 기준]")
    logger.info(comparison_frame.to_string(float_format=lambda value: f"{value:.4f}"))

    best_f1_model = comparison_frame["f1"].idxmax()
    best_recall_model = comparison_frame["recall"].idxmax()
    logger.info(f"\nF1 최고    : {best_f1_model} ({comparison_frame.loc[best_f1_model, 'f1']:.4f})")
    logger.info(f"Recall 최고: {best_recall_model} ({comparison_frame.loc[best_recall_model, 'recall']:.4f})")

    threshold = analyze_threshold(
        build_pipeline(), base_train, base_test, y_train, y_test
    )

    return {
        "comparison": comparison,
        "best_f1_model": best_f1_model,
        "best_recall_model": best_recall_model,
        "threshold": threshold,
    }


def analyze_threshold(
    pipeline: Pipeline,
    X_train: pd.DataFrame,
    X_test: pd.DataFrame,
    y_train: pd.Series,
    y_test: pd.Series,
) -> dict[str, Any]:
    """
    기본 모델의 판정 임계값을 0.05~0.95로 바꿔 가며 Precision·Recall·F1의 변화를 봅니다.

    predict()는 확률 0.5를 기준으로 잘라 판정하는데, 이 값은 통계적 근거가 있는 수치가 아니라
    단순 기본값입니다. 클래스가 3:1로 불균형하면 0.5는 다수 클래스에 유리하게 작동합니다.
    """
    pipeline.fit(X_train, y_train)
    probabilities = pipeline.predict_proba(X_test)[:, 1]

    thresholds = np.arange(0.05, 0.96, 0.01)
    rows = []
    for value in thresholds:
        predictions = (probabilities >= value).astype(int)
        rows.append({
            "threshold": float(value),
            "precision": precision_score(y_test, predictions, zero_division=0),
            "recall": recall_score(y_test, predictions),
            "f1": f1_score(y_test, predictions),
        })
    curve = pd.DataFrame(rows)

    best_row = curve.loc[curve["f1"].idxmax()]
    # 실제 고소득자의 80%를 잡으려면 정밀도를 얼마나 포기해야 하는지 확인합니다.
    recall_80 = curve[curve["recall"] >= 0.80]
    recall_80_row = recall_80.iloc[-1] if not recall_80.empty else None

    logger.info("\n[임계값 조정: 기본 모델]")
    logger.info(f"기본값 0.50    : Recall {curve.loc[curve['threshold'].sub(0.50).abs().idxmin(), 'recall']:.4f}")
    logger.info(f"F1 최대 임계값 : {best_row['threshold']:.2f} → "
          f"F1 {best_row['f1']:.4f} / Precision {best_row['precision']:.4f} / Recall {best_row['recall']:.4f}")
    if recall_80_row is not None:
        logger.info(f"Recall 0.80 달성: 임계값 {recall_80_row['threshold']:.2f} → "
              f"Precision {recall_80_row['precision']:.4f} (정밀도를 그만큼 포기해야 함)")

    save_threshold_figure(curve, float(best_row["threshold"]))

    return {
        "best_threshold": float(best_row["threshold"]),
        "best_f1": float(best_row["f1"]),
        "best_precision": float(best_row["precision"]),
        "best_recall": float(best_row["recall"]),
        "recall80_threshold": float(recall_80_row["threshold"]) if recall_80_row is not None else None,
        "recall80_precision": float(recall_80_row["precision"]) if recall_80_row is not None else None,
    }


def save_threshold_figure(curve: pd.DataFrame, best_threshold: float) -> None:
    """임계값에 따른 Precision·Recall·F1 변화를 한 그림으로 저장합니다."""
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(9.5, 5.8))
    for column, color, label in (
        ("precision", COLOR_LOW, "Precision (고소득이라 예측한 것 중 맞은 비율)"),
        ("recall", COLOR_HIGH, "Recall (실제 고소득자 중 찾아낸 비율)"),
        ("f1", INK, "F1 (둘의 조화평균)"),
    ):
        ax.plot(curve["threshold"], curve[column], color=color, linewidth=2, label=label)

    # 기본값 0.5와 F1이 가장 높은 임계값을 함께 표시해 둘의 차이를 보여 줍니다.
    for value, color, text in (
        (0.5, INK_MUTED, "기본값 0.50"),
        (best_threshold, "#008300", f"F1 최대 {best_threshold:.2f}"),
    ):
        ax.axvline(value, color=color, linewidth=1.2, linestyle="--")
        ax.annotate(
            text, xy=(value, 1.0), xytext=(5, -12), textcoords="offset points",
            color=color, fontsize=11,
            bbox={"facecolor": SURFACE, "edgecolor": "none", "pad": 1.5},
        )

    ax.set_xlim(0.05, 0.95)
    ax.set_ylim(0, 1.05)
    ax.set_title(
        "판정 임계값에 따른 성능 변화 (Precision과 Recall은 한쪽을 얻으면 한쪽을 잃음)",
        loc="left", color=INK,
    )
    ax.set_xlabel("판정 임계값 (이 확률 이상이면 고소득으로 예측)")
    ax.set_ylabel("지표 값")
    ax.legend(loc="lower left", fontsize=10)
    fig.tight_layout(pad=1.5)
    fig.savefig(THRESHOLD_PNG, dpi=200, facecolor=SURFACE)
    plt.close(fig)

    logger.info(f"[저장 완료] {THRESHOLD_PNG}")


# ---------------------------------------------------------------------------
# 9. 자동 보고서 생성 — 실제 실행 결과만 사용합니다.
# ---------------------------------------------------------------------------

def generate_report(
    load_summary: dict[str, Any],
    clean_summary: dict[str, Any],
    eda_summary: dict[str, Any],
    description: pd.DataFrame,
    correlation: pd.DataFrame,
    t_test: dict[str, Any],
    ml: dict[str, Any],
    advanced: dict[str, Any],
    versions: dict[str, str],
) -> None:
    """
    앞 단계에서 실제로 계산된 값만 써서 outputs/report.md를 만든다.

    보고서에 들어가는 숫자를 여기서 다시 계산하지 않는 것이 핵심이다.
    각 단계가 반환한 값을 그대로 받아 문자열에 끼워 넣기만 한다.
    보고서용으로 따로 계산하면 화면에 찍힌 값과 문서의 값이 어긋날 수 있는데,
    그러면 '실행하지 않은 숫자'가 문서에 남는 셈이라 신뢰할 수 없는 보고서가 된다.
    """
    log_section("11. outputs/report.md 자동 생성")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    environment_lines = "\n".join(f"| {name} | {version} |" for name, version in versions.items())
    faster = "Polars" if load_summary["polars_seconds"] < load_summary["pandas_seconds"] else "Pandas"
    ratio = max(load_summary["pandas_seconds"], load_summary["polars_seconds"]) / max(
        min(load_summary["pandas_seconds"], load_summary["polars_seconds"]), 1e-9
    )
    missing_lines = "\n".join(
        f"| {column} | {count:,} | {count / clean_summary['rows_before']:.2%} |"
        for column, count in clean_summary["missing_by_column"].items()
    )
    income_lines = "\n".join(
        f"| {label} | {count:,} | {eda_summary['income_ratio'][label]:.2%} |"
        for label, count in eda_summary["income_counts"].items()
    )
    matrix = ml["confusion_matrix"]
    cv_lines = "\n".join(
        f"| {name} | {mean_score:.4f} | ± {std_score:.4f} |"
        for name, (mean_score, std_score) in ml["cv_summary"].items()
    )
    positive_lines = "\n".join(
        f"| {name} | {value:+.4f} | {count:,} |"
        for name, value, count in ml["top_coefficients"]["positive"]
    )
    negative_lines = "\n".join(
        f"| {name} | {value:+.4f} | {count:,} |"
        for name, value, count in reversed(ml["top_coefficients"]["negative"])
    )
    unstable_lines = "\n".join(
        f"| {name} | {value:+.4f} | {count:,} |"
        for name, value, count in ml["top_coefficients"]["unstable"]
    )
    comparison_lines = "\n".join(
        f"| {name} | {scores['accuracy']:.4f} | {scores['precision']:.4f} | "
        f"{scores['recall']:.4f} | {scores['f1']:.4f} | {scores['roc_auc']:.4f} |"
        for name, scores in advanced["comparison"].items()
    )
    threshold = advanced["threshold"]

    report = f"""# Adult Census Income 분석 보고서

- 작성자: 판교_9반_김진수
- 자동 생성 일시: {datetime.now():%Y-%m-%d %H:%M:%S}
- 데이터 출처: {DATA_URL}
- 생성 스크립트: `src/main.py`

> 이 문서는 `src/main.py`를 실행할 때 자동으로 만들어집니다.
> 아래 수치는 손으로 옮겨 적은 값이 아니라 그 실행에서 계산된 값을 그대로 넣은 것입니다.

## 0. 실행 환경과 재현 방법

같은 코드라도 라이브러리 버전이 다르면 소수점 아래 숫자가 달라질 수 있어 환경을 함께 남깁니다.

| 항목 | 버전 |
|---|---|
{environment_lines}

재현 순서는 다음과 같습니다.

```bash
pip install -r requirements.txt
python src/main.py
```

`data/raw/adult.data`가 이미 있으면 그 파일을 쓰고, 없을 때만 원본 URL에서 내려받습니다.
난수를 쓰는 부분(학습·평가 분할, 교차검증, 모델 초기화)은 모두 `random_state={RANDOM_STATE}`로
고정했기 때문에 같은 환경에서 다시 돌리면 같은 수치가 나옵니다.
실행 과정은 `outputs/logs/run.log`에 시각과 함께 기록됩니다.

### 분석에 사용한 변수

| 변수 | 구분 | 설명 |
|---|---|---|
| `age` | 수치형 | 나이(세) |
| `education-num` | 수치형 | 교육 연수. `education`을 순서가 있는 숫자로 바꾼 값 |
| `capital-gain` | 수치형 | 자본 이득(달러). 대부분 0인 희소 변수 |
| `capital-loss` | 수치형 | 자본 손실(달러). 대부분 0인 희소 변수 |
| `hours-per-week` | 수치형 | 주당 근로시간 |
| `workclass` | 범주형 | 고용 형태(민간, 자영업, 공무원 등) |
| `education` | 범주형 | 최종 학력 |
| `marital-status` | 범주형 | 혼인 상태 |
| `occupation` | 범주형 | 직업군 |
| `relationship` | 범주형 | 가구 내 지위 |
| `race`, `sex` | 범주형 | 인종·성별. 민감 특성이라 11절에서 따로 짚습니다 |
| `native-country` | 범주형 | 출신 국가 |
| `income` | 목표 변수 | `<=50K` / `>50K` |

`fnlwgt`는 인구 추정 가중치라서 개인의 특성이 아니고, 그대로 넣으면 표본 설계 값을 학습하게 되므로 제외했습니다.

## 1. 데이터 로딩: Pandas vs Polars

| 항목 | Pandas | Polars |
|---|---|---|
| shape | {load_summary['pandas_shape']} | {load_summary['polars_shape']} |
| 로딩 시간 (초) | {load_summary['pandas_seconds']:.4f} | {load_summary['polars_seconds']:.4f} |
| 메모리 사용량 (MB) | {load_summary['pandas_mb']:.2f} | {load_summary['polars_mb']:.2f} |
| 전체 결측치 수 | {load_summary['pandas_nulls']:,} | {load_summary['polars_nulls']:,} |

- shape 일치 여부: **{'일치' if load_summary['shape_match'] else '불일치'}**
- 결측치 수 일치 여부: **{'일치' if load_summary['null_match'] else '불일치'}**
- 이번 실행에서는 **{faster}**가 약 {ratio:.1f}배 빠르게 로딩했습니다. 다만 1회 측정값이므로
  캐시·실행 환경에 따라 달라질 수 있어 두 라이브러리의 성능을 일반화하기는 어렵습니다.

## 2. 결측치 / 중복 처리

| 컬럼 | 결측치 수 | 비율 |
|---|---|---|
{missing_lines}

- 전체 결측치 수: {clean_summary['missing_total']:,}
- 중복 행 개수: {clean_summary['duplicate_count']:,}
- 원본 행 수: {clean_summary['rows_before']:,} → 처리 후 행 수: **{clean_summary['rows_after']:,}**
- 처리 방침: 중복 행은 제거, 목표 변수 결측 행은 제거, 나머지 범주형 결측은 행을 버리지 않고
  ML Pipeline의 `SimpleImputer(strategy="most_frequent")`로 대치했습니다.
  EDA에서는 원본 분포를 보존하기 위해 결측을 제외한 상태로 집계했습니다.

## 3. 기본 EDA

| income | 건수 | 비율 |
|---|---|---|
{income_lines}

- 클래스 불균형 비율(다수/소수): **{eda_summary['imbalance_ratio']:.2f} : 1**
- 다수 클래스가 약 {max(eda_summary['income_ratio'].values()):.0%}이므로, 모두 `<=50K`로 예측하기만 해도
  Accuracy가 그 수준이 됩니다. 따라서 Accuracy 단독 평가는 적절하지 않고 F1·Recall을 함께 봐야 합니다.

## 4. 기술통계

```
{description.to_string(float_format=lambda value: f"{value:,.2f}")}
```

## 5. 상관분석

```
{correlation.to_string(float_format=lambda value: f"{value: .4f}")}
```

## 6. t-test: 소득 집단별 주당 근로시간

- **H0**: 두 소득 집단의 평균 주당 근로시간은 같다.
- **H1**: 두 소득 집단의 평균 주당 근로시간은 다르다.
- 검정 방법: Welch's t-test (`scipy.stats.ttest_ind(..., equal_var=False)`)
  — 두 집단의 표본 수와 분산이 서로 달라 등분산을 가정하지 않았습니다.

| 집단 | 표본 수 | 평균 (시간/주) | 표준편차 |
|---|---|---|---|
| `<=50K` | {t_test['low_n']:,} | {t_test['low_mean']:.4f} | {t_test['low_std']:.4f} |
| `>50K` | {t_test['high_n']:,} | {t_test['high_mean']:.4f} | {t_test['high_std']:.4f} |

- t-statistic: **{t_test['t_stat']:.6f}**
- p-value: **{format_p_value(t_test['p_value'])}**
- 유의수준: {ALPHA:.2f}
- 평균 차이(효과크기): **{t_test['mean_difference']:.4f} 시간/주**, Cohen's d = **{t_test['cohens_d']:.4f}** ({t_test['effect_label']})
- 해석: {t_test['interpretation']}

> **p-value와 효과크기를 함께 보아야 하는 이유**
> 표본이 {t_test['low_n'] + t_test['high_n']:,}건으로 크면 아주 작은 차이도 p-value가 작게 나옵니다.
> p-value는 '차이가 있는지'만 답하고 '얼마나 큰지'는 답하지 못합니다.
> Cohen's d는 합동 표준편차로 나눈 값이라 표본 크기에 따라 커지지 않으므로,
> 이번 결과({t_test['cohens_d']:.3f}, {t_test['effect_label']})가 차이의 실제 크기를 나타냅니다.

## 7. Machine Learning Pipeline

구조: `ColumnTransformer(수치형: SimpleImputer → StandardScaler / 범주형: SimpleImputer → OneHotEncoder)`
→ `LogisticRegression(max_iter=1000)`

- 학습 데이터: {ml['train_rows']:,}행 / 평가 데이터: {ml['test_rows']:,}행 (test_size={TEST_SIZE}, stratify 적용)

| 지표 | 값 |
|---|---|
| Accuracy | {ml['accuracy']:.4f} |
| F1 Score | {ml['f1']:.4f} |
| Precision | {ml['precision']:.4f} |
| Recall | {ml['recall']:.4f} |
| ROC-AUC | {ml['roc_auc']:.4f} |

### Confusion Matrix (행=실제, 열=예측)

| | 예측 `<=50K` | 예측 `>50K` |
|---|---|---|
| 실제 `<=50K` | {matrix[0][0]:,} | {matrix[0][1]:,} |
| 실제 `>50K` | {matrix[1][0]:,} | {matrix[1][1]:,} |

### Classification Report

```
{ml['classification_report']}
```

### {CV_FOLDS}-겹 교차검증 (StratifiedKFold, shuffle)

| 지표 | 평균 | 표준편차 |
|---|---|---|
{cv_lines}

표준편차가 작다는 것은 위 단일 분할 결과가 특정 분할에 우연히 유리했던 값이 아니라는 뜻입니다.

### 모델이 학습한 방향 (로지스틱 회귀 계수 상위)

아래는 학습 표본이 {MIN_SAMPLES_FOR_COEFFICIENT}건 이상인 특성만 추린 결과입니다.

| 고소득 확률을 높이는 특성 | 계수 | 학습 표본 수 |
|---|---|---|
{positive_lines}

| 고소득 확률을 낮추는 특성 | 계수 | 학습 표본 수 |
|---|---|---|
{negative_lines}

계수는 다중공선성의 영향을 받으므로 개별 값을 인과적 효과 크기로 읽으면 안 되고,
모델이 어떤 방향으로 판단하는지를 보여주는 참고 자료로만 사용합니다.

### 해석에서 제외한 계수 (희소 범주 과적합)

| 특성 | 계수 | 학습 표본 수 |
|---|---|---|
{unstable_lines}

표본이 수십 건뿐인 범주는 몇 사람의 우연한 소득 분포만으로도 계수가 크게 흔들립니다.
계수 절댓값이 크다는 이유로 "이 국적이 소득에 영향을 준다"고 읽으면 안 되며,
위 순위표에서 제외한 이유가 바로 이것입니다.
이런 범주는 `Other`로 묶거나 정규화를 강화하는 방식으로 다루는 것이 안전합니다.

## 8. 심화 분석: 파생변수, 모델 비교, 임계값 조정

기본 모델의 가장 큰 약점은 고소득층 Recall {ml['recall']:.4f}입니다.
실제 고소득자 {matrix[1][0] + matrix[1][1]:,}명 중 {matrix[1][0]:,}명을 놓치고 있어,
이를 세 방향으로 개선해 보고 같은 학습·평가 분할에서 비교했습니다.

### 적용한 파생 변수

| 파생 변수 | 근거 |
|---|---|
| `age-band` (연령대 6구간) | 소득은 나이와 단조 증가가 아니라 46–55세에서 정점을 찍는 곡선 관계라, 선형 계수 하나로는 표현되지 않습니다. |
| `has-capital-gain`, `has-capital-loss` (0/1) | 자본 이득은 전체의 91.7%가 0원인 희소 변수라, 금액보다 '발생 여부'가 안정적인 신호입니다. |
| 결측 → `Unknown` 범주 | 최빈값으로 덮으면 '응답하지 않았다'는 정보 자체가 사라집니다. 별도 범주로 두면 모델이 그 패턴을 직접 판단합니다. |

### 모델 비교

| 모델 | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
{comparison_lines}

- F1 기준 최고: **{advanced['best_f1_model']}**
- Recall 기준 최고: **{advanced['best_recall_model']}**

### 임계값 조정 (기본 모델)

`predict()`가 쓰는 확률 0.5는 통계적 근거가 있는 값이 아니라 단순 기본값입니다.
클래스가 {eda_summary['imbalance_ratio']:.2f}:1로 불균형하면 0.5는 다수 클래스에 유리하게 작동합니다.

| 임계값 | Precision | Recall | F1 |
|---|---|---|---|
| 0.50 (기본값) | {ml['precision']:.4f} | {ml['recall']:.4f} | {ml['f1']:.4f} |
| {threshold['best_threshold']:.2f} (F1 최대) | {threshold['best_precision']:.4f} | {threshold['best_recall']:.4f} | {threshold['best_f1']:.4f} |
{f"| {threshold['recall80_threshold']:.2f} (Recall 0.80 달성) | {threshold['recall80_precision']:.4f} | 0.80 이상 | — |" if threshold['recall80_threshold'] is not None else ""}

모델을 다시 학습하지 않고 임계값만 바꿔도 Recall이 달라집니다.
다만 Precision이 함께 내려가므로, **어느 쪽을 우선할지는 모델의 용도가 정합니다.**
고소득 후보를 놓치면 안 되는 용도라면 Recall을, 잘못 지목하면 곤란한 용도라면 Precision을
우선해야 하며 하나의 정답 임계값은 없습니다. (`outputs/figures/threshold_tradeoff.png` 참고)

## 9. 산출물

| 파일 | 설명 |
|---|---|
파일 이름 앞의 번호는 이 보고서에 실린 순서와 같습니다.

| 파일 | 설명 |
|---|---|
| `outputs/figures/01_income_distribution.png` | Seaborn 정적 차트. 소득 클래스 분포 |
| `outputs/figures/02_age_by_income.png` | Seaborn 정적 차트. 소득 집단별 나이 분포 |
| `outputs/figures/03_correlation_heatmap.png` | Seaborn 정적 차트. 수치형 변수 상관계수 히트맵 |
| `outputs/figures/04_income_by_education.html` | Plotly 인터랙티브 차트. 교육 수준별 고소득 비율 |
| `outputs/figures/05_model_evaluation.png` | Confusion Matrix와 ROC 곡선 |
| `outputs/figures/06_threshold_tradeoff.png` | 임계값별 Precision·Recall·F1 변화 |
| `outputs/model/adult_income_pipeline.joblib` | 전처리와 모델을 함께 저장한 Pipeline |
| `outputs/report.md` | 이 보고서 |
| `outputs/logs/run.log` | 실행 로그 (시각·단계별 소요 시간 포함) |

## 10. 과제 요구사항 대응표

| 요구사항 | 구현 위치 | 결과 |
|---|---|---|
| Pandas 로딩 | `load_with_pandas()` | shape {load_summary['pandas_shape']}, {load_summary['pandas_seconds']:.4f}초 |
| Polars 로딩 | `load_with_polars()` | shape {load_summary['polars_shape']}, {load_summary['polars_seconds']:.4f}초 |
| 두 결과 비교 | `compare_pandas_polars()` | shape·결측 수 {'일치' if load_summary['shape_match'] and load_summary['null_match'] else '불일치'} |
| 결측치 확인·처리 | `clean_data()` | 결측 {clean_summary['missing_total']:,}개 확인, 범주형은 Imputer 대치 |
| 중복 확인·처리 | `clean_data()` | 중복 {clean_summary['duplicate_count']:,}행 제거 |
| 기본 EDA | `perform_eda()` | 소득 분포·범주형 빈도 출력 |
| Seaborn 차트 | `create_seaborn_plots()`, `save_correlation_heatmap()` | 정적 차트 3종 (제목·축 레이블 포함) |
| Plotly 차트 | `create_plotly_chart()` | 인터랙티브 HTML 1종 |
| 평균·표준편차·분위수 | `descriptive_statistics()` | `describe()` 출력 |
| 상관계수 | `correlation_analysis()` | 상관 행렬 + 히트맵 |
| t-test | `perform_t_test()` | t={t_test['t_stat']:.4f}, p={format_p_value(t_test['p_value'])} |
| p-value 해석 | `perform_t_test()` | 유의수준 {ALPHA:.2f} 기준 해석 + 효과크기(Cohen's d {t_test['cohens_d']:.3f}) |
| sklearn Pipeline | `build_pipeline()` | ColumnTransformer + LogisticRegression |
| Accuracy / F1 | `train_machine_learning_pipeline()` | {ml['accuracy']:.4f} / {ml['f1']:.4f} |
| Precision / Recall / ROC-AUC | 동일 | {ml['precision']:.4f} / {ml['recall']:.4f} / {ml['roc_auc']:.4f} |
| joblib 저장 | 동일 | `outputs/model/adult_income_pipeline.joblib` (재로딩 검증 완료) |
| report.md 자동 생성 | `generate_report()` | 이 문서 |
| (추가) 파생변수·모델 비교 | `run_advanced_analysis()` | 4개 모델 비교, F1 최고 {advanced['best_f1_model']} |
| (추가) 임계값 조정 | `analyze_threshold()` | {threshold['best_threshold']:.2f}에서 F1 {threshold['best_f1']:.4f} |

## 11. 분석 의견

- **관찰**: 고소득(`>50K`) 집단의 평균 주당 근로시간은 {t_test['high_mean']:.2f}시간으로
  저소득 집단의 {t_test['low_mean']:.2f}시간보다 {t_test['mean_difference']:.2f}시간 길었고,
  Welch t-test의 p-value는 {format_p_value(t_test['p_value'])}였습니다.
- **해석**: 통계적으로 유의한 차이는 확인되지만, 이는 상관관계일 뿐 근로시간이 소득을 높였다는
  인과관계의 근거는 아닙니다. 교육 수준·직업·연령이 동시에 작용했을 가능성이 큽니다.
  또한 표본이 {t_test['low_n'] + t_test['high_n']:,}건으로 커서 p-value만으로는 차이의 크기를 알 수 없어
  효과크기를 함께 계산했고, Cohen's d는 {t_test['cohens_d']:.3f}({t_test['effect_label']})였습니다.
  즉 **통계적으로는 확실하지만 실질적 격차 자체가 극적이지는 않다**는 것이 더 정확한 표현입니다.
- **한계 ①(불균형)**: 데이터가 약 {eda_summary['imbalance_ratio']:.1f}:1로 불균형하여
  Accuracy({ml['accuracy']:.4f})가 높아 보이지만, 고소득 클래스의 Recall은 {ml['recall']:.4f}로
  실제 고소득자 {matrix[1][0] + matrix[1][1]:,}명 중 {matrix[1][0]:,}명을 놓치고 있습니다.
- **한계 ②(계수 해석)**: 계수 절댓값 상위에는 표본이 수십 건뿐인 국적 범주가 올라옵니다.
  이는 실제 패턴이 아니라 희소 범주에서 계수가 불안정해지는 현상이므로,
  학습 표본 {MIN_SAMPLES_FOR_COEFFICIENT}건 미만은 해석에서 제외했습니다.
- **검증**: {CV_FOLDS}-겹 교차검증에서도 F1이 {ml['cv_summary']['f1'][0]:.4f} ± {ml['cv_summary']['f1'][1]:.4f}로
  단일 분할 결과와 크게 다르지 않아, 위 성능이 특정 분할에 의존한 값은 아니라고 판단했습니다.
- **개선(실제 적용)**: 8절에서 파생 변수(연령대 구간, 자본 발생 여부, Unknown 범주 유지),
  `class_weight="balanced"`, 트리 기반 모델을 실제로 비교했습니다.
  F1 기준으로는 {advanced['best_f1_model']}, Recall 기준으로는 {advanced['best_recall_model']}가 가장 좋았습니다.
  또한 임계값을 {threshold['best_threshold']:.2f}로 낮추면 재학습 없이도
  Recall이 {ml['recall']:.4f} → {threshold['best_recall']:.4f}로 올라갑니다.
- **남은 과제**: `race`·`sex` 같은 민감 특성이 예측에 미치는 영향에 대한 공정성 점검입니다.
  `sex_Female` 계수가 음의 방향으로 크게 나온다는 것은 모델이 1994년 노동시장의 구조적 격차를
  그대로 학습했다는 뜻이고, 이 모델을 실제 의사결정에 쓰면 그 격차를 재생산하게 됩니다.

## 12. 한계와 남은 과제

분석을 끝내고 나서 정리한, 이 결과를 그대로 믿으면 안 되는 지점들입니다.

| 한계 | 왜 문제인가 | 다음에 할 것 |
|---|---|---|
| 1994년 미국 인구조사 데이터 | 30년 전 노동시장이라 지금의 소득 구조와 다릅니다. 임계값 50K도 당시 기준입니다. | 최신 데이터로 같은 파이프라인을 돌려 계수 방향이 유지되는지 확인 |
| 관측 데이터로 얻은 상관관계 | 근로시간·학력이 소득을 '올린다'고 말할 수 없습니다. 세 변수가 서로 얽혀 있습니다. | 인과를 보려면 실험 설계나 준실험 방법(성향점수 매칭 등)이 필요 |
| 민감 특성 학습 | `sex_Female` 계수가 음의 방향으로 크게 나옵니다. 당시의 구조적 격차를 그대로 학습한 것입니다. | 민감 특성 제외 시 성능 변화 측정, 집단별 오류율 비교 |
| 희소 범주 | 표본이 수십 건인 국적 범주는 계수가 불안정합니다. | 빈도가 낮은 범주를 `Other`로 묶고 정규화 강화 |
| 단일 임계값 | F1을 기준으로 고른 값이라 실제 용도와 다를 수 있습니다. | 오분류 비용을 정한 뒤 비용 기준으로 임계값 재선정 |

## 13. 결론

인구통계와 근로 특성으로 고소득 여부를 예측하는 파이프라인을 처음부터 끝까지 구성했습니다.
데이터 로딩과 정제, 통계 검정, 모델 학습과 저장, 보고서 생성까지 한 번의 실행으로 이어집니다.

정리하면 세 가지입니다.

1. **평가 지표를 하나만 보면 안 됩니다.** 클래스가 {eda_summary['imbalance_ratio']:.2f}:1로 치우쳐 있어
   Accuracy {ml['accuracy']:.4f}는 실제보다 좋아 보입니다. 같은 모델의 Recall은 {ml['recall']:.4f}이고,
   F1은 {ml['f1']:.4f}, ROC-AUC는 {ml['roc_auc']:.4f}입니다.
2. **모델을 바꾸지 않아도 개선할 여지가 있습니다.** 임계값을 {threshold['best_threshold']:.2f}로 내리는 것만으로
   Recall이 {ml['recall']:.4f}에서 {threshold['best_recall']:.4f}로 올라갑니다. 대신 Precision을 내주는 거래이고,
   어느 쪽을 택할지는 모델을 어디에 쓸지가 정합니다.
3. **이 모델은 예측용이지 설명용이 아닙니다.** 계수의 부호는 모델의 판단 방향을 보여줄 뿐,
   그 변수가 소득의 원인이라는 근거가 아닙니다.
"""

    REPORT_PATH.write_text(report, encoding="utf-8")
    logger.info(f"[생성 완료] {REPORT_PATH} ({REPORT_PATH.stat().st_size:,} bytes)")


# ---------------------------------------------------------------------------
# 메인 실행부
# ---------------------------------------------------------------------------

def run_stage(stage_name: str, function: Any, *args: Any, **kwargs: Any) -> Any:
    """
    한 단계를 실행하면서 어디서 무엇이 실패했는지 로그에 남긴다.

    단계를 감싸는 이유는 오류 메시지의 위치 정보 때문이다. 그냥 두면
    "KeyError: 'income'"처럼 원인만 나오고 어느 단계에서 터졌는지는 알 수 없다.
    여기서 단계 이름을 붙여 다시 던지면, 로그만 보고도 실패 지점을 바로 찾을 수 있다.

    예외를 삼키지는 않는다. 중간 단계가 실패했는데 계속 진행하면 뒤 단계가
    잘못된 값으로 돌아가 엉뚱한 보고서가 나오기 때문이다.
    """
    logger.debug(f"[단계 시작] {stage_name}")
    started = time.perf_counter()

    try:
        result = function(*args, **kwargs)
    except Exception as error:
        elapsed = time.perf_counter() - started
        logger.error(f"[단계 실패] {stage_name} ({elapsed:.2f}초) - {type(error).__name__}: {error}")
        # 원래 예외를 그대로 올려보내야 아래 __main__의 분류별 처리가 동작한다.
        raise

    elapsed = time.perf_counter() - started
    logger.debug(f"[단계 완료] {stage_name} ({elapsed:.2f}초)")
    return result


def main() -> None:
    """전체 분석 흐름(환경 확인 → 로딩 → 정제 → EDA → 통계 → 시각화 → ML → 보고서)을 실행한다."""
    configure_logging()
    total_started = time.perf_counter()

    logger.info("[종합 실습 2] Adult Census Income 분석을 시작합니다.")
    logger.info(f"로그 파일: {LOG_PATH}")

    versions = log_environment()

    # 테마를 먼저 적용해야 seaborn 기본값이 한글 폰트 설정을 덮어쓰지 않는다.
    configure_chart_theme()
    configure_korean_font()

    raw_path = run_stage("원본 데이터 확보", download_dataset, DATA_URL, RAW_DATA_PATH)

    pandas_df, pandas_seconds = run_stage("Pandas 로딩", load_with_pandas, raw_path)
    polars_df, polars_seconds = run_stage("Polars 로딩", load_with_polars, raw_path)
    load_summary = run_stage(
        "Pandas/Polars 비교", compare_pandas_polars,
        pandas_df, pandas_seconds, polars_df, polars_seconds,
    )

    cleaned, clean_summary = run_stage("결측치·중복 처리", clean_data, pandas_df)
    eda_summary = run_stage("기본 EDA", perform_eda, cleaned)
    description = run_stage("기술통계", descriptive_statistics, cleaned)
    correlation = run_stage("상관분석", correlation_analysis, cleaned)
    t_test = run_stage("t-test", perform_t_test, cleaned)

    run_stage("Seaborn 차트 생성", create_seaborn_plots, cleaned)
    run_stage("Plotly 차트 생성", create_plotly_chart, cleaned)

    ml = run_stage("ML Pipeline 학습·평가·저장", train_machine_learning_pipeline, cleaned)
    advanced = run_stage("심화 분석", run_advanced_analysis, cleaned)
    run_stage(
        "report.md 생성", generate_report,
        load_summary, clean_summary, eda_summary, description,
        correlation, t_test, ml, advanced, versions,
    )

    log_section("12. 산출물 생성 확인")
    expected = (
        INCOME_PNG, AGE_PNG, CORRELATION_PNG, EDUCATION_HTML,
        EVALUATION_PNG, THRESHOLD_PNG, MODEL_PATH, REPORT_PATH,
    )
    missing = []
    for artifact in expected:
        # 파일이 생겼더라도 크기가 0이면 저장이 중간에 끊긴 것이므로 실패로 본다.
        created = artifact.exists() and artifact.stat().st_size > 0
        size = f"{artifact.stat().st_size:,} bytes" if artifact.exists() else "없음"
        logger.info(f"{'생성 완료' if created else '생성 실패'}: "
                    f"{artifact.relative_to(BASE_DIR)} ({size})")
        if not created:
            missing.append(artifact.relative_to(BASE_DIR))

    if missing:
        raise OSError(f"생성되지 않은 산출물이 있습니다: {', '.join(map(str, missing))}")

    total_elapsed = time.perf_counter() - total_started
    logger.info(f"\n[종합 실습 2] 모든 단계가 정상적으로 완료되었습니다. (총 {total_elapsed:.1f}초)")
    logger.info(f"실행 로그는 {LOG_PATH.relative_to(BASE_DIR)} 에 저장되었습니다.")


def report_failure(message: str, error: BaseException | None = None) -> None:
    """
    오류를 화면과 로그 파일에 남긴다.

    로깅 설정 자체가 실패했을 수도 있으므로 핸들러가 붙어 있는지 먼저 확인한다.
    핸들러가 없으면 로거로 찍어도 아무 데도 안 나오기 때문에 stderr로 직접 출력한다.
    오류 메시지를 놓치는 것이 제일 곤란한 상황이라 이중으로 대비한다.
    """
    if logger.handlers:
        logger.error(message)
        if error is not None:
            # 화면에는 요약만, 로그 파일에는 traceback 전체를 남긴다.
            logger.debug("상세 traceback", exc_info=error)
    else:
        print(message, file=sys.stderr)


if __name__ == "__main__":
    # 예외를 종류별로 나눠 잡는 이유는 원인에 맞는 조치를 알려주기 위해서다.
    # 전부 한 번에 잡으면 "오류가 났다"는 말밖에 못 한다.
    try:
        main()
    except FileNotFoundError as error:
        report_failure(f"\n[파일 오류] 필요한 파일을 찾지 못했습니다: {error}", error)
        sys.exit(1)
    except PermissionError as error:
        report_failure(f"\n[권한 오류] 파일을 읽거나 쓸 권한이 없습니다: {error}", error)
        sys.exit(1)
    except pd.errors.EmptyDataError as error:
        report_failure("\n[데이터 오류] 파일에 읽을 내용이 없습니다.", error)
        sys.exit(1)
    except pd.errors.ParserError as error:
        report_failure(f"\n[CSV 형식 오류] 원본 파일의 구분자나 열 개수를 확인하세요: {error}", error)
        sys.exit(1)
    except MemoryError as error:
        report_failure("\n[메모리 부족] 다른 프로그램을 닫고 다시 실행하세요.", error)
        sys.exit(1)
    except (ValueError, TypeError, KeyError) as error:
        report_failure(f"\n[데이터 오류] {type(error).__name__}: {error}", error)
        sys.exit(1)
    except AssertionError as error:
        report_failure(f"\n[검증 오류] {error}", error)
        sys.exit(1)
    except OSError as error:
        report_failure(f"\n[파일 저장 오류] {error}", error)
        sys.exit(1)
    except KeyboardInterrupt:
        report_failure("\n[중단] 사용자가 실행을 중단했습니다.")
        sys.exit(130)
    except Exception as error:
        report_failure(f"\n[예상하지 못한 오류] {type(error).__name__}: {error}", error)
        sys.exit(1)
