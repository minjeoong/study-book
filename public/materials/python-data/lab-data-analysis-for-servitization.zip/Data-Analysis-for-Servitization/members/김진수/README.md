# Adult Census Income — End-to-End 데이터 분석

- **과제**: [종합 실습 2] Adult Census Income
- **소속**: 판교 캠퍼스 9반 3조
- **팀원**: 김명철, 김민정, 김진수, 정민성, 전진만 (가나다순)
- **데이터**: UCI Adult Census Income (`https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data`)
- **목표 변수**: `income` (`<=50K` / `>50K`)

## 역할 분담

분석 단계를 다섯으로 나눠 한 사람이 하나씩 맡고, 서로 한 영역씩 교차 리뷰합니다.
리뷰를 붙인 이유는 담당자만 아는 코드가 생기지 않게 하기 위해서입니다.

| 이름 | 주 담당 | 교차 리뷰 | 관련 함수 |
|---|---|---|---|
| 김명철 | 데이터 로딩, Pandas·Polars 비교 | 통계 분석 | `download_dataset`, `load_with_pandas`, `load_with_polars`, `compare_pandas_polars` |
| 김민정 | 결측치·중복 처리, 기본 EDA | 시각화 | `clean_data`, `perform_eda` |
| 정민성 | 시각화 (Seaborn 3종, Plotly 1종) | ML Pipeline | `create_seaborn_plots`, `create_plotly_chart`, `save_correlation_heatmap` |
| 전진만 | 통계 분석 (기술통계·상관·t-test) | 데이터 로딩 | `descriptive_statistics`, `correlation_analysis`, `perform_t_test` |
| 김진수 | ML Pipeline, 자동 보고서 | 결측치·EDA | `build_pipeline`, `train_machine_learning_pipeline`, `generate_report` |

로깅·예외 처리(`configure_logging`, `run_stage`)와 심화 분석(`run_advanced_analysis`)은 공통 작업으로 함께 봅니다.

> 위 표는 팀에서 합의한 역할 분담입니다. 실제 작업 내용과 다르면 각자 수정해 주세요.

## 협업 규칙 (Convention)

### 브랜치

`main`에는 직접 push하지 않습니다. 다섯 명이 같은 파일(`src/main.py`)을 건드리기 때문에,
바로 올리면 남의 작업을 덮어쓸 수 있습니다. 반드시 브랜치를 파고 PR로 합칩니다.

```text
<타입>/<이름>-<작업내용>

feat/kimjinsu-ml-pipeline
fix/jeongminseong-plotly-label
docs/kimmyeongcheol-readme
```

| 타입 | 언제 쓰나 |
|---|---|
| `feat` | 기능 추가 |
| `fix` | 버그 수정 |
| `docs` | 문서만 수정 |
| `refactor` | 동작은 그대로, 코드 구조만 변경 |
| `chore` | 설정·의존성 등 그 외 |

### 커밋 메시지

```text
<타입>: <무엇을 했는지 한 줄>

(빈 줄)
왜 그렇게 했는지. 무엇을 했는지는 코드를 보면 알 수 있지만,
왜 그랬는지는 적어두지 않으면 나중에 아무도 모릅니다.
```

예시입니다.

```text
feat: Polars 로딩 시 앞 공백 제거 후 숫자 캐스팅

Polars에는 skipinitialspace 옵션이 없어 " State-gov"처럼 앞 공백이 남는다.
그대로 두면 숫자 컬럼이 문자열로 추론되어 Pandas 결과와 shape가 어긋난다.
```

- 한 커밋에는 한 가지 변경만 담습니다.
- 제목은 50자 안쪽, 마침표 없이 씁니다.

### Pull Request

- 리뷰어 **1명 이상** 승인 후 머지합니다. 리뷰어는 위 역할 분담표의 교차 리뷰 담당자입니다.
- PR 본문에는 무엇을 왜 바꿨는지와 **실행 결과 캡처**를 넣습니다.
- 머지 전에 `python src/main.py`가 끝까지 도는지 확인합니다.

### 산출물 규칙

- `outputs/`는 실행하면 다시 만들어지는 폴더입니다. **코드를 고쳤으면 반드시 다시 실행해서 산출물을 맞춰 주세요.** 코드와 결과가 어긋나 있으면 채점에서 감점됩니다.
- `data/`와 `outputs/logs/`는 `.gitignore`에 있어 커밋되지 않습니다. 원본 데이터는 첫 실행 때 자동으로 내려받습니다.
- 보고서(`outputs/report.md`)는 손으로 고치지 않습니다. `src/main.py`의 `generate_report()`를 고쳐야 합니다.

### 처음 받는 사람

```bash
git clone https://github.com/pangyo-9ban-3zo/Data-Analysis-for-Servitization.git
cd Data-Analysis-for-Servitization
pip install -r requirements.txt
python src/main.py
```

## 실행 방법

```bash
pip install -r requirements.txt
```

```bash
python src/main.py
```

원본 데이터(`data/raw/adult.data`)는 **제출본에 그대로 포함**되어 있어 네트워크 없이 바로 실행됩니다.
파일이 없을 경우에만 위 URL에서 자동으로 내려받아 같은 경로에 캐시합니다.

## 프로젝트 구조

```text
판교_9반_김진수_day2종합실습/
├── README.md
├── requirements.txt
├── .gitignore
├── data/
│   └── raw/
│       └── adult.data                     # 원본 데이터 (제출본에 포함)
├── src/
│   └── main.py                            # 분석 전체 파이프라인
├── outputs/                               # 실행하면 만들어지는 산출물
│   ├── report.md                          # 실행 결과로 자동 생성되는 보고서
│   ├── figures/                           # 번호 순서 = 보고서에 실린 순서
│   │   ├── 01_income_distribution.png     # Seaborn. 소득 클래스 분포
│   │   ├── 02_age_by_income.png           # Seaborn. 소득 집단별 나이 분포
│   │   ├── 03_correlation_heatmap.png     # Seaborn. 상관계수 히트맵
│   │   ├── 04_income_by_education.html    # Plotly. 교육 수준별 고소득 비율
│   │   ├── 05_model_evaluation.png        # Confusion Matrix와 ROC 곡선
│   │   └── 06_threshold_tradeoff.png      # 임계값별 Precision·Recall·F1 변화
│   ├── model/
│   │   └── adult_income_pipeline.joblib   # 전처리와 모델을 함께 저장한 Pipeline
│   └── logs/
│       └── run.log                        # 실행 로그 (단계별 시각·소요 시간)
└── docs/
    └── screenshots/
        └── README.md                      # 실행결과 캡처 순서 안내
```

## 분석 단계 (`src/main.py`)

| 단계 | 함수 | 내용 |
|---|---|---|
| 1 | `download_dataset` | 원본 데이터 다운로드 및 로컬 캐시 |
| 2 | `load_with_pandas` / `load_with_polars` | 동일 파일을 두 라이브러리로 로딩 |
| 3 | `compare_pandas_polars` | shape·로딩 시간·메모리·결측 수 비교 |
| 4 | `clean_data` | 결측치·중복 확인 및 처리 |
| 5 | `perform_eda` | 소득 분포, 범주형 변수 빈도 |
| 6 | `descriptive_statistics` | 평균·표준편차·분위수 |
| 7 | `correlation_analysis` | 수치형 변수 상관계수 |
| 8 | `perform_t_test` | Welch t-test, p-value 해석 |
| 9 | `create_seaborn_plots` | Seaborn 정적 차트 2종 |
| 10 | `create_plotly_chart` | Plotly 인터랙티브 차트 1종 |
| 11 | `train_machine_learning_pipeline` | Pipeline 학습·평가·5겹 교차검증·joblib 저장 |
| 12 | `run_advanced_analysis` | (추가) 파생변수·모델 4종 비교·임계값 조정 |
| 13 | `generate_report` | `outputs/report.md` 자동 생성 |

## 주요 설계 판단

- **로컬 캐시 후 두 라이브러리 비교**: Pandas와 Polars가 각각 URL을 호출하면 네트워크 상태 차이가
  로딩 시간에 섞이므로, 원본을 한 번만 내려받아 동일한 로컬 파일을 두 라이브러리에 입력했습니다.
- **결측치 처리 방식 분리**: EDA에서는 원본 분포를 보존하기 위해 결측을 제거하지 않고 제외 집계했고,
  ML에서는 행을 버리지 않고 Pipeline 안의 `SimpleImputer`로 대치했습니다.
- **`fnlwgt` 제외**: 인구 추정 가중치(표본 설계 값)이지 개인의 특성이 아니므로 모델 특징에서 제외했습니다.
- **Welch t-test**: 두 소득 집단의 표본 수와 분산이 달라 등분산을 가정하지 않았습니다.
- **전체 Pipeline 저장**: 전처리와 모델을 한 객체로 저장해 예측 시 동일한 전처리가 재현되도록 했습니다.

## 산출물 확인

실행이 끝나면 아래 파일이 생성됩니다.

```bash
ls -R outputs
```
