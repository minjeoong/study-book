## 데이터 출처
"https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data"

## 데이터 선정 이유

## 폴더구조 

```
data-project/
├── data/ │ ├── raw/ # 원본 데이터 (절대 수정 금지)
│ ├── processed/ # 전처리 완료 데이터
│ └── external/ # 외부 참조 데이터
├── notebooks/ # EDA·실험용 Jupyter 노트북
│ ├── 01_eda.ipynb
│ └── 02_feature_exploration.ipynb
├── src/ # 재사용 가능한 Python 모듈
│ ├── __init__.py
│ ├── clean.py
```

## 시작하기 (환경 세팅)

본 프로젝트는 팀원 모두가 동일한 조건에서 작업할 수 있도록 독립적인 **가상환경(.venv)** 과 **패키지 종속성(requirements.txt)** 을 사용해 분석 환경을 엄격히 관리합니다.

복잡한 설정 명령어를 일일이 칠 필요 없이, 제공되는 `setup.sh` 스크립트를 실행하면 다음 과정이 **한 번에 자동 진행**됩니다.
1. 프로젝트 전용 파이썬 가상환경(`.venv`) 생성 및 활성화
2. `requirements.txt`에 명시된 필수 데이터 분석 패키지 일괄 설치
3. Jupyter Notebook에서 사용할 수 있도록 커널 등록

터미널을 열고 아래 명령어를 순서대로 실행해 주세요.

```bash
# 스크립트 실행 권한 부여 (최초 1회)
chmod +x setup.sh

# 가상환경 세팅 및 패키지 설치 자동 진행
./setup.sh
```

`data/raw/`에 `adult.data`를 넣고 시작합니다.


## 팀 규칙

브랜치 규칙

```
feat-{자신의 이름}
```