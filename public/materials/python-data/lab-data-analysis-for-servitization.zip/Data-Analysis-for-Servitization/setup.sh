#!/bin/bash

echo "🚀 데이터 분석 프로젝트 가상환경 설정을 시작합니다..."

# 1. 가상환경 생성
python3 -m venv .venv
echo "✅ 가상환경(.venv)이 생성되었습니다."

# 2. 가상환경 활성화
source .venv/bin/activate

# 3. pip 최신버전 업데이트
pip install --upgrade pip

# 4. 패키지 설치
echo "📦 requirements.txt에 명시된 패키지들을 설치합니다..."
pip install -r requirements.txt
echo "✅ 패키지 설치가 완료되었습니다."

# 5. 커널 등록
echo "⚙️ Jupyter Notebook용 커널을 등록합니다..."
python -m ipykernel install --user --name=team_prj --display-name="Python (team_prj)"
echo "✅ 커널 등록이 완료되었습니다."

echo "🎉 모든 환경 설정이 성공적으로 끝났습니다!"
