"""
===================================================

제출자 : 판교 9반 P282 김민정
제출일 : 2026.08.06
데이터 분석을 위한 Python 이해 [Day1 종합실습]

===================================================


============== 프로그램 설명 ==============
asyncio + httpx를 사용해 아래 3개의 공개 API를 asyncio.gather()로
동시에 호출하여 결과를 한 번에 수집하는 비동기 파이프라인.

1. Open-Meteo   : 서울 3일 시간대별 기온·강수확률
2. Countries.dev: 한국 국가 정보 (alpha=KOR)
3. ip-api       : IP(8.8.8.8) 기반 지역 정보

수집된 JSON에서 필요한 필드만 추출하여 Pydantic v2 모델(WeatherRecord,
CountryInfo, IPInfo)로 타입·범위를 검증하고, 타입 오류·값 오류는 각각
예외로 잡아 로깅한다. 검증된 결과는 데이터셋별로 CSV와 Parquet 두 형식
모두로 저장하며, 수집·검증·저장 각 단계의 소요 시간을 측정해 출력한다.

- fetch_json      : 단일 엔드포인트를 비동기로 호출하고 (JSON, 소요시간)을 반환
- fetch_all       : asyncio.gather()로 3개 API를 동시 수집
- validate_results: 수집 결과에서 필드를 추출해 Pydantic 모델로 검증 (타입/값 오류 예외 처리)
- build_dataframes: 검증된 결과를 데이터셋별 DataFrame으로 변환
- save_dataframes : 각 DataFrame을 CSV·Parquet으로 저장하고 저장 소요 시간을 측정
- main            : 전체 파이프라인 실행 + 단계별 성능 측정 결과 출력
===================================================
"""

import asyncio
import json
import logging
import time
from pathlib import Path

import httpx
import pandas as pd
from pydantic import BaseModel, Field, ValidationError

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent
RESULT_PATH = BASE_DIR / "async_api_result.json"
VALIDATED_PATH = BASE_DIR / "validated_result.json"

# 데이터셋별 CSV/Parquet 저장 경로
OUTPUT_PATHS = {
    "open_meteo": (BASE_DIR / "open_meteo.csv", BASE_DIR / "open_meteo.parquet"),
    "countries_dev": (BASE_DIR / "countries_dev.csv", BASE_DIR / "countries_dev.parquet"),
    "ip_api": (BASE_DIR / "ip_api.csv", BASE_DIR / "ip_api.parquet"),
}

# 수집 대상 API 목록
APIS = {
    "open_meteo": (
        "https://api.open-meteo.com/v1/forecast"
        "?latitude=37.5665&longitude=126.9780"
        "&hourly=temperature_2m,precipitation_probability"
        "&forecast_days=3&timezone=Asia/Seoul"
    ),
    "countries_dev": "https://countries.dev/alpha/KOR",
    "ip_api": "http://ip-api.com/json/8.8.8.8",
}


# ---------------------------------------------------------------------------
# 1) 단일 API 비동기 호출
# - httpx.AsyncClient로 요청 후 (JSON, 소요시간)을 반환
# - 실패 시 예외를 삼키지 않고 {"error": ...} 형태로 반환하여
#   gather()의 다른 작업들이 실패에 영향받지 않도록 처리
# ---------------------------------------------------------------------------
async def fetch_json(client: httpx.AsyncClient, name: str, url: str) -> tuple[dict, float]:
    logger.info("요청 시작: %s", name)
    start = time.perf_counter()
    try:
        response = await client.get(url, timeout=10.0)
        response.raise_for_status()
        elapsed = time.perf_counter() - start
        logger.info("요청 완료: %s (status=%d, %.3f초)", name, response.status_code, elapsed)
        return response.json(), elapsed
    except httpx.HTTPStatusError as e:
        elapsed = time.perf_counter() - start
        logger.error("HTTP 오류 [%s]: %s", name, e)
        return {"error": f"HTTP {e.response.status_code}"}, elapsed
    except httpx.RequestError as e:
        elapsed = time.perf_counter() - start
        logger.error("요청 오류 [%s]: %s", name, e)
        return {"error": str(e)}, elapsed


# ---------------------------------------------------------------------------
# 2) 3개 API 동시 수집
# - asyncio.gather()로 모든 요청을 병렬 실행
# - 반환값을 (결과 dict, API별 요청 소요시간 dict)로 분리
# ---------------------------------------------------------------------------
async def fetch_all(apis: dict) -> tuple[dict, dict]:
    async with httpx.AsyncClient() as client:
        tasks = [fetch_json(client, name, url) for name, url in apis.items()]
        outcomes = await asyncio.gather(*tasks)
    results = {name: data for name, (data, _) in zip(apis.keys(), outcomes, strict=True)}
    timings = {name: elapsed for name, (_, elapsed) in zip(apis.keys(), outcomes, strict=True)}
    return results, timings


# ---------------------------------------------------------------------------
# 3) Pydantic v2 스키마 정의
# - WeatherRecord : open-meteo 시간대별 기온·강수확률 (0 <= 강수확률 <= 100)
# - CountryInfo   : 국가명·수도·인구·면적 (인구·면적은 0 이상)
# - IPInfo        : IP 조회 결과 위경도(-90~90 / -180~180)·국가코드(2자리)
# - 각 필드는 타입이 선언되어 있어, API가 문자열/None 등 다른 타입을 주면
#   Pydantic이 ValidationError를 발생시키고 validate_results()에서 이를 잡아 처리한다.
# ---------------------------------------------------------------------------
class WeatherRecord(BaseModel):
    time: str
    temperature_2m: float
    precipitation_probability: int = Field(ge=0, le=100)


class CountryInfo(BaseModel):
    name: str
    capital: str
    region: str
    population: int = Field(ge=0)
    area: float = Field(ge=0)
    alpha3Code: str = Field(min_length=3, max_length=3)


class IPInfo(BaseModel):
    query: str
    country: str
    countryCode: str = Field(min_length=2, max_length=2)
    city: str
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    timezone: str


# ---------------------------------------------------------------------------
# 4) 필드 추출 + 스키마 검증
# - 각 API 응답에서 필요한 필드만 추출해 해당 Pydantic 모델로 검증
# - open-meteo는 hourly.time/temperature_2m/precipitation_probability를
#   같은 인덱스끼리 묶어(zip) 시간대별 WeatherRecord 리스트로 변환
# - KeyError    : 응답에 필요한 필드 자체가 없는 경우 (구조 오류)
# - TypeError   : 필드 값이 인덱싱/순회가 불가능한 예상 밖 타입인 경우
# - ValidationError : 필드는 있지만 타입·범위가 스키마와 맞지 않는 경우 (타입 오류)
#   세 예외를 구분해 로깅하고, 실패한 데이터셋만 None으로 표시해 나머지 파이프라인은 계속 진행
# ---------------------------------------------------------------------------
def validate_results(results: dict) -> dict:
    validated = {}

    try:
        hourly = results["open_meteo"]["hourly"]
        records = [
            WeatherRecord(
                time=t,
                temperature_2m=temp,
                precipitation_probability=precip,
            )
            for t, temp, precip in zip(
                hourly["time"],
                hourly["temperature_2m"],
                hourly["precipitation_probability"],
                strict=True,
            )
        ]
        validated["open_meteo"] = [r.model_dump() for r in records]
        logger.info("open_meteo 스키마 검증 성공 (%d건)", len(records))
    except KeyError as e:
        logger.error("open_meteo 필드 누락: %s", e)
        validated["open_meteo"] = None
    except TypeError as e:
        logger.error("open_meteo 타입 오류(구조 불일치): %s", e)
        validated["open_meteo"] = None
    except ValidationError as e:
        logger.error("open_meteo 스키마 검증 실패(타입/범위 오류): %s", e.errors())
        validated["open_meteo"] = None

    try:
        cd = results["countries_dev"]
        country = CountryInfo(
            name=cd["name"],
            capital=cd["capital"],
            region=cd["region"],
            population=cd["population"],
            area=cd["area"],
            alpha3Code=cd["alpha3Code"],
        )
        validated["countries_dev"] = country.model_dump()
        logger.info("countries_dev 스키마 검증 성공")
    except KeyError as e:
        logger.error("countries_dev 필드 누락: %s", e)
        validated["countries_dev"] = None
    except TypeError as e:
        logger.error("countries_dev 타입 오류(구조 불일치): %s", e)
        validated["countries_dev"] = None
    except ValidationError as e:
        logger.error("countries_dev 스키마 검증 실패(타입/범위 오류): %s", e.errors())
        validated["countries_dev"] = None

    try:
        ip = results["ip_api"]
        ip_info = IPInfo(
            query=ip["query"],
            country=ip["country"],
            countryCode=ip["countryCode"],
            city=ip["city"],
            lat=ip["lat"],
            lon=ip["lon"],
            timezone=ip["timezone"],
        )
        validated["ip_api"] = ip_info.model_dump()
        logger.info("ip_api 스키마 검증 성공")
    except KeyError as e:
        logger.error("ip_api 필드 누락: %s", e)
        validated["ip_api"] = None
    except TypeError as e:
        logger.error("ip_api 타입 오류(구조 불일치): %s", e)
        validated["ip_api"] = None
    except ValidationError as e:
        logger.error("ip_api 스키마 검증 실패(타입/범위 오류): %s", e.errors())
        validated["ip_api"] = None

    return validated


# ---------------------------------------------------------------------------
# 5) 검증된 결과 -> DataFrame 변환
# - open_meteo   : 72건(3일 x 24시간) 행을 가진 DataFrame
# - countries_dev / ip_api : 단일 레코드를 1행 DataFrame으로 변환
# - 검증에 실패해 None인 데이터셋은 건너뛴다.
# ---------------------------------------------------------------------------
def build_dataframes(validated: dict) -> dict[str, pd.DataFrame]:
    dataframes = {}
    for name, value in validated.items():
        if value is None:
            logger.warning("%s: 검증 실패로 DataFrame 생성 건너뜀", name)
            continue
        rows = value if isinstance(value, list) else [value]
        dataframes[name] = pd.DataFrame(rows)
    return dataframes


# ---------------------------------------------------------------------------
# 6) DataFrame -> CSV·Parquet 저장 + 재로딩까지 포함한 쓰기/읽기 성능 측정
# - 데이터셋별로 CSV/Parquet 각각의 쓰기(write) 시간과, 저장한 파일을 다시
#   읽어들이는 읽기(read) 시간을 측정해 반환한다.
# - 측정 전 더미 데이터로 Parquet를 한 번 써보고 읽어 pyarrow 엔진을 예열한다.
#   (최초 1회 초기화 비용이 실제 읽기/쓰기 성능 측정값에 섞이는 것을 방지)
# ---------------------------------------------------------------------------
def save_dataframes(dataframes: dict[str, pd.DataFrame]) -> dict[str, dict[str, float]]:
    # pyarrow 엔진 최초 호출 비용(초기화 오버헤드)을 실제 측정에서 배제하기 위한 예열
    warmup_path = BASE_DIR / "_parquet_warmup.tmp"
    pd.DataFrame({"x": [1]}).to_parquet(warmup_path, index=False)
    pd.read_parquet(warmup_path)
    warmup_path.unlink(missing_ok=True)

    perf = {}
    for name, df in dataframes.items():
        csv_path, parquet_path = OUTPUT_PATHS[name]

        start = time.perf_counter()
        df.to_csv(csv_path, index=False, encoding="utf-8")
        csv_write_seconds = time.perf_counter() - start

        start = time.perf_counter()
        df.to_parquet(parquet_path, index=False)
        parquet_write_seconds = time.perf_counter() - start

        start = time.perf_counter()
        pd.read_csv(csv_path)
        csv_read_seconds = time.perf_counter() - start

        start = time.perf_counter()
        pd.read_parquet(parquet_path)
        parquet_read_seconds = time.perf_counter() - start

        perf[name] = {
            "csv_write_seconds": csv_write_seconds,
            "parquet_write_seconds": parquet_write_seconds,
            "csv_read_seconds": csv_read_seconds,
            "parquet_read_seconds": parquet_read_seconds,
            "rows": len(df),
        }
        logger.info(
            "%s 성능: 쓰기 CSV %.4f초/Parquet %.4f초, 읽기 CSV %.4f초/Parquet %.4f초 (%d행)",
            name, csv_write_seconds, parquet_write_seconds,
            csv_read_seconds, parquet_read_seconds, len(df),
        )
    return perf


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    total_start = time.perf_counter()

    fetch_start = time.perf_counter()
    results, request_timings = asyncio.run(fetch_all(APIS))
    fetch_elapsed = time.perf_counter() - fetch_start

    with open(RESULT_PATH, "w", encoding="utf-8") as file:
        json.dump(results, file, ensure_ascii=False, indent=2)

    print(f"\n비동기 수집 완료 — {len(results)}개 API, 총 {fetch_elapsed:.3f}초 소요")
    for name in results:
        status = "성공" if "error" not in results[name] else f"실패({results[name]['error']})"
        print(f"  - {name}: {status} ({request_timings[name]:.3f}초)")
    print(f"결과 저장: {RESULT_PATH}")

    validate_start = time.perf_counter()
    validated = validate_results(results)
    validate_elapsed = time.perf_counter() - validate_start

    with open(VALIDATED_PATH, "w", encoding="utf-8") as file:
        json.dump(validated, file, ensure_ascii=False, indent=2)

    print("\n스키마 검증 결과")
    for name, value in validated.items():
        status = "통과" if value is not None else "실패"
        count = f" ({len(value)}건)" if isinstance(value, list) else ""
        print(f"  - {name}: {status}{count}")
    print(f"검증 결과 저장: {VALIDATED_PATH} ({validate_elapsed:.3f}초)")

    dataframes = build_dataframes(validated)
    save_perf = save_dataframes(dataframes)

    print("\nCSV vs Parquet 읽기/쓰기 성능 비교")
    for name, perf in save_perf.items():
        write_faster = "Parquet" if perf["parquet_write_seconds"] < perf["csv_write_seconds"] else "CSV"
        read_faster = "Parquet" if perf["parquet_read_seconds"] < perf["csv_read_seconds"] else "CSV"
        write_ratio = max(perf["csv_write_seconds"], perf["parquet_write_seconds"]) / max(
            min(perf["csv_write_seconds"], perf["parquet_write_seconds"]), 1e-9
        )
        read_ratio = max(perf["csv_read_seconds"], perf["parquet_read_seconds"]) / max(
            min(perf["csv_read_seconds"], perf["parquet_read_seconds"]), 1e-9
        )
        print(f"  - {name} ({perf['rows']}행)")
        print(
            f"      쓰기: CSV {perf['csv_write_seconds']:.4f}초 / "
            f"Parquet {perf['parquet_write_seconds']:.4f}초 -> {write_faster}가 {write_ratio:.1f}배 빠름"
        )
        print(
            f"      읽기: CSV {perf['csv_read_seconds']:.4f}초 / "
            f"Parquet {perf['parquet_read_seconds']:.4f}초 -> {read_faster}가 {read_ratio:.1f}배 빠름"
        )

    save_total = sum(
        p["csv_write_seconds"] + p["parquet_write_seconds"]
        + p["csv_read_seconds"] + p["parquet_read_seconds"]
        for p in save_perf.values()
    )
    total_elapsed = time.perf_counter() - total_start
    print(f"\n전체 파이프라인 소요 시간: {total_elapsed:.3f}초 "
          f"(수집 {fetch_elapsed:.3f}초 + 검증 {validate_elapsed:.3f}초 + 저장·읽기 {save_total:.3f}초)")
