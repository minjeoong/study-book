"""
===================================================

제출자 : 판교 9반 P282 김민정
제출일 : 2026.08.06
데이터 분석을 위한 Python 이해 [Day1 종합실습] - 스키마 검증 테스트

===================================================

pytest로 판교_9반_김민정.py의 Pydantic v2 스키마(WeatherRecord, CountryInfo,
IPInfo)와 validate_results()의 예외 처리 분기를 검증한다.

- 정상 데이터 -> 모델 생성/검증 통과
- 범위를 벗어난 값 -> ValidationError
- 타입이 맞지 않는 값 -> ValidationError
- 필드 누락(KeyError) -> validate_results가 해당 데이터셋만 None 처리
===================================================
"""

import pytest
from pydantic import ValidationError

from 판교_9반_김민정 import CountryInfo, IPInfo, WeatherRecord, validate_results


# ---------------------------------------------------------------------------
# WeatherRecord
# ---------------------------------------------------------------------------
def test_weather_record_valid():
    record = WeatherRecord(time="2026-08-06T00:00", temperature_2m=28.3, precipitation_probability=18)
    assert record.temperature_2m == 28.3
    assert record.precipitation_probability == 18


def test_weather_record_precipitation_out_of_range():
    with pytest.raises(ValidationError):
        WeatherRecord(time="2026-08-06T00:00", temperature_2m=28.3, precipitation_probability=150)


def test_weather_record_invalid_temperature_type():
    with pytest.raises(ValidationError):
        WeatherRecord(time="2026-08-06T00:00", temperature_2m="hot", precipitation_probability=18)


# ---------------------------------------------------------------------------
# CountryInfo
# ---------------------------------------------------------------------------
def test_country_info_valid():
    country = CountryInfo(
        name="Korea (Republic of)",
        capital="Seoul",
        region="Asia",
        population=51780579,
        area=100210,
        alpha3Code="KOR",
    )
    assert country.alpha3Code == "KOR"


def test_country_info_negative_population():
    with pytest.raises(ValidationError):
        CountryInfo(
            name="Korea (Republic of)",
            capital="Seoul",
            region="Asia",
            population=-1,
            area=100210,
            alpha3Code="KOR",
        )


def test_country_info_alpha3code_wrong_length():
    with pytest.raises(ValidationError):
        CountryInfo(
            name="Korea (Republic of)",
            capital="Seoul",
            region="Asia",
            population=51780579,
            area=100210,
            alpha3Code="KO",
        )


def test_country_info_population_invalid_type():
    with pytest.raises(ValidationError):
        CountryInfo(
            name="Korea (Republic of)",
            capital="Seoul",
            region="Asia",
            population="많음",
            area=100210,
            alpha3Code="KOR",
        )


# ---------------------------------------------------------------------------
# IPInfo
# ---------------------------------------------------------------------------
def test_ip_info_valid():
    ip_info = IPInfo(
        query="8.8.8.8",
        country="United States",
        countryCode="US",
        city="Ashburn",
        lat=39.03,
        lon=-77.5,
        timezone="America/New_York",
    )
    assert ip_info.countryCode == "US"


def test_ip_info_latitude_out_of_range():
    with pytest.raises(ValidationError):
        IPInfo(
            query="8.8.8.8",
            country="United States",
            countryCode="US",
            city="Ashburn",
            lat=999,
            lon=-77.5,
            timezone="America/New_York",
        )


def test_ip_info_country_code_wrong_length():
    with pytest.raises(ValidationError):
        IPInfo(
            query="8.8.8.8",
            country="United States",
            countryCode="USA",
            city="Ashburn",
            lat=39.03,
            lon=-77.5,
            timezone="America/New_York",
        )


# ---------------------------------------------------------------------------
# validate_results: 정상/누락/타입오류 시나리오
# ---------------------------------------------------------------------------
@pytest.fixture
def sample_results():
    return {
        "open_meteo": {
            "hourly": {
                "time": ["2026-08-06T00:00", "2026-08-06T01:00"],
                "temperature_2m": [28.3, 27.7],
                "precipitation_probability": [18, 16],
            }
        },
        "countries_dev": {
            "name": "Korea (Republic of)",
            "capital": "Seoul",
            "region": "Asia",
            "population": 51780579,
            "area": 100210,
            "alpha3Code": "KOR",
        },
        "ip_api": {
            "query": "8.8.8.8",
            "country": "United States",
            "countryCode": "US",
            "city": "Ashburn",
            "lat": 39.03,
            "lon": -77.5,
            "timezone": "America/New_York",
        },
    }


def test_validate_results_all_valid(sample_results):
    validated = validate_results(sample_results)
    assert len(validated["open_meteo"]) == 2
    assert validated["countries_dev"]["alpha3Code"] == "KOR"
    assert validated["ip_api"]["countryCode"] == "US"


def test_validate_results_missing_field_returns_none(sample_results):
    del sample_results["countries_dev"]["population"]
    validated = validate_results(sample_results)
    assert validated["countries_dev"] is None
    # 다른 데이터셋은 영향받지 않고 계속 검증되어야 한다.
    assert validated["ip_api"] is not None


def test_validate_results_type_error_returns_none(sample_results):
    sample_results["ip_api"]["lat"] = "북위삼십구도"
    validated = validate_results(sample_results)
    assert validated["ip_api"] is None
    assert validated["countries_dev"] is not None


def test_validate_results_out_of_range_returns_none(sample_results):
    sample_results["open_meteo"]["hourly"]["precipitation_probability"] = [180, 16]
    validated = validate_results(sample_results)
    assert validated["open_meteo"] is None
