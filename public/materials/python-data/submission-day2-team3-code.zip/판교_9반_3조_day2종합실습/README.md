# Adult Census Income — End-to-End 데이터 분석

- **과제**: [종합 실습 2] Adult Census Income
- **소속**: 판교 캠퍼스 9반 3조
- **팀원**: 김명철, 김민정, 김진수, 정민성, 전진만 (가나다순)
- **데이터**: UCI Adult Census Income (`https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data`)
- **목표 변수**: `income` (`<=50K` / `>50K`)
 
## 빠른 시작(가상환경 및 패키지 설치 및 실행)
```bash
chmod +x setup.sh
```

```bash
./setup.sh
```
# 생성한 가상환경 활성화
```bash
source .venv/bin/activate
```
# main.py 파일 실행
```bash
python src/main.py
```

main.py 파일 실행시 자동으로 url 기반으로 데이터를 다운 받고 mkdir을 활용하여
data/raw 경로의 폴더가 생성된 후 원본 데이터('adult.data')가 다운로드 됩니다.

이후 순차적으로 각 모듈이 실행되어 분석이 자동화 됩니다.

실행이 끝나면 아래와 같이 결과물이 생성됩니다.

| 결과물 | 위치 | 쓰임 |
|---|---|---|
| 분석 보고서 | `outputs/report.md` | 모든 수치가 채워진 자동 생성 보고서 |
| **보고서용 캡쳐본** | `보고서용_캡쳐본/` | **각자 보고서에 바로 붙여 쓰는 이미지** |
| 실행 로그 | `outputs/logs/run.log` | 단계별 시각·소요 시간 |

## 보고서 쓰는 법 (조원 공통)

터미널을 직접 캡처할 필요가 없습니다. `보고서용_캡쳐본/` 폴더에 실행 결과가
터미널 모양 이미지로 이미 만들어져 있습니다. 번호 순서대로 붙이면 됩니다.

다섯 명이 각자 화면을 캡처하면 폰트와 창 크기가 달라 보고서가 들쭉날쭉해집니다.
같은 이미지를 쓰면 그 문제가 없고, 캡처 뜨는 시간도 아낍니다.

자세한 순서는 `보고서용_캡쳐본/README.md`에 있습니다.

> **Plotly 차트 하나만 직접 캡처해야 합니다.** hover tooltip이 떠 있는 순간을
> 보여줘야 하는데 그건 자동으로 만들 수 없습니다.
> `open outputs/figures/05_income_by_education.html`

## 역할 분담

분석 단계를 다섯으로 나눠 한 사람이 한 모듈씩 맡고, 서로 한 영역씩 교차 리뷰합니다.
리뷰를 붙인 이유는 담당자만 아는 코드가 생기지 않게 하기 위해서입니다.

| 이름 | 주 담당 | 담당 모듈 | 교차 리뷰 |
|---|---|---|---|
| 김명철 | 데이터 로딩, Pandas·Polars 비교 | `src/data_loader.py` | 통계 분석 |
| 김민정 | 결측치·중복 처리, EDA, 기술통계 | `src/preprocess.py` | 시각화 |
| 정민성 | 시각화 (Seaborn 4종, Plotly 1종) | `src/visualization.py` | ML Pipeline |
| 전진만 | 통계 분석 (상관·카이제곱·t-test) | `src/statistical_tests.py` | 데이터 로딩 |
| 김진수 | ML Pipeline, 보고서·캡쳐본 자동화 | `src/modeling.py`, `src/report.py`, `src/capture.py` | 결측치·EDA |

공통 관리: `src/config.py`(상수), `src/logging_setup.py`(로깅), `src/main.py`(흐름 조립)

> 위 표는 팀에서 합의한 역할 분담입니다. 실제 작업 내용과 다르면 각자 수정해 주세요.

## 프로젝트 구조

```text
판교_9반_3조_day2종합실습/
├── README.md
├── requirements.txt
├── .gitignore
├── data/
│   └── raw/
│       └── adult.data                     # 원본 데이터 (제출본에 포함)
├── src/
│   ├── main.py                            # 전체 흐름 조립
│   ├── config.py                          # 경로·컬럼·색상·상수
│   ├── logging_setup.py                   # 로깅, 실행 환경, 오류 출력
│   ├── data_loader.py                     # Pandas·Polars 로딩과 비교
│   ├── preprocess.py                      # 결측·중복 처리, EDA, 기술통계
│   ├── statistical_tests.py               # 상관·카이제곱·가정 검정·t-test
│   ├── visualization.py                   # Seaborn 4종 + Plotly 1종
│   ├── modeling.py                        # Pipeline 학습·평가·저장, 심화 분석
│   ├── report.py                          # report.md 생성
│   └── capture.py                         # 보고서용 캡쳐본 생성
├── outputs/                               # 실행하면 만들어짐
│   ├── report.md
│   ├── figures/01~07
│   ├── model/*.joblib                     # 기본 + 불균형 대응 2종
│   └── logs/run.log
└── 보고서용_캡쳐본/                        # 실행하면 만들어짐
    ├── README.md                          # 어떤 이미지를 어디에 쓰는지
    ├── 01~16_*.png                        # 터미널 실행 결과
    └── 07~12_차트_*.png                    # 그래프
```

## 분석 단계

| 단계 | 모듈 | 내용 |
|---|---|---|
| 0 | `logging_setup` | 실행 환경(라이브러리 버전) 기록 |
| 1 | `data_loader` | Pandas·Polars 로딩, shape·시간·메모리·dtype 비교, Polars 집계 |
| 2 | `preprocess` | 결측치·중복 확인 및 처리 |
| 3 | `preprocess` | 기본 EDA (분포·불균형·빈도) |
| 4 | `preprocess` | 기술통계 (평균·표준편차·분위수) |
| 5 | `statistical_tests` | 수치형 상관계수 + 히트맵 |
| 6 | `statistical_tests` | **범주형 연관성 (카이제곱 · Cramér's V)** |
| 7 | `statistical_tests` | **t-test (Shapiro-Wilk · Levene 가정 검정 후 실행)** |
| 8 | `visualization` | Seaborn 정적 차트 |
| 9 | `visualization` | Plotly 인터랙티브 차트 |
| 10 | `modeling` | Pipeline 학습·평가·저장 (**기본 + class_weight='balanced'**) |
| 11 | `modeling` | 심화 분석 (파생변수·모델 비교·임계값 조정) |
| 12 | `report` | `outputs/report.md` 자동 생성 |
| 13 | `capture` | `보고서용_캡쳐본/` 이미지 생성 |

## 주요 설계 판단

- **동일 로컬 파일로 두 라이브러리 비교**: Pandas와 Polars가 각각 URL을 호출하면
  네트워크 상태 차이가 로딩 시간에 섞이므로, 원본을 한 번만 내려받아 같은 파일을 넣었습니다.
- **Polars 정합성 맞추기**: Polars에는 `skipinitialspace`·`na_values`가 없어
  공백 제거 → `?`를 null로 → `Int64` 캐스팅 → 빈 행 제거 순으로 후처리해
  Pandas와 shape·결측 수·dtype이 모두 일치하는지 확인합니다.
- **Polars를 읽기 전용으로 쓰지 않음**: `filter` → `group_by` → `agg` 집계를
  분석 흐름에 넣어 실제로 활용합니다.
- **t-test 전 가정 검정**: Shapiro-Wilk(부분표본)로 정규성, Levene으로 등분산성을
  확인하고 그 결과에 따라 `equal_var`를 정합니다. 이번 데이터는 등분산이 기각되어
  Welch's t-test가 선택됩니다.
- **범주형은 카이제곱으로**: 특성 13개 중 8개가 범주형이라 수치형 상관계수만 보면
  절반을 놓칩니다. 카이제곱으로 독립성을, Cramér's V로 강도를 봅니다.
- **클래스 불균형 대응**: 기본 모델과 `class_weight='balanced'` 모델을 같은 분할에서
  학습해 비교하고 둘 다 저장합니다. 임계값 조정 효과도 함께 확인합니다.
- **`fnlwgt` 제외**: 인구 추정 가중치라 개인의 특성이 아닙니다.
- **전체 Pipeline 저장**: 전처리와 모델을 한 객체로 저장해 예측 시 동일한 전처리가
  재현되도록 했고, 재로딩 후 예측이 같은지 검증합니다.

## 협업 규칙 (Convention)

### 브랜치

`main`에는 직접 push하지 않습니다. 브랜치를 파고 PR로 합칩니다.

```text
<타입>/<이름>-<작업내용>

feat/kimjinsu-ml-pipeline
fix/jeongminseong-plotly-label
docs/kimmyeongcheol-readme
```

| 타입 | 언제 쓰나 |
|---|---|
| `feat` | 기능 추가 |
| `fix` | 버그 수정 |
| `docs` | 문서만 수정 |
| `refactor` | 동작은 그대로, 코드 구조만 변경 |
| `chore` | 설정·의존성 등 그 외 |

### 커밋 메시지

```text
<타입>: <무엇을 했는지 한 줄>

(빈 줄)
왜 그렇게 했는지. 무엇을 했는지는 코드를 보면 알 수 있지만,
왜 그랬는지는 적어두지 않으면 나중에 아무도 모릅니다.
```

- 한 커밋에는 한 가지 변경만 담습니다.
- 제목은 50자 안쪽, 마침표 없이 씁니다.

### Pull Request

- 리뷰어 **1명 이상** 승인 후 머지합니다. 리뷰어는 역할 분담표의 교차 리뷰 담당자입니다.
- PR 본문에는 무엇을 왜 바꿨는지와 실행 결과를 넣습니다.
- 머지 전에 `python src/main.py`가 끝까지 도는지 확인합니다.

### 산출물 규칙

- `outputs/`와 `보고서용_캡쳐본/`은 실행하면 다시 만들어집니다.
  **코드를 고쳤으면 반드시 다시 실행해서 산출물을 맞춰 주세요.**
  코드와 결과가 어긋나 있으면 감점됩니다.
- `data/`와 `outputs/logs/`는 `.gitignore`에 있어 커밋되지 않습니다.
- 보고서(`outputs/report.md`)는 손으로 고치지 않습니다. `src/report.py`를 고쳐야 합니다.
