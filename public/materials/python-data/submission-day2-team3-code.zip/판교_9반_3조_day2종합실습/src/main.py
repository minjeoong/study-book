"""
제출자 : 판교 9반 3조 (김명철, 김민정, 김진수, 정민성, 전진만)
과제   : [종합 실습 2] Adult Census Income End-to-End 데이터 분석

전체 분석 흐름을 조립하는 파일이다. 실제 처리는 아래 모듈이 나눠 맡는다.

  config.py             경로·컬럼·색상·상수
  logging_setup.py      로깅 설정, 실행 환경 기록, 오류 출력
  data_loader.py        원본 확보, Pandas·Polars 로딩과 비교
  preprocess.py         결측치·중복 처리, 기본 EDA, 기술통계
  statistical_tests.py  상관분석, 카이제곱·Cramér's V, 가정 검정과 t-test
  visualization.py      Seaborn 4종·Plotly 1종 차트
  modeling.py           Pipeline 학습·평가·저장, 심화 분석
  report.py             outputs/report.md 생성
  capture.py            보고서용 캡쳐본 이미지 생성

실행 순서
  0. 실행 환경 기록
  1. Pandas / Polars 로딩 및 비교 (+ Polars 표현식 집계)
  2. 결측치·중복 처리
  3. 기본 EDA
  4. 기술통계
  5. 수치형 상관분석
  6. 범주형 연관성 (카이제곱 · Cramér's V)
  7. t-test (정규성·등분산성 검정 후 실행)
  8. Seaborn 정적 차트
  9. Plotly 인터랙티브 차트
 10. ML Pipeline 학습·평가·저장 (기본 + 불균형 대응)
 11. 심화 분석 (파생변수·모델 비교·임계값)
 12. report.md 자동 생성
 13. 보고서용 캡쳐본 생성
"""

from __future__ import annotations

import sys
import time
from typing import Any

REQUIRED_PACKAGES = "pandas polars numpy matplotlib seaborn scipy scikit-learn joblib plotly tabulate"

try:
    import pandas as pd

    from capture import build_capture_pack
    from config import (
        CAPTURE_DIR,
        CATEGORICAL_PNG,
        CORRELATION_PNG,
        DATA_URL,
        EDUCATION_HTML,
        EVALUATION_PNG,
        INCOME_PNG,
        AGE_PNG,
        BALANCED_MODEL_PATH,
        BASE_DIR,
        LOG_PATH,
        MODEL_PATH,
        RAW_DATA_PATH,
        REPORT_PATH,
        THRESHOLD_PNG,
    )
    from data_loader import (
        compare_pandas_polars,
        download_dataset,
        load_with_pandas,
        load_with_polars,
    )
    from logging_setup import (
        configure_logging,
        log_environment,
        log_section,
        logger,
        report_failure,
    )
    from modeling import run_advanced_analysis, train_machine_learning_pipeline
    from preprocess import clean_data, descriptive_statistics, perform_eda
    from report import generate_report
    from statistical_tests import (
        categorical_association,
        correlation_analysis,
        perform_t_test,
    )
    from visualization import (
        configure_chart_theme,
        configure_korean_font,
        create_plotly_chart,
        create_seaborn_plots,
        save_categorical_association_chart,
        save_correlation_heatmap,
    )
except ImportError as error:
    raise SystemExit(
        f"[환경 오류] '{getattr(error, 'name', '필수 패키지')}' 를 불러올 수 없습니다.\n"
        "지금 실행 중인 Python에 그대로 설치하려면 아래 명령을 사용하세요.\n"
        f"  {sys.executable} -m pip install {REQUIRED_PACKAGES}\n"
        f"(현재 실행 중인 Python: {sys.executable})"
    ) from error


def run_stage(stage_name: str, function: Any, *args: Any, **kwargs: Any) -> Any:
    """
    한 단계를 실행하면서 어디서 무엇이 실패했는지 로그에 남긴다.

    단계를 감싸는 이유는 오류 메시지의 위치 정보 때문이다. 그냥 두면
    "KeyError: 'income'"처럼 원인만 나오고 어느 단계에서 터졌는지는 알 수 없다.
    여기서 단계 이름을 붙여 다시 던지면 로그만 보고도 실패 지점을 찾을 수 있다.

    예외를 삼키지는 않는다. 중간 단계가 실패했는데 계속 진행하면 뒤 단계가
    잘못된 값으로 돌아가 엉뚱한 보고서가 나오기 때문이다.
    """
    logger.debug(f"[단계 시작] {stage_name}")
    started = time.perf_counter()
    try:
        result = function(*args, **kwargs)
    except Exception as error:
        elapsed = time.perf_counter() - started
        logger.error(
            f"[단계 실패] {stage_name} ({elapsed:.2f}초) - {type(error).__name__}: {error}"
        )
        # 원래 예외를 그대로 올려보내야 아래 __main__의 분류별 처리가 동작한다.
        raise
    logger.debug(f"[단계 완료] {stage_name} ({time.perf_counter() - started:.2f}초)")
    return result


def main() -> None:
    """전체 분석 흐름을 실행한다."""
    configure_logging()
    total_started = time.perf_counter()

    logger.info("[종합 실습 2] Adult Census Income 분석을 시작합니다.")
    logger.info("판교 9반 3조 — 김명철, 김민정, 김진수, 정민성, 전진만")
    logger.info(f"로그 파일: {LOG_PATH}")

    versions = log_environment()

    # 테마를 먼저 적용해야 seaborn 기본값이 한글 폰트 설정을 덮어쓰지 않는다.
    configure_chart_theme()
    configure_korean_font()

    raw_path = run_stage("원본 데이터 확보", download_dataset, DATA_URL, RAW_DATA_PATH)

    pandas_df, pandas_seconds = run_stage("Pandas 로딩", load_with_pandas, raw_path)
    polars_df, polars_seconds = run_stage("Polars 로딩", load_with_polars, raw_path)
    load_summary = run_stage(
        "Pandas/Polars 비교", compare_pandas_polars,
        pandas_df, pandas_seconds, polars_df, polars_seconds,
    )

    cleaned, clean_summary = run_stage("결측치·중복 처리", clean_data, pandas_df)
    eda_summary = run_stage("기본 EDA", perform_eda, cleaned)
    description = run_stage("기술통계", descriptive_statistics, cleaned)

    correlation = run_stage("수치형 상관분석", correlation_analysis, cleaned)
    run_stage("상관 히트맵 저장", save_correlation_heatmap, correlation)

    association = run_stage("범주형 연관성 분석", categorical_association, cleaned)
    run_stage("범주형 연관 차트 저장", save_categorical_association_chart, association)

    t_test = run_stage("t-test (가정 검정 포함)", perform_t_test, cleaned)

    run_stage("Seaborn 차트 생성", create_seaborn_plots, cleaned)
    run_stage("Plotly 차트 생성", create_plotly_chart, cleaned)

    ml = run_stage("ML Pipeline 학습·평가·저장", train_machine_learning_pipeline, cleaned)
    advanced = run_stage("심화 분석", run_advanced_analysis, cleaned)

    run_stage(
        "report.md 생성", generate_report,
        load_summary, clean_summary, eda_summary, description,
        correlation, association, t_test, ml, advanced, versions,
    )

    verify_artifacts()

    # 캡쳐본은 로그 파일을 읽어 만들기 때문에 다른 단계가 모두 끝난 뒤에 실행한다.
    run_stage("보고서용 캡쳐본 생성", build_capture_pack)

    total_elapsed = time.perf_counter() - total_started
    logger.info(f"\n[종합 실습 2] 모든 단계가 정상적으로 완료되었습니다. (총 {total_elapsed:.1f}초)")
    logger.info(f"보고서   : {REPORT_PATH.relative_to(BASE_DIR)}")
    logger.info(f"캡쳐본   : {CAPTURE_DIR.name}/")
    logger.info(f"실행 로그: {LOG_PATH.relative_to(BASE_DIR)}")


def verify_artifacts() -> None:
    """산출물이 실제로 만들어졌는지 확인한다."""
    log_section("산출물 생성 확인")

    expected = (
        INCOME_PNG, AGE_PNG, CORRELATION_PNG, CATEGORICAL_PNG, EDUCATION_HTML,
        EVALUATION_PNG, THRESHOLD_PNG, MODEL_PATH, BALANCED_MODEL_PATH, REPORT_PATH,
    )
    missing = []
    for artifact in expected:
        # 파일이 생겼더라도 크기가 0이면 저장이 중간에 끊긴 것이므로 실패로 본다.
        created = artifact.exists() and artifact.stat().st_size > 0
        size = f"{artifact.stat().st_size:,} bytes" if artifact.exists() else "없음"
        logger.info(
            f"{'생성 완료' if created else '생성 실패'}: "
            f"{artifact.relative_to(BASE_DIR)} ({size})"
        )
        if not created:
            missing.append(artifact.relative_to(BASE_DIR))

    if missing:
        raise OSError(f"생성되지 않은 산출물이 있습니다: {', '.join(map(str, missing))}")


if __name__ == "__main__":
    # 예외를 종류별로 나눠 잡는 이유는 원인에 맞는 조치를 알려주기 위해서다.
    # 전부 한 번에 잡으면 "오류가 났다"는 말밖에 못 한다.
    try:
        main()
    except FileNotFoundError as error:
        report_failure(f"\n[파일 오류] 필요한 파일을 찾지 못했습니다: {error}", error)
        sys.exit(1)
    except PermissionError as error:
        report_failure(f"\n[권한 오류] 파일을 읽거나 쓸 권한이 없습니다: {error}", error)
        sys.exit(1)
    except pd.errors.EmptyDataError as error:
        report_failure("\n[데이터 오류] 파일에 읽을 내용이 없습니다.", error)
        sys.exit(1)
    except pd.errors.ParserError as error:
        report_failure(f"\n[CSV 형식 오류] 구분자나 열 개수를 확인하세요: {error}", error)
        sys.exit(1)
    except MemoryError as error:
        report_failure("\n[메모리 부족] 다른 프로그램을 닫고 다시 실행하세요.", error)
        sys.exit(1)
    except (ValueError, TypeError, KeyError) as error:
        report_failure(f"\n[데이터 오류] {type(error).__name__}: {error}", error)
        sys.exit(1)
    except AssertionError as error:
        report_failure(f"\n[검증 오류] {error}", error)
        sys.exit(1)
    except OSError as error:
        report_failure(f"\n[파일 저장 오류] {error}", error)
        sys.exit(1)
    except KeyboardInterrupt:
        report_failure("\n[중단] 사용자가 실행을 중단했습니다.")
        sys.exit(130)
    except Exception as error:
        report_failure(f"\n[예상하지 못한 오류] {type(error).__name__}: {error}", error)
        sys.exit(1)
