"""
원본 데이터 확보와 Pandas / Polars 로딩.

두 라이브러리에 같은 로컬 파일을 넣어 shape·시간·메모리·결측 수를 비교한다.
"""

from __future__ import annotations

import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

import pandas as pd
import polars as pl

from config import (
    COLUMNS,
    POLARS_NUMERIC_COLUMNS,
    POSITIVE_LABEL,
    TARGET_COLUMN,
)
from logging_setup import log_section, logger


def download_dataset(url: str, destination: Path) -> Path:
    """
    원본 데이터를 한 번만 내려받아 로컬에 캐시한다.

    Pandas와 Polars가 각각 URL을 호출하면 네트워크 상태 차이가 로딩 시간에 섞여
    라이브러리 비교가 공정하지 않다. Polars의 read_csv도 로컬 경로 입력이 가장
    안정적이라, 동일한 로컬 파일을 두 라이브러리에 똑같이 넣는다.
    """
    destination.parent.mkdir(parents=True, exist_ok=True)

    # 크기가 0이면 이전 다운로드가 중간에 끊긴 것이므로 캐시로 인정하지 않는다.
    if destination.exists() and destination.stat().st_size > 0:
        logger.info(f"[캐시 사용] 이미 내려받은 원본을 사용합니다: {destination}")
        return destination

    logger.info(f"[다운로드] {url}")
    try:
        urllib.request.urlretrieve(url, destination)
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as error:
        raise SystemExit(
            f"[네트워크 오류] 원본 데이터를 내려받지 못했습니다: {error}\n"
            f"브라우저로 {url} 를 저장한 뒤 {destination} 경로에 두고 다시 실행하세요."
        ) from error

    if destination.stat().st_size == 0:
        raise ValueError(f"내려받은 파일이 비어 있습니다: {destination}")

    logger.info(f"[다운로드 완료] {destination} ({destination.stat().st_size:,} bytes)")
    return destination


def load_with_pandas(path: Path) -> tuple[pd.DataFrame, float]:
    """Pandas로 데이터를 로딩하고 소요 시간을 함께 반환한다."""
    start = time.perf_counter()
    # header=None: 원본에 컬럼명이 없다.
    # skipinitialspace=True: 값이 ", State-gov"처럼 콤마 뒤 공백을 포함한다.
    # na_values="?": Adult 데이터는 결측을 '?' 문자열로 표기한다.
    dataframe = pd.read_csv(
        path,
        header=None,
        names=COLUMNS,
        skipinitialspace=True,
        na_values="?",
        skip_blank_lines=True,
    )
    elapsed = time.perf_counter() - start
    return dataframe, elapsed


def load_with_polars(path: Path) -> tuple[pl.DataFrame, float]:
    """
    Polars로 동일한 데이터를 로딩하고 소요 시간을 함께 반환한다.

    Polars에는 skipinitialspace 옵션이 없어 값이 " State-gov"처럼 앞 공백을 포함한다.
    그래서 Pandas 결과와 shape·dtype·결측 수를 맞추려면 읽은 뒤 네 단계를 더 거쳐야 한다.
      (1) 문자열 앞뒤 공백 제거
      (2) '?'를 null로 변환 (Pandas의 na_values="?"에 해당)
      (3) 숫자 컬럼을 Int64로 캐스팅 (Pandas의 dtype 추론에 해당)
      (4) 파일 끝 빈 줄이 만든 '전부 null'인 행 제거
    """
    start = time.perf_counter()
    frame = (
        pl.read_csv(
            path,
            has_header=False,
            new_columns=COLUMNS,
            # 앞 공백 때문에 숫자 컬럼이 잘못 추론되므로 일단 전부 문자열로 읽는다.
            infer_schema_length=0,
            truncate_ragged_lines=True,
        )
        .with_columns(pl.col(pl.String).str.strip_chars())
        .with_columns(
            pl.when(pl.col(pl.String) == "?")
            .then(None)
            .otherwise(pl.col(pl.String))
            .name.keep()
        )
        .with_columns(pl.col(POLARS_NUMERIC_COLUMNS).cast(pl.Int64, strict=False))
        .filter(~pl.all_horizontal(pl.all().is_null()))
    )
    elapsed = time.perf_counter() - start
    return frame, elapsed


def summarize_with_polars(frame: pl.DataFrame) -> pl.DataFrame:
    """
    Polars 표현식으로 집계를 직접 수행한다.

    Polars를 읽기 전용으로만 쓰면 "형식적으로 넣었다"는 지적을 받을 수 있어,
    실제 분석에 쓰이는 집계를 Polars 쪽에서 한 번 돌린다.
    30세 초과 응답자를 걸러 소득 구간별 인원·평균 근로시간·평균 교육연수를 낸다.
    Pandas의 groupby와 결과가 같은지 화면에서 바로 대조할 수 있다.
    """
    return (
        frame.filter(pl.col("age") > 30)
        .group_by(TARGET_COLUMN)
        .agg(
            pl.len().alias("인원수"),
            pl.col("hours-per-week").mean().round(2).alias("평균_주당근로시간"),
            pl.col("education-num").mean().round(2).alias("평균_교육연수"),
            pl.col("age").mean().round(2).alias("평균_나이"),
        )
        .sort(TARGET_COLUMN)
    )


def compare_pandas_polars(
    pandas_df: pd.DataFrame,
    pandas_seconds: float,
    polars_df: pl.DataFrame,
    polars_seconds: float,
) -> dict[str, Any]:
    """두 라이브러리의 shape·로딩 시간·메모리·결측 수를 비교하고 요약 통계까지 출력한다."""
    log_section("1. 데이터 로딩: Pandas vs Polars 비교")

    # deep=True라야 object(문자열) 컬럼의 실제 문자열 메모리까지 합산된다.
    pandas_mb = pandas_df.memory_usage(deep=True).sum() / 1024 ** 2
    polars_mb = polars_df.estimated_size("mb")

    pandas_nulls = int(pandas_df.isna().sum().sum())
    polars_nulls = int(polars_df.null_count().sum_horizontal().item())

    logger.info(f"Pandas shape        : {pandas_df.shape}")
    logger.info(f"Polars shape        : {polars_df.shape}")
    logger.info(f"Pandas loading time : {pandas_seconds:.4f} 초")
    logger.info(f"Polars loading time : {polars_seconds:.4f} 초")
    logger.info(f"Pandas 메모리 사용량 : {pandas_mb:,.2f} MB")
    logger.info(f"Polars 메모리 사용량 : {polars_mb:,.2f} MB")
    logger.info(f"Pandas 전체 결측치 수 : {pandas_nulls:,}")
    logger.info(f"Polars 전체 결측치 수 : {polars_nulls:,}")

    shape_match = pandas_df.shape == polars_df.shape
    null_match = pandas_nulls == polars_nulls
    dtype_match = _numeric_dtypes_match(pandas_df, polars_df)

    logger.info(f"\nshape 일치 여부      : {'일치' if shape_match else '불일치'}")
    logger.info(f"결측치 수 일치 여부  : {'일치' if null_match else '불일치'}")
    logger.info(f"숫자형 dtype 일치    : {'일치' if dtype_match else '불일치'}")

    # 로딩 직후 데이터가 어떤 상태인지 이 단계에서 바로 보이도록 요약을 함께 찍는다.
    missing_by_column = pandas_df.isna().sum()
    missing_columns = missing_by_column[missing_by_column > 0]
    logger.info(
        f"\n[결측 요약] 결측이 있는 컬럼 {len(missing_columns)}개 / 전체 결측 {pandas_nulls:,}건 "
        f"({pandas_nulls / pandas_df.size:.2%} of 전체 셀)"
    )
    logger.info(
        "[결측 상세] "
        + ", ".join(f"{col} {int(cnt):,}건" for col, cnt in missing_columns.items())
    )
    logger.info(
        f"[기술통계 요약] 나이 평균 {pandas_df['age'].mean():.1f}세 / "
        f"주당 근로시간 평균 {pandas_df['hours-per-week'].mean():.1f}시간 / "
        f"교육연수 평균 {pandas_df['education-num'].mean():.1f}년"
    )
    high_ratio = (pandas_df[TARGET_COLUMN].str.strip() == POSITIVE_LABEL).mean()
    logger.info(
        f"[목표 변수] 고소득(>50K) 비율 {high_ratio:.2%} / 중복 행 "
        f"{int(pandas_df.duplicated().sum()):,}건"
    )

    logger.info("\n[Pandas head(3)]")
    logger.info(pandas_df.head(3).to_string())
    logger.info("\n[Polars head(3)]")
    logger.info(polars_df.head(3))

    # Polars 표현식으로 직접 집계해 읽기 전용 사용이 아님을 보인다.
    polars_summary = summarize_with_polars(polars_df)
    logger.info("\n[Polars 집계] 30세 초과 응답자, 소득 구간별 요약")
    logger.info("(filter → group_by → agg 를 Polars 표현식으로 수행)")
    logger.info(polars_summary)

    return {
        "pandas_shape": pandas_df.shape,
        "polars_shape": polars_df.shape,
        "pandas_seconds": pandas_seconds,
        "polars_seconds": polars_seconds,
        "pandas_mb": pandas_mb,
        "polars_mb": polars_mb,
        "pandas_nulls": pandas_nulls,
        "polars_nulls": polars_nulls,
        "shape_match": shape_match,
        "null_match": null_match,
        "dtype_match": dtype_match,
        # to_pandas()는 pyarrow를 요구하므로, 의존성을 늘리지 않도록 dict를 거쳐 변환한다.
        "polars_summary": pd.DataFrame(polars_summary.to_dicts()),
        "missing_by_column": {k: int(v) for k, v in missing_columns.items()},
    }


def _numeric_dtypes_match(pandas_df: pd.DataFrame, polars_df: pl.DataFrame) -> bool:
    """
    숫자 컬럼이 양쪽 모두 정수형으로 읽혔는지 확인한다.

    Polars는 전부 문자열로 읽은 뒤 캐스팅하므로, 이 확인을 빠뜨리면 shape만 같고
    dtype이 어긋난 채로 "일치한다"고 잘못 보고할 수 있다.
    """
    polars_dtypes = dict(zip(polars_df.columns, polars_df.dtypes))
    for column in POLARS_NUMERIC_COLUMNS:
        if not pd.api.types.is_integer_dtype(pandas_df[column]):
            return False
        if polars_dtypes[column] != pl.Int64:
            return False
    return True
