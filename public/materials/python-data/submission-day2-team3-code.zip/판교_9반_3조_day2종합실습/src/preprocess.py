"""결측치·중복 처리와 기본 EDA."""

from __future__ import annotations

from typing import Any

import pandas as pd

from config import NUMERIC_FEATURES, POSITIVE_LABEL, TARGET_COLUMN
from logging_setup import log_section, logger


def clean_data(dataframe: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    """
    결측치와 중복을 확인하고 처리한다.

    처리 방침
    - 중복 행은 같은 응답이 두 번 집계되어 분포와 검정 결과를 왜곡하므로 제거한다.
    - 결측이 있는 세 컬럼(workclass, occupation, native-country)은 모두 범주형이고
      전체의 일부다. EDA에서는 결측을 제거하지 않고 '결측 제외' 상태로 집계해 원본
      분포를 보존하고, ML에서는 행을 버리지 않고 Pipeline의 SimpleImputer로 대치한다.
    - 목표 변수 income에 결측이 있으면 정답이 없는 행이라 그 행만 제거한다.
    """
    log_section("2. 결측치 / 중복 데이터 확인 및 처리")

    missing_by_column = dataframe.isna().sum()
    duplicate_count = int(dataframe.duplicated().sum())

    logger.info("[컬럼별 결측치 수]")
    logger.info(missing_by_column.to_string())
    logger.info(f"\n결측치가 있는 컬럼 수 : {int((missing_by_column > 0).sum())}")
    logger.info(f"전체 결측치 수        : {int(missing_by_column.sum()):,}")
    logger.info(f"중복 행 개수          : {duplicate_count:,}")

    before_rows = len(dataframe)
    cleaned = dataframe.drop_duplicates().copy()
    after_duplicates = len(cleaned)

    # income 문자열에 공백이나 마침표('<=50K.')가 섞이면 클래스가 4개로 갈라진다.
    cleaned[TARGET_COLUMN] = cleaned[TARGET_COLUMN].str.strip().str.rstrip(".")
    cleaned = cleaned[cleaned[TARGET_COLUMN].notna()]
    after_target = len(cleaned)

    if cleaned.empty:
        raise ValueError("중복·결측 처리 후 분석할 데이터가 없습니다.")

    logger.info(f"\n원본 행 수                    : {before_rows:,}")
    logger.info(
        f"중복 제거 후 행 수            : {after_duplicates:,} "
        f"(제거 {before_rows - after_duplicates:,}행)"
    )
    logger.info(
        f"목표 변수 결측 제거 후 행 수  : {after_target:,} "
        f"(제거 {after_duplicates - after_target:,}행)"
    )
    logger.info(
        f"처리 후 남은 결측치 수        : {int(cleaned.isna().sum().sum()):,} "
        f"(범주형 3개 컬럼, ML Pipeline에서 최빈값으로 대치)"
    )
    logger.info(f"income 클래스 목록            : {sorted(cleaned[TARGET_COLUMN].unique())}")

    summary = {
        "missing_by_column": missing_by_column[missing_by_column > 0].to_dict(),
        "missing_total": int(missing_by_column.sum()),
        "duplicate_count": duplicate_count,
        "rows_before": before_rows,
        "rows_after": after_target,
        "missing_after": int(cleaned.isna().sum().sum()),
        "classes": sorted(cleaned[TARGET_COLUMN].unique()),
    }
    return cleaned, summary


def perform_eda(dataframe: pd.DataFrame) -> dict[str, Any]:
    """소득 분포와 주요 범주형 변수 빈도를 출력해 데이터의 전반적 구조를 확인한다."""
    log_section("3. 기본 EDA")

    logger.info("[데이터 구조]")
    logger.info(f"행 수 : {len(dataframe):,} / 열 수 : {len(dataframe.columns)}")
    logger.info("\n[dtypes]")
    logger.info(dataframe.dtypes.to_string())

    income_counts = dataframe[TARGET_COLUMN].value_counts()
    income_ratio = dataframe[TARGET_COLUMN].value_counts(normalize=True)

    logger.info("\n[income 분포]")
    for label in income_counts.index:
        logger.info(f"{label:>6} : {income_counts[label]:>7,}건 ({income_ratio[label]:.2%})")
    # 클래스 불균형은 Accuracy만 보면 안 되는 이유가 되므로 비율을 명시적으로 남긴다.
    logger.info(
        f"클래스 불균형 비율(다수/소수) : {income_counts.max() / income_counts.min():.2f} : 1"
    )

    logger.info("\n[education 빈도 상위 5개]")
    logger.info(dataframe["education"].value_counts().head(5).to_string())
    logger.info("\n[occupation 빈도 상위 5개, 결측 제외]")
    logger.info(dataframe["occupation"].value_counts().head(5).to_string())
    logger.info("\n[sex 빈도]")
    logger.info(dataframe["sex"].value_counts().to_string())

    return {
        "income_counts": income_counts.to_dict(),
        "income_ratio": {k: float(v) for k, v in income_ratio.items()},
        "imbalance_ratio": float(income_counts.max() / income_counts.min()),
        "top_education": dataframe["education"].value_counts().head(5).to_dict(),
        "top_occupation": dataframe["occupation"].value_counts().head(5).to_dict(),
    }


def descriptive_statistics(dataframe: pd.DataFrame) -> pd.DataFrame:
    """수치형 변수의 평균·표준편차·분위수를 출력한다."""
    log_section("4. 기술통계: 평균 / 표준편차 / 분위수")

    description = dataframe[NUMERIC_FEATURES].describe().T
    logger.info(description.to_string(float_format=lambda value: f"{value:,.2f}"))

    logger.info("\n[소득 집단별 주요 지표 평균]")
    grouped = dataframe.groupby(TARGET_COLUMN)[
        ["age", "education-num", "hours-per-week"]
    ].mean()
    logger.info(grouped.to_string(float_format=lambda value: f"{value:,.2f}"))

    return description
