"""
보고서용 캡쳐본 생성.

터미널 출력을 사람이 직접 스크린샷 뜨는 대신, 실행 로그를 단계별로 잘라
터미널 모양의 PNG로 렌더링한다. 조원들이 각자 화면을 캡처할 필요 없이
같은 이미지를 보고서에 바로 붙일 수 있다.

차트 PNG도 번호와 한글 설명이 붙은 이름으로 함께 복사해 둔다.
"""

from __future__ import annotations

import re
import shutil
from pathlib import Path

from matplotlib import font_manager
from matplotlib import pyplot as plt

from config import (
    AGE_PNG,
    CAPTURE_DIR,
    CATEGORICAL_PNG,
    CORRELATION_PNG,
    EDUCATION_HTML,
    EVALUATION_PNG,
    INCOME_PNG,
    LOG_PATH,
    THRESHOLD_PNG,
)
from logging_setup import log_section, logger

# 터미널처럼 보이도록 어두운 배경에 밝은 글자를 쓴다.
TERMINAL_BG = "#1c1c1e"
TERMINAL_FG = "#e8e6e3"
TERMINAL_ACCENT = "#7fd3a2"
TERMINAL_DIM = "#8a8a8e"

# 한 이미지에 담을 최대 줄 수. 넘치면 여러 장으로 나눈다.
MAX_LINES_PER_IMAGE = 46

# 차트 파일을 보고서 순서대로 옮길 때 쓸 이름.
FIGURE_EXPORTS: list[tuple[Path, str]] = [
    (INCOME_PNG, "07_차트_소득분포.png"),
    (AGE_PNG, "08_차트_나이분포.png"),
    (CORRELATION_PNG, "09_차트_상관계수히트맵.png"),
    (CATEGORICAL_PNG, "10_차트_범주형연관강도.png"),
    (EVALUATION_PNG, "11_차트_모델평가.png"),
    (THRESHOLD_PNG, "12_차트_임계값조정.png"),
]


def find_monospace_font() -> str | None:
    """
    한글이 나오는 고정폭 폰트를 찾는다.

    표(describe 결과 등)를 렌더링하려면 글자 폭이 일정해야 열이 맞는다.
    비례폭 폰트로 그리면 숫자 열이 어긋나 보기 나빠진다.
    """
    installed = {font.name for font in font_manager.fontManager.ttflist}
    for name in ("D2Coding", "NanumGothicCoding", "D2Coding ligature", "Menlo", "Monaco"):
        if name in installed:
            return name
    return None


def parse_log_sections(log_path: Path) -> list[tuple[str, list[str]]]:
    """
    실행 로그를 '=' 구분선 기준으로 단계별로 자른다.

    로그 파일에는 'YYYY-MM-DD HH:MM:SS [INFO   ] ' 접두사가 붙어 있으므로 먼저 떼어낸다.
    화면에 보이던 그대로를 이미지로 만들기 위해서다.
    """
    if not log_path.exists():
        raise FileNotFoundError(f"로그 파일이 없습니다: {log_path}")

    prefix = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} \[\w+\s*\] ?")
    lines = [
        prefix.sub("", raw.rstrip("\n"))
        for raw in log_path.read_text(encoding="utf-8").splitlines()
    ]
    # DEBUG 줄은 화면에 안 나오던 내용이라 캡쳐본에서도 뺀다.
    lines = [line for line in lines if not line.startswith("[단계 ")]

    sections: list[tuple[str, list[str]]] = []
    current_title = "실행 시작"
    current_body: list[str] = []
    index = 0

    while index < len(lines):
        line = lines[index]
        # '===' 줄 다음이 제목, 그다음이 다시 '===' 이면 새 단계의 시작이다.
        if set(line.strip()) == {"="} and index + 2 < len(lines) and set(lines[index + 2].strip()) == {"="}:
            if current_body:
                sections.append((current_title, current_body))
            current_title = lines[index + 1].strip()
            current_body = []
            index += 3
            continue
        current_body.append(line)
        index += 1

    if current_body:
        sections.append((current_title, current_body))

    return sections


def render_terminal_image(
    title: str, body_lines: list[str], destination: Path, font_name: str | None
) -> None:
    """터미널 화면처럼 보이는 PNG 한 장을 만든다."""
    # 빈 줄이 연속으로 오면 이미지가 불필요하게 길어지므로 하나로 줄인다.
    compact: list[str] = []
    for line in body_lines:
        if not line.strip() and compact and not compact[-1].strip():
            continue
        compact.append(line)
    while compact and not compact[0].strip():
        compact.pop(0)
    while compact and not compact[-1].strip():
        compact.pop()

    longest = max((len(line) for line in compact), default=40)
    longest = max(longest, len(title) + 4)

    # 글자 크기를 기준으로 그림 크기를 역산한다. 문자 하나의 폭은 대략 높이의 0.6배다.
    font_size = 11
    char_width_inch = font_size * 0.6 / 72
    line_height_inch = font_size * 1.55 / 72
    width = min(max(longest * char_width_inch + 0.9, 7.5), 24)
    height = (len(compact) + 3) * line_height_inch + 0.55

    fig = plt.figure(figsize=(width, height), facecolor=TERMINAL_BG)
    ax = fig.add_axes((0, 0, 1, 1))
    ax.set_facecolor(TERMINAL_BG)
    ax.axis("off")

    text_kwargs = {"family": font_name} if font_name else {}

    # 상단 제목 줄
    ax.text(
        0.018, 1 - 0.4 * line_height_inch / height,
        f"$ {title}",
        color=TERMINAL_ACCENT, fontsize=font_size + 1, va="top", ha="left",
        transform=ax.transAxes, fontweight="bold", **text_kwargs,
    )

    y = 1 - (2.0 * line_height_inch) / height
    for line in compact:
        stripped = line.strip()
        if set(stripped) in ({"="}, {"-"}) and len(stripped) > 8:
            color = TERMINAL_DIM
        elif stripped.startswith("[") and "]" in stripped:
            color = TERMINAL_ACCENT
        else:
            color = TERMINAL_FG
        ax.text(
            0.018, y, line, color=color, fontsize=font_size,
            va="top", ha="left", transform=ax.transAxes, **text_kwargs,
        )
        y -= line_height_inch / height

    destination.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(destination, dpi=170, facecolor=TERMINAL_BG)
    plt.close(fig)


def slugify(title: str) -> str:
    """단계 제목을 파일명으로 쓸 수 있게 정리한다."""
    cleaned = re.sub(r"[^\w가-힣]+", "_", title).strip("_")
    return cleaned[:40]


def build_capture_pack() -> list[Path]:
    """
    실행 로그와 차트를 모아 `보고서용_캡쳐본/` 폴더를 만든다.

    조원 다섯 명이 각자 터미널을 캡처하면 폰트·창 크기가 달라 보고서가 들쭉날쭉해진다.
    같은 이미지를 쓰면 그 문제가 없고, 캡처를 뜨는 시간도 아낄 수 있다.
    """
    log_section("13. 보고서용 캡쳐본 생성")

    # 이전 실행에서 만든 이미지가 남아 섞이지 않도록 폴더를 비우고 시작한다.
    if CAPTURE_DIR.exists():
        shutil.rmtree(CAPTURE_DIR)
    CAPTURE_DIR.mkdir(parents=True, exist_ok=True)

    font_name = find_monospace_font()
    if font_name is None:
        logger.warning(
            "[경고] 고정폭 한글 폰트를 찾지 못했습니다. 표의 열이 어긋나 보일 수 있습니다."
        )
    else:
        logger.debug(f"캡쳐본 폰트: {font_name}")

    created: list[Path] = []
    sections = parse_log_sections(LOG_PATH)

    order = 1
    for title, body in sections:
        if not any(line.strip() for line in body):
            continue
        # 한 단계 출력이 길면 여러 장으로 쪼갠다. 한 장에 다 넣으면 글씨가 너무 작아진다.
        chunks = [
            body[i:i + MAX_LINES_PER_IMAGE]
            for i in range(0, len(body), MAX_LINES_PER_IMAGE)
        ] or [body]

        for part, chunk in enumerate(chunks, start=1):
            suffix = f"_{part}" if len(chunks) > 1 else ""
            name = f"{order:02d}_{slugify(title)}{suffix}.png"
            path = CAPTURE_DIR / name
            render_terminal_image(title, chunk, path, font_name)
            created.append(path)
            logger.info(f"[캡쳐 생성] {name}")
        order += 1

    # 차트 이미지도 보고서 순서대로 이름을 붙여 함께 넣는다.
    for source, target_name in FIGURE_EXPORTS:
        if source.exists():
            target = CAPTURE_DIR / target_name
            shutil.copy2(source, target)
            created.append(target)
            logger.info(f"[차트 복사] {target_name}")

    _write_capture_guide(created)
    logger.info(f"\n총 {len(created)}개 파일을 {CAPTURE_DIR.name}/ 에 만들었습니다.")
    return created


def _write_capture_guide(created: list[Path]) -> None:
    """캡쳐본 폴더에 어떤 이미지를 어디에 쓰는지 안내하는 README를 남긴다."""
    listing = "\n".join(
        f"| {path.name} | |" for path in sorted(created, key=lambda p: p.name)
    )
    guide = f"""# 보고서용 캡쳐본

`python src/main.py`를 실행하면 이 폴더가 자동으로 다시 만들어집니다.
터미널을 직접 캡처할 필요 없이, 아래 이미지를 보고서에 그대로 붙여 쓰면 됩니다.

조원 다섯 명이 각자 화면을 캡처하면 폰트와 창 크기가 달라 보고서가 들쭉날쭉해집니다.
같은 이미지를 쓰면 그 문제가 없습니다.

## 파일 목록

`01_`~ 로 시작하는 것은 터미널 실행 결과, `07_차트_` 부터는 그래프입니다.
번호 순서가 곧 보고서에 넣는 순서입니다.

| 파일 | 넣을 위치 (직접 채우세요) |
|---|---|
{listing}

## 보고서 목차 예시

1. 프로젝트 개요 · 데이터셋 소개
2. 실행 환경 — `01_` 이미지
3. Pandas / Polars 로딩 비교 — `02_` 이미지
4. 결측치 · 중복 처리 — `03_` 이미지
5. 기본 EDA — `04_` 이미지
6. 기술통계 — `05_` 이미지
7. 상관분석 — `06_` 이미지 + `09_차트_상관계수히트맵.png`
8. 범주형 연관성(카이제곱·Cramér's V) — `10_차트_범주형연관강도.png`
9. t-test 가정 검정과 결과 — 해당 단계 이미지
10. Seaborn 시각화 — `07_차트_`, `08_차트_`
11. Plotly 시각화 — 브라우저에서 `outputs/figures/05_income_by_education.html`을 열고
    **hover tooltip이 떠 있는 순간**을 직접 캡처 (인터랙티브라 자동 생성 불가)
12. ML Pipeline 평가 — `11_차트_모델평가.png`
13. 심화 분석 · 임계값 조정 — `12_차트_임계값조정.png`
14. 분석 의견 — `outputs/report.md` 12절 참고, 본인 표현으로 정리
15. 한계와 결론 — `outputs/report.md` 13~14절 참고

## 주의

Plotly 차트만은 자동으로 만들 수 없습니다. 인터랙티브 요소(hover tooltip)가
떠 있는 화면을 보여줘야 하는데, 그건 실제로 마우스를 올린 상태를 캡처해야 합니다.

```bash
open outputs/figures/05_income_by_education.html
```
"""
    (CAPTURE_DIR / "README.md").write_text(guide, encoding="utf-8")
