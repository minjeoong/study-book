"""
로깅 설정과 실행 환경 기록.

화면과 로그 파일에 동시에 남기되 형식을 다르게 둔다.
화면은 캡처를 떠야 하므로 메시지만, 파일은 나중에 되짚어야 하므로 시각과 레벨까지 남긴다.
"""

from __future__ import annotations

import logging
import platform
import sys
from pathlib import Path
from typing import Final

from config import BASE_DIR, LOG_DIR, LOG_PATH

logger: Final[logging.Logger] = logging.getLogger("adult_analysis")


def configure_logging() -> None:
    """
    화면과 로그 파일에 동시에 기록하도록 로거를 설정한다.

    핸들러를 둘로 나눈 이유가 있다.
    - 화면(stdout)에는 메시지만 그대로 찍는다. 앞에 시각·레벨이 붙으면 표나 구분선이
      밀려서 캡처가 지저분해진다.
    - 파일(outputs/logs/run.log)에는 시각과 레벨을 함께 남긴다. "이 숫자가 언제 나온
      값이냐"를 나중에 되짚을 때 필요하다.
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logger.setLevel(logging.DEBUG)
    # 같은 프로세스에서 두 번 호출되어도 핸들러가 중복으로 붙지 않게 비우고 시작한다.
    logger.handlers.clear()
    # 루트 로거로 올려보내지 않는다. 안 그러면 같은 줄이 두 번 찍힌다.
    logger.propagate = False

    console = logging.StreamHandler(stream=sys.stdout)
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter("%(message)s"))

    logfile = logging.FileHandler(LOG_PATH, mode="w", encoding="utf-8")
    logfile.setLevel(logging.DEBUG)
    logfile.setFormatter(
        logging.Formatter("%(asctime)s [%(levelname)-7s] %(message)s", "%Y-%m-%d %H:%M:%S")
    )

    logger.addHandler(console)
    logger.addHandler(logfile)


def log_section(title: str) -> None:
    """각 실행 단계를 구분선과 함께 찍는다. 캡처할 때 단계 경계가 분명해진다."""
    logger.info("\n" + "=" * 78)
    logger.info(title)
    logger.info("=" * 78)


def log_environment() -> dict[str, str]:
    """
    실행 환경을 로그와 보고서에 남긴다.

    같은 코드라도 라이브러리 버전이 다르면 수치가 조금씩 달라질 수 있다.
    나중에 "왜 값이 다르지"를 따질 때 기준이 되므로 버전을 먼저 기록해 둔다.
    """
    # 버전 조회는 여기서만 하므로 지역 import로 두어 모듈 간 의존을 줄인다.
    import joblib
    import matplotlib
    import numpy as np
    import pandas as pd
    import plotly
    import polars as pl
    import scipy
    import seaborn as sns
    import sklearn

    versions = {
        "Python": platform.python_version(),
        "OS": f"{platform.system()} {platform.release()}",
        "pandas": pd.__version__,
        "polars": pl.__version__,
        "numpy": np.__version__,
        "scikit-learn": sklearn.__version__,
        "scipy": scipy.__version__,
        "matplotlib": matplotlib.__version__,
        "seaborn": sns.__version__,
        "plotly": plotly.__version__,
        "joblib": joblib.__version__,
    }

    log_section("0. 실행 환경")
    for name, version in versions.items():
        logger.info(f"{name:<14}: {version}")
    logger.debug(f"실행 파일 경로 : {Path(__file__).resolve()}")
    logger.debug(f"작업 기준 경로 : {BASE_DIR}")

    return versions


def report_failure(message: str, error: BaseException | None = None) -> None:
    """
    오류를 화면과 로그 파일에 남긴다.

    로깅 설정 자체가 실패했을 수도 있으므로 핸들러가 붙어 있는지 먼저 확인한다.
    핸들러가 없으면 로거로 찍어도 아무 데도 안 나오기 때문에 stderr로 직접 출력한다.
    오류 메시지를 놓치는 것이 제일 곤란한 상황이라 이중으로 대비한다.
    """
    if logger.handlers:
        logger.error(message)
        if error is not None:
            # 화면에는 요약만, 로그 파일에는 traceback 전체를 남긴다.
            logger.debug("상세 traceback", exc_info=error)
    else:
        print(message, file=sys.stderr)
