"""
통계 분석.

수치형 변수 상관분석, 범주형 변수와 목표 변수의 연관성(카이제곱·Cramér's V),
그리고 가정 검정을 거친 두 집단 평균 비교(t-test)를 담는다.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import (
    chi2_contingency,
    kurtosis,
    levene,
    shapiro,
    skew,
    ttest_ind,
)

from config import (
    ALPHA,
    CATEGORICAL_FEATURES,
    NEGATIVE_LABEL,
    NUMERIC_FEATURES,
    POSITIVE_LABEL,
    RANDOM_STATE,
    SHAPIRO_MAX_SAMPLES,
    TARGET_COLUMN,
)
from logging_setup import log_section, logger


def format_p_value(p_value: float) -> str:
    """
    p-value를 사람이 읽을 수 있게 표기한다.

    표본이 크면 p-value가 double의 표현 한계(약 1e-308) 아래로 내려가 0.0으로 반환된다.
    이때 '0'이라고 적으면 오해를 주므로 '표현 한계 미만'임을 명시한다.
    """
    if p_value == 0.0:
        return "1e-308 미만 (부동소수점 표현 한계로 0.0으로 반환됨)"
    return f"{p_value:.6g}"


# ---------------------------------------------------------------------------
# 수치형 상관분석
# ---------------------------------------------------------------------------

def correlation_analysis(dataframe: pd.DataFrame) -> pd.DataFrame:
    """수치형 변수 간 상관계수 행렬을 출력한다."""
    log_section("5. 상관분석: 수치형 변수 상관계수")

    # 목표 변수와의 관계를 함께 보기 위해 income을 0/1로 바꾼 파생 컬럼을 추가한다.
    numeric_frame = dataframe[NUMERIC_FEATURES].copy()
    numeric_frame["income_binary"] = (dataframe[TARGET_COLUMN] == POSITIVE_LABEL).astype(int)

    correlation = numeric_frame.corr()
    logger.info(correlation.to_string(float_format=lambda value: f"{value: .4f}"))

    target_correlation = (
        correlation["income_binary"].drop("income_binary").sort_values(ascending=False)
    )
    logger.info("\n[고소득 여부(income_binary)와의 상관계수, 절댓값 큰 순]")
    logger.info(target_correlation.to_string(float_format=lambda value: f"{value: .4f}"))

    logger.info(
        "\n피어슨 상관계수는 선형 관계만 잡아낸다. 수치형 변수만 대상이므로,"
        "\n범주형 변수와 목표 변수의 관계는 다음 단계에서 카이제곱 검정으로 따로 확인한다."
    )

    return correlation


# ---------------------------------------------------------------------------
# 범주형 연관성 분석
# ---------------------------------------------------------------------------

def cramers_v(confusion: np.ndarray, chi2: float, n_obs: int) -> float:
    """
    카이제곱 통계량을 0~1 범위의 연관 강도로 바꾼다(Cramér's V).

    카이제곱 값 자체는 표본 수가 커지면 같이 커져서 변수 간 비교에 쓸 수 없다.
    표본 수와 자유도로 나눠 정규화하면 서로 다른 변수의 연관 강도를 견줄 수 있다.
    편향 보정(bias correction)은 표본이 3만 건대로 충분히 커서 생략했다.
    """
    min_dimension = min(confusion.shape) - 1
    if min_dimension <= 0 or n_obs <= 0:
        return 0.0
    return float(np.sqrt(chi2 / (n_obs * min_dimension)))


def interpret_cramers_v(value: float) -> str:
    """Cohen의 관례적 기준으로 연관 강도를 해석한다."""
    if value < 0.10:
        return "매우 약함"
    if value < 0.20:
        return "약함"
    if value < 0.35:
        return "중간"
    return "강함"


def categorical_association(dataframe: pd.DataFrame) -> pd.DataFrame:
    """
    범주형 변수와 목표 변수(income)의 연관성을 카이제곱 검정으로 확인한다.

    수치형 상관계수만으로는 이 데이터의 절반을 놓친다. Adult 데이터의 특성 13개 중
    8개가 범주형이고, 직관적으로도 직업이나 혼인 상태가 소득과 무관할 리 없다.
    범주형 대 범주형은 피어슨 상관계수를 쓸 수 없어 카이제곱 독립성 검정을 쓰고,
    검정 결과가 '관계가 있다/없다'만 답하므로 강도는 Cramér's V로 따로 잰다.
    """
    log_section("6. 범주형 변수 연관성 분석 (카이제곱 검정 · Cramér's V)")

    logger.info("H0 : 해당 범주형 변수와 income은 서로 독립이다(관계가 없다).")
    logger.info("H1 : 두 변수는 독립이 아니다(관계가 있다).")
    logger.info(f"유의수준 : {ALPHA:.2f}\n")

    rows = []
    for column in CATEGORICAL_FEATURES:
        # 교차표를 만들 때 결측은 자동으로 빠진다. 그 행 수를 따로 세어 남긴다.
        contingency = pd.crosstab(dataframe[column], dataframe[TARGET_COLUMN])
        if contingency.shape[0] < 2:
            logger.warning(f"[건너뜀] {column}: 범주가 하나뿐이라 검정할 수 없습니다.")
            continue

        chi2, p_value, degrees_of_freedom, _ = chi2_contingency(contingency)
        n_obs = int(contingency.to_numpy().sum())
        v_value = cramers_v(contingency.to_numpy(), chi2, n_obs)

        rows.append({
            "변수": column,
            "범주 수": contingency.shape[0],
            "카이제곱": chi2,
            "자유도": degrees_of_freedom,
            "p-value": p_value,
            "Cramers_V": v_value,
            "연관 강도": interpret_cramers_v(v_value),
            "유의성": "유의함" if p_value < ALPHA else "유의하지 않음",
        })

    result = pd.DataFrame(rows).sort_values("Cramers_V", ascending=False).reset_index(drop=True)

    logger.info("[범주형 변수와 income의 연관성, Cramér's V 큰 순]")
    display = result.copy()
    display["카이제곱"] = display["카이제곱"].map(lambda v: f"{v:,.1f}")
    display["p-value"] = display["p-value"].map(format_p_value)
    display["Cramers_V"] = display["Cramers_V"].map(lambda v: f"{v:.4f}")
    logger.info(display.to_string(index=False))

    strongest = result.iloc[0]
    logger.info(
        f"\n가장 강하게 연관된 변수는 {strongest['변수']} 입니다 "
        f"(Cramér's V = {strongest['Cramers_V']:.4f}, {strongest['연관 강도']})."
    )
    logger.info(
        "표본이 3만 건대라 대부분의 변수에서 p-value가 매우 작게 나온다."
        "\n따라서 '유의한가'보다 Cramér's V로 '얼마나 강한가'를 보는 것이 실질적이다."
    )

    return result


# ---------------------------------------------------------------------------
# t-test 가정 검정
# ---------------------------------------------------------------------------

def check_normality(values: pd.Series, group_name: str) -> dict[str, Any]:
    """
    정규성을 확인한다.

    Shapiro-Wilk는 scipy 문서상 표본 5000건까지만 정확하고, 그 이상에서는 아주 작은
    이탈에도 귀무가설을 기각한다. 여기서는 두 집단 모두 5000건을 넘으므로
    무작위 부분표본으로 검정하고, 왜도·첨도를 함께 본다.

    다만 표본이 수만 건이면 중심극한정리에 의해 '표본평균의 분포'가 정규에 가까워진다.
    t-test가 가정하는 것은 원자료가 아니라 표본평균의 분포이므로, 원자료가 다소
    비대칭이더라도 평균 비교의 타당성은 크게 흔들리지 않는다. 이 점을 함께 기록한다.
    """
    sample_size = min(len(values), SHAPIRO_MAX_SAMPLES)
    subsample = values.sample(sample_size, random_state=RANDOM_STATE)

    statistic, p_value = shapiro(subsample)
    skewness = float(skew(values))
    kurt = float(kurtosis(values))
    normal = p_value >= ALPHA

    logger.info(
        f"  {group_name:<12} n={len(values):>7,} → 부분표본 {sample_size:,}건 검정  "
        f"W={statistic:.4f}  p={format_p_value(p_value)}  "
        f"왜도={skewness:+.3f}  첨도={kurt:+.3f}  "
        f"→ {'정규성 기각 못 함' if normal else '정규성 기각'}"
    )

    return {
        "group": group_name,
        "n": len(values),
        "sample_size": sample_size,
        "statistic": float(statistic),
        "p_value": float(p_value),
        "skewness": skewness,
        "kurtosis": kurt,
        "normal": bool(normal),
    }


def check_equal_variance(
    group_a: pd.Series, group_b: pd.Series,
    label_a: str = "집단 A", label_b: str = "집단 B",
) -> dict[str, Any]:
    """
    Levene 검정으로 등분산성을 확인한다.

    Levene을 쓰는 이유는 Bartlett 검정과 달리 정규성 가정에 덜 민감해서다.
    이 데이터의 근로시간은 40시간에 몰려 있는 비대칭 분포라 Bartlett은 적절하지 않다.

    검정 결과가 t-test의 equal_var 인자를 그대로 결정한다.
    등분산이 기각되면 Welch's t-test(equal_var=False)를 써야 한다.
    """
    statistic, p_value = levene(group_a, group_b, center="median")
    equal_variance = p_value >= ALPHA

    logger.info("\n[등분산성 검정: Levene's test]")
    logger.info("  H0 : 두 집단의 분산은 같다.")
    logger.info(f"  통계량 W = {statistic:.6f}  /  p-value = {format_p_value(p_value)}")
    logger.info(f"  표준편차 : {label_a}={group_a.std():.4f} / {label_b}={group_b.std():.4f}")
    logger.info(
        f"  → p-value가 {ALPHA:.2f} "
        f"{'이상이므로 등분산을 기각하지 못합니다' if equal_variance else '미만이므로 등분산이 기각됩니다'}."
    )

    return {
        "statistic": float(statistic),
        "p_value": float(p_value),
        "equal_variance": bool(equal_variance),
    }


def compute_cohens_d(group_a: pd.Series, group_b: pd.Series) -> float:
    """
    두 집단 평균 차이의 효과크기(Cohen's d)를 계산한다.

    합동 표준편차로 평균 차이를 나눈 값이라 표본 크기가 커져도 값이 커지지 않는다.
    p-value가 '차이의 존재'를 말한다면 d는 '차이의 크기'를 말한다.
    """
    n_a, n_b = len(group_a), len(group_b)
    variance_a, variance_b = group_a.var(ddof=1), group_b.var(ddof=1)
    pooled_std = np.sqrt(((n_a - 1) * variance_a + (n_b - 1) * variance_b) / (n_a + n_b - 2))

    if pooled_std == 0:
        raise ValueError("두 집단의 분산이 모두 0이라 효과크기를 계산할 수 없습니다.")

    return float((group_a.mean() - group_b.mean()) / pooled_std)


def interpret_effect_size(cohens_d: float) -> str:
    """Cohen(1988)의 관례적 기준으로 효과크기를 해석한다."""
    magnitude = abs(cohens_d)
    if magnitude < 0.2:
        return "매우 작음"
    if magnitude < 0.5:
        return "작음"
    if magnitude < 0.8:
        return "중간"
    return "큼"


def perform_t_test(dataframe: pd.DataFrame) -> dict[str, Any]:
    """
    두 소득 집단의 주당 근로시간 평균 차이를 검정한다.

    바로 t-test로 가지 않고 가정부터 확인한다.
      1) 정규성  : Shapiro-Wilk(부분표본) + 왜도·첨도, 그리고 중심극한정리 검토
      2) 등분산성: Levene 검정
      3) 위 결과에 따라 equal_var 인자를 정해 ttest_ind 실행
    가정을 확인하지 않고 얻은 p-value는 해석의 근거가 약하기 때문이다.

    H0: 두 소득 집단의 평균 주당 근로시간은 같다.
    H1: 두 소득 집단의 평균 주당 근로시간은 다르다.
    """
    log_section("7. t-test: 소득 집단별 주당 근로시간 평균 비교")

    low_group = dataframe.loc[dataframe[TARGET_COLUMN] == NEGATIVE_LABEL, "hours-per-week"].dropna()
    high_group = dataframe.loc[dataframe[TARGET_COLUMN] == POSITIVE_LABEL, "hours-per-week"].dropna()

    for name, values in ((NEGATIVE_LABEL, low_group), (POSITIVE_LABEL, high_group)):
        if len(values) < 2:
            raise ValueError(f"t-test를 하려면 '{name}' 집단 데이터가 2개 이상 필요합니다.")

    logger.info("H0 : 두 소득 집단의 평균 주당 근로시간은 같다.")
    logger.info("H1 : 두 소득 집단의 평균 주당 근로시간은 다르다.")
    logger.info(
        f"\n{NEGATIVE_LABEL} 집단 : n = {len(low_group):,} / 평균 = {low_group.mean():.4f} "
        f"/ 표준편차 = {low_group.std():.4f}"
    )
    logger.info(
        f"{POSITIVE_LABEL} 집단 : n = {len(high_group):,} / 평균 = {high_group.mean():.4f} "
        f"/ 표준편차 = {high_group.std():.4f}"
    )

    # ── 가정 1: 정규성 ────────────────────────────────────────────────────
    logger.info("\n[정규성 검정: Shapiro-Wilk]")
    logger.info(
        f"  표본이 {SHAPIRO_MAX_SAMPLES:,}건을 넘으면 Shapiro-Wilk가 미세한 이탈에도 기각하므로,"
    )
    logger.info("  무작위 부분표본으로 검정하고 왜도·첨도를 함께 봅니다.")
    normality = {
        NEGATIVE_LABEL: check_normality(low_group, NEGATIVE_LABEL),
        POSITIVE_LABEL: check_normality(high_group, POSITIVE_LABEL),
    }

    both_normal = all(item["normal"] for item in normality.values())
    total_n = len(low_group) + len(high_group)
    logger.info(
        f"\n  두 집단 모두 정규성을 만족하지는 {'않습니다' if not both_normal else '합니다'}. "
        f"다만 표본이 {total_n:,}건으로 충분히 큽니다."
    )
    logger.info(
        "  t-test가 가정하는 것은 원자료가 아니라 '표본평균의 분포'이고,"
        "\n  중심극한정리에 따라 표본이 크면 원자료가 비대칭이어도 표본평균은 정규에 가까워집니다."
        "\n  따라서 평균 비교에는 t-test를 그대로 적용할 수 있다고 판단했습니다."
    )

    # ── 가정 2: 등분산성 ──────────────────────────────────────────────────
    variance_check = check_equal_variance(
        high_group, low_group, label_a=POSITIVE_LABEL, label_b=NEGATIVE_LABEL
    )
    equal_var = variance_check["equal_variance"]

    # ── 검정 실행 ─────────────────────────────────────────────────────────
    test_name = "Student's t-test" if equal_var else "Welch's t-test"
    logger.info(
        f"\n[검정 방법 결정] 등분산 {'성립' if equal_var else '기각'} "
        f"→ {test_name} (equal_var={equal_var})"
    )

    t_stat, p_value = ttest_ind(high_group, low_group, equal_var=equal_var)

    if not (np.isfinite(t_stat) and np.isfinite(p_value)):
        raise ValueError("t-test 결과가 유효하지 않습니다(집단 분산이 0인지 확인하세요).")

    # 표본이 3만 건이 넘으면 아주 작은 차이도 p-value가 작게 나온다.
    # p-value는 '차이가 있는지'만 알려주므로 '얼마나 큰지'는 효과크기로 따로 본다.
    mean_difference = float(high_group.mean() - low_group.mean())
    cohens_d = compute_cohens_d(high_group, low_group)
    effect_label = interpret_effect_size(cohens_d)

    logger.info(f"\nt-statistic : {t_stat:.6f}")
    logger.info(f"p-value     : {format_p_value(p_value)}")
    logger.info(f"평균 차이   : {mean_difference:.4f} 시간/주")
    logger.info(f"Cohen's d   : {cohens_d:.4f} ({effect_label})")

    if p_value < ALPHA:
        interpretation = (
            f"p-value가 유의수준 {ALPHA:.2f}보다 작으므로 귀무가설(H0)을 기각합니다. "
            "두 소득 집단의 평균 주당 근로시간에는 통계적으로 유의한 차이가 있습니다. "
            f"다만 표본이 {total_n:,}건으로 매우 크면 작은 차이도 유의하게 나오므로 "
            f"차이의 크기까지 함께 보아야 합니다. 실제 차이는 {mean_difference:.2f}시간/주이고 "
            f"Cohen's d는 {cohens_d:.3f}({effect_label})입니다. "
            "또한 이는 '차이가 있다'는 의미일 뿐, 근로시간이 고소득의 원인이라는 뜻은 아닙니다."
        )
    else:
        interpretation = (
            f"p-value가 유의수준 {ALPHA:.2f} 이상이므로 귀무가설(H0)을 기각할 근거가 부족합니다. "
            "두 집단의 평균 근로시간 차이를 통계적으로 확인하지 못했습니다."
        )

    logger.info(f"해석        : {interpretation}")

    return {
        "low_n": len(low_group),
        "high_n": len(high_group),
        "low_mean": float(low_group.mean()),
        "high_mean": float(high_group.mean()),
        "low_std": float(low_group.std()),
        "high_std": float(high_group.std()),
        "t_stat": float(t_stat),
        "p_value": float(p_value),
        "mean_difference": mean_difference,
        "cohens_d": cohens_d,
        "effect_label": effect_label,
        "interpretation": interpretation,
        "normality": normality,
        "variance_check": variance_check,
        "equal_var": equal_var,
        "test_name": test_name,
    }
