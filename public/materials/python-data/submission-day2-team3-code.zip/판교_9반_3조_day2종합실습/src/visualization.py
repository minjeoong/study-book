"""
차트 생성.

Seaborn 정적 차트 4종과 Plotly 인터랙티브 차트 1종을 만든다.
모든 그림에 제목과 x·y축 레이블을 넣는다(채점 항목).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.express as px
import seaborn as sns
from matplotlib import font_manager
from matplotlib import pyplot as plt

from config import (
    AGE_PNG,
    CATEGORICAL_PNG,
    COLOR_HIGH,
    COLOR_LOW,
    CORRELATION_PNG,
    DISPLAY_LABELS,
    DIVERGING_CMAP,
    EDUCATION_HTML,
    EVALUATION_PNG,
    FIGURE_DIR,
    GRID,
    INCOME_PNG,
    INK,
    INK_MUTED,
    INK_SOFT,
    NEGATIVE_LABEL,
    POSITIVE_LABEL,
    SEQUENTIAL_CMAP,
    SURFACE,
    TARGET_COLUMN,
    THRESHOLD_PNG,
)
from logging_setup import log_section, logger


def configure_chart_theme() -> None:
    """차트 배경·격자·글자색을 한 번에 지정한다(차트마다 반복 설정하지 않기 위함)."""
    sns.set_theme(style="white")
    plt.rcParams.update({
        "axes.unicode_minus": False,
        "figure.facecolor": SURFACE,
        "axes.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "axes.grid": True,
        "axes.grid.axis": "y",
        "grid.color": GRID,
        "grid.linewidth": 0.8,
        "axes.axisbelow": True,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.edgecolor": "#c3c2b7",
        "axes.labelcolor": INK_SOFT,
        "text.color": INK,
        "xtick.color": INK_MUTED,
        "ytick.color": INK_MUTED,
        "axes.titlesize": 15,
        "axes.labelsize": 12,
        "legend.frameon": False,
    })


def configure_korean_font() -> None:
    """
    운영체제에 깔린 한글 폰트를 찾아 Matplotlib에 적용한다.

    폰트를 못 찾아도 실행을 멈추지는 않는다. 차트의 한글이 네모로 깨질 뿐 수치와
    분석 결과는 그대로 나오기 때문이다. 대신 경고를 남겨서 캡처를 뜨기 전에 알아채게 한다.
    """
    installed = {font.name for font in font_manager.fontManager.ttflist}

    for font_name in ("AppleGothic", "Malgun Gothic", "NanumGothic"):
        if font_name in installed:
            plt.rcParams["font.family"] = font_name
            logger.debug(f"한글 폰트 적용: {font_name}")
            return

    logger.warning(
        "[경고] 한글 폰트를 찾지 못했습니다. 차트의 한글이 깨져 보이면 "
        "AppleGothic·맑은 고딕·나눔고딕 중 하나를 설치한 뒤 다시 실행하세요."
    )


def create_seaborn_plots(dataframe: pd.DataFrame) -> None:
    """소득 클래스 분포와 소득별 나이 분포를 Seaborn 정적 차트로 저장한다."""
    log_section("8. Seaborn 정적 차트 생성")

    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    palette = {NEGATIVE_LABEL: COLOR_LOW, POSITIVE_LABEL: COLOR_HIGH}
    order = [NEGATIVE_LABEL, POSITIVE_LABEL]

    # ── 1: 소득 클래스 분포 ───────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(8, 5.5))
    sns.countplot(
        data=dataframe, x=TARGET_COLUMN, order=order,
        hue=TARGET_COLUMN, palette=palette, legend=False, width=0.55, ax=ax,
    )
    total = len(dataframe)
    # 막대 위에 건수와 비율을 함께 적어 클래스 불균형 정도가 바로 읽히게 한다.
    for patch, label in zip(ax.patches, order):
        count = int(patch.get_height())
        ax.annotate(
            f"{count:,}건 ({count / total:.1%})",
            xy=(patch.get_x() + patch.get_width() / 2, count),
            xytext=(0, 6), textcoords="offset points",
            ha="center", color=INK, fontsize=12,
        )
    ax.margins(y=0.15)
    ax.set_title("소득 클래스 분포 (저소득 집단이 약 3배 많음)", loc="left", color=INK)
    ax.set_xlabel("연간 소득 구간 (income)")
    ax.set_ylabel("응답자 수 (명)")
    # 한글 폰트에 '<'·'>' 글리프가 없어 깨지므로 눈금 이름만 한글 표기로 바꾼다.
    ax.set_xticks(range(len(order)))
    ax.set_xticklabels([DISPLAY_LABELS[label] for label in order])
    fig.tight_layout()
    fig.savefig(INCOME_PNG, dpi=200, facecolor=SURFACE)
    plt.close(fig)
    logger.info(f"[저장 완료] {INCOME_PNG.name}")

    # ── 2: 소득별 나이 분포 ───────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(9, 5.5))
    sns.histplot(
        data=dataframe, x="age", hue=TARGET_COLUMN, hue_order=order,
        palette=palette, bins=40, element="step",
        # 두 집단의 표본 수 차이가 크므로 density로 각 분포의 모양을 비교한다.
        stat="density", common_norm=False, alpha=0.35, ax=ax,
    )
    # 평균선 주석이 히스토그램 마루와 겹치지 않도록 y축 위쪽 여백을 먼저 확보한다.
    ax.margins(y=0.18)
    for label, color in palette.items():
        mean_age = dataframe.loc[dataframe[TARGET_COLUMN] == label, "age"].mean()
        ax.axvline(mean_age, color=color, linewidth=1.4, linestyle="--")
        ax.annotate(
            f"{DISPLAY_LABELS[label]} 평균 {mean_age:.1f}세",
            xy=(mean_age, ax.get_ylim()[1]),
            xytext=(6, -16 if label == NEGATIVE_LABEL else -34),
            textcoords="offset points", color=color, fontsize=11,
            bbox={"facecolor": SURFACE, "edgecolor": "none", "pad": 1.5},
        )
    ax.set_title("소득 집단별 나이 분포 (고소득 집단은 중년층에 몰려 있음)", loc="left", color=INK)
    ax.set_xlabel("나이 (세)")
    ax.set_ylabel("상대 밀도 (집단별 정규화)")
    legend = ax.get_legend()
    if legend is not None:
        legend.set_title("소득 구간")
        for text, label in zip(legend.get_texts(), order):
            text.set_text(DISPLAY_LABELS[label])
    fig.tight_layout()
    fig.savefig(AGE_PNG, dpi=200, facecolor=SURFACE)
    plt.close(fig)
    logger.info(f"[저장 완료] {AGE_PNG.name}")


def save_correlation_heatmap(correlation: pd.DataFrame) -> None:
    """상관계수 행렬을 Seaborn 히트맵으로 저장한다(숫자 표만으로는 크기 비교가 어렵다)."""
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    korean_labels = {
        "age": "나이",
        "education-num": "교육 연수",
        "capital-gain": "자본 이득",
        "capital-loss": "자본 손실",
        "hours-per-week": "주당 근로시간",
        "income_binary": "고소득 여부",
    }
    labeled = correlation.rename(index=korean_labels, columns=korean_labels)

    # 대칭 행렬이라 위쪽 절반은 같은 정보의 반복이다.
    # 아래 삼각형만 남기고, 전부 가려지는 첫 행·마지막 열은 잘라 빈 칸을 없앤다.
    lower_triangle = labeled.iloc[1:, :-1]
    upper_mask = np.triu(np.ones_like(lower_triangle, dtype=bool), k=1)

    fig, ax = plt.subplots(figsize=(8.5, 6.5))
    sns.heatmap(
        lower_triangle, mask=upper_mask, annot=True, fmt=".3f",
        cmap=DIVERGING_CMAP, vmin=-1, vmax=1, center=0,  # 무상관(0)을 중립색에 고정한다.
        linewidths=2, linecolor=SURFACE, annot_kws={"fontsize": 11},
        cbar_kws={"shrink": 0.7, "ticks": [-1, -0.5, 0, 0.5, 1]}, ax=ax,
    )
    ax.set_title(
        "수치형 변수 상관계수 (고소득 여부와 가장 관련이 큰 변수는 교육 연수)",
        loc="left", color=INK,
    )
    ax.set_xlabel("변수")
    ax.set_ylabel("변수")
    ax.tick_params(axis="both", rotation=0, length=0)
    ax.grid(False)
    # bbox_inches="tight"로 세로로 세운 y축 이름이 잘리지 않게 여백을 다시 계산한다.
    fig.tight_layout(pad=1.5)
    fig.savefig(CORRELATION_PNG, dpi=200, facecolor=SURFACE, bbox_inches="tight")
    plt.close(fig)

    logger.info(f"\n[저장 완료] {CORRELATION_PNG.name}")


def save_categorical_association_chart(association: pd.DataFrame) -> None:
    """
    범주형 변수와 income의 연관 강도(Cramér's V)를 가로 막대로 저장한다.

    카이제곱 p-value는 표본이 크면 전부 0에 가까워져 변수 간 비교에 쓸 수 없다.
    그래서 강도를 나타내는 Cramér's V를 크기순으로 세워 어느 변수가 실제로
    소득과 관련이 큰지 한눈에 보이게 한다.
    """
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    ordered = association.sort_values("Cramers_V")
    colors = [SEQUENTIAL_CMAP(value / max(ordered["Cramers_V"].max(), 1e-9))
              for value in ordered["Cramers_V"]]

    fig, ax = plt.subplots(figsize=(9.5, 5.8))
    bars = ax.barh(ordered["변수"], ordered["Cramers_V"], color=colors, height=0.68)

    for bar, value, strength in zip(bars, ordered["Cramers_V"], ordered["연관 강도"]):
        ax.annotate(
            f"{value:.3f} ({strength})",
            xy=(value, bar.get_y() + bar.get_height() / 2),
            xytext=(6, 0), textcoords="offset points",
            va="center", color=INK_SOFT, fontsize=10.5,
        )

    ax.set_xlim(0, ordered["Cramers_V"].max() * 1.32)
    # 한글 폰트에 'é' 글리프가 없어 두부(□)로 깨지므로, 그림 안에서는 악센트 없이 쓴다.
    # 보고서(report.md)와 터미널 출력은 폰트 제약이 없어 Cramér's V 그대로 표기한다.
    ax.set_title(
        "범주형 변수와 소득의 연관 강도 (Cramer's V)", loc="left", color=INK,
    )
    ax.set_xlabel("Cramer's V (0 = 무관, 1 = 완전 연관)")
    ax.set_ylabel("범주형 변수")
    ax.grid(axis="x", color=GRID, linewidth=0.8)
    ax.grid(axis="y", visible=False)
    fig.tight_layout(pad=1.2)
    fig.savefig(CATEGORICAL_PNG, dpi=200, facecolor=SURFACE, bbox_inches="tight")
    plt.close(fig)

    logger.info(f"[저장 완료] {CATEGORICAL_PNG.name}")


def create_plotly_chart(dataframe: pd.DataFrame) -> None:
    """교육 수준별 고소득(>50K) 비율을 Plotly 인터랙티브 막대 차트로 저장한다."""
    log_section("9. Plotly 인터랙티브 차트 생성")

    FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    # 교육 수준은 education-num이 곧 서열이므로 그 순서대로 x축을 세운다.
    summary = (
        dataframe.assign(is_high=(dataframe[TARGET_COLUMN] == POSITIVE_LABEL).astype(int))
        .groupby(["education-num", "education"], as_index=False)
        .agg(고소득비율=("is_high", "mean"), 인원수=("is_high", "size"))
        .sort_values("education-num")
    )
    summary["고소득비율(%)"] = summary["고소득비율"] * 100

    figure = px.bar(
        summary,
        x="education", y="고소득비율(%)",
        color="고소득비율(%)",
        color_continuous_scale=["#c9dcf5", COLOR_HIGH],
        custom_data=["education-num", "인원수"],
        template="plotly_white",
    )
    figure.update_traces(
        hovertemplate=(
            "<b>%{x}</b> (education-num %{customdata[0]})<br>"
            "고소득 비율 %{y:.1f}%<br>표본 %{customdata[1]:,}명<extra></extra>"
        )
    )
    figure.update_layout(
        title={
            "text": (
                "교육 수준별 고소득(&gt;50K) 비율"
                f"<br><sup style='color:{INK_SOFT}'>UCI Adult Census Income · "
                f"정제 후 {len(dataframe):,}건 · 막대에 마우스를 올리면 표본 수가 표시됩니다</sup>"
            ),
            "x": 0.02, "font": {"size": 20, "color": INK},
        },
        xaxis={"title": "교육 수준 (education, 낮은 학력 → 높은 학력 순)",
               "categoryorder": "array", "categoryarray": summary["education"].tolist()},
        yaxis={"title": "고소득(>50K) 비율 (%)", "gridcolor": GRID},
        font={"family": "AppleGothic, Malgun Gothic, NanumGothic, sans-serif",
              "size": 13, "color": INK_SOFT},
        coloraxis_showscale=False,
        paper_bgcolor=SURFACE, plot_bgcolor=SURFACE,
        margin={"l": 70, "r": 40, "t": 110, "b": 120}, height=620,
    )

    # show()가 아니라 write_html로 저장해야 제출용 산출물이 파일로 남는다.
    figure.write_html(
        EDUCATION_HTML, include_plotlyjs=True, full_html=True,
        config={"responsive": True, "displaylogo": False},
    )

    if not EDUCATION_HTML.exists() or EDUCATION_HTML.stat().st_size == 0:
        raise OSError(f"Plotly HTML 저장에 실패했습니다: {EDUCATION_HTML}")

    logger.info(f"[저장 완료] {EDUCATION_HTML.name}")
    logger.info("브라우저에서 열어 hover tooltip이 보이는 화면을 캡처하세요.")


def save_evaluation_figure(
    matrix: np.ndarray,
    y_test: pd.Series,
    probabilities: np.ndarray,
    roc_auc: float,
) -> None:
    """Confusion Matrix와 ROC 곡선을 한 Figure에 저장한다."""
    from sklearn.metrics import roc_curve

    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    fig, (ax_matrix, ax_roc) = plt.subplots(1, 2, figsize=(14, 5.8))

    labels = [DISPLAY_LABELS[NEGATIVE_LABEL], DISPLAY_LABELS[POSITIVE_LABEL]]
    sns.heatmap(
        matrix, annot=True, fmt=",d", cmap="Blues", cbar=False,
        xticklabels=[f"예측 {label}" for label in labels],
        yticklabels=[f"실제 {label}" for label in labels],
        linewidths=2, linecolor=SURFACE, annot_kws={"fontsize": 14}, ax=ax_matrix,
    )
    ax_matrix.set_title(
        "Confusion Matrix (고소득자를 놓친 경우가 왼쪽 아래에 몰려 있음)", loc="left", color=INK
    )
    ax_matrix.set_xlabel("예측 클래스")
    ax_matrix.set_ylabel("실제 클래스")
    ax_matrix.tick_params(axis="both", rotation=0, length=0)
    ax_matrix.grid(False)

    false_positive_rate, true_positive_rate, _ = roc_curve(y_test, probabilities)
    ax_roc.plot(
        false_positive_rate, true_positive_rate,
        color=COLOR_HIGH, linewidth=2, label=f"ROC 곡선 (AUC = {roc_auc:.4f})",
    )
    # 무작위 분류기(AUC 0.5) 기준선을 함께 그려야 곡선의 개선 정도가 읽힌다.
    ax_roc.plot([0, 1], [0, 1], color=INK_MUTED, linewidth=1, linestyle="--",
                label="무작위 분류 (AUC = 0.5)")
    ax_roc.set_xlim(0, 1)
    ax_roc.set_ylim(0, 1.02)
    ax_roc.set_title("ROC 곡선 (임계값을 바꿔 가며 본 분류 성능)", loc="left", color=INK)
    ax_roc.set_xlabel("거짓 양성 비율 (False Positive Rate)")
    ax_roc.set_ylabel("참 양성 비율 (True Positive Rate)")
    ax_roc.legend(loc="lower right", fontsize=11)

    # pad를 두지 않으면 세로로 세운 y축 이름이 그림 왼쪽 끝에서 잘린다.
    fig.tight_layout(pad=1.8)
    fig.savefig(EVALUATION_PNG, dpi=200, facecolor=SURFACE)
    plt.close(fig)

    logger.info(f"\n[저장 완료] {EVALUATION_PNG.name}")


def save_threshold_figure(curve: pd.DataFrame, best_threshold: float) -> None:
    """임계값에 따른 Precision·Recall·F1 변화를 한 그림으로 저장한다."""
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(9.5, 5.8))
    for column, color, label in (
        ("precision", COLOR_LOW, "Precision (고소득이라 예측한 것 중 맞은 비율)"),
        ("recall", COLOR_HIGH, "Recall (실제 고소득자 중 찾아낸 비율)"),
        ("f1", INK, "F1 (둘의 조화평균)"),
    ):
        ax.plot(curve["threshold"], curve[column], color=color, linewidth=2, label=label)

    # 기본값 0.5와 F1이 가장 높은 임계값을 함께 표시해 둘의 차이를 보여 준다.
    for value, color, text in (
        (0.5, INK_MUTED, "기본값 0.50"),
        (best_threshold, "#008300", f"F1 최대 {best_threshold:.2f}"),
    ):
        ax.axvline(value, color=color, linewidth=1.2, linestyle="--")
        ax.annotate(
            text, xy=(value, 1.0), xytext=(5, -12), textcoords="offset points",
            color=color, fontsize=11,
            bbox={"facecolor": SURFACE, "edgecolor": "none", "pad": 1.5},
        )

    ax.set_xlim(0.05, 0.95)
    ax.set_ylim(0, 1.05)
    ax.set_title(
        "판정 임계값에 따른 성능 변화 (Precision과 Recall은 한쪽을 얻으면 한쪽을 잃음)",
        loc="left", color=INK,
    )
    ax.set_xlabel("판정 임계값 (이 확률 이상이면 고소득으로 예측)")
    ax.set_ylabel("지표 값")
    ax.legend(loc="lower left", fontsize=10)
    fig.tight_layout(pad=1.5)
    fig.savefig(THRESHOLD_PNG, dpi=200, facecolor=SURFACE)
    plt.close(fig)

    logger.info(f"[저장 완료] {THRESHOLD_PNG.name}")
