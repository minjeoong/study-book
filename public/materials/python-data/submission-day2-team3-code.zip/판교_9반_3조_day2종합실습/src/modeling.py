"""
머신러닝 Pipeline.

전처리와 모델을 하나의 Pipeline 객체로 묶어 학습·평가·저장한다.
클래스 불균형(약 3:1)을 기본 모델 단계에서부터 다루고, 심화 단계에서 추가로 비교한다.
"""

from __future__ import annotations

from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_validate, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from config import (
    AGE_BIN_EDGES,
    AGE_BIN_LABELS,
    BALANCED_MODEL_PATH,
    CATEGORICAL_FEATURES,
    CV_FOLDS,
    ENGINEERED_CATEGORICAL_FEATURES,
    ENGINEERED_NUMERIC_FEATURES,
    FEATURE_COLUMNS,
    MIN_SAMPLES_FOR_COEFFICIENT,
    MODEL_DIR,
    MODEL_PATH,
    NEGATIVE_LABEL,
    NUMERIC_FEATURES,
    POSITIVE_LABEL,
    RANDOM_STATE,
    TARGET_COLUMN,
    TEST_SIZE,
    UNKNOWN_CATEGORY,
)
from logging_setup import log_section, logger
from visualization import save_evaluation_figure, save_threshold_figure


def build_pipeline(class_weight: str | None = None) -> Pipeline:
    """
    ColumnTransformer로 수치형·범주형 전처리를 나누고 LogisticRegression과 묶는다.

    class_weight를 인자로 받는 이유는 불균형 대응 모델을 같은 코드로 만들기 위해서다.
    구조가 동일해야 두 모델의 성능 차이를 '가중치 때문'이라고 말할 수 있다.
    """
    numeric_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        # 로지스틱 회귀는 변수 스케일에 민감하고 수렴 속도에도 영향을 받으므로 표준화한다.
        ("scaler", StandardScaler()),
    ])
    categorical_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        # handle_unknown="ignore": 학습에 없던 범주가 들어와도 예측이 실패하지 않는다.
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, NUMERIC_FEATURES),
            ("categorical", categorical_pipeline, CATEGORICAL_FEATURES),
        ],
        remainder="drop",
    )

    return Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("model", LogisticRegression(
            max_iter=1000, random_state=RANDOM_STATE, class_weight=class_weight
        )),
    ])


def train_machine_learning_pipeline(dataframe: pd.DataFrame) -> dict[str, Any]:
    """
    Pipeline을 학습·평가하고 전처리를 포함한 전체 객체를 joblib으로 저장한다.

    불균형 데이터라서 두 모델을 함께 학습한다.
      - 기본 모델          : class_weight 없음. 비교 기준선
      - 불균형 대응 모델   : class_weight="balanced". 소수 클래스에 가중치를 준다
    둘을 같은 분할에서 평가해야 가중치의 효과를 분리해서 볼 수 있다.
    """
    log_section("10. Machine Learning Pipeline: 학습 · 평가 · 저장")

    features = dataframe[FEATURE_COLUMNS]
    target = (dataframe[TARGET_COLUMN] == POSITIVE_LABEL).astype(int)

    if target.isna().any():
        raise ValueError("목표 변수에 결측이 남아 있습니다.")

    # stratify=target: 클래스 비율이 약 3:1이므로 학습·평가 세트의 비율을 동일하게 유지한다.
    X_train, X_test, y_train, y_test = train_test_split(
        features, target, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=target
    )
    logger.info(f"학습 데이터 수 : {len(X_train):,} / 평가 데이터 수 : {len(X_test):,}")
    logger.info(
        f"학습 세트 클래스 비율 : {NEGATIVE_LABEL} {(y_train == 0).mean():.2%} / "
        f"{POSITIVE_LABEL} {(y_train == 1).mean():.2%}"
    )

    # ── 기본 모델 ─────────────────────────────────────────────────────────
    pipeline = build_pipeline()
    pipeline.fit(X_train, y_train)
    predictions = pipeline.predict(X_test)
    probabilities = pipeline.predict_proba(X_test)[:, 1]

    metrics = _score(y_test, predictions, probabilities)
    matrix = confusion_matrix(y_test, predictions)
    report_text = classification_report(
        y_test, predictions, target_names=[NEGATIVE_LABEL, POSITIVE_LABEL], digits=4
    )

    logger.info("\n[기본 모델] LogisticRegression (class_weight 없음)")
    _log_metrics(metrics)
    logger.info("\n[Classification Report]")
    logger.info(report_text)
    logger.info("[Confusion Matrix]  행=실제, 열=예측")
    logger.info(pd.DataFrame(
        matrix,
        index=[f"실제 {NEGATIVE_LABEL}", f"실제 {POSITIVE_LABEL}"],
        columns=[f"예측 {NEGATIVE_LABEL}", f"예측 {POSITIVE_LABEL}"],
    ).to_string())

    # ── 불균형 대응 모델 ──────────────────────────────────────────────────
    logger.info("\n[불균형 대응] class_weight='balanced' 적용 모델을 같은 분할로 학습합니다.")
    logger.info("소수 클래스(>50K)의 오분류에 더 큰 벌점을 주어 Recall을 끌어올리는 방식입니다.")
    balanced_pipeline = build_pipeline(class_weight="balanced")
    balanced_pipeline.fit(X_train, y_train)
    balanced_predictions = balanced_pipeline.predict(X_test)
    balanced_probabilities = balanced_pipeline.predict_proba(X_test)[:, 1]
    balanced_metrics = _score(y_test, balanced_predictions, balanced_probabilities)

    logger.info("\n[불균형 대응 모델] LogisticRegression(class_weight='balanced')")
    _log_metrics(balanced_metrics)
    logger.info(
        f"\n기본 대비 Recall {metrics['recall']:.4f} → {balanced_metrics['recall']:.4f} "
        f"({balanced_metrics['recall'] - metrics['recall']:+.4f}), "
        f"Precision {metrics['precision']:.4f} → {balanced_metrics['precision']:.4f} "
        f"({balanced_metrics['precision'] - metrics['precision']:+.4f})"
    )

    # ── 교차검증 ──────────────────────────────────────────────────────────
    # 한 번의 분할 결과가 우연인지 확인하기 위해 층화 5-겹 교차검증을 함께 수행한다.
    cv_scores = cross_validate(
        build_pipeline(),
        features, target,
        cv=StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE),
        scoring=("accuracy", "f1", "roc_auc"),
        n_jobs=-1,
    )
    cv_summary = {
        name: (float(cv_scores[f"test_{name}"].mean()), float(cv_scores[f"test_{name}"].std()))
        for name in ("accuracy", "f1", "roc_auc")
    }
    logger.info(f"\n[{CV_FOLDS}-겹 교차검증: 평균 ± 표준편차]")
    for name, (mean_score, std_score) in cv_summary.items():
        logger.info(f"{name:<9}: {mean_score:.4f} ± {std_score:.4f}")

    top_coefficients = summarize_coefficients(pipeline, X_train)
    save_evaluation_figure(matrix, y_test, probabilities, metrics["roc_auc"])

    # ── 저장 ──────────────────────────────────────────────────────────────
    # 전처리 + 모델 전체 Pipeline을 저장해야 예측 시 같은 전처리가 그대로 재현된다.
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, MODEL_PATH)
    joblib.dump(balanced_pipeline, BALANCED_MODEL_PATH)

    for path in (MODEL_PATH, BALANCED_MODEL_PATH):
        if not path.exists() or path.stat().st_size == 0:
            raise OSError(f"모델 저장에 실패했습니다: {path}")
        logger.info(f"\n[저장 완료] {path.name} ({path.stat().st_size:,} bytes)")

    # 재로딩 후 예측이 같아야 전처리까지 온전히 직렬화된 것이다.
    loaded = joblib.load(MODEL_PATH)
    if not np.array_equal(predictions, loaded.predict(X_test)):
        raise AssertionError("저장 전과 재로딩 후 예측 결과가 일치하지 않습니다.")
    logger.info("[재로딩 검증 완료] 저장 전과 재로딩 후 예측 결과가 일치합니다.")

    return {
        **metrics,
        "balanced_metrics": balanced_metrics,
        "train_rows": len(X_train),
        "test_rows": len(X_test),
        "confusion_matrix": matrix.tolist(),
        "classification_report": report_text,
        "cv_summary": cv_summary,
        "top_coefficients": top_coefficients,
        "model_path": MODEL_PATH,
    }


def _score(y_true: pd.Series, predictions: np.ndarray, probabilities: np.ndarray) -> dict[str, float]:
    """평가 지표 묶음을 한 번에 계산한다(여러 모델에 같은 기준을 적용하기 위함)."""
    return {
        "accuracy": accuracy_score(y_true, predictions),
        "precision": precision_score(y_true, predictions, zero_division=0),
        "recall": recall_score(y_true, predictions),
        "f1": f1_score(y_true, predictions),
        "roc_auc": roc_auc_score(y_true, probabilities),
    }


def _log_metrics(metrics: dict[str, float]) -> None:
    """평가 지표를 일정한 순서로 찍는다."""
    logger.info(f"Accuracy  : {metrics['accuracy']:.4f}")
    logger.info(f"F1 Score  : {metrics['f1']:.4f}")
    logger.info(f"Precision : {metrics['precision']:.4f}")
    logger.info(f"Recall    : {metrics['recall']:.4f}")
    logger.info(f"ROC-AUC   : {metrics['roc_auc']:.4f}")


def count_training_samples(feature_name: str, X_train: pd.DataFrame) -> int:
    """원-핫 특성 이름에 해당하는 학습 표본 수를 센다."""
    if not feature_name.startswith("categorical__"):
        return len(X_train)  # 수치형은 모든 행이 값을 가지므로 전체 표본 수다.

    body = feature_name.removeprefix("categorical__")
    for column in CATEGORICAL_FEATURES:
        if body.startswith(f"{column}_"):
            category = body.removeprefix(f"{column}_")
            return int((X_train[column] == category).sum())
    return 0


def summarize_coefficients(
    pipeline: Pipeline, X_train: pd.DataFrame
) -> dict[str, list[tuple[str, float, int]]]:
    """
    학습된 로지스틱 회귀의 계수를 표본 수와 함께 정리한다.

    표본이 적은 범주는 몇 건의 우연으로도 계수가 크게 흔들리므로(희소 범주 과적합),
    학습 표본이 기준 미만인 범주는 신뢰할 수 있는 순위에서 빼고 따로 보여 준다.
    """
    feature_names = pipeline.named_steps["preprocessor"].get_feature_names_out()
    coefficients = pipeline.named_steps["model"].coef_[0]

    entries = [
        (name, float(value), count_training_samples(name, X_train))
        for name, value in zip(feature_names, coefficients)
    ]
    reliable = sorted(
        (e for e in entries if e[2] >= MIN_SAMPLES_FOR_COEFFICIENT),
        key=lambda e: e[1], reverse=True,
    )
    # 표본이 적은데도 계수 절댓값이 큰 항목: '해석하면 안 되는 계수'의 예시로 보여 준다.
    unstable = sorted(
        (e for e in entries if e[2] < MIN_SAMPLES_FOR_COEFFICIENT),
        key=lambda e: abs(e[1]), reverse=True,
    )[:5]

    top_positive, top_negative = reliable[:5], reliable[-5:]

    logger.info(
        f"\n[고소득 확률을 높이는 방향 상위 5개, 학습 표본 {MIN_SAMPLES_FOR_COEFFICIENT}건 이상만]"
    )
    for name, value, count in top_positive:
        logger.info(f"  {value:+.4f}  (n={count:,})  {name}")
    logger.info(
        f"[고소득 확률을 낮추는 방향 상위 5개, 학습 표본 {MIN_SAMPLES_FOR_COEFFICIENT}건 이상만]"
    )
    for name, value, count in reversed(top_negative):
        logger.info(f"  {value:+.4f}  (n={count:,})  {name}")

    logger.info("\n[참고: 표본이 적어 계수가 불안정한 항목, 해석에서 제외]")
    for name, value, count in unstable:
        logger.info(f"  {value:+.4f}  (n={count:,})  {name}")

    return {"positive": top_positive, "negative": top_negative, "unstable": unstable}


# ---------------------------------------------------------------------------
# 심화 분석
# ---------------------------------------------------------------------------

def engineer_features(dataframe: pd.DataFrame) -> pd.DataFrame:
    """
    EDA에서 확인한 세 가지 패턴을 모델이 쓸 수 있는 형태로 바꾼다.

    1) 나이 → 연령대 구간: 소득은 46~55세에서 정점을 찍고 다시 낮아지는 곡선 관계라
       선형 계수 하나로는 표현되지 않는다. 구간으로 묶으면 각 구간이 독립된 가중치를 갖는다.
    2) 자본 이득·손실 → 발생 여부(0/1): 대부분이 0원인 희소 변수라 금액 자체보다
       '있었는가'가 더 안정적인 신호다. 원래 금액 컬럼도 함께 남긴다.
    3) 범주형 결측 → 'Unknown' 범주: 최빈값으로 덮으면 '응답하지 않았다'는 정보가 사라진다.
    """
    engineered = dataframe.copy()
    engineered["age-band"] = pd.cut(
        engineered["age"], bins=AGE_BIN_EDGES, labels=AGE_BIN_LABELS
    ).astype(str)
    engineered["has-capital-gain"] = (engineered["capital-gain"] > 0).astype(int)
    engineered["has-capital-loss"] = (engineered["capital-loss"] > 0).astype(int)
    return engineered


def build_engineered_pipeline(model: Any) -> Pipeline:
    """파생 변수를 쓰고 결측을 'Unknown' 범주로 남기는 Pipeline을 만든다."""
    numeric_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipeline = Pipeline(steps=[
        # strategy="constant": 결측을 최빈값으로 덮지 않고 별도 범주로 남긴다.
        ("imputer", SimpleImputer(strategy="constant", fill_value=UNKNOWN_CATEGORY)),
        # sparse_output=False: 트리 모델(HistGradientBoosting)이 희소 행렬을 받지 못한다.
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, ENGINEERED_NUMERIC_FEATURES),
            ("categorical", categorical_pipeline, ENGINEERED_CATEGORICAL_FEATURES),
        ],
        remainder="drop",
    )
    return Pipeline(steps=[("preprocessor", preprocessor), ("model", model)])


def evaluate_pipeline(
    pipeline: Pipeline, X_train: pd.DataFrame, X_test: pd.DataFrame,
    y_train: pd.Series, y_test: pd.Series,
) -> dict[str, float]:
    """Pipeline을 학습하고 동일한 평가 지표 묶음을 계산한다(모델 간 비교용)."""
    pipeline.fit(X_train, y_train)
    return _score(y_test, pipeline.predict(X_test), pipeline.predict_proba(X_test)[:, 1])


def run_advanced_analysis(dataframe: pd.DataFrame) -> dict[str, Any]:
    """
    기본 모델의 약점(고소득층 Recall)을 세 방향으로 개선해 보고 결과를 비교한다.

    ① 파생 변수 추가 + 결측을 Unknown 범주로
    ② 클래스 가중치 부여(class_weight="balanced")
    ③ 트리 기반 모델(HistGradientBoosting)
    마지막으로 기본 모델의 판정 임계값을 조정했을 때 Recall이 얼마나 회복되는지 확인한다.
    """
    log_section("11. 심화 분석: 파생변수, 모델 비교, 임계값 조정")

    engineered = engineer_features(dataframe)
    target = (engineered[TARGET_COLUMN] == POSITIVE_LABEL).astype(int)

    # 기본 모델과 같은 random_state·stratify를 써야 모델 간 비교가 공정하다.
    train_index, test_index = train_test_split(
        engineered.index, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=target
    )
    y_train, y_test = target.loc[train_index], target.loc[test_index]

    base_train = engineered.loc[train_index, FEATURE_COLUMNS]
    base_test = engineered.loc[test_index, FEATURE_COLUMNS]
    engineered_columns = ENGINEERED_NUMERIC_FEATURES + ENGINEERED_CATEGORICAL_FEATURES
    engineered_train = engineered.loc[train_index, engineered_columns]
    engineered_test = engineered.loc[test_index, engineered_columns]

    candidates = {
        "① 기본 (로지스틱 회귀)": (build_pipeline(), base_train, base_test),
        "② + 파생변수 · Unknown 범주": (
            build_engineered_pipeline(
                LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)
            ), engineered_train, engineered_test,
        ),
        "③ + class_weight=balanced": (
            build_engineered_pipeline(
                LogisticRegression(max_iter=1000, random_state=RANDOM_STATE,
                                   class_weight="balanced")
            ), engineered_train, engineered_test,
        ),
        "④ 트리 기반 (HistGradientBoosting)": (
            build_engineered_pipeline(
                HistGradientBoostingClassifier(random_state=RANDOM_STATE)
            ), engineered_train, engineered_test,
        ),
    }

    comparison: dict[str, dict[str, float]] = {}
    for name, (pipeline, X_train, X_test) in candidates.items():
        comparison[name] = evaluate_pipeline(pipeline, X_train, X_test, y_train, y_test)
        logger.info(f"[학습 완료] {name}")

    comparison_frame = pd.DataFrame(comparison).T
    logger.info("\n[모델 비교: 동일한 학습·평가 분할 기준]")
    logger.info(comparison_frame.to_string(float_format=lambda value: f"{value:.4f}"))

    best_f1_model = comparison_frame["f1"].idxmax()
    best_recall_model = comparison_frame["recall"].idxmax()
    logger.info(f"\nF1 최고    : {best_f1_model} ({comparison_frame.loc[best_f1_model, 'f1']:.4f})")
    logger.info(
        f"Recall 최고: {best_recall_model} ({comparison_frame.loc[best_recall_model, 'recall']:.4f})"
    )

    threshold = analyze_threshold(build_pipeline(), base_train, base_test, y_train, y_test)

    return {
        "comparison": comparison,
        "best_f1_model": best_f1_model,
        "best_recall_model": best_recall_model,
        "threshold": threshold,
    }


def analyze_threshold(
    pipeline: Pipeline, X_train: pd.DataFrame, X_test: pd.DataFrame,
    y_train: pd.Series, y_test: pd.Series,
) -> dict[str, Any]:
    """
    기본 모델의 판정 임계값을 0.05~0.95로 바꿔 가며 Precision·Recall·F1의 변화를 본다.

    predict()는 확률 0.5를 기준으로 잘라 판정하는데, 이 값은 통계적 근거가 있는 수치가
    아니라 단순 기본값이다. 클래스가 3:1로 불균형하면 0.5는 다수 클래스에 유리하게 작동한다.
    """
    pipeline.fit(X_train, y_train)
    probabilities = pipeline.predict_proba(X_test)[:, 1]

    rows = []
    for value in np.arange(0.05, 0.96, 0.01):
        predictions = (probabilities >= value).astype(int)
        rows.append({
            "threshold": float(value),
            "precision": precision_score(y_test, predictions, zero_division=0),
            "recall": recall_score(y_test, predictions),
            "f1": f1_score(y_test, predictions),
        })
    curve = pd.DataFrame(rows)

    best_row = curve.loc[curve["f1"].idxmax()]
    # 실제 고소득자의 80%를 잡으려면 정밀도를 얼마나 포기해야 하는지 확인한다.
    recall_80 = curve[curve["recall"] >= 0.80]
    recall_80_row = recall_80.iloc[-1] if not recall_80.empty else None

    logger.info("\n[임계값 조정: 기본 모델]")
    default_recall = curve.loc[curve["threshold"].sub(0.50).abs().idxmin(), "recall"]
    logger.info(f"기본값 0.50    : Recall {default_recall:.4f}")
    logger.info(
        f"F1 최대 임계값 : {best_row['threshold']:.2f} → F1 {best_row['f1']:.4f} / "
        f"Precision {best_row['precision']:.4f} / Recall {best_row['recall']:.4f}"
    )
    if recall_80_row is not None:
        logger.info(
            f"Recall 0.80 달성: 임계값 {recall_80_row['threshold']:.2f} → "
            f"Precision {recall_80_row['precision']:.4f} (정밀도를 그만큼 포기해야 함)"
        )

    save_threshold_figure(curve, float(best_row["threshold"]))

    return {
        "best_threshold": float(best_row["threshold"]),
        "best_f1": float(best_row["f1"]),
        "best_precision": float(best_row["precision"]),
        "best_recall": float(best_row["recall"]),
        "recall80_threshold": float(recall_80_row["threshold"]) if recall_80_row is not None else None,
        "recall80_precision": float(recall_80_row["precision"]) if recall_80_row is not None else None,
    }
