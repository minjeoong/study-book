"""
프로젝트 전역 설정.

경로·컬럼 목록·색상·상수를 이 파일 한 곳에서만 정의한다.
같은 값을 여러 모듈에 흩어 놓으면 한쪽만 고치고 다른 쪽을 놓치는 일이 생기기 때문이다.
"""

from __future__ import annotations

from pathlib import Path
from typing import Final

from matplotlib.colors import LinearSegmentedColormap

# ---------------------------------------------------------------------------
# 경로
# ---------------------------------------------------------------------------

# config.py는 src/ 안에 있으므로 부모의 부모가 프로젝트 루트다.
BASE_DIR: Final[Path] = Path(__file__).resolve().parent.parent

DATA_DIR: Final[Path] = BASE_DIR / "data" / "raw"
OUTPUT_DIR: Final[Path] = BASE_DIR / "outputs"
FIGURE_DIR: Final[Path] = OUTPUT_DIR / "figures"
MODEL_DIR: Final[Path] = OUTPUT_DIR / "model"
LOG_DIR: Final[Path] = OUTPUT_DIR / "logs"
CAPTURE_DIR: Final[Path] = BASE_DIR / "보고서용_캡쳐본"

RAW_DATA_PATH: Final[Path] = DATA_DIR / "adult.data"
LOG_PATH: Final[Path] = LOG_DIR / "run.log"
REPORT_PATH: Final[Path] = OUTPUT_DIR / "report.md"
MODEL_PATH: Final[Path] = MODEL_DIR / "adult_income_pipeline.joblib"
BALANCED_MODEL_PATH: Final[Path] = MODEL_DIR / "adult_income_pipeline_balanced.joblib"

DATA_URL: Final[str] = (
    "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data"
)

# 그림 파일 앞의 번호는 보고서에 실리는 순서와 같다.
# 파일 탐색기에서 정렬만 해도 순서가 맞아서 캡처를 뜰 때 헷갈리지 않는다.
INCOME_PNG: Final[Path] = FIGURE_DIR / "01_income_distribution.png"
AGE_PNG: Final[Path] = FIGURE_DIR / "02_age_by_income.png"
CORRELATION_PNG: Final[Path] = FIGURE_DIR / "03_correlation_heatmap.png"
CATEGORICAL_PNG: Final[Path] = FIGURE_DIR / "04_categorical_association.png"
EDUCATION_HTML: Final[Path] = FIGURE_DIR / "05_income_by_education.html"
EVALUATION_PNG: Final[Path] = FIGURE_DIR / "06_model_evaluation.png"
THRESHOLD_PNG: Final[Path] = FIGURE_DIR / "07_threshold_tradeoff.png"

# ---------------------------------------------------------------------------
# 데이터 스키마
# ---------------------------------------------------------------------------

# 원본 파일에는 헤더가 없어서 과제에서 지정한 컬럼명을 직접 부여한다.
COLUMNS: Final[list[str]] = [
    "age", "workclass", "fnlwgt", "education", "education-num",
    "marital-status", "occupation", "relationship", "race", "sex",
    "capital-gain", "capital-loss", "hours-per-week", "native-country", "income",
]

# Polars는 앞 공백 때문에 숫자 컬럼을 문자열로 추론한다. 읽은 뒤 직접 캐스팅할 대상.
POLARS_NUMERIC_COLUMNS: Final[list[str]] = [
    "age", "fnlwgt", "education-num", "capital-gain", "capital-loss", "hours-per-week",
]

TARGET_COLUMN: Final[str] = "income"
POSITIVE_LABEL: Final[str] = ">50K"
NEGATIVE_LABEL: Final[str] = "<=50K"

# 차트 표시용 이름.
# 한글 폰트(AppleGothic 등)에는 '<'와 '>' 글리프가 없어 '〈=50K'처럼 전각 괄호로 대체되어
# 깨져 보인다. 데이터 값은 원본을 그대로 두고, 그림에 그릴 때만 아래 이름을 쓴다.
DISPLAY_LABELS: Final[dict[str, str]] = {
    NEGATIVE_LABEL: "50K 이하",
    POSITIVE_LABEL: "50K 초과",
}

# 모델 입력 변수.
# fnlwgt는 인구 추정 가중치(표본 설계 값)이지 개인의 특성이 아니라서 제외한다.
NUMERIC_FEATURES: Final[list[str]] = [
    "age", "education-num", "capital-gain", "capital-loss", "hours-per-week",
]
CATEGORICAL_FEATURES: Final[list[str]] = [
    "workclass", "education", "marital-status", "occupation",
    "relationship", "race", "sex", "native-country",
]
FEATURE_COLUMNS: Final[list[str]] = NUMERIC_FEATURES + CATEGORICAL_FEATURES

# ---------------------------------------------------------------------------
# 분석 상수
# ---------------------------------------------------------------------------

ALPHA: Final[float] = 0.05
RANDOM_STATE: Final[int] = 42
TEST_SIZE: Final[float] = 0.20
CV_FOLDS: Final[int] = 5

# 이보다 학습 표본이 적은 범주의 계수는 몇 건의 우연으로도 크게 흔들려서 해석하지 않는다.
MIN_SAMPLES_FOR_COEFFICIENT: Final[int] = 100

# Shapiro-Wilk는 scipy에서 표본 5000건까지만 정확하다고 안내한다.
# 그 이상은 부분표본으로 검정하고, 전체 판단은 중심극한정리에 맡긴다.
SHAPIRO_MAX_SAMPLES: Final[int] = 5000

# 나이는 소득과 단조 증가가 아니라 중년에서 정점을 찍는 곡선 관계다.
# 선형 모델이 그 패턴을 잡을 수 있도록 연령대 구간으로 묶은 파생 변수를 만든다.
AGE_BIN_EDGES: Final[list[int]] = [16, 25, 35, 45, 55, 65, 100]
AGE_BIN_LABELS: Final[list[str]] = [
    "17-25세", "26-35세", "36-45세", "46-55세", "56-65세", "66세 이상",
]

# 결측을 최빈값으로 덮으면 '응답하지 않았다'는 정보 자체가 사라진다.
# 개선 모델에서는 별도 범주로 남겨 모델이 직접 판단하게 한다.
UNKNOWN_CATEGORY: Final[str] = "Unknown"

ENGINEERED_NUMERIC_FEATURES: Final[list[str]] = NUMERIC_FEATURES + [
    "has-capital-gain", "has-capital-loss",
]
ENGINEERED_CATEGORICAL_FEATURES: Final[list[str]] = CATEGORICAL_FEATURES + ["age-band"]

# ---------------------------------------------------------------------------
# 차트 색상
# ---------------------------------------------------------------------------

# 색맹 안전성이 확인된 팔레트에서 소득 두 계층에 고정 배정한다(순위가 바뀌어도 색은 유지).
COLOR_LOW: Final[str] = "#2a78d6"
COLOR_HIGH: Final[str] = "#eb6834"
INK: Final[str] = "#0b0b0b"
INK_SOFT: Final[str] = "#52514e"
INK_MUTED: Final[str] = "#898781"
SURFACE: Final[str] = "#fcfcfb"
GRID: Final[str] = "#e1e0d9"

# 상관계수는 부호가 있는 값이라 파랑↔빨강 발산형에 중립점 회색을 쓴다(무지개 금지).
DIVERGING_CMAP: Final = LinearSegmentedColormap.from_list(
    "blue_gray_red",
    ["#0d366b", "#256abf", "#86b6ef", "#f0efec", "#ea7170", "#d03b3b", "#7d1817"],
)

# Cramér's V는 0~1 사이의 연관 강도라서 단방향 순차 색상을 쓴다.
SEQUENTIAL_CMAP: Final = LinearSegmentedColormap.from_list(
    "warm_sequential", ["#f4f3f0", "#f6c6a8", COLOR_HIGH, "#8f3410"],
)
