# Adult Census Income 분석 보고서

- 과제: [종합 실습 2] Adult Census Income End-to-End 데이터 분석
- 소속: 판교 캠퍼스 9반 3조
- 팀원: 김명철, 김민정, 김진수, 정민성, 전진만 (가나다순)
- 자동 생성 일시: 2026-08-07 20:38:23
- 데이터 출처: https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data
- 생성 스크립트: `src/main.py`

> 이 문서는 `src/main.py`를 실행할 때 자동으로 만들어집니다.
> 아래 수치는 손으로 옮겨 적은 값이 아니라 그 실행에서 계산된 값을 그대로 넣은 것입니다.

## 0. 실행 환경과 재현 방법

같은 코드라도 라이브러리 버전이 다르면 소수점 아래 숫자가 달라질 수 있어 환경을 함께 남깁니다.

| 항목 | 버전 |
|---|---|
| Python | 3.11.15 |
| OS | Darwin 25.5.0 |
| pandas | 3.0.5 |
| polars | 1.43.2 |
| numpy | 2.4.6 |
| scikit-learn | 1.9.0 |
| scipy | 1.17.1 |
| matplotlib | 3.11.1 |
| seaborn | 0.13.2 |
| plotly | 6.9.0 |
| joblib | 1.5.3 |

재현 순서는 다음과 같습니다.

```bash
pip install -r requirements.txt
python src/main.py
```

`data/raw/adult.data`가 이미 있으면 그 파일을 쓰고, 없을 때만 원본 URL에서 내려받습니다.
난수를 쓰는 부분(학습·평가 분할, 교차검증, 부분표본 추출, 모델 초기화)은 모두
`random_state=42`로 고정해서 같은 환경이면 같은 수치가 나옵니다.
실행 과정은 `outputs/logs/run.log`에 시각과 함께 기록됩니다.

### 코드 구조

분석 단계별로 모듈을 나눠 담당자가 자기 파일만 보면 되도록 했습니다.

| 파일 | 역할 |
|---|---|
| `src/config.py` | 경로·컬럼·색상·상수 정의 |
| `src/logging_setup.py` | 로깅 설정, 실행 환경 기록, 오류 출력 |
| `src/data_loader.py` | 원본 확보, Pandas·Polars 로딩과 비교 |
| `src/preprocess.py` | 결측치·중복 처리, 기본 EDA, 기술통계 |
| `src/statistical_tests.py` | 상관분석, 카이제곱·Cramér's V, 가정 검정과 t-test |
| `src/visualization.py` | Seaborn 4종·Plotly 1종 차트 |
| `src/modeling.py` | Pipeline 학습·평가·저장, 심화 분석 |
| `src/report.py` | 이 보고서 생성 |
| `src/capture.py` | 보고서용 캡쳐본 이미지 생성 |
| `src/main.py` | 전체 흐름 조립 |

### 분석에 사용한 변수

| 변수 | 구분 | 설명 |
|---|---|---|
| `age` | 수치형 | 나이(세) |
| `education-num` | 수치형 | 교육 연수. `education`을 순서가 있는 숫자로 바꾼 값 |
| `capital-gain` | 수치형 | 자본 이득(달러). 대부분 0인 희소 변수 |
| `capital-loss` | 수치형 | 자본 손실(달러). 대부분 0인 희소 변수 |
| `hours-per-week` | 수치형 | 주당 근로시간 |
| `workclass` | 범주형 | 고용 형태(민간, 자영업, 공무원 등) |
| `education` | 범주형 | 최종 학력 |
| `marital-status` | 범주형 | 혼인 상태 |
| `occupation` | 범주형 | 직업군 |
| `relationship` | 범주형 | 가구 내 지위 |
| `race`, `sex` | 범주형 | 인종·성별. 민감 특성이라 13절에서 따로 짚습니다 |
| `native-country` | 범주형 | 출신 국가 |
| `income` | 목표 변수 | `<=50K` / `>50K` |

`fnlwgt`는 인구 추정 가중치라서 개인의 특성이 아니고, 그대로 넣으면 표본 설계 값을
학습하게 되므로 제외했습니다.

## 1. 데이터 로딩: Pandas vs Polars

| 항목 | Pandas | Polars |
|---|---|---|
| shape | (32561, 15) | (32561, 15) |
| 로딩 시간 (초) | 0.0207 | 0.0543 |
| 메모리 사용량 (MB) | 19.78 | 3.95 |
| 전체 결측치 수 | 4,262 | 4,262 |

- shape 일치 여부: **일치**
- 결측치 수 일치 여부: **일치**
- 숫자형 dtype 일치 여부: **일치**
- 이번 실행에서는 **Pandas**가 약 2.6배 빠르게 로딩했습니다. 다만 1회 측정값이라
  캐시·실행 환경에 따라 달라질 수 있어 두 라이브러리의 성능을 일반화하기는 어렵습니다.

### 두 라이브러리의 결과를 맞추기 위해 한 일

Polars에는 Pandas의 `skipinitialspace`·`na_values`에 해당하는 옵션이 없어서,
읽은 뒤 네 단계를 더 거쳐야 같은 결과가 나옵니다.

| 순서 | 처리 | 이유 |
|---|---|---|
| 1 | `str.strip_chars()` | 값이 `" State-gov"`처럼 앞 공백을 포함 |
| 2 | `"?"` → `null` | Adult 데이터는 결측을 `?` 문자열로 표기 |
| 3 | `cast(pl.Int64)` | 앞 공백 탓에 숫자 컬럼이 문자열로 추론됨 |
| 4 | 전부 null인 행 제거 | 파일 끝 빈 줄이 만든 행 |

### Polars 표현식으로 수행한 집계

읽기 전용으로만 쓰지 않고 실제 집계도 Polars 쪽에서 수행했습니다.
30세 초과 응답자를 `filter` → `group_by` → `agg`로 요약한 결과입니다.

| income   |   인원수 |   평균_주당근로시간 |   평균_교육연수 |   평균_나이 |
|:---------|---------:|--------------------:|----------------:|------------:|
| <=50K    |    14830 |               40.41 |            9.58 |       45.45 |
| >50K     |     7159 |               45.47 |           11.63 |       45.82 |

## 2. 결측치 / 중복 처리

| 컬럼 | 결측치 수 | 비율 |
|---|---|---|
| workclass | 1,836 | 5.64% |
| occupation | 1,843 | 5.66% |
| native-country | 583 | 1.79% |

- 전체 결측치 수: 4,262
- 중복 행 개수: 24
- 원본 행 수: 32,561 → 처리 후 행 수: **32,537**
- 처리 방침: 중복 행은 제거, 목표 변수 결측 행은 제거, 나머지 범주형 결측은 행을 버리지 않고
  ML Pipeline의 `SimpleImputer(strategy="most_frequent")`로 대치했습니다.
  EDA에서는 원본 분포를 보존하기 위해 결측을 제외한 상태로 집계했습니다.

## 3. 기본 EDA

| income | 건수 | 비율 |
|---|---|---|
| <=50K | 24,698 | 75.91% |
| >50K | 7,839 | 24.09% |

- 클래스 불균형 비율(다수/소수): **3.15 : 1**
- 다수 클래스가 약 76%이므로, 모두 `<=50K`로
  예측하기만 해도 Accuracy가 그 수준이 됩니다. 따라서 Accuracy 단독 평가는 적절하지 않고
  F1·Recall을 함께 봐야 합니다. 이 불균형은 10절에서 `class_weight`로, 11절에서 임계값 조정으로
  실제로 다룹니다.

## 4. 기술통계

```
                   count     mean      std   min   25%   50%   75%       max
age            32,537.00    38.59    13.64 17.00 28.00 37.00 48.00     90.00
education-num  32,537.00    10.08     2.57  1.00  9.00 10.00 12.00     16.00
capital-gain   32,537.00 1,078.44 7,387.96  0.00  0.00  0.00  0.00 99,999.00
capital-loss   32,537.00    87.37   403.10  0.00  0.00  0.00  0.00  4,356.00
hours-per-week 32,537.00    40.44    12.35  1.00 40.00 40.00 45.00     99.00
```

## 5. 상관분석 (수치형)

```
                   age  education-num  capital-gain  capital-loss  hours-per-week  income_binary
age             1.0000         0.0362        0.0777        0.0577          0.0685         0.2340
education-num   0.0362         1.0000        0.1227        0.0799          0.1484         0.3353
capital-gain    0.0777         0.1227        1.0000       -0.0316          0.0784         0.2233
capital-loss    0.0577         0.0799       -0.0316        1.0000          0.0542         0.1505
hours-per-week  0.0685         0.1484        0.0784        0.0542          1.0000         0.2297
income_binary   0.2340         0.3353        0.2233        0.1505          0.2297         1.0000
```

피어슨 상관계수는 수치형 변수의 선형 관계만 잡아냅니다.
이 데이터는 특성 13개 중 8개가 범주형이라, 수치형 상관계수만 보면 절반을 놓칩니다.
범주형은 다음 절에서 따로 검정했습니다.

## 6. 범주형 변수 연관성 (카이제곱 검정 · Cramér's V)

범주형 대 범주형에는 피어슨 상관계수를 쓸 수 없어 카이제곱 독립성 검정을 사용했습니다.
검정은 '관계가 있다/없다'만 답하므로, 강도는 Cramér's V로 따로 쟀습니다.

- **H0**: 해당 범주형 변수와 `income`은 서로 독립이다.
- **H1**: 두 변수는 독립이 아니다.
- 유의수준: 0.05

| 변수 | 범주 수 | 카이제곱 | 자유도 | p-value | Cramér's V | 연관 강도 |
|---|---|---|---|---|---|---|
| relationship | 6 | 6,692.1 | 5 | 1e-308 미만 (부동소수점 표현 한계로 0.0으로 반환됨) | 0.4535 | 강함 |
| marital-status | 7 | 6,510.3 | 6 | 1e-308 미만 (부동소수점 표현 한계로 0.0으로 반환됨) | 0.4473 | 강함 |
| education | 16 | 4,428.4 | 15 | 1e-308 미만 (부동소수점 표현 한계로 0.0으로 반환됨) | 0.3689 | 강함 |
| occupation | 14 | 3,742.8 | 13 | 1e-308 미만 (부동소수점 표현 한계로 0.0으로 반환됨) | 0.3492 | 중간 |
| sex | 2 | 1,516.5 | 1 | 1e-308 미만 (부동소수점 표현 한계로 0.0으로 반환됨) | 0.2159 | 중간 |
| workclass | 8 | 826.4 | 7 | 3.65366e-174 | 0.1641 | 약함 |
| race | 5 | 330.9 | 4 | 2.27979e-70 | 0.1009 | 약함 |
| native-country | 41 | 315.3 | 40 | 1.827e-44 | 0.0993 | 매우 약함 |

- 가장 강하게 연관된 변수는 **relationship** 입니다
  (Cramér's V = 0.4535, 강함).
- 표본이 3만 건대라 대부분의 변수에서 p-value가 매우 작게 나옵니다. 따라서 '유의한가'보다
  Cramér's V로 '얼마나 강한가'를 보는 것이 실질적입니다.
- 그림: `outputs/figures/04_categorical_association.png`

## 7. t-test: 소득 집단별 주당 근로시간

- **H0**: 두 소득 집단의 평균 주당 근로시간은 같다.
- **H1**: 두 소득 집단의 평균 주당 근로시간은 다르다.

| 집단 | 표본 수 | 평균 (시간/주) | 표준편차 |
|---|---|---|---|
| `<=50K` | 24,698 | 38.8429 | 12.3183 |
| `>50K` | 7,839 | 45.4734 | 11.0142 |

### 7-1. 가정 검정

t-test를 바로 적용하지 않고 전제조건부터 확인했습니다.

**정규성 (Shapiro-Wilk)**

| 집단 | 전체 n | 검정 표본 | W 통계량 | p-value | 왜도 | 첨도 |
|---|---|---|---|---|---|---|
| `<=50K` | 24,698 | 5,000 | 0.8780 | 1.29745e-52 | +0.215 | +2.973 |
| `>50K` | 7,839 | 5,000 | 0.8755 | 5.70007e-53 | +0.648 | +3.912 |

Shapiro-Wilk는 표본 5,000건을 넘으면 아주 작은 이탈에도 귀무가설을
기각하므로, 무작위 부분표본으로 검정하고 왜도·첨도를 함께 봤습니다.
두 집단 모두 엄밀한 의미의 정규분포는 아닙니다(근로시간이 40시간에 몰린 분포).

다만 **t-test가 가정하는 것은 원자료가 아니라 표본평균의 분포**입니다.
표본이 32,537건으로 충분히 크면 중심극한정리에 따라
표본평균은 정규에 가까워지므로, 평균 비교에 t-test를 적용할 수 있다고 판단했습니다.

**등분산성 (Levene's test)**

- H0: 두 집단의 분산은 같다.
- 통계량 W = 8.079916
- p-value = 0.00447864
- 판정: p-value가 0.05 미만이므로 **등분산이 기각됩니다**

정규성 가정에 덜 민감한 Levene을 썼습니다. 근로시간은 40시간에 몰린 비대칭 분포라
정규성을 강하게 요구하는 Bartlett 검정은 적절하지 않기 때문입니다.

### 7-2. 검정 결과

등분산 검정 결과에 따라 **Welch's t-test** (`equal_var=False`)를 적용했습니다.

- t-statistic: **45.095026**
- p-value: **1e-308 미만 (부동소수점 표현 한계로 0.0으로 반환됨)**
- 유의수준: 0.05
- 평균 차이: **6.6305 시간/주**, Cohen's d = **0.5518** (중간)
- 해석: p-value가 유의수준 0.05보다 작으므로 귀무가설(H0)을 기각합니다. 두 소득 집단의 평균 주당 근로시간에는 통계적으로 유의한 차이가 있습니다. 다만 표본이 32,537건으로 매우 크면 작은 차이도 유의하게 나오므로 차이의 크기까지 함께 보아야 합니다. 실제 차이는 6.63시간/주이고 Cohen's d는 0.552(중간)입니다. 또한 이는 '차이가 있다'는 의미일 뿐, 근로시간이 고소득의 원인이라는 뜻은 아닙니다.

> **p-value와 효과크기를 함께 보아야 하는 이유**
> 표본이 32,537건으로 크면 아주 작은 차이도 p-value가 작게 나옵니다.
> p-value는 '차이가 있는지'만 답하고 '얼마나 큰지'는 답하지 못합니다.
> Cohen's d는 합동 표준편차로 나눈 값이라 표본 크기에 따라 커지지 않으므로,
> 이번 결과(0.552, 중간)가 차이의 실제 크기를 나타냅니다.

## 8. Machine Learning Pipeline

구조: `ColumnTransformer(수치형: SimpleImputer → StandardScaler / 범주형: SimpleImputer → OneHotEncoder)`
→ `LogisticRegression(max_iter=1000)`

- 학습 데이터: 26,029행 / 평가 데이터: 6,508행 (test_size=0.2, stratify 적용)

### 8-1. 기본 모델과 불균형 대응 모델 비교

클래스가 불균형하므로 `class_weight='balanced'`를 적용한 모델을 같은 분할에서 함께 학습해
가중치의 효과만 분리해 봤습니다.

| 지표 | 기본 모델 | class_weight='balanced' | 변화 |
|---|---|---|---|
| Accuracy | 0.8563 | 0.8107 | -0.0456 |
| Precision | 0.7418 | 0.5712 | -0.1706 |
| Recall | 0.6193 | 0.8597 | +0.2404 |
| F1 Score | 0.6750 | 0.6864 | +0.0113 |
| ROC-AUC | 0.9097 | 0.9097 | -0.0000 |

두 모델 모두 `outputs/model/`에 저장했습니다. 어느 쪽을 쓸지는 용도가 정합니다.
고소득 후보를 놓치면 안 되면 balanced 쪽이, 잘못 지목하면 곤란하면 기본 쪽이 낫습니다.

### 8-2. 기본 모델 상세

### Confusion Matrix (행=실제, 열=예측)

| | 예측 `<=50K` | 예측 `>50K` |
|---|---|---|
| 실제 `<=50K` | 4,602 | 338 |
| 실제 `>50K` | 597 | 971 |

### Classification Report

```
              precision    recall  f1-score   support

       <=50K     0.8852    0.9316    0.9078      4940
        >50K     0.7418    0.6193    0.6750      1568

    accuracy                         0.8563      6508
   macro avg     0.8135    0.7754    0.7914      6508
weighted avg     0.8506    0.8563    0.8517      6508

```

### 5-겹 교차검증 (StratifiedKFold, shuffle)

| 지표 | 평균 | 표준편차 |
|---|---|---|
| accuracy | 0.8508 | ± 0.0019 |
| f1 | 0.6583 | ± 0.0052 |
| roc_auc | 0.9057 | ± 0.0019 |

표준편차가 작다는 것은 위 단일 분할 결과가 특정 분할에 우연히 유리했던 값이 아니라는 뜻입니다.

### 모델이 학습한 방향 (로지스틱 회귀 계수 상위)

학습 표본이 100건 이상인 특성만 추린 결과입니다.

| 고소득 확률을 높이는 특성 | 계수 | 학습 표본 수 |
|---|---|---|
| numeric__capital-gain | +2.2013 | 26,029 |
| categorical__marital-status_Married-civ-spouse | +1.3227 | 11,941 |
| categorical__relationship_Wife | +1.1098 | 1,247 |
| categorical__occupation_Exec-managerial | +0.7840 | 3,255 |
| numeric__education-num | +0.7332 | 26,029 |

| 고소득 확률을 낮추는 특성 | 계수 | 학습 표본 수 |
|---|---|---|
| categorical__occupation_Priv-house-serv | -1.2425 | 117 |
| categorical__relationship_Own-child | -1.1548 | 4,082 |
| categorical__marital-status_Never-married | -1.0704 | 8,600 |
| categorical__sex_Female | -0.9712 | 8,632 |
| categorical__occupation_Farming-fishing | -0.9061 | 783 |

계수는 다중공선성의 영향을 받으므로 개별 값을 인과적 효과 크기로 읽으면 안 되고,
모델이 어떤 방향으로 판단하는지를 보여주는 참고 자료로만 사용합니다.

### 해석에서 제외한 계수 (희소 범주 과적합)

| 특성 | 계수 | 학습 표본 수 |
|---|---|---|
| categorical__native-country_South | -1.6228 | 57 |
| categorical__native-country_Cambodia | +1.2548 | 15 |
| categorical__marital-status_Married-AF-spouse | +1.0095 | 17 |
| categorical__native-country_Columbia | -0.9573 | 45 |
| categorical__native-country_Dominican-Republic | -0.9469 | 51 |

표본이 수십 건뿐인 범주는 몇 사람의 우연한 소득 분포만으로도 계수가 크게 흔들립니다.
계수 절댓값이 크다는 이유로 "이 국적이 소득에 영향을 준다"고 읽으면 안 되며,
위 순위표에서 제외한 이유가 바로 이것입니다.

## 9. 심화 분석: 파생변수, 모델 비교, 임계값 조정

### 적용한 파생 변수

| 파생 변수 | 근거 |
|---|---|
| `age-band` (연령대 6구간) | 소득은 나이와 단조 증가가 아니라 46–55세에서 정점을 찍는 곡선 관계라, 선형 계수 하나로는 표현되지 않습니다. |
| `has-capital-gain`, `has-capital-loss` (0/1) | 자본 이득은 대부분이 0원인 희소 변수라, 금액보다 '발생 여부'가 안정적인 신호입니다. |
| 결측 → `Unknown` 범주 | 최빈값으로 덮으면 '응답하지 않았다'는 정보 자체가 사라집니다. |

### 모델 비교

| 모델 | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
| ① 기본 (로지스틱 회귀) | 0.8563 | 0.7418 | 0.6193 | 0.6750 | 0.9097 |
| ② + 파생변수 · Unknown 범주 | 0.8596 | 0.7477 | 0.6295 | 0.6835 | 0.9169 |
| ③ + class_weight=balanced | 0.8173 | 0.5810 | 0.8667 | 0.6957 | 0.9172 |
| ④ 트리 기반 (HistGradientBoosting) | 0.8772 | 0.7884 | 0.6703 | 0.7246 | 0.9317 |

- F1 기준 최고: **④ 트리 기반 (HistGradientBoosting)**
- Recall 기준 최고: **③ + class_weight=balanced**

### 임계값 조정 (기본 모델)

`predict()`가 쓰는 확률 0.5는 통계적 근거가 있는 값이 아니라 단순 기본값입니다.
클래스가 3.15:1로 불균형하면 0.5는 다수 클래스에 유리하게 작동합니다.

| 임계값 | Precision | Recall | F1 |
|---|---|---|---|
| 0.50 (기본값) | 0.7418 | 0.6193 | 0.6750 |
| 0.32 (F1 최대) | 0.6279 | 0.7889 | 0.6993 |
| 0.30 (Recall 0.80 달성) | 0.6133 | 0.80 이상 | — |

모델을 다시 학습하지 않고 임계값만 바꿔도 Recall이 달라집니다.
다만 Precision이 함께 내려가므로, **어느 쪽을 우선할지는 모델의 용도가 정합니다.**

## 10. 산출물

| 파일 | 설명 |
|---|---|
| `outputs/figures/01_income_distribution.png` | Seaborn. 소득 클래스 분포 |
| `outputs/figures/02_age_by_income.png` | Seaborn. 소득 집단별 나이 분포 |
| `outputs/figures/03_correlation_heatmap.png` | Seaborn. 수치형 상관계수 히트맵 |
| `outputs/figures/04_categorical_association.png` | Seaborn. 범주형 연관 강도(Cramér's V) |
| `outputs/figures/05_income_by_education.html` | Plotly. 교육 수준별 고소득 비율 (인터랙티브) |
| `outputs/figures/06_model_evaluation.png` | Confusion Matrix와 ROC 곡선 |
| `outputs/figures/07_threshold_tradeoff.png` | 임계값별 Precision·Recall·F1 변화 |
| `outputs/model/adult_income_pipeline.joblib` | 전처리+모델 Pipeline (기본) |
| `outputs/model/adult_income_pipeline_balanced.joblib` | 전처리+모델 Pipeline (불균형 대응) |
| `outputs/report.md` | 이 보고서 |
| `outputs/logs/run.log` | 실행 로그 |
| `보고서용_캡쳐본/` | 보고서에 바로 붙일 수 있는 캡쳐 이미지 |

## 11. 과제 요구사항 대응표

| 요구사항 | 구현 위치 | 결과 |
|---|---|---|
| Pandas 로딩 | `data_loader.load_with_pandas()` | shape (32561, 15), 0.0207초 |
| Polars 로딩 | `data_loader.load_with_polars()` | shape (32561, 15), 0.0543초 |
| 두 결과 비교 | `data_loader.compare_pandas_polars()` | shape·결측·dtype 일치 |
| Polars 실질 활용 | `data_loader.summarize_with_polars()` | filter → group_by → agg 집계 수행 |
| 결측치 확인·처리 | `preprocess.clean_data()` | 결측 4,262개, 범주형은 Imputer 대치 |
| 중복 확인·처리 | `preprocess.clean_data()` | 중복 24행 제거 |
| 기본 EDA | `preprocess.perform_eda()` | 소득 분포·범주형 빈도 출력 |
| Seaborn 차트 | `visualization.create_seaborn_plots()` 외 | 정적 차트 4종 (제목·축 레이블 포함) |
| Plotly 차트 | `visualization.create_plotly_chart()` | 인터랙티브 HTML 1종 |
| 평균·표준편차·분위수 | `preprocess.descriptive_statistics()` | `describe()` 출력 |
| 상관계수 | `statistical_tests.correlation_analysis()` | 상관 행렬 + 히트맵 |
| 범주형 연관성 | `statistical_tests.categorical_association()` | 카이제곱 + Cramér's V |
| t-test 가정 검정 | `check_normality()`, `check_equal_variance()` | Shapiro-Wilk + Levene |
| t-test | `statistical_tests.perform_t_test()` | Welch's t-test, t=45.0950 |
| p-value 해석 | 동일 | 유의수준 0.05 기준 + 효과크기 d=0.552 |
| sklearn Pipeline | `modeling.build_pipeline()` | ColumnTransformer + LogisticRegression |
| 클래스 불균형 처리 | 동일 | `class_weight='balanced'` + 임계값 조정 |
| Accuracy / F1 | `modeling.train_machine_learning_pipeline()` | 0.8563 / 0.6750 |
| Precision / Recall / ROC-AUC | 동일 | 0.7418 / 0.6193 / 0.9097 |
| joblib 저장 | 동일 | 모델 2종 저장, 재로딩 검증 완료 |
| report.md 자동 생성 | `report.generate_report()` | 이 문서 |

## 12. 분석 의견

- **관찰**: 고소득(`>50K`) 집단의 평균 주당 근로시간은 45.47시간으로
  저소득 집단의 38.84시간보다 6.63시간 길었습니다.
  범주형 중에서는 relationship가 소득과 가장 강하게 연관되어 있었습니다
  (Cramér's V 0.454).
- **해석**: 통계적으로 유의한 차이는 확인되지만 상관관계일 뿐이고, 근로시간이 소득을 높였다는
  인과의 근거는 아닙니다. 교육 수준·직업·연령이 동시에 작용했을 가능성이 큽니다.
  표본이 커서 p-value만으로는 차이의 크기를 알 수 없어 효과크기를 함께 계산했고,
  Cohen's d는 0.552(중간)였습니다.
- **한계 ①(불균형)**: 데이터가 약 3.2:1로 불균형해
  Accuracy(0.8563)가 높아 보이지만, 기본 모델의 Recall은 0.6193로
  실제 고소득자 1,568명 중 597명을 놓칩니다.
  `class_weight='balanced'`를 적용하면 Recall이 0.8597까지 올라갑니다.
- **한계 ②(계수 해석)**: 계수 절댓값 상위에는 표본이 수십 건뿐인 국적 범주가 올라옵니다.
  실제 패턴이 아니라 희소 범주에서 계수가 불안정해지는 현상이라 해석에서 제외했습니다.
- **검증**: 5-겹 교차검증에서도 F1이 0.6583 ± 0.0052로
  단일 분할 결과와 크게 다르지 않아, 위 성능이 특정 분할에 의존한 값은 아니라고 판단했습니다.

## 13. 한계와 남은 과제

| 한계 | 왜 문제인가 | 다음에 할 것 |
|---|---|---|
| 1994년 미국 인구조사 데이터 | 30년 전 노동시장이라 지금의 소득 구조와 다릅니다. 임계값 50K도 당시 기준입니다. | 최신 데이터로 같은 파이프라인을 돌려 계수 방향이 유지되는지 확인 |
| 관측 데이터로 얻은 상관관계 | 근로시간·학력이 소득을 '올린다'고 말할 수 없습니다. | 인과를 보려면 실험 설계나 준실험 방법(성향점수 매칭 등)이 필요 |
| 민감 특성 학습 | `sex_Female` 계수가 음의 방향으로 크게 나옵니다. 당시의 구조적 격차를 학습한 것입니다. | 민감 특성 제외 시 성능 변화 측정, 집단별 오류율 비교 |
| 희소 범주 | 표본이 수십 건인 국적 범주는 계수가 불안정합니다. | 빈도가 낮은 범주를 `Other`로 묶고 정규화 강화 |
| 단일 임계값 | F1을 기준으로 고른 값이라 실제 용도와 다를 수 있습니다. | 오분류 비용을 정한 뒤 비용 기준으로 임계값 재선정 |

## 14. 결론

인구통계와 근로 특성으로 고소득 여부를 예측하는 파이프라인을 처음부터 끝까지 구성했습니다.
데이터 로딩과 정제, 통계 검정, 모델 학습과 저장, 보고서 생성까지 한 번의 실행으로 이어집니다.

정리하면 세 가지입니다.

1. **평가 지표를 하나만 보면 안 됩니다.** 클래스가 3.15:1로 치우쳐
   Accuracy 0.8563는 실제보다 좋아 보입니다. 같은 모델의 Recall은 0.6193입니다.
2. **불균형은 여러 방법으로 다룰 수 있습니다.** `class_weight='balanced'`로 Recall이
   0.6193 → 0.8597로, 임계값을 0.32로 내리면
   0.7889로 올라갑니다. 어느 쪽이든 Precision을 내주는 거래입니다.
3. **이 모델은 예측용이지 설명용이 아닙니다.** 계수의 부호는 모델의 판단 방향을 보여줄 뿐,
   그 변수가 소득의 원인이라는 근거가 아닙니다.
