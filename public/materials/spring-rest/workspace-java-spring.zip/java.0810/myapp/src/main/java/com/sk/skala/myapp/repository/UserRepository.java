package com.sk.skala.myapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.sk.skala.myapp.domain.User;
import java.util.List;

public interface UserRepository extends JpaRepository<User, Long> {
    List<User> findByName(String name);
    List<User> findByEmail(String email);
}
