package com.sk.skala.myapp.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import com.sk.skala.myapp.domain.User;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import com.sk.skala.myapp.aspect.Metrics;
import com.sk.skala.myapp.dto.UserRequest;
import com.sk.skala.myapp.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("api")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // 모든 사용자 조회 (name으로 필터링 가능)
    
    @GetMapping("/users")
    public List<User> getAllUsers(@RequestParam(required = false) String name) {
        log.info("name: {}", name);
        log.debug("getAllUsers called with name filter: {}", name == null ? "none" : name);
        return userService.getAllUsers(name);
    }

    // GET : 특정 사용자 가져오기
//    @Metrics
    @GetMapping("/users/{id}")
    public User getUserById(@PathVariable long id) {
        
        return userService.getUserById(id).orElse(null);
    }

    // GET : @RequestParam 으로 특정 사용자 가져오기
    @GetMapping("/users/search")
    public User getUserByEmail(@RequestParam long id) {
        return userService.getUserById(id).orElse(null);
    }

    // POST : 사용자 생성
    @PostMapping("/users")
    public User createUser(@RequestBody UserRequest request) {
        return userService.createUser(request);
    }

    // DELETE : 사용자 삭제
    @DeleteMapping("/users/{id}")
    public void deleteUser(@PathVariable long id) {
        userService.deleteUser(id);
    }

    // PUT : 사용자 정보 수정
    @PutMapping("/users/{id}")
    public User updateUser(@PathVariable long id, @RequestBody UserRequest request) {
        return userService.updateUser(id, request).orElse(null);
    }
}
